// Обновление панели для Illustrator — как src/Update.bas, тот же склад и тот же подписанный список. В списке у
// Illustrator своя строка «aifile=illustrator.zip|отпечаток» (CorelDRAW её пропускает, но она подписана вместе
// со всем списком). Скачанный архив сверяется с отпечатком, распаковывается во временную папку, а подменяет
// папку панели отдельная программа — после закрытия Illustrator: пока он открыт, панель и её части в работе.
// Номер версии — общий с CorelDRAW (src/Update.bas), сборка вписывает его в панель.
var AiUpd = (function () {
  var fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process'), https = require('https'), crypto = require('crypto');
  var DEFAULT_URL = 'https://raw.githubusercontent.com/mexxuz/PS-Avtomatizaciya-updates/main/';
  var busy = false;

  // реестр читается внешней программой — не чаще раза в 10 с (панель спрашивает состояние часто)
  var cache = {};
  function reg(k, dv) {
    var c = cache[k], now = Date.now();
    if (!c || now - c.t > 10000) c = cache[k] = { v: AiLic.regGet('Update', k), t: now };
    return c.v === '' ? (dv || '') : c.v;
  }
  function regSet(k, v) { AiLic.regSet('Update', k, v); cache[k] = { v: String(v), t: Date.now() }; }
  // свой адрес склада только для Illustrator (AiUrl — для проверок), иначе общий с CorelDRAW
  function baseUrl() { var u = reg('AiUrl') || reg('Url', DEFAULT_URL); return /\/$/.test(u) ? u : u + '/'; }
  function extDir() { return window.__adobe_cep__.getSystemPath('extension').replace(/^file:\/*/, '').replace(/%20/g, ' ').replace(/\//g, '\\'); }
  function version() {
    try { var m = /ExtensionBundleVersion="([^"]+)"/.exec(fs.readFileSync(path.join(extDir(), 'CSXS', 'manifest.xml'), 'utf8')); return m ? m[1] : '0'; } catch (e) { return '0'; }
  }
  function cmp(a, b) {
    var x = String(a).split('.'), y = String(b).split('.');
    for (var i = 0; i < 4; i++) { var va = +x[i] || 0, vb = +y[i] || 0; if (va != vb) return va > vb ? 1 : -1; }
    return 0;
  }
  function today() { var d = new Date(), p = function (n) { return ('0' + n).slice(-2); }; return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); }
  function hourStamp() { var d = new Date(); return today() + ' ' + ('0' + d.getHours()).slice(-2); }
  function workDir() { return path.join(os.tmpdir(), 'PS-Avtomatizaciya-ai-update'); }
  function logLine(t) { try { fs.appendFileSync(path.join(process.env.APPDATA || '', 'PS Automation', 'illustrator.log'), (function () { var d = new Date(), z = function (n) { return (n < 10 ? '0' : '') + n; }; return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + ' ' + z(d.getHours()) + ':' + z(d.getMinutes()) + ':' + z(d.getSeconds()); })() + '  обновление: ' + t + '\r\n', 'utf8'); } catch (e) { } }

  // ---------- сеть ----------
  function get(url, binary) {
    return new Promise(function (ok) {
      var go = function (u, left) {
        try {
          (/^http:/.test(u) ? require('http') : https).get(u + (u.indexOf('?') < 0 ? '?t=' + Date.now() : ''), { headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'PS-Avtomatizaciya' }, timeout: 120000 }, function (rs) {
            if ((rs.statusCode == 301 || rs.statusCode == 302) && rs.headers.location && left > 0) { rs.resume(); go(rs.headers.location, left - 1); return; }
            if (rs.statusCode != 200) { rs.resume(); ok(null); return; }
            var parts = []; rs.on('data', function (c) { parts.push(c); });
            rs.on('end', function () { var b = Buffer.concat(parts); ok(binary ? b : b.toString('utf8')); });
          }).on('error', function () { ok(null); }).on('timeout', function () { ok(null); });
        } catch (e) { ok(null); }
      };
      go(url, 3);
    });
  }

  // Список склада: «ключ=значение», в конце «sig=подпись» всего, что выше. Ответ — { ver, note, file, hash } или null
  function parse(text) {
    var lines = String(text).replace(/\r/g, '').split('\n'), body = '', o = { ver: '', note: '', file: '', hash: '' }, sig = '';
    for (var i = 0; i < lines.length; i++) {
      var p = lines[i].indexOf('=');
      if (p <= 0) continue;
      var k = lines[i].substring(0, p).trim(), v = lines[i].substring(p + 1).trim();
      if (k == 'sig') { sig = v; continue; }
      body += lines[i] + '\n';
      if (k == 'version') o.ver = v;
      else if (k == 'note') o.note = v.replace(/\\n/g, ' ');
      else if (k == 'aifile') { var a = v.split('|'); o.file = a[0]; o.hash = String(a[1] || '').toLowerCase(); }
    }
    if (!o.ver || !sig || !AiLic.verifyText(body, sig)) return null;
    return o;
  }
  // что на складе: { st: 'ok'|'no'|'err', ... }
  async function check() {
    var t = await get(baseUrl() + 'update.txt');
    if (!t) return { st: 'err', why: 'склад обновлений недоступен' };
    var o = parse(t);
    if (!o) return { st: 'err', why: 'список обновления не подписан или повреждён' };
    if (!o.file) return { st: 'no', o: o };     // в этой версии склада Illustrator ещё нет
    if (cmp(o.ver, version()) <= 0) return { st: 'no', o: o };
    o.st = 'ok';
    return { st: 'ok', o: o };
  }

  // ---------- подмена ----------
  function psQ(s) { return "'" + String(s).replace(/'/g, "''") + "'"; }
  function swapWaiting() {
    try {
      var out = String(cp.execFileSync('powershell.exe', ['-NoProfile', '-Command', "@(Get-CimInstance Win32_Process -Filter \"Name='powershell.exe'\" | Where-Object { $_.CommandLine -like '*PS-Avtomatizaciya-ai-update*swap.ps1*' }).Count"], { windowsHide: true, encoding: 'utf8' }));
      return (+out.trim() || 0) > 0;
    } catch (e) { return true; }   // не узнать — как у CorelDRAW: второй раз не качаем
  }
  function swapScript(src, dst) {
    return '# PS • Автоматизация — подмена панели Illustrator после его закрытия.\r\n' +
      '$src = ' + psQ(src) + '\r\n$dst = ' + psQ(dst) + '\r\n$dir = ' + psQ(workDir()) + '\r\n' +
      '$log = Join-Path $dir \'обновление.log\'; $again = Join-Path $dir \'restart.txt\'\r\n' +
      'function L($m) { Add-Content -LiteralPath $log -Value ((Get-Date -Format \'HH:mm:ss\') + \' \' + $m) -Encoding UTF8 }\r\n' +
      '$mx = New-Object Threading.Mutex($false, \'PS-Avtomatizaciya-ai-swap\'); try { if (-not $mx.WaitOne(0)) { exit } } catch [Threading.AbandonedMutexException] { }\r\n' +
      '$exe = (Get-Process Illustrator -ErrorAction SilentlyContinue | Select-Object -First 1).Path\r\n' +
      'L (\'жду закрытия Illustrator, программа подмены \' + $PID)\r\n' +
      '$asked = $null\r\n' +
      'for ($i = 0; $i -lt 200000; $i++) {\r\n' +
      '  $p = @(Get-Process Illustrator -ErrorAction SilentlyContinue)\r\n' +
      '  if ($p.Count -eq 0) { break }\r\n' +
      '  $w = @($p | Where-Object { $_.MainWindowHandle -ne 0 })\r\n' +
      '  if (-not $asked -and (Test-Path -LiteralPath $again) -and $w.Count) { $asked = Get-Date; L \'закрываю Illustrator по кнопке «Перезапустить и обновить»\'; foreach ($x in $w) { [void]$x.CloseMainWindow() } }\r\n' +
      '  if ($asked -and ((Get-Date) - $asked).TotalSeconds -gt 60 -and $w.Count) { L \'Illustrator не закрылся за минуту — жду, пока его закроют\'; Remove-Item -LiteralPath $again -ErrorAction SilentlyContinue; $asked = $null }\r\n' +
      '  Start-Sleep -Seconds 1\r\n' +
      '}\r\n' +
      'if (Get-Process Illustrator -ErrorAction SilentlyContinue) { L \'Illustrator так и не закрыли — обновление отложено\'; exit }\r\n' +
      'L \'Illustrator закрыт, подменяю панель\'\r\n' +
      'Start-Sleep -Milliseconds 700\r\n' +
      // прежняя панель — во временную папку: в папке панелей Adobe вторая с тем же именем помешала бы
      '$old = Join-Path $dir \'before-update\'\r\n' +
      'try {\r\n' +
      '  if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Recurse -Force }\r\n' +
      '  Copy-Item -LiteralPath $dst $old -Recurse -Force\r\n' +
      '  $null = robocopy $src $dst /MIR /R:10 /W:1 /NFL /NDL /NJH /NJS\r\n' +
      '  if ($LASTEXITCODE -ge 8) { throw (\'robocopy вернул \' + $LASTEXITCODE) }\r\n' +
      '  L \'панель заменена\'\r\n' +
      '} catch { L (\'не заменилась: \' + $_.Exception.Message + \' — возвращаю прежнюю\'); $null = robocopy $old $dst /MIR /R:3 /W:1 /NFL /NDL /NJH /NJS }\r\n' +
      'L \'готово\'\r\n' +
      'if ((Test-Path -LiteralPath $again) -and $exe -and -not (Get-Process Illustrator -ErrorAction SilentlyContinue)) { Remove-Item -LiteralPath $again -ErrorAction SilentlyContinue; L \'открываю Illustrator\'; Start-Process $exe }\r\n';
  }
  // программа подмены должна пережить Illustrator — запускается через службу WMI, отдельно от его процессов
  function spawnSwap(ps) {
    var cmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + ps + '"';
    cp.execFileSync('powershell.exe', ['-NoProfile', '-Command', "$r = ([wmiclass]'Win32_Process').Create(" + psQ(cmd) + "); exit $r.ReturnValue"], { windowsHide: true });
  }

  async function installNow(silent) {
    var c = await check();
    if (c.st == 'err') return 'Обновление не получилось: ' + c.why + '.';
    if (c.st == 'no') return 'У вас последняя версия ' + version() + '.';
    var o = c.o;
    if (reg('AiPending') == o.ver && swapWaiting()) return 'Обновление ' + o.ver + ' уже скачано — встанет, когда закроете Illustrator.';
    var dir = workDir(), zip = path.join(dir, o.file), ext = path.join(dir, 'panel');
    try { (fs.rmSync || fs.rmdirSync).call(fs, dir, { recursive: true, force: true }); } catch (e) { }   // rmSync нет в Illustrator 2021 (старый Node)
    fs.mkdirSync(dir, { recursive: true });
    var data = await get(baseUrl() + o.file, true);
    if (!data) return 'Обновление не получилось: не скачался файл ' + o.file + '.';
    if (crypto.createHash('sha256').update(data).digest('hex') != o.hash) return 'Обновление не получилось: файл ' + o.file + ' скачался неправильно.';
    fs.writeFileSync(zip, data);
    try { cp.execFileSync('powershell.exe', ['-NoProfile', '-Command', 'Expand-Archive -LiteralPath ' + psQ(zip) + ' -DestinationPath ' + psQ(ext) + ' -Force'], { windowsHide: true, timeout: 120000 }); } catch (e) { }
    var man = path.join(ext, 'CSXS', 'manifest.xml');
    if (!fs.existsSync(man) || fs.readFileSync(man, 'utf8').indexOf('ExtensionBundleVersion="' + o.ver + '"') < 0) return 'Обновление не получилось: архив панели распаковался не так.';
    var ps = path.join(dir, 'swap.ps1');
    fs.writeFileSync(ps, '﻿' + swapScript(ext, extDir()), 'utf8');
    spawnSwap(ps);
    regSet('AiPending', o.ver); regSet('AiNote', String(o.note).substring(0, 900));
    logLine('скачано ' + o.ver + (silent ? ' (само)' : ''));
    return 'Обновление ' + o.ver + ' скачано и проверено. Оно встанет само, когда вы закроете Illustrator, — работу прерывать не нужно.';
  }
  async function install(silent) {
    if (busy) return 'Обновление уже скачивается — подождите.';
    busy = true;
    try { return await installNow(silent); }
    catch (e) { return 'Обновление не получилось: ' + e.message + '.'; }
    finally { busy = false; }
  }

  // ---------- для панели ----------
  // «ok|версия|что нового», «pend|версия», «no|наша версия», «err|причина»
  async function info() {
    var c = await check();
    if (c.st == 'err') return 'err|' + c.why;
    regSet('AiLastCheck', today());
    if (c.st == 'no') return 'no|' + version();
    if (reg('AiPending') == c.o.ver && swapWaiting()) return 'pend|' + c.o.ver;
    return 'ok|' + c.o.ver + '|' + String(c.o.note).replace(/\|/g, '/');
  }
  // «Перезапустить и обновить»: всё ли сохранено (unsaved — имена несохранённых документов от Illustrator)
  function restart(unsaved) {
    if (!swapWaiting()) return 'no|Обновление ещё не скачано — нажмите «Проверить обновления».';
    if (unsaved) return 'no|Сначала сохраните: ' + unsaved + '.';
    try { fs.writeFileSync(path.join(workDir(), 'restart.txt'), '1'); } catch (e) { return 'no|Не получилось: ' + e.message; }
    return 'ok|';
  }
  function auto(v) { if (v === '0' || v === '1') regSet('Auto', v); return reg('Auto', '1'); }
  // для состояния панели: версия, только что вставшее обновление, скачанное и ждущее, последняя проверка
  function state() {
    var ver = version(), p = reg('AiPending'), s = { ver: ver, upd: '', updPend: '', updLast: reg('AiLastCheck') };
    if (p) {
      if (cmp(ver, p) >= 0) { s.upd = p + '|' + reg('AiNote'); regSet('AiPending', ''); }
      else s.updPend = p;
    }
    return s;
  }
  // тихая проверка раз в сутки (склад не ответил — снова через час); занят Illustrator (busyFn) — потом
  async function autoCheck(busyFn) {
    if (busy || reg('Auto', '1') != '1') return;
    if (reg('AiLastTry') == hourStamp()) return;
    var p = reg('AiPending'), stuck = p && cmp(p, version()) > 0 && !swapWaiting();
    if (reg('AiLastCheck') == today() && !stuck) return;
    if (busyFn && busyFn()) return;
    regSet('AiLastTry', hourStamp());
    var c = await check();
    if (c.st == 'err') return;
    regSet('AiLastCheck', today());
    if (c.st == 'ok') logLine(await install(true));
  }

  // Отметка для разработчика (/stats в @imexxbot): при первом запуске панели «install», дальше раз в сутки «day» —
  // код компьютера, версия, остаток пробного срока и есть ли ключ, больше ничего. Как Update.Ping в CorelDRAW,
  // реестр общий, поэтому флаги свои (Ai…). Не ушло — флаг не ставим, снова через час. Ответ — код сервера или 0.
  function ping(force) {
    var inst = AiLic.regGet('Stats', 'AiInstall') == '1', h = hourStamp();
    if (!force && ((inst && AiLic.regGet('Stats', 'AiDay') == today()) || AiLic.regGet('Stats', 'AiTry') == h)) return Promise.resolve(0);
    AiLic.regSet('Stats', 'AiTry', h);
    var lic = AiLic.json();
    var body = JSON.stringify({ code: lic.code, ver: version(), app: 'ai', ev: inst ? 'day' : 'install', trial: lic.trial, key: lic.key ? 1 : 0 });
    return new Promise(function (ok) {
      try {
        var rq = https.request({ host: 'davinchi.uz', path: '/imexx-install.php', method: 'POST', timeout: 10000,
          headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), 'User-Agent': 'PS-Avtomatizaciya' } }, function (rs) {
          rs.resume();
          if (rs.statusCode == 204) { AiLic.regSet('Stats', 'AiInstall', '1'); AiLic.regSet('Stats', 'AiDay', today()); }
          ok(rs.statusCode);
        });
        rq.on('error', function () { ok(0); }).on('timeout', function () { rq.destroy(); ok(0); });
        rq.end(body);
      } catch (e) { ok(0); }
    });
  }

  return { info: info, install: install, restart: restart, auto: auto, state: state, autoCheck: autoCheck, version: version, ping: ping };
})();
