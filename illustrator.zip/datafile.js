// Файлы клиента для Illustrator: .xlsx — читаем сами (без Excel), .csv/.txt — с определением кодировки
// (UTF-8, UTF-16 или Windows-1251), .xls/.xlsm/.ods — через невидимый Excel, если он есть.
// Таблица кладётся в %APPDATA%\PS Automation\cache\ — оттуда её берёт Illustrator (сам он ни zip,
// ни кодировки не умеет). Перечитывается, только когда файл изменился.
var AiData = (function () {
  var fs = require('fs'), path = require('path'), zlib = require('zlib'), crypto = require('crypto'), cp = require('child_process');
  var CACHE = path.join(process.env.APPDATA || '', 'PS Automation', 'cache');

  // ---------- zip ----------
  function unzip(buf) {
    var eocd = -1;
    for (var i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i--) if (buf.readUInt32LE(i) == 0x06054b50) { eocd = i; break; }
    if (eocd < 0) throw new Error('это не файл Excel (.xlsx)');
    var n = buf.readUInt16LE(eocd + 10), off = buf.readUInt32LE(eocd + 16), files = {};
    for (var k = 0; k < n; k++) {
      var method = buf.readUInt16LE(off + 10), csize = buf.readUInt32LE(off + 20), nl = buf.readUInt16LE(off + 28),
          xl = buf.readUInt16LE(off + 30), cl = buf.readUInt16LE(off + 32), lho = buf.readUInt32LE(off + 42);
      var name = buf.toString('utf8', off + 46, off + 46 + nl);
      files[name] = { method: method, csize: csize, lho: lho };
      off += 46 + nl + xl + cl;
    }
    return function (name) {
      var f = files[name];
      if (!f) return null;
      var s = f.lho + 30 + buf.readUInt16LE(f.lho + 26) + buf.readUInt16LE(f.lho + 28), data = buf.subarray(s, s + f.csize);
      return (f.method == 8 ? zlib.inflateRawSync(data) : data).toString('utf8');
    };
  }

  function xmlText(s) {
    return s.replace(/<[^>]+>/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
            .replace(/&#(\d+);/g, function (m, c) { return String.fromCharCode(+c); })
            .replace(/&#x([0-9a-f]+);/gi, function (m, c) { return String.fromCharCode(parseInt(c, 16)); }).replace(/&amp;/g, '&');
  }
  function attr(tag, name) { var m = new RegExp('\\s' + name + '="([^"]*)"').exec(tag); return m ? m[1] : null; }
  function colIndex(ref) { var c = 0, m = /^[A-Z]+/.exec(ref)[0]; for (var i = 0; i < m.length; i++) c = c * 26 + m.charCodeAt(i) - 64; return c - 1; }

  // Первый лист книги .xlsx -> массив строк (массивов текстов)
  function readXlsx(file) {
    var get = unzip(fs.readFileSync(file));
    var wb = get('xl/workbook.xml'), rels = get('xl/_rels/workbook.xml.rels') || '';
    var first = /<sheet\b[^>]*>/.exec(wb), rid = first ? (attr(first[0], 'r:id') || attr(first[0], 'id')) : null, target = 'worksheets/sheet1.xml';
    if (rid) { var rm = new RegExp('<Relationship\\b[^>]*Id="' + rid + '"[^>]*>').exec(rels); if (rm) target = attr(rm[0], 'Target'); }
    target = target.replace(/^\/?xl\//, '').replace(/^\//, '');
    var sheet = get('xl/' + target);
    if (!sheet) throw new Error('в книге не нашёлся первый лист');
    // общие строки
    var ss = [], sst = get('xl/sharedStrings.xml') || '';
    sst.replace(/<si>([\s\S]*?)<\/si>/g, function (m, b) {
      var t = ''; b.replace(/<t\b[^>]*>([\s\S]*?)<\/t>/g, function (m2, x) { t += x; return m2; }); ss.push(xmlText(t)); return m;
    });
    // форматы: ячейка «000000» — номер с ведущими нулями
    var styles = get('xl/styles.xml') || '', fmts = {}, xfs = [];
    styles.replace(/<numFmt\b[^>]*>/g, function (m) { fmts[attr(m, 'numFmtId')] = xmlText(attr(m, 'formatCode') || ''); return m; });
    var cx = /<cellXfs\b[^>]*>([\s\S]*?)<\/cellXfs>/.exec(styles);
    if (cx) cx[1].replace(/<xf\b[^>]*>/g, function (m) { xfs.push(attr(m, 'numFmtId')); return m; });
    var rows = [];
    sheet.replace(/<row\b([^>]*)>([\s\S]*?)<\/row>/g, function (m, ra, body) {
      var r = (+attr(' ' + ra, 'r') || rows.length + 1) - 1, row = [];
      body.replace(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g, function (m2, ca, cb) {
        var ref = attr(' ' + ca, 'r'), t = attr(' ' + ca, 't'), s = attr(' ' + ca, 's'), v = '', vm = cb ? /<v>([\s\S]*?)<\/v>/.exec(cb) : null;
        if (t == 's') v = vm ? ss[+vm[1]] || '' : '';
        else if (t == 'inlineStr') { var im = cb ? /<is>([\s\S]*?)<\/is>/.exec(cb) : null; v = im ? xmlText(im[1]) : ''; }
        else if (t == 'b') v = vm ? (vm[1] == '1' ? 'ИСТИНА' : 'ЛОЖЬ') : '';
        else if (t == 'str' || t == 'e') v = vm ? xmlText(vm[1]) : '';
        else if (vm) v = numText(+vm[1], fmts[xfs[+s || 0]] || '');
        row[ref ? colIndex(ref) : row.length] = v;
        return m2;
      });
      for (var i = 0; i < row.length; i++) if (row[i] == null) row[i] = '';
      rows[r] = row;
      return m;
    });
    for (var i = 0; i < rows.length; i++) if (!rows[i]) rows[i] = [];
    return rows;
  }
  // Числа: целые — без «E+», с ведущими нулями, если так отформатирована ячейка
  function numText(v, fmt) {
    if (v == Math.floor(v) && Math.abs(v) < 1e15) {
      var s = String(Math.abs(v));
      if (/^0+$/.test(fmt) && s.length < fmt.length) s = new Array(fmt.length - s.length + 1).join('0') + s;
      return (v < 0 ? '-' : '') + s;
    }
    return String(Math.round(v * 1e10) / 1e10);
  }

  // ---------- текстовые файлы ----------
  function looksUtf8(b) {
    for (var i = 0; i < b.length;) {
      var c = b[i], k = c < 0x80 ? 0 : (c & 0xE0) == 0xC0 ? 1 : (c & 0xF0) == 0xE0 ? 2 : (c & 0xF8) == 0xF0 ? 3 : -1;
      if (k < 0) return false;
      for (var j = 1; j <= k; j++) if (i + j >= b.length || (b[i + j] & 0xC0) != 0x80) return false;
      i += k + 1;
    }
    return true;
  }
  var CP1251 = 'ЂЃ‚ѓ„…†‡€‰Љ‹ЊЌЋЏђ‘’“”•–—\ufffd™љ›њќћџ\u00a0ЎўЈ¤Ґ¦§Ё©Є«¬\u00ad®Ї°±Ііґµ¶·ё№є»јЅѕї';
  function decode1251(b) {
    var s = '';
    for (var i = 0; i < b.length; i++) {
      var c = b[i];
      s += c < 0x80 ? String.fromCharCode(c) : c < 0xC0 ? CP1251.charAt(c - 0x80) : String.fromCharCode(c - 0xC0 + 0x410);
    }
    return s;
  }
  function readText(file) {
    var b = fs.readFileSync(file), s;
    if (b.length >= 2 && b[0] == 0xFF && b[1] == 0xFE) s = b.toString('utf16le', 2);
    else s = looksUtf8(b) ? b.toString('utf8') : decode1251(b);
    return s.charCodeAt(0) == 0xFEFF ? s.substring(1) : s;
  }
  // CSV/TXT: разделитель — табуляция, «;» или «,» (по первой строке), кавычки поддерживаются
  function parseDelimited(txt) {
    txt = txt.replace(/\r\r\n/g, '\n').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    if (!txt) return [];
    var line = txt.split('\n')[0], d = line.indexOf('\t') >= 0 ? '\t' : line.indexOf(';') >= 0 ? ';' : line.indexOf(',') >= 0 ? ',' : '';
    var rows = [], cells = [], cur = '', inQ = false;
    for (var i = 0; i < txt.length; i++) {
      var ch = txt.charAt(i);
      if (inQ) { if (ch == '"') { if (txt.charAt(i + 1) == '"') { cur += '"'; i++; } else inQ = false; } else cur += ch; }
      else if (ch == '"' && cur == '') inQ = true;
      else if (d && ch == d) { cells.push(cur); cur = ''; }
      else if (ch == '\n') { cells.push(cur); cur = ''; if (!(cells.length == 1 && cells[0] == '')) rows.push(cells); cells = []; }
      else cur += ch;
    }
    if (cur != '' || cells.length) { cells.push(cur); rows.push(cells); }
    return rows;
  }

  // .xls и прочее — через Excel в CSV (UTF-16 с табуляцией), во временный файл
  function viaExcel(file) {
    var out = path.join(require('os').tmpdir(), 'psa_xls_' + Date.now() + '.txt');
    var ps = "$ErrorActionPreference='Stop'; $x=New-Object -ComObject Excel.Application; $x.Visible=$false; $x.DisplayAlerts=$false; " +
             "try { $w=$x.Workbooks.Open($env:PSA_IN, 0, $true); $w.Worksheets.Item(1).Activate(); $w.SaveAs($env:PSA_OUT, 42); $w.Close($false) } finally { $x.Quit() }";
    try {
      cp.execFileSync((process.env.SystemRoot || 'C:\\Windows') + '\\System32\\WindowsPowerShell\\v1.0\\powershell.exe',
        ['-NoProfile', '-NonInteractive', '-Command', ps], { env: Object.assign({}, process.env, { PSA_IN: file, PSA_OUT: out }), windowsHide: true, timeout: 120000 });
    } catch (e) { throw new Error('файл .xls читается только через Excel, а он не открылся. Сохраните таблицу как .xlsx или .csv'); }
    var t = readText(out);
    try { fs.unlinkSync(out); } catch (e) { }
    return parseDelimited(t);
  }

  function readTable(file) {
    var ext = path.extname(file).toLowerCase();
    if (ext == '.xlsx' || ext == '.xlsm') { try { return readXlsx(file); } catch (e) { if (ext == '.xlsm') return viaExcel(file); throw e; } }
    if (ext == '.xls' || ext == '.ods') return viaExcel(file);
    return parseDelimited(readText(file));
  }

  // имя таблицы в кэше — так же считает Illustrator (dataio.jsx, dataCacheName)
  function cacheName(file) {
    var s = String(file).replace(/\//g, '\\').toLowerCase(), h = 5381;
    for (var i = 0; i < s.length; i++) h = (h * 33 + s.charCodeAt(i)) % 4294967296;
    return path.join(CACHE, ('0000000' + h.toString(16)).slice(-8) + '-' + s.length + '.json');
  }

  // Обновить таблицы файлов (список путей). Ответ: { путь: '' | текст ошибки }
  function sync(files) {
    var res = {};
    fs.mkdirSync(CACHE, { recursive: true });
    for (var i = 0; i < files.length; i++) {
      var f = files[i], c = cacheName(f);
      try {
        if (!fs.existsSync(f)) { res[f] = 'файл не найден: ' + f; continue; }
        var st = fs.statSync(f), stamp = st.mtimeMs + '|' + st.size;
        if (fs.existsSync(c)) { try { if (JSON.parse(fs.readFileSync(c, 'utf8')).stamp == stamp) { res[f] = ''; continue; } } catch (e) { } }
        var rows = readTable(f);
        fs.writeFileSync(c, JSON.stringify({ path: f, stamp: stamp, rows: rows }), 'utf8');
        res[f] = '';
      } catch (e) {
        res[f] = 'не удалось прочитать ' + f + ': ' + e.message;
        try { fs.writeFileSync(c, JSON.stringify({ path: f, stamp: '', error: res[f] }), 'utf8'); } catch (x) { }
      }
    }
    return res;
  }

  return { sync: sync, readTable: readTable, cacheName: cacheName };
})();
if (typeof module !== 'undefined' && typeof window === 'undefined') module.exports = AiData;
