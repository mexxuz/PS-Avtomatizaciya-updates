// Лазер CO2 и фрезер — как src/Laser.bas: раскладка деталей стык в стык (или с зазором на фрезу), общий рез,
// склейка контуров и порядок реза. Геометрию считает bin/VarPrint_nest.exe (--pack и --laser), здесь — сбор
// контуров из документа и результат обратно:
//   слой «Лазер: рез»            — линии реза в порядке реза (нижняя — первая);
//   слой «Лазер: холостые ходы»  — непечатаемый: куда голова едет без реза и номера по порядку;
//   слой «Лазер: исходные»       — скрытый: сами детали, чтобы вернуть как было.
// Координаты для расчёта — мм от левого нижнего угла активной монтажной области, y вверх.

// Свободное место под новую монтажную область w × h мм, только внутри холста (пробовать за краем нельзя —
// портит документ). Места-кандидаты — справа и слева от каждой области, под и над ней, у краёв холста;
// берётся свободное, ближайшее к правому верхнему углу занятого (сначала справа, потом ниже). Ответ — rect (пт) или null
function freeBoard(d, w, h, gapMm) {
    var abs = [], i, j, G = pt(gapMm || 30), M = pt(100);
    for (i = 0; i < d.artboards.length; i++) abs.push(d.artboards[i].artboardRect);
    var b = abs[0].slice(0);
    for (i = 1; i < abs.length; i++) { b[0] = Math.min(b[0], abs[i][0]); b[1] = Math.max(b[1], abs[i][1]); b[2] = Math.max(b[2], abs[i][2]); b[3] = Math.min(b[3], abs[i][3]); }
    var c = canvasCenter(d), half = 8191 - M, W = pt(w), H = pt(h), L = c[0] - half, T = c[1] + half;
    var fits = function (q) { return q[0] >= c[0] - half && q[2] <= c[0] + half && q[3] >= c[1] - half && q[1] <= c[1] + half; };
    var free = function (q) {
        for (var k = 0; k < abs.length; k++) { var r = abs[k]; if (q[0] < r[2] + G && q[2] > r[0] - G && q[3] < r[1] + G && q[1] > r[3] - G) return false; }
        return true;
    };
    var xs = [L], ys = [T];
    for (i = 0; i < abs.length; i++) { xs.push(abs[i][2] + G, abs[i][0] - G - W, abs[i][0]); ys.push(abs[i][1], abs[i][3] - G, abs[i][1] + G + H); }
    var best = null, bd = 0;
    for (i = 0; i < xs.length; i++) for (j = 0; j < ys.length; j++) {
        var q = [xs[i], ys[j], xs[i] + W, ys[j] - H];
        if (!fits(q) || !free(q)) continue;
        // справа от занятого — без штрафа, ниже — небольшой, левее и выше — больше
        var dx = q[0] >= b[2] ? q[0] - b[2] : (b[2] - q[0]) * 3, dy = q[1] <= b[1] ? (b[1] - q[1]) * 1.5 : (q[1] - b[1]) * 3, dd = dx + dy;
        if (!best || dd < bd) { best = q; bd = dd; }
    }
    return best;
}

var Laser = (function () {
    var cOffs = 'none', cSideOut = 'out', cSideHole = 'in', cR = 0, cFailed = 0;

    function isOurs(L) { return L.name == LASER_CUT_LAYER || L.name == LASER_MOVE_LAYER || L.name == LASER_SRC_LAYER; }
    function G(c, k, dv) { return c.hasOwnProperty(k) ? c[k] : dv; }
    function sz(it) { var b = it.geometricBounds; return [mm(b[2] - b[0]), mm(b[1] - b[3])]; }

    // Что берём: выделенное; ничего не выделено — всё на активной области, кроме наших слоёв
    function source(d, ab) {
        var sel = selectionItems(d), out = [], i;
        if (sel.length) { for (i = 0; i < sel.length; i++) if (!isOurs(cutTopLayer(sel[i]))) out.push(sel[i]); return out; }
        for (i = 0; i < d.layers.length; i++) { var L = d.layers[i]; if (!isOurs(L) && !cutIsOurs(L) && L.visible && L.printable) out = out.concat(topItemsOn(d, L, ab)); }
        return out;
    }

    // ---------- раскладка стык в стык ----------
    function longStrip(w, h, sw, sh, m) {
        var a = Math.max(w, h), b = Math.min(w, h), s = Math.min(sw, sh);
        return b > 0 && a >= 5 * b && a > s - 2 * m + 0.01 && a <= s + 0.01;
    }
    function pack(params) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, sel = selectionItems(d);
        if (!sel.length) return 'Выделите детали — каждый объект или группа будет деталью.';
        var c = parseKV(params), W = cutNum(G(c, 'laW', '600')), H = cutNum(G(c, 'laH', '400')), kits = Math.max(1, Math.round(cutNum(G(c, 'laKits', '1'))));
        var mill = G(c, 'laMill', '0') == '1', gap = mill ? cutNum(G(c, 'laTool', '3')) : cutNum(G(c, 'laGap', '0')), longCnt = 0, i;
        var job = 'sheetW=' + cutN(W) + '\nsheetH=' + cutN(H) + '\nmargin=' + cutN(cutNum(G(c, 'laMargin', '5'))) + '\ngap=' + cutN(gap) +
                  '\nrot=' + G(c, 'laRot', '1') + '\nstrips=' + (mill ? '1' : '0') + '\n';
        for (i = 0; i < sel.length; i++) {
            var s = sz(sel[i]);
            job += 'item=' + (i + 1) + '|' + cutN(s[0]) + '|' + cutN(s[1]) + '|' + kits + '\n';
            if (mill && longStrip(s[0], s[1], W, H, cutNum(G(c, 'laMargin', '10')))) longCnt++;
        }
        var res = cutRunExe('--pack', job);
        if (cutVal(res, 'ok') != '1') return 'Раскладка не получилась: ' + cutVal(res, 'error');
        var sheets = Math.round(cutNum(cutVal(res, 'sheets'))), rects = [], k, placed = 0, un = [];
        try {
            for (k = 0; k < sheets; k++) {
                var R = freeBoard(d, W, H);
                if (!R) return 'Листов ' + sheets + ' по ' + mmText(W) + ' × ' + mmText(H) + ' мм не помещаются на холст Illustrator рядом с макетом. Вынесите детали в новый документ и разложите там.';
                d.artboards.add(R);
                d.artboards[d.artboards.length - 1].name = (mill ? 'Фрезер' : 'Лазер') + ' — лист ' + (k + 1) + ' из ' + sheets;
                rects.push(R);
            }
            var L = d.activeLayer;
            if (!L.visible || L.locked || isOurs(L)) for (i = 0; i < d.layers.length; i++) if (d.layers[i].visible && !d.layers[i].locked && !isOurs(d.layers[i])) { L = d.layers[i]; break; }
            var lines = cutLines(res, 'placed');
            for (i = 0; i < lines.length; i++) {
                var f = lines[i].split('|'), src = sel[+f[0] - 1], Rr = rects[+f[4]];
                var cp = src.duplicate(L, ElementPlacement.PLACEATBEGINNING);
                if (f[3] == '1') cp.rotate(90);
                var b = cp.geometricBounds, at = cutPt(Rr, cutNum(f[1]), cutNum(f[2]));
                cp.translate(at[0] - b[0], at[1] - b[3]);
                placed++;
            }
            var ul = cutLines(res, 'unplaced');
            for (i = 0; i < ul.length; i++) { var g2 = ul[i].split('|'); un.push('деталь ' + g2[0] + ' — ' + g2[1] + ' шт.'); }
            d.artboards.setActiveArtboardIndex(d.artboards.length - sheets);
        } catch (e) {
            logLine('сбой раскладки лазера: ' + e.message + ' (строка ' + e.line + ')');
            return 'Раскладка не получилась: ' + e.message;
        }
        return (mill ? 'Разложено с зазором ' + mmText(gap) + ' мм на фрезу, полосы — в начале листа: ' : 'Разложено стык в стык: ') + placed + ' шт. на ' + sheets + (sheets == 1 ? ' листе ' : ' листах ') +
               mmText(W) + ' × ' + mmText(H) + ' мм — новыми монтажными областями справа.' +
               (un.length ? '\nНе поместилось (деталь больше листа): ' + un.join(', ') : '') +
               (longCnt ? '\nПолос длиннее, чем помещается между полями, — ' + longCnt + ': им не за что держаться, и они легли вдоль листа. Сделайте их на ' +
                          Math.round(2 * cutNum(G(c, 'laMargin', '10'))) + ' мм короче листа — концы останутся в поле, и полосы встанут в начало листа поперёк.' : '') +
               '\nДальше — «Оптимизировать резку» на области с раскладкой.';
    }

    // ---------- общий рез и порядок реза ----------
    function pointIn(poly, x, y) {
        var inside = false;
        for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            var xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1];
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside;
        }
        return inside;
    }
    // выпуклый многоугольник из одних прямых — его смещает расчёт сам
    function convexPoly(pi) {
        var pp = pi.pathPoints, n = pp.length, turn = 0;
        if (n < 3) return false;
        for (var i = 0; i < n; i++) {
            var p = pp[i];
            if (Math.abs(p.leftDirection[0] - p.anchor[0]) + Math.abs(p.leftDirection[1] - p.anchor[1]) + Math.abs(p.rightDirection[0] - p.anchor[0]) + Math.abs(p.rightDirection[1] - p.anchor[1]) > 0.003) return false;
        }
        for (i = 0; i < n; i++) {
            var a = pp[i].anchor, b = pp[(i + 1) % n].anchor, c = pp[(i + 2) % n].anchor;
            var crs = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
            if (Math.abs(crs) > 1e-6) { var sg = crs > 0 ? 1 : -1; if (!turn) turn = sg; else if (sg != turn) return false; }
        }
        return true;
    }
    // путь центра кривого контура — смещение контура Illustrator на радиус (наружу или внутрь), углы скруглены
    function offsetSub(pi, side, isHole, key, R, out) {
        var L = pi.layer, tmp = null, got = [];
        try {
            tmp = pi.duplicate(L, ElementPlacement.PLACEATBEGINNING);
            tmp.closed = true; tmp.filled = true; tmp.fillColor = cmykColor(0, 0, 0, 100); tmp.stroked = false;
            tmp.applyEffect('<LiveEffect name="Adobe Offset Path"><Dict data="R mlim 4 R ofst ' + (side == 'out' ? pt(cR) : -pt(cR)) + ' I jntp 0 "/></LiveEffect>');
            d0().selection = null; tmp.selected = true;
            app.executeMenuCommand('expandStyle');
            var r = d0().selection.length ? d0().selection[0] : null, k = 0;
            if (r) {
                got.push(r);
                var subs = [];
                (function walk(x) {
                    if (x.typename == 'PathItem') subs.push(x);
                    else if (x.typename == 'CompoundPathItem') for (var q = 0; q < x.pathItems.length; q++) subs.push(x.pathItems[q]);
                    else if (x.typename == 'GroupItem') for (var q2 = 0; q2 < x.pageItems.length; q2++) walk(x.pageItems[q2]);
                })(r);
                for (var i = 0; i < subs.length; i++) if (subs[i].closed && subs[i].pathPoints.length > 1) { k++; out.push('p=' + key + '_' + k + '|1|' + cutPathData(subs[i], R) + '|' + (isHole ? 'gh' : 'g')); }
            }
            for (i = 0; i < got.length; i++) try { got[i].remove(); } catch (e) { }
            d0().selection = null;
            if (!k) cFailed++;
            return k > 0;
        } catch (e) {
            for (var j = 0; j < got.length; j++) try { got[j].remove(); } catch (x) { }
            try { if (tmp && tmp.parent) tmp.remove(); } catch (x) { }
            cFailed++;
            return false;
        }
    }
    function d0() { return app.activeDocument; }

    // Контуры объекта в задание: p=объект.номер|замкнут|точки|роль (o — наружный, h — окно, l — линия, g/gh — путь центра)
    // номер объекта для расчёта — целое число (у CorelDRAW это был его постоянный номер)
    function addShape(it, st, R, out) {
        if (it.typename == 'GroupItem') { for (var i = it.pageItems.length - 1; i >= 0; i--) addShape(it.pageItems[i], st, R, out); return; }
        var id = ++st.n, tmp = [], subs = cutSubs(it, tmp), polys = [], k;
        for (k = 0; k < subs.length; k++) polys.push(cutFlatten(subs[k], R, 0.05));
        for (k = 0; k < subs.length; k++) {
            var sp = subs[k];
            if (sp.pathPoints.length < 2) continue;
            if (!sp.closed) { out.push('p=' + id + '.' + (k + 1) + '|0|' + cutPathData(sp, R) + '|l'); continue; }
            var inside = 0, p0 = polys[k][0];
            for (var j = 0; j < subs.length; j++) if (j != k && subs[j].closed && pointIn(polys[j], p0[0], p0[1])) inside++;
            var isHole = inside % 2 == 1, side = isHole ? cSideHole : cSideOut, done = false;
            if (cOffs == 'prog' && side != 'on' && cR > 0 && !convexPoly(sp)) done = offsetSub(sp, side, isHole, id + '.' + (k + 1), R, out);
            if (!done) out.push('p=' + id + '.' + (k + 1) + '|1|' + cutPathData(sp, R) + '|' + (isHole ? 'h' : 'o'));
        }
        for (k = 0; k < tmp.length; k++) try { tmp[k].remove(); } catch (e) { }
    }

    function rgbOfText(s, dr, dg, db) {
        var a = String(s).replace(/[; ]/g, ',').split(',');
        return a.length >= 3 ? rgbColor(+a[0] || 0, +a[1] || 0, +a[2] || 0) : rgbColor(dr, dg, db);
    }
    function M(v) { return v >= 1000 ? (Math.round(v / 10) / 100).toFixed(2).replace('.', ',') + ' м' : Math.round(v) + ' мм'; }
    function Tm(sec) { return sec >= 60 ? Math.floor(sec / 60) + ' мин ' + Math.round(sec - Math.floor(sec / 60) * 60) + ' с' : Math.round(sec) + ' с'; }

    function optimize(params) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, A = cutAb(d), R = A.R, i, j;
        var lc0 = cutFindLayer(d, LASER_CUT_LAYER);
        if (lc0 && topItemsOn(d, lc0, A.i).length) return 'На этой области резка уже подготовлена. Нажмите «Вернуть как было», поправьте детали и оптимизируйте заново.';
        var src = source(d, A.i);
        if (!src.length) return 'Нечего резать: выделите детали или откройте область с раскладкой.';
        var c = parseKV(params), W = mm(R[2] - R[0]), H = mm(R[1] - R[3]);
        var st = G(c, 'laStart', G(c, 'laHead', 'tl')), hx = W / 2, hy = H / 2;
        if (st.indexOf('l') >= 0) hx = 0; if (st.indexOf('r') >= 0) hx = W; if (st.indexOf('b') >= 0) hy = 0; if (st.indexOf('t') >= 0) hy = H;
        var mill = G(c, 'laMill', '0') == '1';
        cOffs = G(c, 'laOffset', '') || (mill ? (G(c, 'laMillMode', 'center') == 'contour' ? 'machine' : 'prog') : 'none');
        cSideOut = G(c, 'laSideOut', 'out'); cSideHole = G(c, 'laSideHole', 'in');
        cR = mill ? cutNum(G(c, 'laTool', '3')) / 2 : cutNum(G(c, 'laKerf', '0.15')) / 2; cFailed = 0;
        var job = 'tol=' + cutN(cutNum(G(c, 'laTol', '0.05'))) + '\ndedupe=' + G(c, 'laDedupe', '1') + '\njoin=' + G(c, 'laJoin', '1') + '\ninner=' + G(c, 'laInner', '1') +
                  '\nheadX=' + cutN(hx) + '\nheadY=' + cutN(hy) + '\noffset=' + cOffs + '\nsideOut=' + cSideOut + '\nsideHole=' + cSideHole +
                  '\norder=' + G(c, 'laOrder', mill ? 'rows' : 'color') + '\nentry=' + G(c, 'laEntry', 'near') + '\nlead=' + cutN(cutNum(G(c, 'laLead', '0'))) +
                  '\nkerf=' + cutN(2 * cR) + '\nmargin=' + cutN(cutNum(G(c, 'laMargin', '10'))) + '\npageX0=0\npageY0=0\npageX1=' + cutN(W) + '\npageY1=' + cutN(H) + '\n';
        if (mill) job += 'mill=1\ntool=' + cutN(2 * cR) + '\nhold=' + G(c, 'laHold', '1') + '\n';
        var old = app.userInteractionLevel, lines = [];
        app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
        var ids = { n: 0 };
        try { for (i = 0; i < src.length; i++) addShape(src[i], ids, R, lines); } finally { app.userInteractionLevel = old; }
        if (!lines.length) return 'У выделенного нет контуров для резки.';
        var res = cutRunExe('--laser', job + lines.join('\n') + '\n');
        if (cutVal(res, 'ok') != '1') return 'Расчёт не получился: ' + cutVal(res, 'error');
        var cnt = 0;
        try {
            // исходные — на скрытый слой, запомнив, откуда
            var ls = cutLayer(d, LASER_SRC_LAYER, true);
            for (i = 0; i < src.length; i++) {
                var tg = src[i].tags.add(); tg.name = 'psaLayer'; tg.value = cutTopLayer(src[i]).name;
                src[i].move(ls, ElementPlacement.PLACEATBEGINNING);
            }
            var lc = layerNamed(d, LASER_CUT_LAYER, true), lm = cutLayer(d, LASER_MOVE_LAYER, true);
            lc.visible = true; lc.locked = false;
            var oneCol = G(c, 'laColors', '1') != '1' || G(c, 'laOrder', 'color') != 'color';
            var colIn = rgbOfText(G(c, 'laColIn', '255 0 0'), 255, 0, 0), colOut = rgbOfText(G(c, 'laColOut', '0 0 255'), 0, 0, 255), colOn = rgbColor(0, 160, 0);
            var clsName = [' · по линии', ' · снаружи', ' · внутри'], showMoves = G(c, 'laMoves', '1') == '1', nums = G(c, 'laNums', '1') == '1';
            var px = hx, py = hy, a = cutLines(res, 'c');
            // по порядку: каждая следующая — выше, нижняя режется первой
            for (i = 0; i < a.length; i++) {
                var f = a[i].split('|'), hole = f.length > 6 && f[6] == '1';
                var sh = cutMakePath(lc, R, f[4], f[2] == '1');
                sh.move(lc, ElementPlacement.PLACEATBEGINNING);
                cnt++;
                sh.filled = false; sh.stroked = true; sh.strokeWidth = pt(0.01);
                var no = ('00' + cnt).slice(-3);
                if (mill && f.length > 5) {
                    sh.strokeColor = f[5] == '2' ? rgbColor(255, 0, 0) : (f[5] == '1' ? rgbColor(0, 0, 255) : colOn);
                    sh.name = 'Рез ' + no + (clsName[+f[5]] || '') + (hole ? ', окно' : '') + (f[1] == '1' ? ', общая' : '');
                } else {
                    sh.strokeColor = oneCol || +f[0] > 0 || f[1] == '1' || hole ? colIn : colOut;
                    sh.name = 'Рез ' + no + (+f[0] > 0 || hole ? ' · внутри' : (f[1] == '1' ? ' · общий край' : ' · внешний край'));
                }
                var pts = f[4].split(';'), q = pts[0].replace(/^\s+|\s+$/g, '').split(' '), sx = cutNum(q[0]), sy = cutNum(q[1]);
                if (showMoves) {
                    var mv = lm.pathItems.add(); mv.setEntirePath([cutPt(R, px, py), cutPt(R, sx, sy)]);
                    mv.filled = false; mv.stroked = true; mv.strokeWidth = pt(0.2); mv.strokeColor = rgbColor(150, 150, 150); mv.strokeDashes = [pt(1), pt(1)];
                    var tl = cutPt(R, sx - 0.8, sy + 0.8), dot = lm.pathItems.ellipse(tl[1], tl[0], pt(1.6), pt(1.6));
                    dot.stroked = false; dot.filled = true; dot.fillColor = rgbColor(0, 160, 0);
                    if (nums) {
                        var t = lm.textFrames.pointText(cutPt(R, sx + 1.2, sy + 1.2)); t.contents = String(cnt);
                        try { t.textRange.characterAttributes.textFont = app.textFonts.getByName('ArialMT'); } catch (x) { }
                        t.textRange.characterAttributes.size = 7; t.textRange.characterAttributes.fillColor = rgbColor(0, 120, 0);
                    }
                }
                q = pts[pts.length - 1].replace(/^\s+|\s+$/g, '').split(' ');
                if (q[0] == 'C') { px = cutNum(q[5]); py = cutNum(q[6]); } else { px = cutNum(q[1]); py = cutNum(q[2]); }
            }
            // слой исходных прячем, а текущим делаем слой реза: при скрытом текущем Illustrator не даёт рисовать
            d.activeLayer = lc;
            ls.visible = false;
            setDocProp(d, 'cutstart_' + A.i, st);
            d.selection = null;
        } catch (e) {
            logLine('сбой оптимизации резки: ' + e.message + ' (строка ' + e.line + ')');
            return 'Оптимизация не получилась: ' + e.message;
        }
        var r = report(res, cnt, src.length, c, mill);
        logLine('лазер: ' + r.replace(/\n/g, ' / '));
        return r;
    }

    function report(res, cnt, parts, c, mill) {
        var cb = cutNum(cutVal(res, 'cutBefore')), ca = cutNum(cutVal(res, 'cutAfter')), rm = cutNum(cutVal(res, 'removed'));
        var tb = cutNum(cutVal(res, 'travelBefore')), ta = cutNum(cutVal(res, 'travelAfter')), pb = Math.round(cutNum(cutVal(res, 'piercesBefore'))), pa = Math.round(cutNum(cutVal(res, 'piercesAfter')));
        var r = 'Резка подготовлена: ' + cnt + ' линий в порядке реза (было ' + parts + ' объектов).\nРез: ' + M(ca) + (rm > 0.5 ? ' — общие края режутся один раз, убрано ' + M(rm) : '') + '.\n' +
                'Прожигов: ' + pa + ' вместо ' + pb + '.\n' +
                (cutVal(res, 'leads') ? 'Заходов со стороны отхода: ' + cutVal(res, 'leads') + (+cutVal(res, 'leadsSkipped') > 0 ? ', без захода ' + cutVal(res, 'leadsSkipped') + ' (рядом другая деталь)' : '') + '.\n' : '') +
                (cFailed ? 'Не удалось сместить контуров: ' + cFailed + ' — слишком малы для фрезы, режутся как нарисованы.\n' : '') +
                'Холостой ход: ' + M(ta) + ' вместо ' + M(tb) + (tb > 0 ? ' (-' + Math.round((1 - ta / tb) * 100) + ' %)' : '') + '.\n' +
                'Линии — на слое «' + LASER_CUT_LAYER + '»: нижняя режется первой. Детали — на скрытом слое «' + LASER_SRC_LAYER + '».';
        if (mill) {
            r = r.replace('Прожигов:', 'Врезок:').replace('общие края режутся один раз', 'общая линия соседей режется один раз');
            if (cOffs == 'machine') r += '\nКонтуры деталей — как нарисованы, смещение на фрезу задаётся в программе фрезера: синие — «снаружи», красные (окна) — «внутри», зелёные (линии полос) — «по линии».';
            else if (cOffs == 'prog') r += '\nВсе линии — путь центра фрезы ' + G(c, 'laTool', '3') + ' мм: в программе фрезера обработка «по линии», без смещения. У каждой детали окна режутся раньше контура.';
            else r += '\nЛинии — как нарисованы, без смещения: в программе фрезера сторону и фрезу задайте сами.';
            if (+cutVal(res, 'tooClose') > 0) r += '\nВнимание: деталей, стоящих ближе, чем фреза, — ' + cutVal(res, 'tooClose') + ' пар: фреза зайдёт в соседнюю деталь. Разложите с зазором на фрезу.';
            return r;
        }
        var sp = cutNum(G(c, 'laSpeed', '0')), idle = cutNum(G(c, 'laIdle', '300')) || 300;
        if (sp > 0) r += '\nВремя: около ' + Tm(ca / sp + ta / idle) + ' вместо ' + Tm(cb / sp + tb / idle) + ' (' + G(c, 'laMode', '') + ', холостой ход ' + idle + ' мм/с).';
        return r;
    }

    // Вернуть как было: линии реза и холостые ходы — вон, детали — на свои слои
    function undo() {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, A = cutAb(d), i, cnt = 0;
        var lc = cutFindLayer(d, LASER_CUT_LAYER), lm = cutFindLayer(d, LASER_MOVE_LAYER), ls = cutFindLayer(d, LASER_SRC_LAYER);
        if (!ls) return 'На этой области резка не готовилась.';
        try {
            var kill = function (L) { if (!L) return; L.locked = false; L.visible = true; var t = topItemsOn(d, L, A.i); for (var k = t.length - 1; k >= 0; k--) t[k].remove(); if (!L.pageItems.length) L.remove(); };
            kill(lc); kill(lm);
            ls.visible = true; ls.locked = false;
            var items = topItemsOn(d, ls, A.i);
            for (i = 0; i < items.length; i++) {
                var nm = '', it = items[i], target = null;
                try { for (var t = it.tags.length - 1; t >= 0; t--) if (it.tags[t].name == 'psaLayer') { nm = it.tags[t].value; it.tags[t].remove(); } } catch (e) { }
                if (nm) target = cutFindLayer(d, nm);
                if (!target) for (var q = 0; q < d.layers.length; q++) if (!isOurs(d.layers[q]) && !cutIsOurs(d.layers[q])) { target = d.layers[q]; break; }
                if (!target) { target = d.layers.add(); target.name = 'Слой 1'; }
                target.visible = true; target.locked = false;
                it.move(target, ElementPlacement.PLACEATEND);
                cnt++;
            }
            var rest = ls.pageItems.length;
            if (!rest) ls.remove();
            try { if (d.activeLayer.name == LASER_SRC_LAYER) d.activeLayer = d.layers[0]; } catch (e) { }
            if (rest) return 'Вернул не всё: ' + rest + ' объектов остались на слое «' + LASER_SRC_LAYER + '» — он снова видим.';
        } catch (e) {
            logLine('сбой «вернуть как было»: ' + e.message + ' (строка ' + e.line + ')');
            return 'Не получилось вернуть: ' + e.message;
        }
        return 'Вернул как было: ' + cnt + ' объектов на своих слоях.';
    }

    // Таблица режимов, нарисованная надписями: все надписи документа, «центрX|центрY|ширина|высота|текст», мм
    function tableRead() {
        if (!hasDoc()) return 'Откройте файл с таблицей режимов.';
        var d = app.activeDocument, t = '';
        for (var i = 0; i < d.textFrames.length; i++) {
            var tf = d.textFrames[i], b = tf.geometricBounds, s = String(tf.contents).replace(/\r\n|\r|\n/g, ' / ').replace(/\|/g, '/');
            t += cutN(mm((b[0] + b[2]) / 2)) + '|' + cutN(mm((b[1] + b[3]) / 2)) + '|' + cutN(mm(b[2] - b[0])) + '|' + cutN(mm(b[1] - b[3])) + '|' + s + '\n';
        }
        return t || 'В открытом документе нет надписей.';
    }

    return { pack: pack, optimize: optimize, undo: undo, tableRead: tableRead };
})();

Bridge.LaserPack = function (params) {
    if (!PSA.has('L')) return 'Раскладка для лазера входит в часть «Лазер» — её нет в вашем ключе.';
    Settings.set('Laser', 'Params', params);
    return Laser.pack(params);
};
Bridge.LaserOptimize = function (params) {
    if (!PSA.has('L')) return 'Оптимизация резки входит в часть «Лазер» — её нет в вашем ключе.';
    Settings.set('Laser', 'Params', params);
    return Laser.optimize(params);
};
Bridge.LaserUndo = function () { return Laser.undo(); };
Bridge.LaserTableRead = function () { return Laser.tableRead(); };
Bridge.LaserTableGet = function () { return Settings.get('Laser', 'Table', ''); };
Bridge.LaserTableSave = function (json) { Settings.set('Laser', 'Table', json); return 'ok'; };
