// Данные из файла клиента — как src/DataIO.bas. Сам файл (Excel, CSV, TXT) читает панель и кладёт
// таблицу в %APPDATA%\PS Automation\cache\ (Illustrator не умеет ни zip, ни кодировки); здесь — разбор
// таблицы по полю: столбец или шаблон из нескольких столбцов, ведущие нули, хвостовые пустые строки.

// Имя таблицы в кэше — то же, что даёт панель (datafile.js, cacheName)
function dataCacheName(path) {
    var s = String(path).replace(/\//g, '\\').toLowerCase(), h = 5381;
    for (var i = 0; i < s.length; i++) h = (h * 33 + s.charCodeAt(i)) % 4294967296;
    return PSA_DATA + '/cache/' + ('0000000' + h.toString(16)).slice(-8) + '-' + s.length + '.json';
}

var DataIO = {
    // таблица файла: { rows } или { error }
    Table: function (path) {
        var c = fromJson(readText(dataCacheName(path)));
        if (!c) return { error: 'файл ещё не прочитан — откройте панель «PS • Автоматизация» (она читает файлы клиента)' };
        if (c.error) return { error: c.error };
        return { rows: c.rows || [] };
    },

    // Загрузить значения поля. '' — готово, иначе текст ошибки.
    LoadField: function (f) {
        if (f.Source == 0) { f.Loaded = true; return ''; }
        if (f.FilePath == '') return 'не выбран файл с данными';
        if (!new File(f.FilePath).exists) return 'файл не найден: ' + f.FilePath;
        var t = this.Table(f.FilePath);
        if (t.error) return t.error;
        var tbl = t.rows, first = f.FirstRow - 1, i, row, vals = [];
        if (first < 0) first = 0;
        if (first == 0 && f.HasHeader) first = 1;
        var n = Math.max(0, tbl.length - first);
        for (i = 0; i < n; i++) {
            row = tbl[i + first] || [];
            if (f.Template.replace(/\s/g, '') != '') vals.push(this.Compose(f.Template, row, first > 0 ? tbl[first - 1] : null));
            else vals.push(f.Column - 1 < row.length ? this.PadZeros(row[f.Column - 1], f.NumDigits) : '');
        }
        while (n > 0 && String(vals[n - 1]).replace(/\s/g, '') == '') n--;
        vals.length = n;
        f.Values = vals;
        f.ValuesCount = n;
        f.Loaded = true;
        return '';
    },

    // Шаблон «{Имя} {Фамилия}» — по заголовкам, «{1} {3}» — по номерам столбцов. Пустой столбец не оставляет двойных пробелов.
    Compose: function (tpl, row, hdr) {
        var out = '', p = 0, q, e, key, c, j, trim = function (s) { return String(s).replace(/^\s+|\s+$/g, ''); };
        for (;;) {
            q = tpl.indexOf('{', p);
            if (q < 0) { out += tpl.substring(p); break; }
            out += tpl.substring(p, q);
            e = tpl.indexOf('}', q);
            if (e < 0) { out += tpl.substring(q); break; }
            key = trim(tpl.substring(q + 1, e));
            c = -1;
            if (/^\d+$/.test(key)) c = parseInt(key, 10) - 1;
            else if (hdr) for (j = 0; j < hdr.length; j++) if (trim(hdr[j]).toLowerCase() == key.toLowerCase()) { c = j; break; }
            if (c >= 0 && c < row.length) out += trim(row[c]);
            else if (c < 0) out += '{' + key + '}';
            p = e + 1;
        }
        while (out.indexOf('  ') >= 0) out = out.replace(/  /g, ' ');
        return trim(out);
    },

    // Число короче нужного дополняется нулями слева (9132 -> 09132). Не число — без изменений.
    PadZeros: function (v, digits) {
        var t = String(v).replace(/^\s+|\s+$/g, '');
        if (digits > 0 && t.length < digits && t.length > 0 && /^\d+$/.test(t)) return zeroPad(t, digits);
        return String(v);
    },

    // Первые строки таблицы и сколько всего — для выбора столбца
    Preview: function (path, maxRows) {
        var t = this.Table(path);
        if (t.error) return t;
        var rows = t.rows, cols = 0;
        for (var i = 0; i < rows.length && i <= 500; i++) if (rows[i].length > cols) cols = rows[i].length;
        return { rows: rows.slice(0, maxRows), total: rows.length, cols: cols };
    }
};

// Файлы клиента, которые нужны полям открытого документа — панель обновляет их таблицы перед расчётом
Bridge.DataFiles = function () {
    prepare();
    var a = [];
    for (var i = 0; i < Engine.Fields.length; i++) {
        var f = Engine.Fields[i];
        if (f.Source == 1 && f.FilePath) a.push(f.FilePath);
    }
    return toJson(a);
};

// Столбцы файла клиента для выбора: {"rows":N,"firstRow":r,"cols":[{"n":1,"head":"…","first":"…"},…]}
Bridge.Columns = function (id) {
    prepare();
    var f = Engine.FieldById(+id);
    if (!f) return '';
    if (f.FilePath == '') return toJson({ rows: 0, cols: [] });
    var r = f.FirstRow;
    if (r < 1) r = f.HasHeader ? 2 : 1;
    var p = DataIO.Preview(f.FilePath, r);
    if (p.error) return toJson({ rows: 0, cols: [], err: p.error });
    var cols = [];
    for (var i = 0; i < p.cols; i++) {
        var hd = r >= 2 && p.rows[r - 2] ? (p.rows[r - 2][i] || '') : '', fv = p.rows[r - 1] ? (p.rows[r - 1][i] || '') : '';
        cols.push({ n: i + 1, head: String(hd).substring(0, 30), first: String(fv).substring(0, 40) });
    }
    return toJson({ rows: p.total, firstRow: r, cols: cols });
};

Bridge.PickDataFile = function (id) {
    if (!PSA.has('D')) { alert(freeWhy('Номера из файла клиента'), 'PS • Автоматизация'); return ''; }
    prepare();
    var f = Engine.FieldById(+id);
    if (!f) return '';
    var start = f.FilePath ? new File(f.FilePath) : new File(Folder.myDocuments.fsName + '/данные');
    var p = start.openDlg('Файл клиента', 'Данные:*.xlsx;*.xls;*.xlsm;*.csv;*.txt,Все файлы:*.*', false);
    if (!p) return '';
    f.FilePath = p.fsName;
    f.Loaded = false;
    Engine.SaveConfig();
    return p.fsName;
};

Bridge.PickPicFolder = function (id) {
    prepare();
    var f = Engine.FieldById(+id);
    if (!f) return '';
    var fo = (f.PicFolder ? new Folder(f.PicFolder) : Folder.myDocuments).selectDlg('Папка с картинками');
    if (!fo) return '';
    f.PicFolder = fo.fsName;
    Engine.SaveConfig();
    return fo.fsName;
};
