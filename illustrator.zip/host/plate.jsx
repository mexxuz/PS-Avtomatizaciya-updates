// Лист на пластину для вывода (CTP) — как src/Plate.bas. Готовый лист — монтажная область документа
// (область = лист бумаги) — встаёт на пластину печатника: по центру по ширине, нижний край — на клапане.
// Вокруг работы — метки как в файлах бюро: уголки с мишенями, шкалы тонов по бокам, шкала цветового контроля
// у хвоста, «КЛАПАН» и квадраты красок под работой; внизу пластины — контрольная полоса, «N СТРАНИЦ В ФАЙЛЕ»,
// строка вывода, названия красок и линейка. Итог — файл Illustrator и PDF «ширина-высота_пластин_PS_FOR_ПЕЧАТНИК_имя.pdf».
// Здесь координаты меток — мм от левого нижнего угла пластины, y вверх (как в CorelDRAW).

var PLATE_LAYER = 'Пластина';
var PLATE_GUIDES = 'Пластина — разметка (не печатается)';

var Plate = (function () {
    var inkC, inkM, inkY, inkK, spots, scanned, boxKey = '', boxVal = null, lastCap = 1;

    function from(params) {
        var c = parseKV(params), G = function (k, dv) { return c.hasOwnProperty(k) ? c[k] : dv; }, N = function (k, dv) { return toNum(G(k, ''), dv); };
        var p = {
            PW: N('plW', 0), PH: N('plH', 0), Klapan: N('plK', 0), ToJob: G('plTo', 'paper') == 'job', Printer: trimS(G('plPrinter', '')),
            PaperW: N('plPaperW', 0), PaperH: N('plPaperH', 0), Bleed: N('plBleed', 0), Corners: Math.round(N('plCorners', 1)),
            Wedges: G('plWedges', '1') == '1', Bar: Math.round(N('plBar', 0)), Klap: G('plKlap', '1') == '1', Footer: G('plFooter', '1') == '1',
            Company: trimS(G('plCompany', 'POLITEXT')), FileName: ''
        };
        if (G('plCenter', '0') == '1') p.Klapan = -1;
        return p;
    }
    function trimS(s) { return String(s).replace(/^\s+|\s+$/g, ''); }

    function isPlateDoc(d) { return docProp(d, 'kind') == 'plate'; }

    // Нижний край листа от нижнего края пластины; jy — низ работы от низа страницы (для клапана «до работы»)
    function paperBottom(p, pw, ph, h, jy) {
        if (p.Klapan < 0) return (p.PH - ph) / 2;
        if (p.ToJob) return p.Klapan - ((ph - h) / 2 + jy);
        return p.Klapan;
    }

    // ---------- где работа на странице ----------
    // Рамка работы по содержимому: линии, мелкие метки без заливки и регистрационные метки не в счёт.
    // Большую группу (весь лист одной группой, как открывается PDF) разбирает внутрь.
    // Ответ: jx, jy — левый нижний угол работы от левого нижнего угла области (мм), jw, jh; вылет вычтен
    function jobBox(d, ab, bleed) {
        var R = d.artboards[ab].artboardRect, pw = R[2] - R[0], ph = R[1] - R[3], acc = { x0: 1e30, y0: 1e30, x1: -1e30, y1: -1e30, found: false };
        function fillOf(it) { var s = it.typename == 'CompoundPathItem' && it.pathItems.length ? it.pathItems[0] : it; try { return s.filled ? s.fillColor : null; } catch (e) { return null; } }
        function isMark(it, w, h) {
            if (w < pt(0.8) || h < pt(0.8)) return true;
            var t = it.typename;
            if (t == 'RasterItem' || t == 'PlacedItem') return false;
            if (t != 'PathItem' && t != 'CompoundPathItem') return false;
            var f = fillOf(it);
            if (!f && w < pt(16) && h < pt(16)) return true;
            if (f && f.typename == 'SpotColor' && w < pt(30) && h < pt(30)) { try { if (f.spot.colorType == ColorModel.REGISTRATION) return true; } catch (e) { } }
            return false;
        }
        function add(it, depth) {
            try { if (it.hidden || it.guides) return; } catch (e) { }
            var b = it.geometricBounds;
            if (b[2] < R[0] || b[0] > R[2] || b[1] < R[3] || b[3] > R[1]) return;
            var w = b[2] - b[0], h = b[1] - b[3];
            if (it.typename == 'GroupItem') {
                if (depth < 4 && (w > pw * 0.6 || h > ph * 0.6)) {
                    for (var i = 0; i < it.pageItems.length; i++) {
                        var c = it.pageItems[i];
                        if (it.clipped && c.typename == 'PathItem' && c.clipping) continue;
                        add(c, depth + 1);
                    }
                    return;
                }
            } else if (isMark(it, w, h)) return;
            if (b[0] < acc.x0) acc.x0 = b[0];
            if (b[3] < acc.y0) acc.y0 = b[3];
            if (b[2] > acc.x1) acc.x1 = b[2];
            if (b[1] > acc.y1) acc.y1 = b[1];
            acc.found = true;
        }
        function walk(L) {
            if (!L.visible || !L.printable) return;
            for (var i = 0; i < L.pageItems.length; i++) if (L.pageItems[i].parent == L) add(L.pageItems[i], 0);
            for (i = 0; i < L.layers.length; i++) walk(L.layers[i]);
        }
        for (var li = 0; li < d.layers.length; li++) walk(d.layers[li]);
        var full = { jx: 0, jy: 0, jw: mm(pw), jh: mm(ph) };
        if (!acc.found) return full;
        var x0 = Math.max(acc.x0, R[0]), y0 = Math.max(acc.y0, R[3]), x1 = Math.min(acc.x1, R[2]), y1 = Math.min(acc.y1, R[1]);
        var o = { jx: mm(x0 - R[0]) + bleed, jy: mm(y0 - R[3]) + bleed, jw: mm(x1 - x0) - 2 * bleed, jh: mm(y1 - y0) - 2 * bleed };
        return o.jw < 10 || o.jh < 10 ? full : o;
    }

    // «ok|страниц|ширина листа|высота|работа ш|работа в|сверху до края пластины|предупреждение» или «err|почему»
    function info(p) {
        try {
            if (!hasDoc()) return 'err|Откройте готовый лист: каждая монтажная область — лист бумаги, как его печатать.';
            var d = app.activeDocument;
            if (isPlateDoc(d)) return 'err|Открыт уже готовый файл пластин. Откройте исходный лист — программа поставит его на пластину заново.';
            var s = abSizeMm(d, 0), w = s.w, h = s.h, odd = [], i;
            for (i = 1; i < d.artboards.length; i++) { var z = abSizeMm(d, i); if (Math.abs(z.w - w) > 0.5 || Math.abs(z.h - h) > 0.5) odd.push(i + 1); }
            var path = ''; try { path = d.fullName.fsName; } catch (e) { }
            var key = path + '|' + d.name + '|' + d.pageItems.length + '|' + w + '|' + h + '|' + p.Bleed;
            if (key != boxKey || !boxVal) { boxVal = jobBox(d, 0, p.Bleed); boxKey = key; }
            var jb = boxVal, pw = p.PaperW > 0 ? p.PaperW : w, ph = p.PaperH > 0 ? p.PaperH : h, warn = '';
            if (p.PW <= 0 || p.PH <= 0) return 'err|Выберите печатника или впишите размер пластины.';
            if (pw < w - 0.5 || ph < h - 0.5) return 'err|Бумага ' + mmText(pw) + ' × ' + mmText(ph) + ' меньше страницы ' + mmText(w) + ' × ' + mmText(h) + ' мм.';
            if (pw > p.PW + 0.5) return 'err|Лист ' + mmText(pw) + ' мм шире пластины ' + mmText(p.PW) + ' мм. Проверьте печатника или поверните лист.';
            var pb = paperBottom(p, pw, ph, h, jb.jy), top = p.PH - pb - ph;
            if (top < 0) return 'err|Лист ' + mmText(ph) + ' мм выше, чем помещается над клапаном: пластина ' + mmText(p.PH) + ', клапан ' + mmText(pb) + ' мм. Не хватает ' + mmText(-top) + ' мм.';
            if (pb < 0) return 'err|Работа ниже края пластины: клапан меньше, чем поле листа под работой.';
            if (p.Footer && pb < 18) warn += ' Клапан меньше 18 мм — полоса внизу пластины заденет лист.';
            if (odd.length) warn += ' Страницы ' + odd.join(', ') + ' другого размера — встанут по своему размеру.';
            return 'ok|' + d.artboards.length + '|' + mmText(w) + '|' + mmText(h) + '|' + mmText(jb.jw) + '|' + mmText(jb.jh) + '|' + mmText(top) + '|' + trimS(warn);
        } catch (e) { return 'err|' + e.message; }
    }

    // ---------- краски макета ----------
    // Сколько пластин на страницу и какие: «C,M,Y,K,PANTONE 151 U» (процесс, потом плашки)
    function allProcess() { inkC = inkM = inkY = inkK = true; }
    function colorInks(c) {
        try {
            switch (c.typename) {
                case 'NoColor': return;
                case 'CMYKColor':
                    if (c.cyan > 0) inkC = true; if (c.magenta > 0) inkM = true; if (c.yellow > 0) inkY = true; if (c.black > 0) inkK = true; return;
                case 'GrayColor': if (c.gray > 0) inkK = true; return;
                case 'RGBColor': if (!(c.red == 255 && c.green == 255 && c.blue == 255)) allProcess(); return;
                case 'GradientColor':
                    var st = c.gradient.gradientStops;
                    for (var i = 0; i < st.length; i++) colorInks(st[i].color);
                    return;
                case 'SpotColor':
                    var sp = c.spot;
                    if (sp.colorType == ColorModel.REGISTRATION) return;
                    var nm = trimS(sp.name), k = '|' + nm.toLowerCase() + '|';
                    // технические плашки (линия реза, белила) — не пластины
                    if ('|cutcontour|contourcut|cut|thru-cut|thrucut|kisscut|w|white|белила|'.indexOf(k) >= 0) return;
                    for (var j = 0; j < spots.length; j++) if (spots[j].toLowerCase() == nm.toLowerCase()) return;
                    spots.push(nm);
                    return;
                default: allProcess();
            }
        } catch (e) { }
    }
    function scanItem(it) {
        if (++scanned > 40000) return;
        try { if (it.hidden || it.guides) return; } catch (e) { }
        var t = it.typename, i;
        if (t == 'GroupItem') { for (i = 0; i < it.pageItems.length; i++) scanItem(it.pageItems[i]); return; }
        if (t == 'CompoundPathItem') { if (it.pathItems.length) scanItem(it.pathItems[0]); return; }
        if (t == 'PathItem') {
            if (it.clipping) return;
            if (it.filled) colorInks(it.fillColor);
            if (it.stroked) colorInks(it.strokeColor);
            return;
        }
        if (t == 'TextFrame') {
            var rs = it.textRanges;
            for (i = 0; i < rs.length && i < 200; i++) { var a = rs[i].characterAttributes; colorInks(a.fillColor); try { if (a.strokeWeight > 0) colorInks(a.strokeColor); } catch (e) { } }
            return;
        }
        if (t == 'RasterItem') {
            try { if (it.imageColorSpace == ImageColorSpace.GrayScale || it.imageColorSpace == ImageColorSpace.Bitmap) { inkK = true; return; } } catch (e) { }
            allProcess(); return;
        }
        // вставленные файлы, символы, сетчатые и прочие: чем напечатаются — не узнать, считаем полноцветными
        allProcess();
    }
    function inkList(d) {
        inkC = inkM = inkY = inkK = false; spots = []; scanned = 0;
        function walk(L) {
            if (!L.visible || !L.printable) return;
            for (var i = 0; i < L.pageItems.length; i++) if (L.pageItems[i].parent == L) scanItem(L.pageItems[i]);
            for (i = 0; i < L.layers.length; i++) walk(L.layers[i]);
        }
        for (var li = 0; li < d.layers.length; li++) walk(d.layers[li]);
        var s = [];
        if (inkC) s.push('C'); if (inkM) s.push('M'); if (inkY) s.push('Y'); if (inkK) s.push('K');
        s = s.concat(spots);
        return s.length ? s.join(',') : 'K';
    }

    // Часть имени файла: CMYK — числом пластин (4 на страницу), иначе буквами: K, P — как в файлах бюро
    function platesTag(inks, pages) {
        if (inks == 'C,M,Y,K') return String(4 * pages);
        var a = inks.split(','), t = '';
        for (var i = 0; i < a.length; i++) t += a[i].length == 1 ? a[i] : 'P';
        return t;
    }

    // ---------- рисование (мм от левого нижнего угла пластины R, y вверх) ----------
    function P(R, x, y) { return [R[0] + pt(x), R[3] + pt(y)]; }
    function rectY(c, R, x0, y0, x1, y1) { var a = P(R, Math.min(x0, x1), Math.max(y0, y1)); var s = c.pathItems.rectangle(a[1], a[0], pt(Math.abs(x1 - x0)), pt(Math.abs(y1 - y0))); s.stroked = false; return s; }
    function hair(c, R, x0, y0, x1, y1, wd) {
        var l = c.pathItems.add();
        l.setEntirePath([P(R, x0, y0), P(R, x1, y1)]);
        l.filled = false; l.stroked = true; l.strokeWidth = pt(wd); l.strokeColor = regColor();
        return l;
    }
    function ellipseC(c, R, cx, cy, r) { var a = P(R, cx - r, cy + r); return c.pathItems.ellipse(a[1], a[0], pt(2 * r), pt(2 * r)); }
    function inkColor(ink, v) { return cmykColor(ink == 0 ? v : 0, ink == 1 ? v : 0, ink == 2 ? v : 0, ink == 3 ? v : 0); }
    function regTint(t) { var c = regColor(); c.tint = t; return c; }
    function spotColor(d, nm) {
        try { var c = new SpotColor(); c.spot = d.spots.getByName(nm); c.tint = 100; return c; } catch (e) { return cmykColor(0, 50, 100, 0); }
    }
    function setFont(t, name) { try { t.textRange.characterAttributes.textFont = app.textFonts.getByName(name); } catch (e) { } }
    // Надпись высотой букв h мм (заглавные и цифры): кегль — по высоте прописных Arial (0,716 кегля)
    function txt(c, s, font, h) {
        var t = c.textFrames.pointText([0, 0]);
        t.contents = s;
        setFont(t, font == 'Segoe UI' ? 'SegoeUI' : 'ArialMT');
        t.textRange.characterAttributes.size = Math.max(0.1, pt(h) / 0.716);
        lastCap = h;
        return t;
    }
    // Поставить только что сделанную надпись (высота букв — lastCap): ax — 0 левый край, 0,5 середина, 1 правый; ay — 0 низ букв, 0,5 середина, 1 верх
    function put(t, R, x, y, ax, ay) {
        var b = t.geometricBounds, w = b[2] - b[0], ch = pt(lastCap), a = P(R, x, y), base = t.anchor[1];
        t.translate(a[0] - ax * w - b[0], a[1] - ay * ch - base);
    }
    function fillText(t, c) { t.textRange.characterAttributes.fillColor = c; }
    // Текст Segoe UI кеглем size, левый край x, базовая линия y
    function txtAt(c, R, s, size, x, y) {
        var t = c.textFrames.pointText(P(R, x, y));
        t.contents = s;
        setFont(t, 'SegoeUI');
        t.textRange.characterAttributes.size = size;
        lastCap = mm(size * 0.7);
        return t;
    }

    // Мишень: 1 — перекрестие 6 мм, квадрат 4 мм и точка 2 мм; 2 — окружность 4 мм вместо квадрата
    function target(c, R, x, y, style) {
        var g = c.groupItems.add(), s;
        g.name = 'Мишень';
        hair(g, R, x - 3, y, x + 3, y, 0.09); hair(g, R, x, y - 3, x, y + 3, 0.09);
        s = style == 2 ? ellipseC(g, R, x, y, 2) : rectY(g, R, x - 2, y - 2, x + 2, y + 2);
        s.filled = false; s.stroked = true; s.strokeWidth = pt(0.09); s.strokeColor = regColor();
        s = ellipseC(g, R, x, y, 1); s.stroked = false; s.filled = true; s.fillColor = regColor();
        return g;
    }

    // Шкала тонов 2 × 10 клеток: слева светлые 10…01 %, справа тёмные 90…99 %, цифры — 50 % той же краски.
    // x — середина шкалы; y0 — край у мишени (голубая и жёлтая вверх, пурпурная и чёрная вниз)
    function wedge(c, R, x, y0, ink, jobH) {
        var ch = 4, i, names = ['голубой', 'пурпурный', 'жёлтый', 'чёрный'];
        if (jobH < 92) ch = (jobH - 12) / 20;
        if (ch < 2) return;
        var g = c.groupItems.add(), ytop = (ink == 0 || ink == 2) ? y0 + 10 * ch : y0, s, t;
        g.name = 'Шкала тонов — ' + names[ink];
        for (i = 0; i <= 9; i++) {
            var yt = ytop - i * ch;
            s = rectY(g, R, x - 2.5, yt, x, yt - ch); s.fillColor = inkColor(ink, 10 - i);
            s = rectY(g, R, x, yt, x + 2.5, yt - ch); s.fillColor = inkColor(ink, 90 + i);
            if (i > 0) { s = hair(g, R, x - 2.5, yt, x + 2.5, yt, 0.127); s.strokeColor = cmykColor(0, 0, 0, 0); }
            t = txt(g, (10 - i < 10 ? '0' : '') + (10 - i), 'Arial', 0.39 * ch); fillText(t, inkColor(ink, 50)); put(t, R, x - 2.45, yt - ch + 0.15, 0, 0);
            t = txt(g, String(90 + i), 'Arial', 0.39 * ch); fillText(t, inkColor(ink, 50)); put(t, R, x + 2.45, yt - 0.15, 1, 1);
        }
        s = rectY(g, R, x - 2.5, ytop, x + 2.5, ytop - 10 * ch);
        s.filled = false; s.stroked = true; s.strokeWidth = pt(0.076); s.strokeColor = inkColor(ink, 50);
    }

    function hasInk(inks, k) { return (',' + inks + ',').indexOf(',' + k + ',') >= 0; }

    // «КЛАПАН» под левым нижним углом работы и квадраты красок под серединой (с чертой по центру)
    function klapanMarks(d, c, R, jl, yb, jcx, inks) {
        var t = txt(c, 'КЛАПАН', 'Arial', 3.56), b = t.geometricBounds;
        // узкие буквы, как в шкалках: 14,6 × 3,6 мм
        t.textRange.characterAttributes.horizontalScale = 100 * pt(14.64) / Math.max(1, b[2] - b[0]);
        fillText(t, regColor()); put(t, R, jl + 4, yb - 0.44, 0, 1); t.name = 'КЛАПАН';
        var g = c.groupItems.add(), pos = [-12, -6, 1, 7], a = inks.split(','), nSpot = 0;
        g.name = 'Краски';
        for (var i = 0; i < a.length; i++) {
            var k = 'CMYK'.indexOf(a[i]), x;
            if (a[i].length == 1 && k >= 0) x = jcx + pos[k]; else { k = -1; x = jcx + 13 + 6 * nSpot++; }
            var s = rectY(g, R, x, yb - 1, x + 5, yb - 6);
            s.fillColor = k >= 0 ? inkColor(k, 100) : spotColor(d, a[i]);
            var tt = txt(g, k >= 0 ? 'CMYK'.charAt(k) : 'P', 'Segoe UI', 2.65);
            fillText(tt, cmykColor(0, 0, 0, 0)); put(tt, R, x + 2.5, yb - 3.5, 0.5, 0.5);
        }
        hair(g, R, jcx, yb - 1, jcx, yb - 7, 0.1);
    }

    // Шкала цветового контроля у хвоста (как у VIZA): ячейки 4,29 × 2,83, 20 ячеек в звене
    function colorBar(c, R, x0, x1, y, split) {
        var g = c.groupItems.add(), cx = (x0 + x1) / 2;
        g.name = 'Шкала цветового контроля';
        if (split) { barRun(g, R, x0, cx - 12, y); barRun(g, R, cx + 12, x1, y); target(g, R, cx, y + 1.42, 1); }
        else barRun(g, R, x0, x1, y);
    }
    function barRun(g, R, x0, x1, y) {
        var CW = 4.29, CH = 2.83, seq = ['c0', 'h0', 's0', 'o0', 'g', 'c1', 'h1', 's1', 'o1', 'g', 'c2', 'h2', 's2', 'o2', '3', 'c3', 'b', 'h3', 's3', 'g'];
        var n = Math.floor((x1 - x0 + 0.01) / CW);
        if (n < 1) return;
        var x = x0 + (x1 - x0 - n * CW) / 2;
        for (var i = 0; i < n; i++) {
            var kind = seq[i % 20], ch0 = kind.charAt(0);
            cell(g, R, x, y, CW, CH, kind);
            if (ch0 == 'c' || ch0 == 'h') {
                var ink = +kind.charAt(1), t = txt(g, ch0 == 'c' ? 'CMYK'.charAt(ink) : '50%', 'Arial', 0.8);
                fillText(t, inkColor(ink, 100)); put(t, R, x + CW / 2, y + CH + 0.25, 0.5, 0);
            }
            x += CW;
            if (i % 20 == 19) x += 0.49;
            if (x + CW > x1 + 0.01) break;
        }
    }
    function cell(g, R, x, y, w, h, kind) {
        var s, k0 = kind.charAt(0), ink = +kind.charAt(1);
        if (k0 == 'c' || k0 == 'h') { s = rectY(g, R, x, y, x + w, y + h); s.fillColor = inkColor(ink, k0 == 'c' ? 100 : 50); }
        else if (k0 == 'o') { s = rectY(g, R, x, y, x + w, y + h); s.fillColor = ink == 0 ? cmykColor(100, 100, 0, 0) : (ink == 1 ? cmykColor(0, 100, 100, 0) : cmykColor(100, 0, 100, 0)); }
        else if (k0 == '3') { s = rectY(g, R, x, y, x + w, y + h); s.fillColor = cmykColor(100, 100, 100, 0); }
        else if (k0 == 'b') { s = rectY(g, R, x, y, x + w, y + h); s.fillColor = cmykColor(50, 38, 38, 0); }
        else if (k0 == 'g') {
            s = rectY(g, R, x, y + h / 2, x + w, y + h); s.fillColor = cmykColor(50, 38, 38, 0);
            s = rectY(g, R, x, y, x + w, y + h / 2); s.fillColor = cmykColor(0, 0, 0, 50);
        } else if (k0 == 's') {
            // звезда: четверти 2, 98, 4, 96 % и лучи 100 %
            s = rectY(g, R, x, y + h / 2, x + w / 2, y + h); s.fillColor = inkColor(ink, 2);
            s = rectY(g, R, x + w / 2, y + h / 2, x + w, y + h); s.fillColor = inkColor(ink, 98);
            s = rectY(g, R, x, y, x + w / 2, y + h / 2); s.fillColor = inkColor(ink, 4);
            s = rectY(g, R, x + w / 2, y, x + w, y + h / 2); s.fillColor = inkColor(ink, 96);
            var cp = g.compoundPathItems.add(), cx = x + w / 2, cy = y + h / 2;
            for (var k = 0; k < 16; k += 2) {
                var a = k * Math.PI / 8, b = a + Math.PI / 8, tri = cp.pathItems.add();
                tri.setEntirePath([P(R, cx, cy), P(R, cx + w / 2 * Math.cos(a), cy + h / 2 * Math.sin(a)), P(R, cx + w / 2 * Math.cos(b), cy + h / 2 * Math.sin(b))]);
                tri.closed = true;
            }
            cp.pathItems[0].filled = true; cp.pathItems[0].stroked = false; cp.pathItems[0].fillColor = inkColor(ink, 100);
        }
    }

    // Дата и время как в строке вывода бюро: «November 14, 2025   23:44:05»
    function enDate(d) {
        var m = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], z = function (n) { return (n < 10 ? '0' : '') + n; };
        return m[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear() + '   ' + z(d.getHours()) + ':' + z(d.getMinutes()) + ':' + z(d.getSeconds());
    }

    // Низ пластины: контрольная полоса, «N СТРАНИЦ В ФАЙЛЕ», строка вывода, линейка, названия красок
    function footer(d, c, R, p, inks, idx, total) {
        var W = p.PW, yb = 10, cx = W / 2, i, j, s, t;
        // полоса — звеньями влево от середины пластины минус 50 мм; вышедшее за край обрезается
        var sg = c.groupItems.add(), x0 = cx - 50 - 80.02, any = false;
        while (x0 + 80 > 0) {
            any = true;
            s = rectY(sg, R, x0, yb, x0 + 35, yb + 7); s.fillColor = regTint(70);
            for (i = 0; i <= 4; i++) {
                s = hair(sg, R, x0 + 7 * i, yb, x0 + 7 * i + 7, yb + 7, 0.35); s.strokeColor = cmykColor(0, 0, 0, 0);
                s = hair(sg, R, x0 + 7 * i, yb + 7, x0 + 7 * i + 7, yb, 0.35); s.strokeColor = cmykColor(0, 0, 0, 0);
            }
            for (i = 0; i <= 5; i++) for (j = 0; j <= 1; j++) {
                s = rectY(sg, R, x0 + 35 + i * 3.5, yb + j * 3.5, x0 + 35 + (i + 1) * 3.5, yb + (j + 1) * 3.5);
                s.fillColor = regTint(70); s.stroked = true; s.strokeWidth = pt(0.1); s.strokeColor = cmykColor(0, 0, 0, 0);
            }
            s = rectY(sg, R, x0 + 56, yb + 1, x0 + 80.02, yb + 7); s.fillColor = regTint(70);
            x0 -= 80.02;
        }
        if (any) {
            var fr = rectY(sg, R, 0, yb - 0.5, cx - 50, yb + 7.5);
            fr.zOrder(ZOrderMethod.BRINGTOFRONT);
            sg.clipped = true; fr.clipping = true;
            sg.name = 'Контрольная полоса пластины';
        } else sg.remove();
        t = txtAt(c, R, total + '   СТРАНИЦ В ФАЙЛЕ', 24, 3, 1.6); fillText(t, regTint(70)); t.name = 'Страниц в файле';
        t = txtAt(c, R, (p.Company ? p.Company + '   ' : '') + p.FileName + '   ' + enDate(new Date()) + '   Page - ' + idx, 8, cx - 45, yb + 0.9);
        fillText(t, regTint(70)); t.name = 'Строка вывода';
        // линейка 10 мм у правого края: штрихи через 1 мм, крайние и средний — толще и длиннее
        var lg = c.groupItems.add();
        lg.name = 'Линейка';
        for (i = 0; i <= 10; i++) {
            var x = W - 10.1 + i;
            if (i == 0 || i == 5 || i == 10) hair(lg, R, x, yb, x, yb + 3, 0.2); else hair(lg, R, x, yb + 0.3, x, yb + 2.5, 0.1);
            if (i > 0 && i < 10) { t = txt(lg, String(10 - i), 'Arial', 0.55); fillText(t, regColor()); put(t, R, x, yb + 3.1, 0.5, 0); }
        }
        // названия красок — справа налево до линейки, каждое своей краской
        var a = inks.split(','), xr = W - 15, big = false;
        for (i = a.length - 1; i >= 0; i--) {
            var k = a[i].length == 1 ? 'CMYK'.indexOf(a[i]) : -1, nm = k >= 0 ? ['Cyan', 'Magenta', 'Yellow', 'Black'][k] : a[i];
            t = txtAt(c, R, nm, 8.5, 0, yb + 0.9);
            fillText(t, k >= 0 ? inkColor(k, 100) : spotColor(d, nm));
            t.translate(P(R, xr, 0)[0] - t.geometricBounds[2], 0);
            t.name = 'Краска ' + nm;
            xr = mm(t.geometricBounds[0] - R[0]) - 3;
            // плашка — ещё и крупно в нижней строке, как в файлах бюро: видно, чья это пластина
            if (k < 0 && !big) {
                big = true;
                var bt = txtAt(c, R, nm, 24, 0, 1.6);
                fillText(bt, spotColor(d, nm));
                bt.translate(P(R, W - 15, 0)[0] - bt.geometricBounds[2], 0);
                bt.name = 'Плашка ' + nm;
            }
        }
    }

    function drawMarks(d, c, R, p, jl, jb, jr, jt, inks, idx, total) {
        var b = p.Bleed, jc = (jt + jb) / 2, jcx = (jl + jr) / 2, sx, sy;
        // уголки с мишенями: мишень в 4 мм от края работы, в 3 мм внутрь по высоте; линия края работы до мишени
        if (p.Corners > 0) for (sx = -1; sx <= 1; sx += 2) for (sy = -1; sy <= 1; sy += 2) {
            var g = c.groupItems.add(), ax = sx < 0 ? jl : jr, ay = sy > 0 ? jt : jb, cx = ax + sx * (4 + b), cy = ay - sy * 3;
            g.name = 'Уголок с мишенью';
            target(g, R, cx, cy, p.Corners);
            hair(g, R, cx, ay, ax + sx * b, ay, 0.1);
            hair(g, R, ax, ay + sy * (1 + b), ax, ay + sy * (4 + b), 0.1);
        }
        // шкалы тонов по бокам: голубая и пурпурная слева, жёлтая и чёрная справа, между ними мишень
        if (p.Wedges) {
            var x = jl - b - 4;
            if (hasInk(inks, 'C')) wedge(c, R, x, jc + 6, 0, jt - jb);
            if (hasInk(inks, 'M')) wedge(c, R, x, jc - 6, 1, jt - jb);
            target(c, R, x, jc, p.Corners == 2 ? 2 : 1);
            x = jr + b + 4;
            if (hasInk(inks, 'Y')) wedge(c, R, x, jc + 6, 2, jt - jb);
            if (hasInk(inks, 'K')) wedge(c, R, x, jc - 6, 3, jt - jb);
            target(c, R, x, jc, p.Corners == 2 ? 2 : 1);
        }
        if (p.Bar > 0) colorBar(c, R, jl - b, jr + b, jt + b + 5.5, p.Bar == 2);
        if (p.Klap) klapanMarks(d, c, R, jl, jb - b, jcx, inks);
        if (p.Footer) footer(d, c, R, p, inks, idx, total);
    }

    // PDF как у бюро: PDF 1.7, цвет как в макете, плашки — плашками, наложение сохраняется, картинки без ужатия
    function savePlatePdf(d, path) {
        var o = new PDFSaveOptions();
        o.compatibility = PDFCompatibility.ACROBAT8;
        o.preserveEditability = false; o.generateThumbnails = false; o.viewAfterSaving = false; o.acrobatLayers = false;
        o.fontSubsetThreshold = 100;
        try { o.colorConversionID = ColorConversion.None; } catch (e) { }
        try { o.overprint = PDFOverprint.PRESERVEPDFOVERPRINT; } catch (e) { }
        try { o.colorDownsamplingMethod = DownsampleMethod.NODOWNSAMPLE; o.grayscaleDownsamplingMethod = DownsampleMethod.NODOWNSAMPLE; o.monochromeDownsamplingMethod = DownsampleMethod.NODOWNSAMPLE; } catch (e) { }
        try { o.trimMarks = false; o.registrationMarks = false; o.colorBars = false; o.pageInformation = false; } catch (e) { }
        // сохранение в PDF переименовывает документ — после него файл Illustrator сохраняется заново под своим именем
        var ai = d.fullName;
        d.saveAs(new File(path), o);
        d.saveAs(ai, new IllustratorSaveOptions());
    }

    // Копия листа рядом с PDF (.ai): области встают на пластины, появляются метки; копия сохраняется и выводится в PDF
    function run(p, outPdf, inks) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var src = app.activeDocument, inf = info(p), a = inf.split('|');
        if (a[0] != 'ok') return a[1];
        var path = '';
        try { path = src.fullName.fsName; } catch (e) { }
        if (!path || !/\.ai$/i.test(path)) return 'Сначала сохраните лист как файл Illustrator (.ai) — Файл → Сохранить как, потом ставьте на пластину.';
        var outAi = outPdf.replace(/\.pdf$/i, '') + '.ai';
        if (new File(outAi).fsName.toLowerCase() == path.toLowerCase()) return 'Файл пластин совпал бы с исходным листом — выберите другое имя.';
        var saved = false;
        if (!src.saved) { src.save(); saved = true; }
        var n = src.artboards.length, jobs = [], i;
        for (i = 0; i < n; i++) jobs.push(jobBox(src, i, p.Bleed));
        if (!inks) inks = inkList(src);
        var wd;
        try { wd = new WorkDoc(src, outAi); } catch (e) { return 'Не удалось сделать файл пластин: ' + e.message; }
        try {
            var d = wd.d, e1 = wd.grid(n, p.PW, p.PH);
            if (e1) { wd.fail(); src.activate(); return e1; }
            var sizes = [];
            for (i = 0; i < n; i++) sizes.push(abSizeMm(d, i));
            wd.collectPages();
            wd.L.name = 'Лист';
            for (i = 0; i < n; i++) {
                var R = wd.rects[i], w = sizes[i].w, h = sizes[i].h, pw = p.PaperW > 0 ? p.PaperW : w, ph = p.PaperH > 0 ? p.PaperH : h, j = jobs[i];
                var pb = paperBottom(p, pw, ph, h, j.jy), offX = (p.PW - w) / 2, pageB = pb + (ph - h) / 2;
                d.artboards[wd.ab(i)].name = 'Пластина ' + (i + 1);
                // содержимое страницы — целиком, страница встаёт на своё место на пластине
                var pr = wd.got[i];
                if (pr) {
                    var at = P(R, offX, pageB + h);
                    pr.g.hidden = false;
                    pr.g.translate(at[0] - pr.x, at[1] - pr.y);
                    pr.g.name = 'Лист ' + (i + 1);
                    wd.got[i] = null;
                }
                // разметка: бумага и клапан — видно на экране, не печатается
                var pl = (p.PW - pw) / 2, gl = layerNamed(d, PLATE_GUIDES, false);
                var r = rectY(gl, R, pl, pb, pl + pw, pb + ph);
                r.filled = false; r.stroked = true; r.strokeColor = rgbColor(220, 120, 40); r.strokeWidth = pt(0.3);
                r.name = 'Бумага ' + mmText(pw) + ' × ' + mmText(ph);
                var kl = hair(gl, R, 0, pb, p.PW, pb, 0.2);
                kl.strokeColor = rgbColor(220, 120, 40); kl.strokeDashes = [pt(2), pt(1)]; kl.name = 'Клапан';
                var t = txtAt(gl, R, 'Бумага ' + mmText(pw) + ' × ' + mmText(ph) + ' · клапан ' + mmText(pb) + ' мм' + (p.Printer ? ' · ' + p.Printer : '') +
                              ' · пластина ' + mmText(p.PW) + ' × ' + mmText(p.PH), 9, 3, pb + 1.5);
                fillText(t, rgbColor(200, 100, 30));
                // печатные метки — слоем поверх
                var jl = offX + j.jx, jb = pageB + j.jy;
                drawMarks(d, layerNamed(d, PLATE_LAYER, true), R, p, jl, jb, jl + j.jw, jb + j.jh, inks, i + 1, n);
            }
            wd.finish('plate');
            savePlatePdf(d, outPdf);
        } catch (e) {
            wd.fail();
            logLine('сбой пластины: ' + e.message + ' (строка ' + e.line + ')');
            return 'Сбой при выводе на пластину: ' + e.message;
        }
        logLine('пластина: ' + outPdf + ' (' + p.Printer + ', ' + mmText(p.PW) + '×' + mmText(p.PH) + ', клапан ' + mmText(p.Klapan) + ', краски ' + inks + ')');
        return 'Готово: ' + n + ' ' + (n == 1 ? 'страница' : 'стр.') + ' на пластине ' + mmText(p.PW) + ' × ' + mmText(p.PH) + (p.Printer ? ' (' + p.Printer + ')' : '') +
            ', краски ' + inks.replace(/,/g, ' + ') + ' — пластин ' + n * inks.split(',').length + '.\r\nPDF для вывода: ' + outPdf +
            '\r\nРядом — файл Illustrator с тем же именем, он открыт: проверьте клапан и метки.' +
            (saved ? '\r\nИсходный лист сохранён: ' + path : '') + (a[7] ? '\r\n' + a[7] : '');
    }

    return { from: from, info: info, run: run, inkList: inkList, platesTag: platesTag };
})();

// Короткое имя печатника для имени файла: «EURO ASIA по умолчанию…» → EURO_ASIA, «VIZA черн» → VIZA
function printerShort(s) {
    var w = String(s).replace(/^\s+|\s+$/g, '').split(' '), o = [], k = 0;
    for (var i = 0; i < w.length; i++) {
        if (!w[i]) continue;
        if (k > 0 && (w[i] != w[i].toUpperCase() || w[i].charAt(0) == '(' || k >= 3)) break;
        o.push(w[i]); k++;
    }
    return o.join('_');
}
function safeName(s) { return String(s).replace(/[\\\/:*?"<>|]/g, '_'); }

Bridge.PlateInfo = function (params) { return Plate.info(Plate.from(params)); };

// Без окна выбора файла — сразу в outPdf (для проверок)
Bridge.PlateRunTo = function (params, outPdf) {
    if (!hasDoc()) return 'Нет открытого документа.';
    var p = Plate.from(params);
    p.FileName = outPdf.replace(/^.*[\\\/]/, '');
    return Plate.run(p, outPdf, '');
};

// Лист на пластину: спросит имя PDF (подскажет по образцу бюро), сделает файл пластин и PDF
Bridge.PlateRun = function (params) {
    if (!PSA.has('O')) return 'Пластина для вывода входит в часть «Офсет» — её нет в вашем ключе.';
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument, p = Plate.from(params), r = Plate.info(p);
    if (r.substring(0, 3) != 'ok|') return r.substring(r.indexOf('|') + 1);
    var inks = Plate.inkList(d), base = d.name.replace(/\.[^.]*$/, '') || 'лист', folder = '';
    try { folder = d.fullName.parent.fsName; } catch (e) { folder = Folder.myDocuments.fsName; }
    var sh = printerShort(p.Printer);
    var nm = safeName(mmText(p.PW) + '-' + mmText(p.PH) + '_' + Plate.platesTag(inks, d.artboards.length) + '_PS' + (sh ? '_FOR_' + sh : '') + '_' + base + '.pdf');
    var sel = new File(folder + '/' + nm).saveDlg('PDF для вывода пластин', 'PDF:*.pdf');
    if (!sel) return '';
    var f = sel.fsName;
    if (!/\.pdf$/i.test(f)) f += '.pdf';
    var ai = f.replace(/\.pdf$/i, '') + '.ai', cur = '';
    try { cur = d.fullName.fsName; } catch (e) { }
    if (ai.toLowerCase() == cur.toLowerCase()) return 'Имя совпадает с исходным файлом — выберите другое.';
    if (!freeToReplace(ai)) return '';
    d.activate();
    p.FileName = f.replace(/^.*[\\\/]/, '');
    return Plate.run(p, f, inks);
};
