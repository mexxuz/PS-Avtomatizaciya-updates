// Тетради для брошюр и книг — как src/Signature.bas: какая полоса в какое место печатного листа,
// какой стороной и головой куда. Схема получается «сгибанием» листа: лист — сетка полос, сгибы пополам
// по очереди, последний — корешок. У первого поперечного сгиба полосы «голова к голове», полоса 1 — головой вверх.
// Сверено со стандартом: 16 полос — «5↓ 12↓ 9↓ 8↓ / 4 13 16 1» и «7↓ 10↓ 11↓ 6↓ / 2 15 14 3», 8 — «5↓ 4↓ / 8 1».

var Signature = (function () {
    // Сгибы: последний — всегда вертикальный (корешок). 2 полосы — один листок без сгибов
    function baseFolds(P) {
        switch (P) {
            case 2: return { cols: 1, rows: 1, f: '' };
            case 4: return { cols: 2, rows: 1, f: 'v' };
            case 8: return { cols: 2, rows: 2, f: 'hv' };
            case 16: return { cols: 4, rows: 2, f: 'vhv' };
            case 32: return { cols: 4, rows: 4, f: 'hvhv' };
        }
        return { cols: 0, rows: 0, f: '' };
    }

    // Схема: P, Cols, Rows; стороны A и B (как смотришь на эту сторону, ряды сверху вниз) —
    // номер полосы в тетради (1..P) и «голова вниз»
    function make(P) {
        var b = baseFolds(P), s = { P: P, Cols: b.cols, Rows: b.rows, PgA: [], RotA: [], PgB: [], RotB: [], Folds: '' };
        if (!s.Cols) return s;
        if (b.f == '') { s.PgA = [1]; s.PgB = [2]; s.RotA = [false]; s.RotB = [false]; return s; }
        var k = b.f.length;
        for (var combo = 0; combo < (1 << k); combo++) {
            var folds = '';
            for (var i = 0; i < k; i++) { var c = b.f.charAt(i); folds += (combo & (1 << i)) ? c.toUpperCase() : c; }
            simulate(s, folds);
            if (acceptable(s, b.f.indexOf('h') >= 0)) { s.Folds = folds; return s; }
        }
        return s;
    }

    // Сложить лист по сгибам и прочитать полосы: ячейка — x, y в сложенном виде, слой z (0 — низ),
    // какой стороной вверх и куда смотрят оси содержимого лицевой стороны
    function simulate(s, folds) {
        var n = s.Cols * s.Rows, cx = [], cy = [], cz = [], up = [], a00 = [], a01 = [], a10 = [], a11 = [], i, j;
        for (i = 0; i < n; i++) { cx[i] = i % s.Cols; cy[i] = Math.floor(i / s.Cols); cz[i] = 0; up[i] = true; a00[i] = 1; a01[i] = 0; a10[i] = 0; a11[i] = 1; }
        var W = s.Cols, H = s.Rows, L = 1;
        for (j = 0; j < folds.length; j++) {
            var f = folds.charAt(j), half;
            for (i = 0; i < n; i++) {
                var mv;
                if (f == 'v') mv = cx[i] >= Math.floor(W / 2);
                else if (f == 'V') mv = cx[i] < Math.floor(W / 2);
                else if (f == 'h') mv = cy[i] >= Math.floor(H / 2);
                else mv = cy[i] < Math.floor(H / 2);
                if (f == 'v' || f == 'V') {
                    if (mv) { cx[i] = W - 1 - cx[i]; cz[i] = 2 * L - 1 - cz[i]; up[i] = !up[i]; a00[i] = -a00[i]; a01[i] = -a01[i]; }
                    if (f == 'V') cx[i] -= Math.floor(W / 2);
                } else {
                    if (mv) { cy[i] = H - 1 - cy[i]; cz[i] = 2 * L - 1 - cz[i]; up[i] = !up[i]; a10[i] = -a10[i]; a11[i] = -a11[i]; }
                    if (f == 'H') cy[i] -= Math.floor(H / 2);
                }
            }
            if (f == 'v' || f == 'V') W = Math.floor(W / 2); else H = Math.floor(H / 2);
            L *= 2;
        }
        s.PgA = []; s.RotA = []; s.PgB = []; s.RotB = [];
        var last = folds.charAt(folds.length - 1);
        for (i = 0; i < n; i++) {
            // корешок — последний сгиб: «v» — справа, тетрадь поворачивается на 180°, чтобы корешок был слева
            var rot = last == 'v' ? (-a11[i] < 0) : (a11[i] < 0);
            var order = L - 1 - cz[i], c = i % s.Cols, r = s.Rows - 1 - Math.floor(i / s.Cols);
            var ia = r * s.Cols + c, ib = r * s.Cols + (s.Cols - 1 - c);
            if (up[i]) { s.PgA[ia] = 2 * order + 1; s.PgB[ib] = 2 * order + 2; }
            else { s.PgA[ia] = 2 * order + 2; s.PgB[ib] = 2 * order + 1; }
            s.RotA[ia] = rot; s.RotB[ib] = rot;
        }
    }

    function acceptable(s, hasH) {
        var i;
        if (hasH && s.Rows >= 2) {
            var r0 = Math.floor(s.Rows / 2) - 1;
            for (i = 0; i < s.Cols; i++) {
                if (!s.RotA[r0 * s.Cols + i]) return false;
                if (s.RotA[(r0 + 1) * s.Cols + i]) return false;
            }
        }
        for (i = 0; i < s.Cols * s.Rows; i++) {
            if (s.PgA[i] == 1 && s.RotA[i]) return false;
            if (s.PgB[i] == 1 && s.RotB[i]) return false;
        }
        return true;
    }

    function sideText(pg, rot, cols) {
        var t = '';
        for (var i = 0; i < pg.length; i++) { if (i > 0) t += i % cols == 0 ? ' / ' : ' '; t += pg[i] + (rot[i] ? 'v' : ''); }
        return t;
    }
    function schemeText(s) { return 'A: ' + sideText(s.PgA, s.RotA, s.Cols) + '; B: ' + sideText(s.PgB, s.RotB, s.Cols); }

    // Тетради, чтобы покрыть total полос: сначала самые большие (maxP), остаток — меньшими. «16,16,8»
    function splitSizes(total, maxP) {
        var left = total, P = maxP, t = [];
        while (left > 0 && P >= 2) {
            while (left >= P) { t.push(P); left -= P; }
            P = Math.floor(P / 2);
        }
        return t.join(',');
    }

    // Полосы каждой тетради: массив мест в блоке (1..T) для полос тетради 1..P (индекс 0..P-1)
    function assign(T, sizes, saddle) {
        var out = [], sz = sizes.split(','), lo = 1, hi = T;
        for (var s = 0; s < sz.length; s++) {
            var P = parseInt(sz[s], 10), a = [];
            for (var i = 1; i <= P; i++) {
                if (saddle) a.push(i <= P / 2 ? lo + i - 1 : hi - (P - i));
                else a.push(lo + i - 1);
            }
            if (saddle) { lo += P / 2; hi -= P / 2; } else lo += P;
            out.push(a);
        }
        return out;
    }

    // Порядок полос блока с пустыми (0): страницы first..last, дополнить до кратного unit.
    // Пустые — перед двумя последними полосами (задняя обложка и её оборот) или в самом конце
    function pad(first, last, unit, beforeBack) {
        var c = [], n = last - first + 1, blanks = (unit - n % unit) % unit, keepEnd = beforeBack && n >= 4 ? 2 : 0, i;
        for (i = first; i <= last - keepEnd; i++) c.push(i);
        for (i = 0; i < blanks; i++) c.push(0);
        for (i = last - keepEnd + 1; i <= last; i++) c.push(i);
        return c;
    }

    return { make: make, schemeText: schemeText, splitSizes: splitSizes, assign: assign, pad: pad };
})();
