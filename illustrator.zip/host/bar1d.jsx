// Линейные штрихкоды — как src/Bar1D.bas: EAN-13, EAN-8, UPC-A, UPC-E, Code 128, GS1-128, Code 39, ITF-14.
// Результат — строка модулей ('1' — полоса, '0' — просвет) и подписи под кодом.
// { modules, labels: [{ text, cx }], guard, quietL, quietR, bearer, error }

var Bar1D = (function () {
    var EAN_L = '0001101,0011001,0010011,0111101,0100011,0110001,0101111,0111011,0110111,0001011'.split(',');
    var EAN_G = '0100111,0110011,0011011,0100001,0011101,0111001,0000101,0010001,0001001,0010111'.split(',');
    var EAN_R = '1110010,1100110,1101100,1000010,1011100,1001110,1010000,1000100,1001000,1110100'.split(',');
    var EAN_PARITY = 'LLLLLL,LLGLGG,LLGGLG,LLGGGL,LGLLGG,LGGLLG,LGGGLL,LGLGLG,LGLGGL,LGGLGL'.split(',');
    var UPCE_PARITY = 'EEEOOO,EEOEOO,EEOOEO,EEOOOE,EOEEOO,EOOEEO,EOOOEE,EOEOEO,EOEOOE,EOOEOE'.split(',');
    var C128 = ('212222,222122,222221,121223,121322,131222,122213,122312,132212,221213,' +
        '221312,231212,112232,122132,122231,113222,123122,123221,223211,221132,' +
        '221231,213212,223112,312131,311222,321122,321221,312212,322112,322211,' +
        '212123,212321,232121,111323,131123,131321,112313,132113,132311,211313,' +
        '231113,231311,112133,112331,132131,113123,113321,133121,313121,211331,' +
        '231131,213113,213311,213131,311123,311321,331121,312113,312311,332111,' +
        '314111,221411,431111,111224,111422,121124,121421,141122,141221,112214,' +
        '112412,122114,122411,142112,142211,241211,221114,413111,241112,134111,' +
        '111242,121142,121241,114212,124112,124211,411212,421112,421211,212141,' +
        '214121,412121,111143,111341,131141,114113,114311,411113,411311,113141,' +
        '114131,311141,411131,211412,211214,211232,2331112').split(',');

    function rep(ch, n) { var s = ''; for (var i = 0; i < n; i++) s += ch; return s; }
    function onlyDigits(s) { return /^\d+$/.test(s); }
    // Контрольная цифра по модулю 10 (EAN, UPC, ITF, GTIN)
    function mod10(s) {
        var sum = 0, w = 3;
        for (var i = s.length - 1; i >= 0; i--) { sum += parseInt(s.charAt(i), 10) * w; w = 4 - w; }
        return String((10 - (sum % 10)) % 10);
    }
    function res() { return { modules: '', labels: [], guard: '', quietL: 0, quietR: 0, bearer: false, error: '' }; }
    function err(t) { var r = res(); r.error = t; return r; }
    function label(r, t, cx) { r.labels.push({ text: t, cx: cx }); }
    // Ширины (полоса, просвет, полоса…) -> модули
    function widths(w) { var s = '', bar = true; for (var i = 0; i < w.length; i++) { s += rep(bar ? '1' : '0', parseInt(w.charAt(i), 10)); bar = !bar; } return s; }
    // Данные нужной длины с контрольной цифрой; '' — не годится
    function withCheck(s, n) {
        s = trimS(s);
        if (!onlyDigits(s)) return '';
        if (s.length == n) return s + mod10(s);
        if (s.length == n + 1 && mod10(s.substring(0, n)) == s.charAt(n)) return s;
        return '';
    }

    function EAN13(s) {
        var d = withCheck(s, 12), r = res(), i, m;
        if (!d) return err('EAN-13: нужно 12 или 13 цифр (13-я — верная контрольная)');
        var par = EAN_PARITY[parseInt(d.charAt(0), 10)];
        m = '101';
        for (i = 1; i <= 6; i++) m += (par.charAt(i - 1) == 'L' ? EAN_L : EAN_G)[parseInt(d.charAt(i), 10)];
        m += '01010';
        for (i = 7; i <= 12; i++) m += EAN_R[parseInt(d.charAt(i), 10)];
        m += '101';
        r.modules = m;
        r.guard = '111' + rep('0', 42) + '11111' + rep('0', 42) + '111';
        r.quietL = 11; r.quietR = 7;
        label(r, d.charAt(0), -5.5); label(r, d.substr(1, 6), 24); label(r, d.substr(7, 6), 71);
        return r;
    }

    function EAN8(s) {
        var d = withCheck(s, 7), r = res(), i, m;
        if (!d) return err('EAN-8: нужно 7 или 8 цифр (8-я — верная контрольная)');
        m = '101';
        for (i = 0; i < 4; i++) m += EAN_L[parseInt(d.charAt(i), 10)];
        m += '01010';
        for (i = 4; i < 8; i++) m += EAN_R[parseInt(d.charAt(i), 10)];
        m += '101';
        r.modules = m;
        r.guard = '111' + rep('0', 28) + '11111' + rep('0', 28) + '111';
        r.quietL = 7; r.quietR = 7;
        label(r, d.substring(0, 4), 17); label(r, d.substring(4), 50);
        return r;
    }

    function UPCA(s) {
        var d = withCheck(s, 11);
        if (!d) return err('UPC-A: нужно 11 или 12 цифр (12-я — верная контрольная)');
        var r = EAN13('0' + d);
        // у UPC-A удлинены ещё крайние цифры
        r.guard = rep('1', 10) + rep('0', 35) + '11111' + rep('0', 35) + rep('1', 10);
        r.quietL = 9; r.quietR = 9;
        r.labels = [];
        label(r, d.charAt(0), -5); label(r, d.substr(1, 5), 27.5); label(r, d.substr(6, 5), 67.5); label(r, d.charAt(11), 100);
        return r;
    }

    // UPC-E -> UPC-A (11 цифр без контрольной)
    function upceToUpca(ns, d) {
        var last = d.charAt(5);
        if (last == '0' || last == '1' || last == '2') return ns + d.substring(0, 2) + last + '0000' + d.substr(2, 3);
        if (last == '3') return ns + d.substring(0, 3) + '00000' + d.substr(3, 2);
        if (last == '4') return ns + d.substring(0, 4) + '00000' + d.charAt(4);
        return ns + d.substring(0, 5) + '0000' + last;
    }

    function UPCE(s) {
        s = trimS(s);
        if (!onlyDigits(s) || s.length < 6 || s.length > 8) return err('UPC-E: нужно 6, 7 или 8 цифр');
        var ns, body, r = res(), i, m;
        if (s.length == 6) { ns = '0'; body = s; } else { ns = s.charAt(0); body = s.substr(1, 6); }
        if (ns != '0' && ns != '1') return err('UPC-E: первая цифра должна быть 0 или 1');
        var chk = mod10(upceToUpca(ns, body));
        if (s.length == 8 && s.charAt(7) != chk) return err('UPC-E: неверная контрольная цифра');
        var par = UPCE_PARITY[parseInt(chk, 10)];
        m = '101';
        // для системы 0: E — набор G, O — набор L; для системы 1 наоборот
        for (i = 0; i < 6; i++) m += ((par.charAt(i) == 'E') == (ns == '0') ? EAN_G : EAN_L)[parseInt(body.charAt(i), 10)];
        m += '010101';
        r.modules = m;
        r.guard = '111' + rep('0', 42) + '111111';
        r.quietL = 9; r.quietR = 7;
        label(r, ns, -5); label(r, body, 24); label(r, chk, 56);
        return r;
    }

    // ---------- Code 128 ----------

    function digitRun(s, pos) { var n = 0; while (pos + n < s.length && /\d/.test(s.charAt(pos + n))) n++; return n; }

    // Строка -> значения Code 128. Символ 29 (GS) превращается в FNC1; gs1 — FNC1 в начале. null — ошибка (e.text).
    function values128(s, gs1, e) {
        var v = [], i, cset = '', ch, n, want;
        for (i = 0; i < s.length; i++) if (s.charCodeAt(i) > 127) { e.text = 'Code 128: допустимы только латиница, цифры и знаки (без кириллицы)'; return null; }
        i = 0;
        while (i < s.length) {
            n = digitRun(s, i);
            if (n >= 4 && (n % 2 == 0 || cset != 'C')) want = 'C';
            else if (cset == 'C' && n >= 2) want = 'C';
            else if (s.charCodeAt(i) == 29 && cset != '') want = cset;
            else if (s.charCodeAt(i) < 32) want = 'A';
            else want = 'B';
            // нечётная серия цифр: первую — в текущем наборе, остальные — в C
            if (want == 'C' && cset != 'C' && n % 2 == 1) {
                if (cset == '') { cset = 'B'; v.push(104); if (gs1) v.push(102); }
                v.push(s.charCodeAt(i) - 32);
                i++;
                want = 'C';
            }
            if (want != cset) {
                if (cset == '') { v.push(want == 'A' ? 103 : (want == 'B' ? 104 : 105)); if (gs1) v.push(102); }
                else v.push(want == 'A' ? 101 : (want == 'B' ? 100 : 99));
                cset = want;
            }
            ch = s.charCodeAt(i);
            if (ch == 29) { v.push(102); i++; }
            else if (cset == 'C') { v.push(parseInt(s.substr(i, 2), 10)); i += 2; }
            else if (cset == 'A') { v.push(ch < 32 ? ch + 64 : ch - 32); i++; }
            else { v.push(ch - 32); i++; }
        }
        if (!v.length) { v.push(104); if (gs1) v.push(102); }
        return v;
    }

    function modules128(v) {
        var sum = v[0], m = widths(C128[v[0]]);
        for (var i = 1; i < v.length; i++) { sum += v[i] * i; m += widths(C128[v[i]]); }
        return m + widths(C128[sum % 103]) + widths(C128[106]);
    }

    function Code128(s) {
        if (!s.length) return err('Code 128: пустые данные');
        var e = {}, v = values128(s, false, e), r = res();
        if (!v) return err(e.text);
        r.modules = modules128(v);
        r.quietL = 10; r.quietR = 10;
        label(r, s.replace(/\u001d/g, ' '), r.modules.length / 2);
        return r;
    }

    // Длина данных для ИИ с фиксированной длиной (по первым двум цифрам ИИ)
    function gs1Fixed(ai) {
        var a = ai.substring(0, 2);
        if (a == '00') return 18;
        if (a == '01' || a == '02' || a == '03') return 14;
        if (a == '04') return 16;
        if (/^1[1-9]$/.test(a)) return 6;
        if (a == '20') return 2;
        if (/^3[1-6]$/.test(a)) return 6;
        if (a == '41') return 13;
        return 0;
    }

    // «(01)04601234567893(10)ABC» -> данные с разделителем GS после полей переменной длины.
    // Без скобок строка берётся как есть. r: { human, error }
    function GS1Parse(s, r) {
        s = trimS(s);
        r.human = ''; r.error = '';
        if (s.charAt(0) != '(') { r.human = s.replace(/\u001d/g, ' '); return s; }
        var parts = s.substring(1).split('('), out = '';
        for (var i = 0; i < parts.length; i++) {
            var p = parts[i].indexOf(')');
            if (p < 0) { r.error = 'GS1: не закрыта скобка'; return ''; }
            var ai = parts[i].substring(0, p), dat = parts[i].substring(p + 1);
            if (!onlyDigits(ai) || ai.length < 2 || ai.length > 4) { r.error = 'GS1: неверный идентификатор (' + ai + ')'; return ''; }
            var fl = gs1Fixed(ai);
            if (fl > 0 && dat.length != fl) {
                if ((ai == '01' || ai == '02') && dat.length == 13 && onlyDigits(dat)) dat += mod10(dat);
                else { r.error = 'GS1: для (' + ai + ') нужно ' + fl + ' символов'; return ''; }
            }
            out += ai + dat;
            r.human += '(' + ai + ')' + dat;
            if (fl == 0 && i < parts.length - 1) out += '\u001d';
        }
        return out;
    }

    function GS1_128(s) {
        var g = {}, dat = GS1Parse(s, g);
        if (g.error) return err(g.error);
        if (!dat.length) return err('GS1-128: пустые данные');
        var e = {}, v = values128(dat, true, e), r = res();
        if (!v) return err(e.text);
        r.modules = modules128(v);
        r.quietL = 10; r.quietR = 10;
        label(r, g.human, r.modules.length / 2);
        return r;
    }

    // ---------- Code 39 ----------

    function Code39(s) {
        var CH = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%', r = res(), i, j, p, m = '', w;
        var pat = ('000110100,100100001,001100001,101100000,000110001,100110000,001110000,000100101,100100100,001100100,' +
                   '100001001,001001001,101001000,000011001,100011000,001011000,000001101,100001100,001001100,000011100,' +
                   '100000011,001000011,101000010,000010011,100010010,001010010,000000111,100000110,001000110,000010110,' +
                   '110000001,011000001,111000000,010010001,110010000,011010000,010000101,110000100,011000100,010010100,' +
                   '010101000,010100010,010001010,000101010').split(',');
        s = trimS(s).toUpperCase();
        if (!s.length) return err('Code 39: пустые данные');
        for (i = 0; i < s.length; i++) if (CH.indexOf(s.charAt(i)) < 0 || s.charAt(i) == '*') return err('Code 39: допустимы цифры, латинские буквы, пробел и - . $ / + %');
        for (i = 0; i <= s.length + 1; i++) {
            p = (i == 0 || i == s.length + 1) ? CH.indexOf('*') : CH.indexOf(s.charAt(i - 1));
            w = pat[p];
            for (j = 0; j < 9; j++) m += rep(j % 2 == 0 ? '1' : '0', w.charAt(j) == '1' ? 3 : 1);
            if (i <= s.length) m += '0';
        }
        r.modules = m;
        r.quietL = 10; r.quietR = 10;
        label(r, s, m.length / 2);
        return r;
    }

    // ---------- ITF-14 ----------

    function ITF14(s) {
        var pat = 'NNWWN,WNNNW,NWNNW,WWNNN,NNWNW,WNWNN,NWWNN,NNNWW,WNNWN,NWNWN'.split(','), d = withCheck(s, 13), r = res(), i, j, m;
        if (!d) return err('ITF-14: нужно 13 или 14 цифр (14-я — верная контрольная)');
        m = '1010';
        for (i = 0; i < 14; i += 2) {
            var a = pat[parseInt(d.charAt(i), 10)], b = pat[parseInt(d.charAt(i + 1), 10)];
            for (j = 0; j < 5; j++) { m += rep('1', a.charAt(j) == 'W' ? 3 : 1); m += rep('0', b.charAt(j) == 'W' ? 3 : 1); }
        }
        m += '11101';
        r.modules = m;
        r.quietL = 10; r.quietR = 10;
        r.bearer = true;
        label(r, d.charAt(0) + ' ' + d.substr(1, 2) + ' ' + d.substr(3, 5) + ' ' + d.substr(8, 5) + ' ' + d.charAt(13), m.length / 2);
        return r;
    }

    function encode(type, v) {
        switch (type) {
            case 'EAN-13': return EAN13(v);
            case 'EAN-8': return EAN8(v);
            case 'UPC-A': return UPCA(v);
            case 'UPC-E': return UPCE(v);
            case 'GS1-128': return GS1_128(v);
            case 'Code 39': return Code39(v);
            case 'ITF-14': return ITF14(v);
            default: return Code128(v);
        }
    }

    return { encode: encode, mod10: mod10, GS1Parse: GS1Parse, onlyDigits: onlyDigits };
})();
