// Общие помощники для Illustrator: JSON (в ExtendScript его нет), настройки, журнал, единицы.

// ---------- JSON ----------
var J = function (s) {
    s = String(s);
    var o = '', i, c, n;
    for (i = 0; i < s.length; i++) {
        c = s.charAt(i); n = s.charCodeAt(i);
        if (c == '"') o += '\\"';
        else if (c == '\\') o += '\\\\';
        else if (n == 10) o += '\\n';
        else if (n == 13) o += '\\r';
        else if (n == 9) o += '\\t';
        else if (n < 32 || n == 0x2028 || n == 0x2029) o += '\\u' + ('000' + n.toString(16)).slice(-4);
        else o += c;
    }
    return '"' + o + '"';
};

// значение -> текст JSON (объекты, массивы, строки, числа, да/нет)
function toJson(v) {
    var i, a, k;
    if (v === null || v === undefined) return 'null';
    if (typeof v == 'string') return J(v);
    if (typeof v == 'number') return isFinite(v) ? String(v) : 'null';
    if (typeof v == 'boolean') return v ? 'true' : 'false';
    if (v instanceof Array) {
        a = [];
        for (i = 0; i < v.length; i++) a.push(toJson(v[i]));
        return '[' + a.join(',') + ']';
    }
    a = [];
    for (k in v) if (v.hasOwnProperty(k)) a.push(J(k) + ':' + toJson(v[k]));
    return '{' + a.join(',') + '}';
}

// JSON -> значение. Только для своих файлов и ответов панели.
function fromJson(s) {
    if (!s) return null;
    try { return eval('(' + s + ')'); } catch (e) { return null; }
}

// ---------- файлы ----------
var PSA_DATA = Folder.userData.fsName + '/PS Automation';

// Ход долгой работы — для панели: Illustrator занят и сам ничего не показывает, панель читает этот файл
// и рисует «3 из 26» с кнопкой «Стоп». Стоп — файл-флажок, который кладёт панель.
var Progress = {
    file: PSA_DATA + '/progress.json', stopFile: PSA_DATA + '/stop.flag',
    start: function (title) { try { new File(this.stopFile).remove(); } catch (e) { } this.title = title; this.step(0, 0, ''); },
    step: function (i, n, note) { try { writeText(this.file, toJson({ t: this.title || '', i: i, n: n, s: note || '' })); } catch (e) { } },
    stopped: function () { try { return new File(this.stopFile).exists; } catch (e) { return false; } },
    end: function () { try { new File(this.file).remove(); } catch (e) { } try { new File(this.stopFile).remove(); } catch (e) { } }
};

function readText(path) {
    var f = new File(path);
    if (!f.exists) return '';
    f.encoding = 'UTF-8';
    if (!f.open('r')) return '';
    var s = f.read();
    f.close();
    return s;
}

function writeText(path, s, append) {
    var f = new File(path);
    var d = f.parent;
    if (!d.exists) d.create();
    f.encoding = 'UTF-8';
    f.lineFeed = 'Windows';
    if (!f.open(append ? 'a' : 'w')) return false;
    f.write(s);
    f.close();
    return true;
}

// ---------- настройки ----------
// Как GetSetting/SaveSetting в CorelDRAW: раздел, ключ, значение строкой.
// Хранятся в %APPDATA%\PS Automation\illustrator.json.
var Settings = (function () {
    var path = PSA_DATA + '/illustrator.json', data = null;
    function load() {
        if (data) return data;
        data = fromJson(readText(path)) || {};
        return data;
    }
    return {
        get: function (sec, key, dflt) {
            var d = load();
            if (d[sec] && d[sec].hasOwnProperty(key)) return String(d[sec][key]);
            return dflt === undefined ? '' : String(dflt);
        },
        num: function (sec, key, dflt) {
            var s = this.get(sec, key, '');
            if (s === '') return dflt;
            var n = parseFloat(s.replace(',', '.'));
            return isNaN(n) ? dflt : n;
        },
        set: function (sec, key, v) {
            var d = load();
            if (!d[sec]) d[sec] = {};
            d[sec][key] = String(v);
            writeText(path, toJson(d));
        },
        del: function (sec, key) {
            var d = load();
            if (d[sec]) { delete d[sec][key]; writeText(path, toJson(d)); }
        },
        // все ключи раздела — как GetAllSettings
        keys: function (sec) {
            var d = load(), a = [];
            if (d[sec]) for (var k in d[sec]) if (d[sec].hasOwnProperty(k)) a.push(k);
            return a;
        }
    };
})();

// ---------- журнал ----------
// %APPDATA%\PS Automation\illustrator.log: что нажимали и что ответили — для разбора сбоев.
// Больше 1 МБ — начинается заново (прежний остаётся рядом как .old).
function logLine(t) {
    var p = PSA_DATA + '/illustrator.log', f = new File(p), d = new Date();
    var z = function (n) { return (n < 10 ? '0' : '') + n; };
    try {
        if (f.exists && f.length > 1048576) {
            var old = new File(p + '.old');
            if (old.exists) old.remove();
            f.rename('illustrator.log.old');
        }
        writeText(p, d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + ' ' + z(d.getHours()) + ':' +
            z(d.getMinutes()) + ':' + z(d.getSeconds()) + '  ' + String(t).replace(/[\r\n]+/g, ' / ') + '\r\n', true);
        // сбой — отметка для панели: отчёт о нём уйдёт разработчику сам, если это разрешено (как LogErr у CorelDRAW)
        if (/^(сбой|СБОЙ)/.test(String(t)) && !(typeof PSA != 'undefined' && PSA.quiet)) writeText(PSA_DATA + '/crash.flag', String(t).substring(0, 300) + '\r\n', true);
    } catch (e) { }
}

// ---------- единицы ----------
var PT_MM = 25.4 / 72;
// Видимые границы объекта. У объектов с графическим стилем (тень и др.) Illustrator порой отдаёт нелепые числа
// (левый край правее правого, десятки тысяч пунктов) — тогда берём настоящие границы, без эффектов.
function visBounds(it) {
    var v = it.visibleBounds;
    if (v[0] <= v[2] && v[3] <= v[1] && Math.abs(v[0]) < 1e5 && Math.abs(v[1]) < 1e5 && Math.abs(v[2]) < 1e5 && Math.abs(v[3]) < 1e5) return v;
    return it.geometricBounds;
}
function mm(pt) { return pt * PT_MM; }
function pt(mmv) { return mmv / PT_MM; }

// Число из текста: запятая или точка, пусто — запасное
function toNum(s, dflt) {
    s = String(s === undefined || s === null ? '' : s).replace(/^\s+|\s+$/g, '').replace(',', '.');
    if (s === '') return dflt;
    var n = parseFloat(s);
    return isNaN(n) ? dflt : n;
}

// Поля панели «ключ=значение|…» -> объект
function parseKV(s) {
    var o = {}, parts = String(s || '').split('|'), i, p;
    for (i = 0; i < parts.length; i++) {
        p = parts[i].indexOf('=');
        if (p > 0) o[parts[i].substring(0, p)] = parts[i].substring(p + 1);
    }
    return o;
}
