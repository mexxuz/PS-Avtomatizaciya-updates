// Офсетная часть: развороты → полосы (src/Spreads.bas), спуск на скрепку (src/Booklet.bas),
// брошюра и книга тетрадями (src/Book.bas). Документ брошюры — каждая монтажная область — полоса, по порядку.
// Итог — новый файл (копия источника): листы — новыми монтажными областями, каждая полоса — в рамке
// с вылетом (обтравочная группа); исходные области и слои убираются.

var FOLD_LAYER = 'Метки фальцовки';

// ---------- общее ----------

function plural(n, one, few, many) {
    if (n % 10 == 1 && n % 100 != 11) return one;
    if (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20)) return few;
    return many;
}

// Файл открыт — закрыть, чтобы записать заново (с правками — спросить). false — отказались
function freeToReplace(path) {
    for (var i = app.documents.length - 1; i >= 0; i--) {
        var d = app.documents[i], p = '';
        try { p = d.fullName.fsName; } catch (e) { }
        if (p.toLowerCase() != new File(path).fsName.toLowerCase()) continue;
        if (!d.saved && !confirm('В файле «' + d.name + '» есть несохранённые правки — они пропадут, файл заменится.\r\n\r\nЗаменить?', true, 'Заменить файл')) return false;
        d.close(SaveOptions.DONOTSAVECHANGES);
    }
    return true;
}

function savedPath(d) { try { return d.saved ? d.fullName.fsName : ''; } catch (e) { return ''; } }
function abSizeMm(d, i) { var r = d.artboards[i].artboardRect; return { w: mm(r[2] - r[0]), h: mm(r[1] - r[3]) }; }

// Рабочий файл — копия источника (быстро: копии внутри одного документа Illustrator делает мгновенно,
// между документами — минуты). Полосы собираются группами на слое «Полосы», листы — новыми областями
// поверх исходных; в конце исходные области и слои убираются.
function WorkDoc(src, outPath) {
    var f = new File(outPath), i;
    if (f.exists) f.remove();
    if (!src.fullName.copy(f)) throw new Error('не удалось записать файл ' + outPath);
    var old = app.userInteractionLevel;
    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    try { this.d = app.open(f); } finally { app.userInteractionLevel = old; }
    var d = this.d;
    this.orig = d.artboards.length;
    this.srcLayers = [];
    for (i = 0; i < d.layers.length; i++) { d.layers[i].locked = false; this.srcLayers.push(d.layers[i]); }
    // свои слои — с чистого листа, даже если в источнике есть одноимённые
    for (i = 0; i < this.srcLayers.length; i++) this.srcLayers[i].name = '~ ' + this.srcLayers[i].name;
    this.L = d.layers.add();
    this.L.name = 'Полосы';
    this.L.zOrder(ZOrderMethod.SENDTOBACK);
    this.got = {};
    this.rects = [];
}

// Полосы (области источника) — по группе на каждую, спрятанные; копии берутся отсюда
WorkDoc.prototype.collectPages = function () {
    var map = itemsByBoard(this.d, this.srcLayers);
    for (var k = 0; k < this.orig; k++) {
        var list = map[k] || [], R = this.d.artboards[k].artboardRect;
        if (!list.length) { this.got[k] = null; continue; }
        var g = this.L.groupItems.add();
        for (var i = 0; i < list.length; i++) { try { list[i].locked = false; } catch (e) { } list[i].move(g, ElementPlacement.PLACEATBEGINNING); }
        g.hidden = true;
        this.got[k] = { g: g, x: R[0], y: R[1] };
    }
};

// Копия полосы pno (1..n), левый верх — в точку (x, y) пт; null — полоса пустая
WorkDoc.prototype.copy = function (pno, x, y) {
    var p = this.got[pno - 1];
    if (!p) return null;
    var g = p.g.duplicate();
    g.hidden = false;
    g.translate(x - p.x, y - p.y);
    return g;
};

// Середина холста (пт). Illustrator не даёт её прочитать, а пробная область за краем холста портит
// документ (ошибка, потом сбои и падение). Начало плиток печати (pageOrigin) ставится при создании файла
// так, что страница печати (Letter 612 × 792, или A4 — разница в пару сантиметров) — по центру холста.
function canvasCenter(d) { var o = d.pageOrigin; return [o[0] + 306, o[1] + 396]; }

// Области листов сеткой по центру холста (холст 5,78 × 5,78 м; 10 см от краёв — запас на неточность).
// Ответ — '' или почему не вышло; область листа i — ab(i)
WorkDoc.prototype.grid = function (n, W, H) {
    var d = this.d, GAP = 30, LIM = 5500, i;
    var per = Math.max(1, Math.min(n, Math.floor((LIM + GAP) / (W + GAP)))), rows = Math.ceil(n / per), gw = per * (W + GAP) - GAP, gh = rows * (H + GAP) - GAP;
    if (W > LIM || gh > LIM || this.orig + n > 1000)
        return 'Листов ' + n + ' по ' + mmText(W) + ' × ' + mmText(H) + ' мм не помещаются в один файл Illustrator (холст около 5,7 × 5,7 м). Разбейте документ на части.';
    var c = canvasCenter(d), left = c[0] - pt(gw) / 2, top = c[1] + pt(gh) / 2;
    this.base = d.artboards.length;
    for (i = 0; i < n; i++) {
        var x = left + pt((i % per) * (W + GAP)), y = top - pt(Math.floor(i / per) * (H + GAP)), R = [x, y, x + pt(W), y - pt(H)];
        d.artboards.add(R);
        this.rects.push(R);
    }
    return '';
};
WorkDoc.prototype.ab = function (i) { return this.base + i; };

// Готово: убрать заготовки полос, исходные области и слои; сохранить
WorkDoc.prototype.finish = function (kind) {
    var d = this.d, i;
    for (var k in this.got) if (this.got.hasOwnProperty(k) && this.got[k]) this.got[k].g.remove();
    for (i = this.orig - 1; i >= 0; i--) d.artboards.remove(i);
    for (i = 0; i < this.srcLayers.length; i++) { try { this.srcLayers[i].locked = false; this.srcLayers[i].remove(); } catch (e) { } }
    if (kind) setDocProp(d, 'kind', kind);
    d.artboards.setActiveArtboardIndex(0);
    d.save();
};
WorkDoc.prototype.fail = function () {
    var f = null;
    try { f = this.d.fullName; this.d.close(SaveOptions.DONOTSAVECHANGES); } catch (e) { }
    try { if (f) f.remove(); } catch (e) { }
};

// Объекты источника — по монтажным областям (центр объекта в области), снизу вверх: { ab: [объекты] }
function itemsByBoard(d, layers) {
    var map = {}, li;
    function walk(L) {
        if (!L.visible || !L.printable) return;
        var n = L.pageItems.length, i;
        for (i = L.layers.length - 1; i >= 0; i--) walk(L.layers[i]);
        for (i = n - 1; i >= 0; i--) {
            var it = L.pageItems[i];
            if (it.parent != L || it.hidden) continue;
            try { if (it.guides) continue; } catch (e) { }
            var ab = abIndexOf(d, it);
            if (ab < 0) continue;
            (map[ab] = map[ab] || []).push(it);
        }
    }
    for (li = layers.length - 1; li >= 0; li--) walk(layers[li]);
    return map;
}

// Группа it — в рамку (x, y — левый верх, мм от угла области R) с обтравкой; ответ — обтравочная группа
function clipInto(it, L, R, x, y, w, h, name) {
    var cg = L.groupItems.add();
    it.move(cg, ElementPlacement.PLACEATEND);
    var fr = imRect(cg, R, x, y, w, h);
    fr.zOrder(ZOrderMethod.BRINGTOFRONT);
    cg.clipped = true;
    fr.clipping = true;
    cg.name = name;
    return cg;
}

// ---------- развороты → полосы ----------

var Spreads = {};

// Похоже ли, что монтажные области — развороты: «ширина|высота полосы|какие — развороты|какие — одиночные» или ''
Spreads.Guess = function (d) {
    var n = d.artboards.length, nw = 0, nh = 0, i, wide = [], singles = [];
    for (i = 0; i < n; i++) { var s = abSizeMm(d, i); if (nw == 0 || s.w < nw) { nw = s.w; nh = s.h; } }
    if (n >= 1) { var s1 = abSizeMm(d, 0); if (Math.abs(nw - s1.w) < 1 && s1.w > s1.h * 1.15) { nw = s1.w / 2; nh = s1.h; } }
    for (i = 0; i < n; i++) { var z = abSizeMm(d, i); if (z.w > nw * 1.5 || z.h > nh * 1.5) wide.push(i + 1); else singles.push(i + 1); }
    if (!wide.length) return '';
    return mmText(nw) + '|' + mmText(nh) + '|' + ranges(wide) + '|' + ranges(singles);
};

// [1,2,3,5] → «1–3, 5»
function ranges(a) {
    if (!a.length) return '';
    var t = [], lo = a[0], hi = lo;
    for (var i = 1; i < a.length; i++) {
        if (a[i] == hi + 1) hi = a[i];
        else { t.push(lo == hi ? String(lo) : lo + '–' + hi); lo = hi = a[i]; }
    }
    t.push(lo == hi ? String(lo) : lo + '–' + hi);
    return t.join(', ');
}

// Объекты источника, заходящие в прямоугольник rr (пт), снизу вверх
function itemsInRect(layers, rr) {
    var out = [];
    function walk(L) {
        if (!L.visible || !L.printable) return;
        var i;
        for (i = L.layers.length - 1; i >= 0; i--) walk(L.layers[i]);
        for (i = L.pageItems.length - 1; i >= 0; i--) {
            var it = L.pageItems[i];
            if (it.parent != L || it.hidden) continue;
            try { if (it.guides) continue; } catch (e) { }
            var b = visBounds(it), e = 0.03;
            if (b[2] > rr[0] + e && b[0] < rr[2] - e && b[1] > rr[3] + e && b[3] < rr[1] - e) out.push(it);
        }
    }
    for (var li = layers.length - 1; li >= 0; li--) walk(layers[li]);
    return out;
}

Spreads.SplitDoc = function (w, h, coverSpread, bleed, outPath) {
    if (!hasDoc()) return 'Нет открытого документа.';
    if (w <= 0 || h <= 0) return 'Укажите формат одной полосы, мм.';
    var src = app.activeDocument, sp = savedPath(src);
    if (!sp) return 'Сначала сохраните документ.';
    if (new File(outPath).fsName.toLowerCase() == sp.toLowerCase()) return 'Полосы нельзя сохранить поверх исходного файла.';
    var cells = [], grid = [], i, r, c, wd;
    try { wd = new WorkDoc(src, outPath); } catch (e) { return 'Не удалось сделать файл полос: ' + e.message; }
    var d = wd.d, n0 = wd.orig;
    // 1. где полосы на каждой области: [область, левый край, верх] — мм от левого верхнего угла
    for (i = 0; i < n0; i++) {
        var s = abSizeMm(d, i), cols = Math.floor(s.w / w + 0.02), rows = Math.floor(s.h / h + 0.02), gx = 0, gy = 0, pairs = false;
        if (cols < 1 || rows < 1) { wd.fail(); src.activate(); return 'Страница ' + (i + 1) + ' (' + mmText(s.w) + ' × ' + mmText(s.h) + ' мм) меньше полосы ' + mmText(w) + ' × ' + mmText(h) + ' — проверьте формат полосы.'; }
        if (cols > 1) {
            if (cols % 2 == 0 && cols > 2) { gx = (s.w - cols * w) / (cols / 2 - 1); pairs = true; }
            else if (cols > 2) gx = (s.w - cols * w) / (cols - 1);
        }
        if (rows > 1) gy = (s.h - rows * h) / (rows - 1);
        if (gx < 0.5) gx = 0;
        if (gy < 0.5) gy = 0;
        if (cols * rows > 1) grid.push('стр. ' + (i + 1) + ': ' + cols + ' × ' + rows);
        for (r = 0; r < rows; r++) for (c = 0; c < cols; c++)
            cells.push([i, pairs ? Math.floor(c / 2) * (2 * w + gx) + (c % 2) * w : c * (w + gx), r * (h + gy)]);
    }
    function cellRect(cell, b) { var R = d.artboards[cell[0]].artboardRect, a = imPt(R, cell[1] - b, cell[2] - b); return [a[0], a[1], a[0] + pt(w + 2 * b), a[1] - pt(h + 2 * b)]; }
    function empty(cell) { return itemsInRect(wd.srcLayers, cellRect(cell, 0)).length == 0; }
    // 2. пустые места в начале и в конце — не полосы
    var first = 0, last = cells.length - 1;
    while (first < last && empty(cells[first])) first++;
    while (last > first && empty(cells[last])) last--;
    // 3. обложка разворотом «последняя | первая»: первая половина — последняя полоса
    var seq = [];
    if (coverSpread && last > first) { for (i = first + 1; i <= last; i++) seq.push(cells[i]); seq.push(cells[first]); }
    else for (i = first; i <= last; i++) seq.push(cells[i]);
    try {
        var e1 = wd.grid(seq.length, w, h);
        if (e1) { wd.fail(); src.activate(); return e1; }
        // что в какую полосу — до переноса: картинка через весь разворот попадает в обе половины
        var lists = [];
        for (i = 0; i < seq.length; i++) lists.push(itemsInRect(wd.srcLayers, cellRect(seq[i], bleed)));
        for (i = 0; i < seq.length; i++) {
            d.artboards[wd.ab(i)].name = 'Полоса ' + (i + 1);
            if (!lists[i].length) continue;
            var g = wd.L.groupItems.add(), cr = cellRect(seq[i], bleed), R = wd.rects[i];
            for (var k = 0; k < lists[i].length; k++) lists[i][k].duplicate(g, ElementPlacement.PLACEATBEGINNING);
            g.translate(R[0] - (cr[0] + pt(bleed)), R[1] - (cr[1] - pt(bleed)));
            clipInto(g, wd.L, R, -bleed, -bleed, w + 2 * bleed, h + 2 * bleed, 'Полоса ' + (i + 1));
        }
        wd.finish('');
    } catch (e) {
        wd.fail();
        logLine('сбой разрезания на полосы: ' + e.message + ' (строка ' + e.line + ')');
        return 'Сбой при разрезании на полосы: ' + e.message;
    }
    var cnt = seq.length;
    var msg = 'Готово: ' + cnt + ' ' + plural(cnt, 'полоса', 'полосы', 'полос') + ' ' + mmText(w) + ' × ' + mmText(h) + ' мм из ' + n0 + ' стр.' +
        (grid.length ? ' Нашла на страницах ' + grid.join(', ') + '.' : '') +
        (first > 0 || last < cells.length - 1 ? ' Пустых мест по краям убрано: ' + (first + cells.length - 1 - last) + '.' : '') +
        (coverSpread ? ' Обложка разворотом: левая половина первого разворота — последняя полоса.' : '') +
        (cnt % 4 ? ' Полос ' + cnt + ' — не кратно 4: проверьте, всё ли на месте.' : '') +
        ' Пролистайте файл — порядок полос должен совпадать с порядком чтения.\r\n' + outPath;
    logLine('развороты → полосы: ' + msg.replace(/\r\n/g, ' / '));
    return msg;
};

// Документ полос годится для спуска: сохранён, все полосы одного размера. Ответ — { w, h, n } или строка-ошибка
function bookSource(src, what) {
    if (!savedPath(src)) return 'Сначала сохраните документ брошюры (каждая монтажная область — полоса, по порядку).';
    if (docProp(src, 'kind') == 'book') return 'Открыт уже готовый файл ' + what + ' — раскладывать нужно документ брошюры (каждая монтажная область — полоса).';
    var n = src.artboards.length, s = abSizeMm(src, 0);
    for (var i = 1; i < n; i++) {
        var z = abSizeMm(src, i);
        if (Math.abs(z.w - s.w) > 0.1 || Math.abs(z.h - s.h) > 0.1)
            return 'Страница ' + (i + 1) + ' другого размера (' + mmText(z.w) + ' × ' + mmText(z.h) + '), а первая — ' + mmText(s.w) + ' × ' + mmText(s.h) + ' мм. У брошюры все полосы одного формата.';
    }
    return { w: s.w, h: s.h, n: n };
}

// ---------- спуск на скрепку: развороты ----------

var Booklet = {};

Booklet.Run = function (outPath, bleed, creep) {
    if (!PSA.has('CO')) return 'Брошюра входит в части «Цифровая печать» и «Офсет» — их нет в вашем ключе.';
    if (!hasDoc()) return 'Нет открытого документа.';
    var src = app.activeDocument, bs = bookSource(src, 'разворотов');
    if (typeof bs == 'string') return bs;
    var n = bs.n, w = bs.w, h = bs.h;
    if (n < 2) return 'В документе одна монтажная область — спускать нечего. Каждая полоса брошюры — отдельная область.';
    if (new File(outPath).fsName.toLowerCase() == savedPath(src).toLowerCase()) return 'Развороты нельзя сохранить поверх брошюры.';
    var total = Math.ceil(n / 4) * 4, sheets = total / 4, k, side;
    var wd;
    try { wd = new WorkDoc(src, outPath); } catch (e) { return 'Не удалось сделать файл разворотов: ' + e.message; }
    try {
        var e1 = wd.grid(sheets * 2, 2 * w, h);
        if (e1) { wd.fail(); src.activate(); return e1; }
        wd.collectPages();
        var d = wd.d, L = wd.L;
        for (k = 0; k < sheets; k++) {
            var sh = creep * k;
            for (side = 0; side <= 1; side++) {
                var a = side == 0 ? total - 2 * k : 2 * k + 2, b = side == 0 ? 2 * k + 1 : total - 2 * k - 1, ai = 2 * k + side, R = wd.rects[ai];
                d.artboards[wd.ab(ai)].name = 'Разворот ' + (k + 1) + (side == 0 ? ' — лицо' : ' — оборот') + ' (стр. ' + a + ' и ' + b + ')';
                // половина разворота: вылет с трёх наружных сторон, у корешка — ровно по сгибу
                if (a <= n) { var ga = wd.copy(a, R[0] + pt(sh), R[1]); if (ga) clipInto(ga, L, R, -bleed, -bleed, w + bleed, h + 2 * bleed, 'Полоса ' + a); }
                if (b <= n) { var gb = wd.copy(b, R[0] + pt(w - sh), R[1]); if (gb) clipInto(gb, L, R, w, -bleed, w + bleed, h + 2 * bleed, 'Полоса ' + b); }
            }
        }
        wd.finish('book');
    } catch (e) {
        wd.fail();
        logLine('сбой спуска полос: ' + e.message + ' (строка ' + e.line + ')');
        return 'Сбой спуска полос: ' + e.message;
    }
    var msg = 'Готово: ' + n + ' полос → ' + sheets + (sheets == 1 ? ' лист' : ' листа(ов)') + ' (лицо и оборот), разворот ' + mmText(2 * w) + ' × ' + mmText(h) + ' мм.';
    if (total > n) msg += ' Полос не кратно 4 — в конце ' + (total - n) + ' пустых.';
    if (creep > 0 && sheets > 1) msg += ' Сдвиг на сползание — до ' + mmText(creep * (sheets - 1)) + ' мм у среднего листа.';
    msg += '\r\n' + outPath;
    logLine('брошюра: ' + msg.replace(/\r\n/g, ' / '));
    return msg;
};

// ---------- брошюра и книга тетрадями ----------
// Скрепка — тетради вкладываются одна в другую; КБС — подбираются одна за другой, корешок фрезеруется.
// Геометрия тетради: у корешка полосы вплотную (КБС — с припуском на фрезеровку), у остальных сгибов
// (голова к голове, передний край) — раздвинуты на припуск под обрез.

var Book = (function () {
    var SHEETS = '450x320,640x450,700x500,900x640,1000x700,1040x720';

    function from(params, bparams) {
        var c = parseKV(bparams), G = function (k, dv) { return c.hasOwnProperty(k) ? c[k] : dv; };
        var b = {
            Imp: Impose.ParamsFrom(params), Saddle: G('bkBind', 'saddle') == 'saddle', MaxP: Math.round(toNum(G('bkP', '0'), 0)),
            CoverSep: G('bkCover', '0') == '1', BlankEnd: G('bkBlank', 'back') == 'end', Bleed: toNum(G('bkBleed', '3'), 3),
            Trim: toNum(G('bkTrim', '6'), 6), Creep: toNum(G('bkCreep', '0.1'), 0.1), Grind: toNum(G('bkGrind', '3'), 3),
            Paper: toNum(G('bkPaper', '0.1'), 0.1), SpineW: 0, FoldMarks: G('bkFold', '1') == '1', Collate: G('bkCollate', '1') == '1',
            AutoSheet: G('bkAuto', '1') == '1', Copies: G('bkCopies', 'auto')
        };
        b.Imp.CutMarks = G('bkCut', '1') == '1';
        if (b.Imp.CutLen <= 0) b.Imp.CutLen = 5;
        return b;
    }

    function unit(bp) { return bp.Saddle ? 4 : 2; }
    function blankBeforeBack(bp) { return !bp.BlankEnd && !bp.CoverSep; }
    function blockRange(bp, n) { return bp.CoverSep ? { first: 3, last: n - 2 } : { first: 1, last: n }; }

    function check(bp, n) {
        if (n < 4) return 'Страниц ' + n + ' — для брошюры нужно хотя бы 4 (каждая полоса — отдельная монтажная область).';
        if (bp.CoverSep && n < 8) return 'Обложка отдельно — нужно хотя бы 8 страниц: 4 на обложку и 4 на блок.';
        return '';
    }

    function gapAfterCol(bp, c) { return c % 2 == 0 ? (bp.Saddle ? 0 : 2 * bp.Grind) : bp.Trim; }

    // Где полосы в блоке тетради: левые края столбцов, верхние края рядов, размер блока
    function grid(bp, s, w, h) {
        var cx = [], ry = [], x = 0, y = 0, c, r;
        for (c = 0; c < s.Cols; c++) { cx.push(x); x += w; if (c < s.Cols - 1) x += gapAfterCol(bp, c); }
        for (r = 0; r < s.Rows; r++) { ry.push(y); y += h; if (r < s.Rows - 1) y += bp.Trim; }
        return { cx: cx, ry: ry, bw: x, bh: y };
    }

    // Параметры листа для блока тетради как одной «карты» — поля, клапан, пластина, обвязка
    function blockParams(bp, bw, bh) {
        var p = {}, k;
        for (k in bp.Imp) if (bp.Imp.hasOwnProperty(k)) p[k] = bp.Imp[k];
        p.CutW = bw; p.CutH = bh; p.Cols = 1; p.Rows = 1; p.Orient = 1; p.GapX = 0; p.GapY = 0;
        p.Bleed = bp.Bleed; p.AlignH = 0; p.AlignV = 0; p.MirrorBack = false; p.WorkTurn = false; p.Guides = false;
        return p;
    }

    // Как тетрадь встаёт на лист: 1 — как есть, 2 — повёрнутой на 90°, 0 — никак
    function turn(bp, P, w, h) {
        var g = grid(bp, Signature.make(P), w, h), f = Impose.Fit(blockParams(bp, g.bw, g.bh));
        if (f.cols >= 1 && f.rows >= 1) return 1;
        f = Impose.Fit(blockParams(bp, g.bh, g.bw));
        return f.cols >= 1 && f.rows >= 1 ? 2 : 0;
    }
    function fits(bp, P, w, h) { return turn(bp, P, w, h) > 0; }
    function fitP(bp, w, h) { var a = [32, 16, 8, 4]; for (var i = 0; i < a.length; i++) if (fits(bp, a[i], w, h)) return a[i]; return 0; }

    function copyGap(bp) {
        var o = Math.max(Impose.CutOffset(bp.Imp), bp.Bleed + 1), ln = bp.Imp.CutLen > 0 ? bp.Imp.CutLen : 5;
        if (bp.FoldMarks && ln < 8) ln = 8;
        return 2 * (o + ln) + 2;
    }

    // Повёрнута ли, сколько одинаковых рядом (kc × kr) и своим ли оборотом
    function arrange(bp, P, w, h) {
        var g = grid(bp, Signature.make(P), w, h), turned = turn(bp, P, w, h) == 2, a = { turned: turned, kc: 1, kr: 1, wt: false };
        var pa = turned ? blockParams(bp, g.bh, g.bw) : blockParams(bp, g.bw, g.bh);
        if (bp.Copies == 'one') return a;
        pa.GapX = pa.GapY = copyGap(bp); pa.Cols = 0; pa.Rows = 0;
        var f = Impose.Fit(pa);
        a.kc = Math.max(1, f.cols); a.kr = Math.max(1, f.rows);
        if (bp.Copies == 'wt') {
            if (a.kc >= 2) { a.wt = true; if (a.kc % 2 == 1) a.kc--; }
            else { a.kc = 1; a.kr = 1; }
        }
        return a;
    }

    function sheetOnPlate(bp, sw, sh) {
        if (!bp.Imp.PlateOn) return true;
        return sw <= bp.Imp.PlateW + 0.1 && sh + (bp.Imp.PlateCenter ? 0 : bp.Imp.Klapan) <= bp.Imp.PlateH + 0.1;
    }

    function chooseSheet(bp, n, w, h) {
        var br = blockRange(bp, n), cnt = br.last - br.first + 1, blanks = (unit(bp) - cnt % unit(bp)) % unit(bp), best = 0, bestArea = 0, bw = 0, bh = 0;
        var list = SHEETS.split(',');
        for (var i = 0; i < list.length; i++) {
            var a = list[i].split('x'), sw = +a[0], sh = +a[1];
            if (!sheetOnPlate(bp, sw, sh)) continue;
            bp.Imp.SheetW = sw; bp.Imp.SheetH = sh;
            var P = bp.MaxP > 0 ? (fits(bp, bp.MaxP, w, h) ? bp.MaxP : 0) : fitP(bp, w, h);
            if (P <= 0) continue;
            var k = Signature.splitSizes(cnt + blanks, P).split(',').length, area = sw * sh;
            if (bp.Imp.PlateOn) { if (best == 0 || area > bestArea) { best = 1; bestArea = area; bw = sw; bh = sh; } }
            else if (best == 0 || k < best || (k == best && area < bestArea)) { best = k; bestArea = area; bw = sw; bh = sh; }
        }
        if (best == 0) return 'Ни на один стандартный лист (' + SHEETS.replace(/x/g, ' × ').replace(/,/g, ', ') + ') тетрадь не встаёт' +
            (bp.Imp.PlateOn ? ' с пластиной ' + mmText(bp.Imp.PlateW) + ' × ' + mmText(bp.Imp.PlateH) : '') + '. Задайте лист вручную.';
        bp.Imp.SheetW = bw; bp.Imp.SheetH = bh;
        return '';
    }

    // «ok|полос в тетради|тетради|пустых|листов|обложка|что учесть|повёрнута|лист|авто|на листе|свой оборот» или «err|почему»
    function plan(bp, n, w, h) {
        var e = check(bp, n);
        if (e) return 'err|' + e;
        if (bp.AutoSheet) { e = chooseSheet(bp, n, w, h); if (e) return 'err|' + e; }
        var br = blockRange(bp, n), cnt = br.last - br.first + 1, P = bp.MaxP || fitP(bp, w, h), note = '';
        if (!P) return 'err|Тетрадь даже на 4 полосы не помещается на лист ' + mmText(bp.Imp.SheetW) + ' × ' + mmText(bp.Imp.SheetH) + ' мм с полями и метками.';
        if (!fits(bp, P, w, h)) return 'err|Тетрадь на ' + P + ' полос не помещается на лист — выберите меньше полос или больший лист.';
        var blanks = (unit(bp) - cnt % unit(bp)) % unit(bp), sizes = Signature.splitSizes(cnt + blanks, P);
        if (blanks > 0) note = (bp.CoverSep ? 'Блок — ' + cnt + ' полос' : 'Страниц ' + n) + ' — не кратно ' + unit(bp) + ': добавится пустых ' + blanks +
            (blankBeforeBack(bp) ? ' перед двумя последними полосами (задняя обложка и её оборот).' : ' в конце блока.');
        if (!bp.Saddle && (',' + sizes + ',').indexOf(',2,') >= 0) note = trimS(note + ' Последние две полосы блока — листком: при КБС он вклеивается вместе с тетрадями.');
        if (bp.CoverSep) note = trimS(note + ' Обложка — полосы 1, 2, ' + (n - 1) + ', ' + n + '.');
        var a = arrange(bp, parseInt(sizes.split(',')[0], 10), w, h);
        if (bp.Copies == 'wt' && !a.wt) note = trimS(note + ' Своим оборотом не выйдет: на лист не встают две тетради рядом — будет лицо и оборот отдельно.');
        return 'ok|' + P + '|' + sizes + '|' + blanks + '|' + (sizes.split(',').length + (bp.CoverSep ? 1 : 0)) + '|' + (bp.CoverSep ? 1 : 0) + '|' + note + '|' + (a.turned ? 1 : 0) +
            '|' + mmText(bp.Imp.SheetW) + 'x' + mmText(bp.Imp.SheetH) + '|' + (bp.AutoSheet ? 1 : 0) + '|' + a.kc * a.kr + '|' + (a.wt ? 1 : 0);
    }
    function trimS(s) { return s.replace(/^\s+|\s+$/g, ''); }

    // ---------- рисование ----------

    // Контур полосы с номером — на непечатаемом слое
    function trimFrame(d, R, x, y, w, h, label, col) {
        var l = layerNamed(d, GUIDE_LAYER, false), r = imRect(l, R, x, y, w, h);
        r.filled = false; r.stroked = true; r.strokeWidth = pt(0.2); r.strokeColor = rgbColor(0, 160, 220);
        var t = imLabel(l, R, 0, 0, label, 24, rgbColor(0, 160, 220), 'Полоса ' + label);
        try { t.textRange.characterAttributes.textFont = app.textFonts.getByName('ArialMT'); } catch (e) { }
        var b = t.geometricBounds, c = imPt(R, x + w / 2, y + h / 2);
        t.translate(c[0] - (b[0] + b[2]) / 2, c[1] - (b[1] + b[3]) / 2);
        if (col) { col.push(r); col.push(t); }
    }

    // Полоса pno в рамку (x, y — левый верх, мм от угла области R): голова вниз (rot), сдвиг на сползание, вылет по сторонам
    function placePage(bank, L, R, pno, x, y, w, h, rot, shift, bL, bR, bT, bB, col) {
        var a = imPt(R, x, y), g = bank.copy(pno, a[0], a[1]);
        if (!g) return;
        if (rot) { var c = imPt(R, x + w / 2, y + h / 2); rotateAbout(g, 180, c[0], c[1]); }
        if (shift) g.translate(pt(shift), 0);
        var cg = clipInto(g, L, R, x - bL, y - bT, w + bL + bR, h + bT + bB, 'Полоса ' + pno);
        if (col) col.push(cg);
    }

    function clipSide(bp, s, c, r, sd) {
        var g;
        if (sd == 0) { if (c == 0) return bp.Bleed; g = gapAfterCol(bp, c - 1); }
        else if (sd == 1) { if (c == s.Cols - 1) return bp.Bleed; g = gapAfterCol(bp, c); }
        else if (sd == 2) { if (r == 0) return bp.Bleed; g = bp.Trim; }
        else { if (r == s.Rows - 1) return bp.Bleed; g = bp.Trim; }
        return Math.min(g / 2, bp.Bleed);
    }

    function cutOff(bp) { return Math.max(Impose.CutOffset(bp.Imp), bp.Bleed + 1); }

    // Метки реза тетради: по внешнему краю блока и у срезаемых сгибов; у корешка — нет. bl, bt — левый верх блока
    function cutMarks(d, R, bp, s, gr, w, h, bl, bt, col) {
        var g = layerNamed(d, CUT_LAYER, true).groupItems.add(), o = cutOff(bp), ln = bp.Imp.CutLen > 0 ? bp.Imp.CutLen : 5, lw = bp.Imp.CutLineW > 0 ? bp.Imp.CutLineW : 0.1, c, r, x;
        g.name = 'Метки реза';
        for (c = 0; c < s.Cols; c++) {
            if (c == 0 || (c - 1) % 2 == 1) { x = bl + gr.cx[c]; imLine(g, R, x, bt - o, x, bt - o - ln, lw); imLine(g, R, x, bt + gr.bh + o, x, bt + gr.bh + o + ln, lw); }
            if (c == s.Cols - 1 || c % 2 == 1) { x = bl + gr.cx[c] + w; imLine(g, R, x, bt - o, x, bt - o - ln, lw); imLine(g, R, x, bt + gr.bh + o, x, bt + gr.bh + o + ln, lw); }
        }
        for (r = 0; r < s.Rows; r++) {
            var ys = [bt + gr.ry[r], bt + gr.ry[r] + h];
            for (var k = 0; k < 2; k++) { imLine(g, R, bl - o, ys[k], bl - o - ln, ys[k], lw); imLine(g, R, bl + gr.bw + o, ys[k], bl + gr.bw + o + ln, ys[k], lw); }
        }
        if (col) col.push(g);
    }

    // Пунктир из трёх штрихов по 2 мм длиной 8 мм
    function dashes(g, R, x1, y1, x2, y2) {
        var dx = (x2 - x1) / 8, dy = (y2 - y1) / 8;
        for (var k = 0; k <= 2; k++) imLine(g, R, x1 + dx * k * 3, y1 + dy * k * 3, x1 + dx * (k * 3 + 2), y1 + dy * (k * 3 + 2), 0.2);
    }

    function foldMarks(d, R, bp, s, gr, w, h, bl, bt, col) {
        if (s.Cols < 2 && s.Rows < 2) return;
        var g = layerNamed(d, FOLD_LAYER, true).groupItems.add(), o = cutOff(bp), c, r, x, y;
        g.name = 'Метки фальцовки';
        for (c = 0; c < s.Cols - 1; c++) {
            x = bl + gr.cx[c] + w + gapAfterCol(bp, c) / 2;
            dashes(g, R, x, bt - o, x, bt - o - 8); dashes(g, R, x, bt + gr.bh + o, x, bt + gr.bh + o + 8);
        }
        for (r = 0; r < s.Rows - 1; r++) {
            y = bt + gr.ry[r] + h + bp.Trim / 2;
            dashes(g, R, bl - o, y, bl - o - 8, y); dashes(g, R, bl + gr.bw + o, y, bl + gr.bw + o + 8, y);
        }
        if (col) col.push(g);
    }

    // КБС: метка-ступенька на корешке — чёрный брусок поперёк корешкового сгиба; у каждой следующей тетради ниже
    function collateMark(d, R, bp, s, side, gr, w, h, bl, bt, sigNo, col) {
        for (var i = 0; i < s.Cols * s.Rows; i++) {
            if (!((side == 0 && s.PgA[i] == 1) || (side == 1 && s.PgB[i] == 1))) continue;
            var c = i % s.Cols, r = Math.floor(i / s.Cols), x, stp = 6;
            x = c % 2 == 1 ? bl + gr.cx[c] - gapAfterCol(bp, c - 1) / 2 : bl + gr.cx[c] + w + gapAfterCol(bp, c) / 2;
            var y = bt + gr.ry[r] + 5 + (Math.round((sigNo - 1) * stp) % Math.max(1, Math.round(h - 15)));
            var rc = imRect(layerNamed(d, CUT_LAYER, true), R, x - 2, y, 4, stp);
            rc.stroked = false; rc.filled = true; rc.fillColor = cmykColor(0, 0, 0, 100);
            rc.name = 'Метка подборки ' + sigNo;
            if (col) col.push(rc);
            return;
        }
    }

    // Страницы тетради словами: «17–32» (скрепка — «9–16, 25–32»)
    function pageRange(slots, pages) {
        var a = [];
        for (var i = 0; i < slots.length; i++) { var v = pages ? pages[slots[i] - 1] : slots[i]; if (v > 0) a.push(v); }
        var t = [], lo = 0, hi = 0;
        for (i = 0; i < a.length; i++) {
            if (!lo) { lo = hi = a[i]; }
            else if (a[i] == hi + 1) hi = a[i];
            else { t.push(lo == hi ? String(lo) : lo + '–' + hi); lo = hi = a[i]; }
        }
        if (lo) t.push(lo == hi ? String(lo) : lo + '–' + hi);
        return t.join(', ');
    }

    // Одна тетрадь стороной side с центром (ccx, ccy) мм: полосы, контуры, метки; повёрнутая — всё на 90°
    function drawBlock(ctx, R, s, slots, pages, T, side, sigNo, leafBase, gr, ccx, ccy, turned) {
        var bp = ctx.bp, w = ctx.w, h = ctx.h, col = [], bl = ccx - gr.bw / 2, bt = ccy - gr.bh / 2;
        for (var i = 0; i < s.Cols * s.Rows; i++) {
            var r = Math.floor(i / s.Cols), c = i % s.Cols, slot = side == 0 ? slots[s.PgA[i] - 1] : slots[s.PgB[i] - 1], rot = side == 0 ? s.RotA[i] : s.RotB[i];
            var pno = pages ? pages[slot - 1] : slot, x = bl + gr.cx[c], y = bt + gr.ry[r], shift = 0;
            // сползание: внутренние листы скрепки — к корешку (у чётного столбца корешок справа, у нечётного — слева)
            if (bp.Saddle && bp.Creep > 0 && T > 0) {
                var leaf = leafBase + Math.floor(Math.min(slot - 1, T - slot) / 2);
                shift = bp.Creep * leaf * (c % 2 == 0 ? 1 : -1);
            }
            trimFrame(ctx.d, R, x, y, w, h, pno > 0 ? String(pno) : 'пусто', col);
            if (pno > 0) placePage(ctx.bank, ctx.L, R, pno, x, y, w, h, rot, shift,
                clipSide(bp, s, c, r, 0), clipSide(bp, s, c, r, 1), clipSide(bp, s, c, r, 2), clipSide(bp, s, c, r, 3), col);
        }
        if (bp.Imp.CutMarks) cutMarks(ctx.d, R, bp, s, gr, w, h, bl, bt, col);
        if (bp.FoldMarks) foldMarks(ctx.d, R, bp, s, gr, w, h, bl, bt, col);
        if (bp.Collate && !bp.Saddle && sigNo > 0 && s.P > 2) collateMark(ctx.d, R, bp, s, side, gr, w, h, bl, bt, sigNo, col);
        if (turned) { var c0 = imPt(R, ccx, ccy); for (var k = 0; k < col.length; k++) rotateAbout(col[k], side == 0 ? 90 : -90, c0[0], c0[1]); }
    }

    function needPrepress(p) { return p.RegMarks || p.ColorBar || p.SheetInfo || p.Gripper > 0 || p.PlateOn; }

    // Тетрадь на лист: сторона A (лицо) и B (оборот); своим оборотом — одна сторона, лицо слева, оборот справа
    function placeSig(ctx, s, slots, pages, T, title, shortTitle, sigNo, leafBase) {
        var bp = ctx.bp, gr = grid(bp, s, ctx.w, ctx.h), a = arrange(bp, s.P, ctx.w, ctx.h);
        var cw = a.turned ? gr.bh : gr.bw, ch = a.turned ? gr.bw : gr.bh, p = blockParams(bp, cw, ch), gap = 0;
        if (a.kc * a.kr > 1) { gap = copyGap(bp); p.GapX = p.GapY = gap; }
        var o = Impose.Origin(p, a.kc, a.kr), xs = o.x + Impose.PaperX(p), yb = o.y + Impose.PaperY(p), rng = pageRange(slots, pages);
        for (var side = 0; side <= (a.wt ? 0 : 1); side++) {
            var ab = ctx.bank.ab(ctx.next), R = ctx.bank.rects[ctx.next++];
            ctx.d.artboards[ab].name = shortTitle + (a.wt ? ' — свой оборот' : (side == 0 ? ' — лицо' : ' — оборот'));
            for (var i = 0; i < a.kr; i++) for (var j = 0; j < a.kc; j++) {
                var sd = a.wt ? (j < a.kc / 2 ? 0 : 1) : side;
                drawBlock(ctx, R, s, slots, pages, T, sd, sigNo, leafBase, gr, xs + j * (cw + gap) + cw / 2, yb + i * (ch + gap) + ch / 2, a.turned);
            }
            p.InfoText = bp.Imp.InfoText + ' · ' + title + (rng ? ', стр. ' + rng : '') + (a.kc * a.kr > 1 ? ' · на листе ' + a.kc * a.kr : '') + (a.wt ? ' · своим оборотом' : '');
            if (needPrepress(p)) Impose.DrawPrepress(ctx.d, ab, p, a.kc, a.kr, xs, yb, a.wt ? 'свой оборот' : (side == 0 ? 'лицо' : 'оборот'));
        }
    }

    // КБС: обложка разворотом с корешком. Снаружи — последняя | корешок | первая; внутри — 2 | корешок | предпоследняя
    function placeCover(ctx, cv, T) {
        var bp = ctx.bp, w = ctx.w, h = ctx.h, sw = bp.SpineW;
        if (sw <= 0) sw = Math.round(T / 2 * (bp.Paper > 0 ? bp.Paper : 0.1) * 10) / 10;
        var bw = 2 * w + sw, p = blockParams(bp, bw, h), o = Impose.Origin(p, 1, 1), xs = o.x + Impose.PaperX(p), yb = o.y + Impose.PaperY(p), B = bp.Bleed;
        for (var side = 0; side <= 1; side++) {
            var ab = ctx.bank.ab(ctx.next), R = ctx.bank.rects[ctx.next++], lx = xs, rx = lx + w + sw, top = yb, k, x;
            ctx.d.artboards[ab].name = 'Обложка — ' + (side == 0 ? 'снаружи' : 'внутри');
            var left = side == 0 ? cv[3] : cv[1], right = side == 0 ? cv[0] : cv[2];
            trimFrame(ctx.d, R, lx, top, w, h, String(left), null); placePage(ctx.bank, ctx.L, R, left, lx, top, w, h, false, 0, B, 0, B, B, null);
            trimFrame(ctx.d, R, rx, top, w, h, String(right), null); placePage(ctx.bank, ctx.L, R, right, rx, top, w, h, false, 0, 0, B, B, B, null);
            var o2 = cutOff(bp);
            if (bp.Imp.CutMarks) {
                var g = layerNamed(ctx.d, CUT_LAYER, true).groupItems.add(), xx = [lx, lx + bw], yy = [top, top + h];
                g.name = 'Метки реза';
                for (k = 0; k < 2; k++) {
                    imLine(g, R, xx[k], top - o2, xx[k], top - o2 - 5); imLine(g, R, xx[k], top + h + o2, xx[k], top + h + o2 + 5);
                    imLine(g, R, lx - o2, yy[k], lx - o2 - 5, yy[k]); imLine(g, R, lx + bw + o2, yy[k], lx + bw + o2 + 5, yy[k]);
                }
            }
            var fg = layerNamed(ctx.d, FOLD_LAYER, true).groupItems.add(), fx = [lx + w, lx + w + sw];
            fg.name = 'Метки фальцовки (корешок)';
            for (k = 0; k < 2; k++) { dashes(fg, R, fx[k], top - o2, fx[k], top - o2 - 8); dashes(fg, R, fx[k], top + h + o2, fx[k], top + h + o2 + 8); }
            p.InfoText = bp.Imp.InfoText + ' · обложка, корешок ' + mmText(sw) + ' мм';
            if (needPrepress(p)) Impose.DrawPrepress(ctx.d, ab, p, 1, 1, xs, yb, side == 0 ? 'лицо' : 'оборот');
        }
    }

    function run(bp, outPath) {
        if (!PSA.has('CO')) return 'Брошюра входит в части «Цифровая печать» и «Офсет» — их нет в вашем ключе.';
        if (!hasDoc()) return 'Нет открытого документа.';
        var src = app.activeDocument, bs = bookSource(src, 'тетрадей');
        if (typeof bs == 'string') return bs;
        var n = bs.n, w = bs.w, h = bs.h, pl = plan(bp, n, w, h);
        if (pl.substring(0, 3) == 'err') return pl.substring(4);
        if (new File(outPath).fsName.toLowerCase() == savedPath(src).toLowerCase()) return 'Раскладку нельзя сохранить поверх документа брошюры.';
        var a = pl.split('|'), sizes = a[2], br = blockRange(bp, n);
        var pages = Signature.pad(br.first, br.last, unit(bp), blankBeforeBack(bp)), T = pages.length;
        var sigs = Signature.assign(T, sizes, bp.Saddle), nsig = sigs.length, cv = [1, 2, n - 1, n], k;
        // сколько сторон листов выйдет — для сетки областей
        var boards = bp.CoverSep ? 2 : 0;
        for (k = 0; k < nsig; k++) boards += arrange(bp, sigs[k].length, w, h).wt ? 1 : 2;
        var W = Impose.PageW(bp.Imp), H = Impose.PageH(bp.Imp), wd;
        try { wd = new WorkDoc(src, outPath); } catch (e) { return 'Не удалось сделать файл тетрадей: ' + e.message; }
        try {
            var e1 = wd.grid(boards, W, H);
            if (e1) { wd.fail(); src.activate(); return e1; }
            wd.collectPages();
            var ctx = { d: wd.d, bp: bp, w: w, h: h, L: wd.L, bank: wd, next: 0 };
            if (bp.CoverSep) {
                if (bp.Saddle) placeSig(ctx, Signature.make(4), cv, null, 0, 'Обложка', 'Обложка', 0, 0);
                else placeCover(ctx, cv, T);
            }
            for (k = 0; k < nsig; k++)
                placeSig(ctx, Signature.make(sigs[k].length), sigs[k], pages, T, 'Тетрадь ' + (k + 1) + ' из ' + nsig, 'Тетрадь ' + (k + 1) + '/' + nsig, k + 1, bp.CoverSep && bp.Saddle ? 1 : 0);
            wd.finish('book');      // готовые тетради: панель не примет их за брошюру
        } catch (e) {
            wd.fail();
            logLine('сбой раскладки брошюры: ' + e.message + ' (строка ' + e.line + ')');
            return 'Сбой раскладки брошюры: ' + e.message;
        }
        var msg = 'Готово: ' + n + ' стр. → ' + (bp.CoverSep ? 'обложка и ' : '') + nsig + ' ' + plural(nsig, 'тетрадь', 'тетради', 'тетрадей') + ' (' + sizes.replace(/,/g, ' + ') + ' полос), ' +
            'листов печати ' + (nsig + (bp.CoverSep ? 1 : 0)) + ', у каждого лицо и оборот. ' + (bp.Saddle ? 'Скрепка: тетради вкладываются одна в другую.' : 'КБС: тетради подбираются одна за другой.');
        if (T > br.last - br.first + 1) msg += ' Пустых полос ' + (T - (br.last - br.first + 1)) + '.';
        if (+a[10] > 1) msg += a[11] == '1' ? ' Своим оборотом: на листе ' + a[10] + ' тетради — лицо и оборот рядом, печатают одной формой, лист переворачивают слева направо; тираж — вдвое меньше листов.'
                                            : ' На листе ' + a[10] + ' одинаковых тетради — тираж печатать в ' + a[10] + ' раза меньше листов.';
        msg += '\r\n' + outPath;
        logLine('брошюра: ' + msg.replace(/\r\n/g, ' / '));
        return msg;
    }

    return { from: from, plan: plan, run: run };
})();

// ---------- команды панели ----------

function docFolderBase(d) {
    var o = { folder: '', base: '' };
    try { o.folder = d.fullName.parent.fsName; o.base = d.name.replace(/\.[^.]*$/, ''); } catch (e) { }
    return o;
}

Bridge.BookPlan = function (params, bparams) {
    try {
        if (!hasDoc()) return 'err|Откройте документ брошюры: каждая монтажная область — полоса, по порядку.';
        var d = app.activeDocument;
        if (docProp(d, 'kind') == 'book') return 'err|Открыт готовый файл тетрадей. Для расчёта откройте документ брошюры (каждая монтажная область — полоса).';
        var b = Book.from(params, bparams), s = abSizeMm(d, 0), r = Book.plan(b, d.artboards.length, s.w, s.h);
        // последним полем — похоже ли на развороты: панель предупредит
        if (r.substring(0, 2) == 'ok') r = 'ok|' + d.artboards.length + r.substring(2) + '|' + Spreads.Guess(d).replace(/\|/g, ';');
        return r;
    } catch (e) { return 'err|' + e.message; }
};

Bridge.SpreadGuess = function () { try { return hasDoc() ? Spreads.Guess(app.activeDocument) : ''; } catch (e) { return ''; } };

Bridge.SpreadSplit = function (w, h, cover, bleed) {
    if (!PSA.has('CO')) return 'Развороты на полосы входят в части «Цифровая печать» и «Офсет» — их нет в вашем ключе.';
    if (!hasDoc()) return 'Нет открытого документа.';
    var o = docFolderBase(app.activeDocument);
    if (!o.base) return 'Сначала сохраните документ.';
    var f = outPath('booklet', 'Сохранить полосы', o.base + ' — полосы.ai', o.folder);
    if (!f) return '';
    return Spreads.SplitDoc(toNum(w, 0), toNum(h, 0), cover == '1', toNum(bleed, 3), f);
};

Bridge.BookRun = function (params, bparams) {
    if (!PSA.has('CO')) return 'Брошюра входит в части «Цифровая печать» и «Офсет» — их нет в вашем ключе.';
    if (!hasDoc()) return 'Нет открытого документа.';
    var o = docFolderBase(app.activeDocument), pre = '';
    if (!o.base) return 'Сначала сохраните документ брошюры.';
    // файл разворотами — сначала сам режет на полосы (файл «… — полосы» рядом), потом раскладывает его
    var g = Spreads.Guess(app.activeDocument);
    if (g) {
        var ga = g.split('|'), c = parseKV(bparams), sw = toNum(c.spW || '', 0), sh = toNum(c.spH || '', 0), sp = o.folder + '/' + o.base + ' — полосы.ai';
        if (sw <= 0 || sh <= 0) { sw = toNum(ga[0], 0); sh = toNum(ga[1], 0); }
        if (!freeToReplace(sp)) return '';
        var spl = Spreads.SplitDoc(sw, sh, c.spCover == '1', toNum(c.bkBleed || '3', 3), sp);
        if (spl.substring(0, 6) != 'Готово') return 'Файл разворотами, разрезать на полосы не получилось: ' + spl;
        pre = 'Файл был разворотами (страницы ' + ga[2] + ') — сначала разрезала на полосы: ' + spl.substring(8, spl.indexOf('мм') + 2) + ' — «' + o.base + ' — полосы.ai». \r\n';
    }
    var b = Book.from(params, bparams), f = outPath('booklet', 'Сохранить тетради для печати', o.base + ' — тетради.ai', o.folder);
    if (!f) return '';
    b.Imp.InfoText = f.replace(/^.*[\\\/]/, '');
    return pre + Book.run(b, f);
};

Bridge.BookletRun = function (bleed, creep) {
    if (!PSA.has('CO')) return 'Брошюра входит в части «Цифровая печать» и «Офсет» — их нет в вашем ключе.';
    if (!hasDoc()) return 'Нет открытого документа.';
    Settings.set('Booklet', 'Bleed', bleed); Settings.set('Booklet', 'Creep', creep);
    var o = docFolderBase(app.activeDocument);
    if (!o.base) return 'Сначала сохраните документ брошюры.';
    var f = outPath('booklet', 'Сохранить развороты для печати', o.base + ' — развороты.ai', o.folder);
    if (!f) return '';
    return Booklet.Run(f, toNum(bleed, 2), toNum(creep, 0));
};
