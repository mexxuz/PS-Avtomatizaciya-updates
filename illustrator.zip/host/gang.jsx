// Сборный лист — как src/Gang.bas: несколько разных макетов на одном листе, в количестве по тиражам.
// Каждый выделенный объект верхнего уровня (обычно группа) — один макет вместе с вылетами.
// Раскладка рядами: в ряду копии одного макета; следующий ряд — тому, кому больше не хватает до тиража.

var Gang = (function () {
    var Items = [];

    // сверху вниз, слева направо — так же нумеруются тиражи
    function sorted(list) {
        var a = list.slice(0);
        a.sort(function (x, y) {
            var bx = x.geometricBounds, by = y.geometricBounds;
            if (Math.abs(bx[1] - by[1]) > pt(5)) return by[1] - bx[1];
            return bx[0] - by[0];
        });
        return a;
    }

    // Один вариант поворотов (бит i — макет i боком). Итог — листов (0 — не помещается), over.v — лишних оттисков
    function tryLayout(p, mask, w, h, uw, uh, over) {
        var i, n = Items.length, sheets = 0;
        for (i = 0; i < n; i++) {
            Items[i].Rot = (mask & (1 << i)) != 0;
            Items[i].W = Items[i].Rot ? h[i] : w[i];
            Items[i].H = Items[i].Rot ? w[i] : h[i];
            Items[i].PerRow = Math.floor((uw + p.GapX) / (Items[i].W + p.GapX) + 0.000001);
            Items[i].Rows = 0;
            if (Items[i].PerRow < 1) return 0;
        }
        var used = -p.GapY;
        for (;;) {
            var best = -1, bestV = -1;
            for (i = 0; i < n; i++) if (used + p.GapY + Items[i].H <= uh + 0.000001) {
                var v = Items[i].Rows == 0 ? 1e30 : Items[i].Qty / (Items[i].Rows * Items[i].PerRow);
                if (v > bestV) { bestV = v; best = i; }
            }
            if (best < 0) break;
            Items[best].Rows++;
            used += p.GapY + Items[best].H;
        }
        for (i = 0; i < n; i++) {
            if (!Items[i].Rows) return 0;
            sheets = Math.max(sheets, Math.ceil(Items[i].Qty / (Items[i].Rows * Items[i].PerRow)));
        }
        over.v = 0;
        for (i = 0; i < n; i++) over.v += sheets * Items[i].Rows * Items[i].PerRow - Items[i].Qty;
        return sheets;
    }

    // План: ряды на листе. Ответ — '' или ошибка; out.text — описание для человека
    function plan(p, list, qtys, out) {
        if (list.length < 2) return 'Для сборного листа выделите два или больше макета — каждый отдельной группой.';
        if (list.length > 10) return 'Макетов больше десяти — разбейте на два сборных листа.';
        var q = String(qtys).replace(/;/g, ',').split(','), w = [], h = [], i;
        Items = [];
        var uw = p.SheetW - Impose.ML(p) - Impose.MR(p), uh = p.SheetH - Impose.MT(p) - Impose.MB(p);
        for (i = 0; i < list.length; i++) {
            w.push(mm(list[i].width) - 2 * p.Bleed); h.push(mm(list[i].height) - 2 * p.Bleed);
            if (w[i] <= 0 || h[i] <= 0) return 'Макет ' + (i + 1) + ' меньше двойного вылета — проверьте «Вылет за рез».';
            var qty = i < q.length ? Math.round(toNum(q[i], 1)) : 1;
            Items.push({ Qty: Math.max(1, qty), Title: 'Макет ' + (i + 1) + ' (' + mmText(w[i]) + ' × ' + mmText(h[i]) + ')' });
        }
        var best = -1, bestOver = 0, bestMask = 0, over = {};
        for (var mask = 0; mask < (1 << list.length); mask++) {
            var s = tryLayout(p, mask, w, h, uw, uh, over);
            if (s > 0 && (best < 0 || s < best || (s == best && over.v < bestOver))) { best = s; bestOver = over.v; bestMask = mask; }
        }
        if (best < 0) return 'Все макеты на лист ' + mmText(p.SheetW) + ' × ' + mmText(p.SheetH) + ' не помещаются — возьмите лист больше или меньше макетов.';
        var sheets = tryLayout(p, bestMask, w, h, uw, uh, over), t = '';
        for (i = 0; i < Items.length; i++) {
            var per = Items[i].Rows * Items[i].PerRow;
            t += '\r\n' + Items[i].Title + ': ' + per + ' шт. на листе, тираж ' + Items[i].Qty + ' — выйдет ' + sheets * per + ' (лишних ' + (sheets * per - Items[i].Qty) + ')' + (Items[i].Rot ? ', повёрнут' : '');
        }
        out.text = 'Печатать листов: ' + sheets + '.' + t;
        if (p.CutMarks && (p.GapX < 2 * (p.Bleed + 1.5) || p.GapY < 2 * (p.Bleed + 1.5)))
            out.text += '\r\nМетки реза у каждого макета не поместятся: нужен зазор не меньше ' + mmText(2 * (p.Bleed + 1.5)) + ' мм (два вылета и риски между ними). Сейчас — без меток.';
        return '';
    }

    // метки реза у каждого макета: риски по углам, в зазоре — если зазор позволяет
    function cornerMarks(d, R, p, cx, cy, w, h) {
        var o = p.Bleed + 0.5, ln = Math.min(Impose.CutOffset(p) + p.CutLen - o, p.GapX / 2 - o);
        if (ln < 1) return;
        var g = layerNamed(d, CUT_LAYER, true).groupItems.add(), lw = p.CutLineW > 0 ? p.CutLineW : 0.1;
        g.name = 'Метки реза';
        for (var sx = -1; sx <= 1; sx += 2) for (var sy = -1; sy <= 1; sy += 2) {
            var x = cx + sx * w / 2, y = cy + sy * h / 2;     // мм от левого верха листа (y вниз)
            imLine(g, R, x + sx * o, y, x + sx * (o + ln), y, lw);
            imLine(g, R, x, y + sy * o, x, y + sy * (o + ln), lw);
        }
    }

    function run(p, qtys, outPath) {
        var src = app.activeDocument, sel = selectionItems(src), out = {}, e = plan(p, sorted(sel), qtys, out);
        if (e) return e;
        var parts = sorted(sel), d = app.documents.add(src.documentColorSpace, pt(p.SheetW), pt(p.SheetH));
        try {
            d.artboards[0].name = 'Лист';
            var R = d.artboards[0].artboardRect, L = d.layers[0], gl = p.Guides ? layerNamed(d, GUIDE_LAYER, false) : null, i, r, k;
            L.name = 'Макеты';
            var y = Impose.MT(p);
            for (i = 0; i < Items.length; i++) {
                var proto = parts[i].duplicate(L, ElementPlacement.PLACEATEND), pb = proto.geometricBounds, ox = (pb[0] + pb[2]) / 2, oy = (pb[1] + pb[3]) / 2;
                for (r = 0; r < Items[i].Rows; r++) {
                    // ряд по центру по ширине
                    var x = Impose.ML(p) + ((p.SheetW - Impose.ML(p) - Impose.MR(p)) - (Items[i].PerRow * Items[i].W + (Items[i].PerRow - 1) * p.GapX)) / 2;
                    var cy = y + Items[i].H / 2;
                    for (k = 0; k < Items[i].PerRow; k++) {
                        var cx = x + k * (Items[i].W + p.GapX) + Items[i].W / 2, c = imPt(R, cx, cy);
                        var g = proto.duplicate(L, ElementPlacement.PLACEATEND);
                        g.translate(c[0] - ox, c[1] - oy);
                        if (Items[i].Rot) rotateAbout(g, 90, c[0], c[1]);
                        g.name = Items[i].Title + ' №' + (r * Items[i].PerRow + k + 1);
                        if (gl) {
                            var a = imPt(R, cx - Items[i].W / 2, cy - Items[i].H / 2), rr = gl.pathItems.roundedRectangle(a[1], a[0], pt(Items[i].W), pt(Items[i].H), pt(p.Radius), pt(p.Radius));
                            rr.filled = false; rr.stroked = true; rr.strokeWidth = pt(0.2); rr.strokeColor = rgbColor(0, 160, 220);
                        }
                        if (p.CutMarks) cornerMarks(d, R, p, cx, cy, Items[i].W, Items[i].H);
                    }
                    y += Items[i].H + p.GapY;
                }
                proto.remove();
            }
            setDocProp(d, 'layout', 'src=|' + Impose.ParamsText(p));
            var f = new File(outPath);
            if (f.exists) f.remove();
            d.saveAs(f, new IllustratorSaveOptions());
        } catch (x) {
            try { d.close(SaveOptions.DONOTSAVECHANGES); } catch (y2) { }
            logLine('сбой сборного листа: ' + x.message + ' (строка ' + x.line + ')');
            return 'Сбой сборного листа: ' + x.message;
        }
        return 'Готово: сборный лист ' + mmText(p.SheetW) + ' × ' + mmText(p.SheetH) + ' мм. ' + out.text + '\r\n' + outPath;
    }

    function describe(p, qtys) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var sel = selectionItems(app.activeDocument), out = {}, e = plan(p, sorted(sel), qtys, out);
        return e || 'Выделено макетов: ' + sel.length + '. ' + out.text;
    }

    return { run: run, describe: describe };
})();

Bridge.GangInfo = function (params, qtys) { return Gang.describe(Impose.ParamsFrom(params), qtys); };
Bridge.ImposeGang = function (params, qtys) {
    if (!PSA.has('UWCO')) return 'Сборный лист входит в части «УФ-планшет», «Рулонная печать», «Цифровая печать» и «Офсет» — их нет в вашем ключе.';
    if (!hasDoc()) return 'Нет открытого документа.';
    var p = Impose.ParamsFrom(params), d = app.activeDocument, base = 'Макеты', folder = '';
    Settings.set('Gang', 'Qty', qtys);
    try { folder = d.fullName.parent.fsName; base = d.name.replace(/\.[^.]*$/, ''); } catch (e) { }
    var f = outPath('gang', 'Сохранить сборный лист', base + ' — сборный лист.ai', folder);
    if (!f) return '';
    return Gang.run(p, qtys, f);
};
