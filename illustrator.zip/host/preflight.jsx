// Проверка макета перед печатью — как src/Preflight.bas: цвет, картинки, текст, линии, вылеты, безопасная зона,
// дубли. Проходит все печатаемые объекты (в группах и обтравках тоже), складывает найденное по видам проблем.
// Каждую можно показать (выделить объекты) и, где безопасно, исправить. Пороги — по виду печати.

var Preflight = (function () {
    var RICH_PT = 12, GRAY_LO = 50, THIN_MULTI = 0.25;
    var DUP_LAYER = 'Дубли (не печатается)', DUP_OLD = ['Дубли — проверьте (не печатается)', 'Убранные дубли (не печатается)'];
    var TECH = '|w|white|wh|белила|белый|lak|lack|varnish|v|gloss|лак|primer|праймер|cutcontour|cut|thru-cut|thrucut|kisscut|контур|';
    var Found = null, Order = [], Info = {}, Prof = null, count = 0, Seen = {}, Ins = {}, BOut = {}, HidNames = '', InsNote = '', InkArtLayer = '', InkArtByColor = false, BleedOutMm = 0;
    var Cands = [], SpotB = {}, ShadowDpiV = 300;   // объекты с эффектами; границы плашек и белил по областям

    function profileOf(key) {
        switch (key) {
            case 'digital': return { Key: key, Title: 'цифровая печать', TAC: 320, MinDpi: 200, BadDpi: 150, RGBBad: false, RichText: true, MinLine: 0.1, MinText: 5, Bleed: 2, Safe: 3 };
            case 'uv': return { Key: key, Title: 'УФ-планшет', TAC: 0, MinDpi: 150, BadDpi: 100, RGBBad: false, RichText: false, MinLine: 0.1, MinText: 5, Bleed: 1, Safe: 2 };
            case 'wide': return { Key: key, Title: 'рулонная печать', TAC: 300, MinDpi: 100, BadDpi: 60, RGBBad: false, RichText: false, MinLine: 0.3, MinText: 8, Bleed: 5, Safe: 10 };
            default: return { Key: 'offset', Title: 'офсет', TAC: 300, MinDpi: 250, BadDpi: 150, RGBBad: true, RichText: true, MinLine: 0.1, MinText: 5, Bleed: 2, Safe: 3 };
        }
    }

    function describe(key) {
        var P = Prof, d, la = InkArtLayer == Inks.Title(2);
        switch (key) {
            case 'rgb': d = (P.RGBBad ? '2' : '1') + '|Цвета в RGB|1|Печать идёт красками CMYK. RGB при выводе пересчитается как попало — яркие цвета потускнеют. Исправить — перевести в CMYK.'; break;
            case 'rgbbmp': d = (P.RGBBad ? '2' : '1') + '|Картинки в RGB|1|То же для картинок: перевод в CMYK сейчас, а не в типографии, — видно, как изменится цвет.'; break;
            case 'spot': d = '1|Плашечные цвета (Pantone)|1|Для каждой такой краски нужна отдельная форма или она пропадёт. Если печать только CMYK — перевести в CMYK.'; break;
            case 'tac': d = '2|Слишком много краски|1|Сумма четырёх красок больше ' + P.TAC + ' %: краска не сохнет, листы слипаются и пачкают друг друга. Исправить — уменьшить голубую, пурпурную и жёлтую, чёрную оставить.'; break;
            case 'richtext': d = '2|Мелкий чёрный текст из четырёх красок|1|Текст мельче ' + RICH_PT + ' пт из четырёх красок при малейшем сдвиге красок двоится и «радужит». Исправить — только чёрной краской, с наложением поверх фона.'; break;
            case 'kover': d = '1|Мелкий чёрный текст без наложения|1|Текст чистым чёрным, но без наложения: под ним в фоне вырезается дырка, и при малейшем сдвиге красок вокруг букв видна белая кайма. Исправить — включить наложение.'; break;
            case 'whiteop': d = '2|Белое с наложением|1|Белый объект с наложением при печати исчезает — белой краски нет, остаётся то, что под ним. Исправить — снять наложение.'; break;
            case 'lowdpi': d = '2|Картинки с низким разрешением|0|Меньше ' + P.BadDpi + ' точек на дюйм — будет видна «лесенка» и мыло. Нужен исходник получше: исправить здесь нельзя.'; break;
            case 'middpi': d = '1|Картинки ниже нормы по разрешению|0|Меньше ' + P.MinDpi + ' точек на дюйм для этого вида печати. Мелкие детали размоются. Лучше заменить исходник.'; break;
            case 'linked': d = '2|Картинка по ссылке не найдена|0|Картинка вставлена ссылкой на файл, а файла нет. При выводе будет пустое место или грубое превью.'; break;
            case 'nobleed': d = '2|Нет вылета|1|Объект доходит до края, но не заходит за него на ' + mmText(P.Bleed) + ' мм. ' + (P.Key == 'uv' ? 'Заготовка на столе лежит с допуском, и у края останется непропечатанная полоска.' : 'После резки по краю останется белая полоска.') + ' Исправить — растянуть объект за край (для фона незаметно, для картинки — на доли процента).'; break;
            case 'safe': d = P.Key == 'uv' ? '1|Текст близко к краю карты|0|Ближе ' + mmText(P.Safe) + ' мм к краю: заготовка на столе лежит с допуском 0,5–1 мм, и буквы могут уехать за край. Отодвиньте вручную.'
                                           : '1|Текст близко к резу|0|Ближе ' + mmText(P.Safe) + ' мм к краю: нож ходит на 1–2 мм и может срезать. Отодвиньте вручную.'; break;
            case 'text': d = '1|Текст не в кривых|1|Если в типографии нет такого шрифта, текст поедет. Исправить — перевести в кривые (номера и поля переменной печати не трогаются).'; break;
            case 'hair': d = '1|Слишком тонкие линии|1|Тоньше ' + mmText(P.MinLine) + ' мм — при печати пропадут или будут рваными. Исправить — сделать ' + mmText(P.MinLine) + ' мм.'; break;
            case 'smalltext': d = '1|Очень мелкий текст|0|Мельче ' + P.MinText + ' пт — плохо читается, а белый по тёмному забивается краской. Увеличьте вручную.'; break;
            case 'shadowrich': d = '2|Тени из четырёх красок|0|Тень чёрным или серым из нескольких красок на печати выходит грязно-серой или бурой, с цветной каймой. Исправить: «Показать», затем в панели «Оформление» (Appearance) щёлкнуть «Тень» (Drop Shadow) и поставить цвет C0 M0 Y0 K100 — Illustrator не даёт менять тень сценарием.'; break;
            case 'shadowrgb': d = '1|Тени в цветах экрана (RGB)|0|При выводе пересчитаются в четыре краски как придётся — тёмная тень станет грязной смесью. Исправить: «Показать», в панели «Оформление» щёлкнуть «Тень» и задать цвет в CMYK (для чёрной тени — C0 M0 Y0 K100).'; break;
            case 'shadowcolor': d = '0|Цветные тени|0|Тени не чёрные, а цветные — так бывает задумано (в том числе тень «по цвету объекта»). Цветная тень на цветном фоне печатается смесью красок; если должна быть просто тень — сделайте её чёрной.'; break;
            case 'shadowspot': d = '1|Тень на плашке, белилах или лаке|0|Тень ложится на объект особой краской. При выводе она затемняет его по-своему: вокруг тени может появиться прямоугольник другого оттенка или резкий край. Проверьте готовый PDF; надёжнее — тень на плашку не класть.'; break;
            case 'shadowcut': d = '1|Тень заходит за линию реза|0|Сам объект внутри, а тень уходит за край реза — после резки её срежет по краю. Если так и задумано — оставьте.'; break;
            case 'shadowres': d = '1|Тени и эффекты с низкой детализацией|1|Тени, размытия и свечения в этом документе считаются с разрешением ' + Math.round(app.activeDocument.rasterEffectSettings.resolution) + ' точек на дюйм — на печати выйдут мутными, со ступеньками. Исправить — поставить ' + ShadowDpiV + ' (настройка документа «Растровые эффекты», рисунок не меняется).'; break;
            case 'transp': d = '0|Прозрачности и эффекты|0|Прозрачность, режимы наложения. Обычно печатаются нормально, но при наложении на плашки и белое могут дать сюрприз. Проверьте готовый PDF.'; break;
            case 'outside': d = '0|Объекты за пределами монтажной области|1|Лежат целиком за краем — в печать не попадут, но путают. Исправить — убрать на отдельный непечатаемый слой.'; break;
            case 'dups': d = '1|Дубли|1|Объект лежал точно под таким же: плоттер прошёл бы дважды, краски легло бы вдвое. Найденные копии уже перенесены на слой «Дубли» и закрашены розовым — видно, где они; в печать этот слой не идёт. Исправить — удалить их.'; break;
            case 'hidden': d = '0|Скрытые или непечатаемые слои с объектами|0|Эти объекты в печать не пойдут. Убедитесь, что так и задумано.'; break;
            case 'bleedout': d = '2|Вылет за краем монтажной области|1|Область — ровно по резу, а вылет лежит снаружи, за её краем (' + mmText(BleedOutMm) + ' мм). Раскладка и проверка считают вылет частью области и примут макет за меньший — на листе он выйдет на ' + mmText(2 * BleedOutMm) + ' мм меньше. Исправить — увеличить область на вылет; рисунок останется на месте.'; break;
            case 'rasterside': d = '0|Сторона — одной картинкой|0|Весь макет стороны вставлен растром, и тексты на нём — тоже картинка. Печатать можно, но мелкий текст выйдет мягче, чем в кривых. Если у дизайнера есть исходник в кривых, лучше взять его.'; break;
            case 'graytext': d = '1|Мелкий текст не 100 % чёрным|1|Буквы серым чёрным (' + GRAY_LO + '–99 %) печатаются растровыми точками: выходят серее и с рваным краем. Если серым и задумано — оставьте; если должен быть чёрным — исправить на 100 %.'; break;
            case 'smallrich': d = '1|Мелкие буквы и значки в три-четыре краски|0|Мелкое из трёх-четырёх красок при малейшем сдвиге красок даёт цветную кайму вокруг букв. Крупным заголовкам это не страшно; мелкое лучше делать одной-двумя красками или проверить на пробном оттиске.'; break;
            case 'thinmulti': d = '1|Тонкие линии в несколько красок|0|Линии тоньше 0,25 мм из двух и более красок при сдвиге красок «двоятся». Лучше утолщить или сделать одной краской.'; break;
            case 'inkart': d = '1|Обычный рисунок на слое «' + InkArtLayer + '»|0|На слое спецкраски лежат картинки, номера или объекты разных цветов — так выглядит обычный рисунок, а не ' + (la ? 'лак' : 'белила') + '. ' +
                (InkArtByColor ? 'Сейчас краска отмечена цветом, и слой печатается в цвете, но стоит переключить её на «слоем» — всё на нём уйдёт в ' + (la ? 'лак' : 'белила') + '.'
                               : 'Слой спецкраски печатается одной краской: всё на нём выйдет ' + (la ? 'лаком' : 'белым') + ', а в цвете пропадёт.') +
                ' Перенесите рисунок на обычный слой, на «' + InkArtLayer + '» оставьте только то, что должно лечь ' + (la ? 'лаком' : 'белым') + '.'; break;
        }
        Info[key] = d;
    }

    function hit(key, it) {
        if (!Found[key]) { Found[key] = []; Order.push(key); describe(key); }
        Found[key].push(it);
    }

    // ---- цвета ----
    function isTechSpot(c) { try { return TECH.indexOf('|' + trimS(c.spot.name).toLowerCase() + '|') >= 0; } catch (e) { return false; } }
    function isWhiteC(c) {
        if (!c) return false;
        if (c.typename == 'CMYKColor') return c.cyan + c.magenta + c.yellow + c.black == 0;
        if (c.typename == 'RGBColor') return c.red == 255 && c.green == 255 && c.blue == 255;
        if (c.typename == 'GrayColor') return c.gray == 0;
        return false;
    }
    function isInkSpotColor(c) {
        if (c.typename != 'SpotColor') return false;
        var n = trimS(c.spot.name).toLowerCase();
        for (var i = 1; i <= INK_COUNT; i++) if (n == trimS(Inks.SpotName[i]).toLowerCase() || n == trimS(Inks.OutName[i]).toLowerCase()) return true;
        return false;
    }
    function colorChecks(it, c) {
        if (!c) return;
        switch (c.typename) {
            case 'RGBColor': case 'LabColor': hit('rgb', it); break;
            case 'SpotColor':
                if (c.spot.name == '[Registration]' || c.spot.name == '[Совмещение]') return;
                if (c.spot.colorType == ColorModel.SPOT && !isInkSpotColor(c) && !isTechSpot(c)) hit('spot', it);
                if (c.spot.colorType == ColorModel.SPOT && !isTechSpot(c)) spotAdd(it);
                else if (c.spot.colorType != ColorModel.SPOT) colorChecks(it, c.spot.color);   // глобальный цвет — по его составу
                break;
            case 'CMYKColor': if (Prof.TAC > 0 && c.cyan + c.magenta + c.yellow + c.black > Prof.TAC) hit('tac', it); break;
            case 'GradientColor':
                try { var st = c.gradient.gradientStops; for (var i = 0; i < st.length; i++) colorChecks(it, st[i].color); } catch (e) { }
                break;
        }
    }
    function sig(c) {
        try {
            switch (c.typename) {
                case 'CMYKColor': return 'c' + Math.round(c.cyan) + '.' + Math.round(c.magenta) + '.' + Math.round(c.yellow) + '.' + Math.round(c.black);
                case 'RGBColor': return 'r' + Math.round(c.red) + '.' + Math.round(c.green) + '.' + Math.round(c.blue);
                case 'GrayColor': return 'g' + Math.round(c.gray);
                case 'SpotColor': return 's' + c.spot.name + '.' + Math.round(c.tint);
                default: return 'x' + c.typename;
            }
        } catch (e) { return 'x?'; }
    }
    function nInk(c) { return (c.cyan >= 10 ? 1 : 0) + (c.magenta >= 10 ? 1 : 0) + (c.yellow >= 10 ? 1 : 0) + (c.black >= 10 ? 1 : 0); }

    // ---- обход ----
    function isField(it) { return it.name.substring(0, TAG_FIELD.length) == TAG_FIELD; }

    function shapeChecks(it) {
        var p = it.typename == 'CompoundPathItem' && it.pathItems.length ? it.pathItems[0] : it, t = it.typename, w = 0, fc = null;
        try { if (it.opacity < 100 || it.blendingMode != BlendModes.NORMAL) hit('transp', it); } catch (e) { }
        if (t == 'RasterItem' || t == 'PlacedItem') { bitmapChecks(it); return; }
        if (t == 'TextFrame') { textChecks(it); return; }
        if (p.typename != 'PathItem') return;
        if (p.filled) { fc = p.fillColor; colorChecks(it, fc); if (p.fillOverprint && isWhiteC(fc)) hit('whiteop', it); }
        if (p.stroked && p.strokeWidth > 0) {
            w = mm(p.strokeWidth);
            colorChecks(it, p.strokeColor);
            if (w < Prof.MinLine - 0.0001) hit('hair', it);
            if (p.strokeOverprint && isWhiteC(p.strokeColor)) hit('whiteop', it);
            if (w < THIN_MULTI - 0.0001 && w >= Prof.MinLine - 0.0001 && p.strokeColor.typename == 'CMYKColor' && nInk(p.strokeColor) >= 2) hit('thinmulti', it);
        }
        // мелкое (значки меньше 6 мм): серый чёрный, три-четыре краски
        if (fc && fc.typename == 'CMYKColor' && !isField(it) && mm(it.width) < 6 && mm(it.height) < 6) {
            if (fc.cyan + fc.magenta + fc.yellow == 0 && fc.black >= GRAY_LO && fc.black < 100) hit('graytext', it);
            else if (nInk(fc) >= 3) hit('smallrich', it);
        }
    }

    function textChecks(it) {
        if (!isField(it)) hit('text', it);
        try {
            var a = it.textRange.characterAttributes, sz = a.size, c = a.fillColor;
            colorChecks(it, c);
            if (sz > 0 && sz < Prof.MinText) hit('smalltext', it);
            if (c.typename == 'CMYKColor' && sz > 0 && sz < 12 && !isField(it)) {
                if (c.cyan + c.magenta + c.yellow == 0 && c.black >= GRAY_LO && c.black < 100) hit('graytext', it);
                else if (nInk(c) >= 3 && c.black < 80) hit('smallrich', it);
            }
            if (!Prof.RichText || sz <= 0 || sz >= RICH_PT) return;
            if (c.typename == 'CMYKColor') {
                var cmy = c.cyan + c.magenta + c.yellow;
                if (c.black >= 80 && cmy > 0) hit('richtext', it);
                else if (c.black >= 95 && cmy == 0 && !a.overprintFill) hit('kover', it);
            } else if (c.typename == 'RGBColor' && c.red < 40 && c.green < 40 && c.blue < 40) hit('richtext', it);
        } catch (e) { }
    }

    function bitmapChecks(it) {
        try {
            var d = app.activeDocument, ab = abIndexOf(d, it);
            if (ab >= 0) { var r = d.artboards[ab].artboardRect; if (it.width * it.height >= 0.85 * (r[2] - r[0]) * (r[1] - r[3])) hit('rasterside', it); }
            if (it.typename == 'PlacedItem') { var ok = false; try { ok = it.file.exists; } catch (e) { ok = false; } if (!ok) { hit('linked', it); return; } }
            if (it.typename == 'RasterItem') {
                var cs = it.imageColorSpace;
                if (cs == ImageColorSpace.RGB || cs == ImageColorSpace.LAB) hit('rgbbmp', it);
                // действующее разрешение: точек картинки на дюйм листа (по меньшему)
                var bb = it.boundingBox, px = Math.abs(bb[2] - bb[0]), py = Math.abs(bb[1] - bb[3]), w = it.width / 72, h = it.height / 72;
                if (px > 0 && py > 0 && w > 0 && h > 0) {
                    var dpi = (px > py) != (w > h) ? Math.min(px / h, py / w) : Math.min(px / w, py / h);
                    if (dpi < Prof.BadDpi) hit('lowdpi', it); else if (dpi < Prof.MinDpi) hit('middpi', it);
                }
            }
        } catch (e) { }
    }

    // дубли: совпасть должно всё — место до сотой мм, размер, цвета, форма, содержимое; сомнение — не дубль
    function R2(v) { return (Math.round(v * 100) / 100).toFixed(2); }
    function specialLayer(it) {
        var n = it.layer.name;
        return (Inks.IsInkLayer(n) || n == CUT_LAYER_ROLL || n == CUT_LAYER || n == PREPRESS_LAYER || n == GUIDE_LAYER || n == 'Метки плоттера' || n == 'Люверсы') ? '|L' + n : '';
    }
    function dupSig(it, ab) {
        try {
            if (mm(it.width) <= 0.01 && mm(it.height) <= 0.01) return '';
            if (isField(it)) return '';
            var b = it.geometricBounds, t = ab + '|' + it.typename + '|' + R2(mm(b[0])) + ',' + R2(mm(b[3])) + ',' + R2(mm(it.width)) + ',' + R2(mm(it.height)) + specialLayer(it);
            switch (it.typename) {
                case 'GroupItem':
                    if (it.clipped || it.pageItems.length > 50) return '';
                    t += '|g' + it.pageItems.length + '[';
                    for (var i = 0; i < it.pageItems.length; i++) { var s = dupSig(it.pageItems[i], ab); if (!s) return ''; t += s + ';'; }
                    return t + ']';
                case 'TextFrame': return t + '|' + sig(it.textRange.characterAttributes.fillColor) + '|t' + it.contents.substring(0, 60) + it.contents.length;
                case 'RasterItem': var bb = it.boundingBox; return t + '|b' + Math.round(bb[2] - bb[0]) + 'x' + Math.round(bb[1] - bb[3]);
                case 'PathItem':
                    var pp = it.pathPoints, n = pp.length, st = n > 12 ? Math.floor(n / 12) : 1;
                    t += '|' + (it.filled ? 'f' + sig(it.fillColor) : 'f-') + '|' + (it.stroked ? 'o' + R2(it.strokeWidth) + sig(it.strokeColor) : 'o-') + '|n' + n;
                    for (i = 0; i < n; i += st) t += ';' + R2(pp[i].anchor[0]) + ',' + R2(pp[i].anchor[1]);
                    return t;
                case 'CompoundPathItem':
                    if (!it.pathItems.length) return '';
                    var p0 = it.pathItems[0];
                    return t + '|cp' + it.pathItems.length + '|' + (p0.filled ? sig(p0.fillColor) : '-') + '|' + p0.pathPoints.length;
                default: return '';
            }
        } catch (e) { return ''; }
    }
    function dupCheck(it, ab) {
        if (ab < 0) return false;
        var k = dupSig(it, ab);
        if (!k) return false;
        if (Seen.hasOwnProperty(k)) { hit('dups', it); return true; }
        Seen[k] = 1;
        return false;
    }

    function walk(it, ab) {
        count++;
        if (it.name == 'Вылет зеркалом') return;       // отражённые копии того же рисунка
        var t = it.typename;
        try { if (t == 'PathItem' && it.guides) return; } catch (e) { }
        if (t == 'GroupItem') {
            if (dupCheck(it, ab)) return;
            effCand(it, ab);
            for (var i = 0; i < it.pageItems.length; i++) {
                var ch = it.pageItems[i];
                try { if (it.clipped && ch.clipping) continue; } catch (e) { }
                walk(ch, ab);
            }
            return;
        }
        if (t == 'SymbolItem') return;
        shapeChecks(it);
        effCand(it, ab);
        dupCheck(it, ab);
    }

    // ---- тени ----
    // Тень в Illustrator — эффект оформления; сценарий его настроек не видит. Объект с эффектом узнаём по границам:
    // видимые шире настоящих (на обводку поправка), у графического стиля Illustrator отдаёт и вовсе нелепые границы.
    // Настройки тени читаем из файла: копии таких объектов — во временный документ, он сохраняется без сжатия,
    // и в его тексте у каждого объекта видно имя его оформления, а у оформления — тень: цвет, сдвиг, размытие.
    function effCand(it, ab) {
        if (Cands.length >= 300) return;
        try {
            var g = it.geometricBounds, v = it.visibleBounds, sw = 0, grow;
            if (!(v[0] <= v[2]) || !(v[3] <= v[1]) || Math.abs(v[0]) > 1e5 || Math.abs(v[1]) > 1e5) { Cands.push({ it: it, ab: ab }); return; }
            if (it.typename == 'TextFrame') return;          // у текста видимые границы и так шире — тени на тексте редкость
            try { if (it.typename == 'PathItem' && it.stroked) sw = it.strokeWidth; } catch (e) { }
            if (it.typename == 'GroupItem') {
                // у группы своё оформление видно, если она шире своих частей
                var u = null;
                for (var i = 0; i < it.pageItems.length; i++) {
                    var cb = visBounds(it.pageItems[i]);
                    if (!u) u = [cb[0], cb[1], cb[2], cb[3]]; else { u[0] = Math.min(u[0], cb[0]); u[1] = Math.max(u[1], cb[1]); u[2] = Math.max(u[2], cb[2]); u[3] = Math.min(u[3], cb[3]); }
                }
                if (!u) return;
                g = u;
            }
            grow = Math.max(g[0] - v[0], v[2] - g[2], v[1] - g[1], g[3] - v[3]) - sw / 2;
            if (grow > (it.typename == 'PathItem' ? Math.max(1, sw * 5) : 1)) Cands.push({ it: it, ab: ab });
        } catch (e) { }
    }
    function spotAdd(it) {
        try { var ab = abIndexOf(app.activeDocument, it); if (ab < 0) return; if (!SpotB[ab]) SpotB[ab] = []; SpotB[ab].push({ it: it, b: it.geometricBounds }); } catch (e) { }
    }
    function shadowColor(line) {
        var m;
        line = trimS(line);
        if ((m = line.match(/^([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+) k$/))) return { t: 'cmyk', c: +m[1] * 100, m: +m[2] * 100, y: +m[3] * 100, k: +m[4] * 100 };
        if ((m = line.match(/^([\d.]+) g$/))) return { t: 'gray' };
        if (line.match(/^[\d.]+ [\d.]+ [\d.]+ Xa$/)) return { t: 'rgb' };
        if (line.match(/\) [\d.]+ (x|Xx)$/) || line.match(/ Xx$/)) return { t: 'spot' };
        return { t: '?' };
    }
    function shadowNeutral(c) {
        var mx = Math.max(c.c, c.m, c.y), mn = Math.min(c.c, c.m, c.y);
        return mx - mn <= 30 || c.k >= 60;
    }
    // настройки тени и признак растровых эффектов из описания оформления (графического стиля) в файле
    // nl — перевод строки в файле: весь файл (мегабайты) переводы строк не правим — в движке Illustrator это минуты
    function styleInfo(txt, name, nl) {
        var key = '/KnownStyle :' + nl + '(' + name + ') /Name ,', i = txt.indexOf(key);
        if (i < 0) return null;
        var j = txt.indexOf('/KnownStyle :', i + key.length); if (j < 0) j = txt.length;
        var st = txt.substring(i, j).replace(/\r\n?/g, '\n'), r = { shadows: [], raster: /\((Adobe Drop Shadow|Adobe Gaussian Blur|Adobe Inner Glow|Adobe Outer Glow|Adobe Fuzzy Mask|Adobe Radial Blur|Adobe Smart Blur)\)/.test(st) };
        var pos = 0;
        while ((pos = st.indexOf('(Adobe Drop Shadow) 1 0 /Filter', pos)) >= 0) {
            var end = st.indexOf('; /Dict ;', pos); if (end < 0) end = st.length;
            var blk = st.substring(pos, end), sh = { horz: 7, vert: 7, blur: 5, csrc: 1, dark: 0, color: { t: 'cmyk', c: 0, m: 0, y: 0, k: 100 } }, m;
            if ((m = blk.match(/([-\d.]+) \/Real \(horz\)/))) sh.horz = +m[1];
            if ((m = blk.match(/([-\d.]+) \/Real \(vert\)/))) sh.vert = +m[1];
            if ((m = blk.match(/([-\d.]+) \/Real \(blur\)/))) sh.blur = +m[1];
            if ((m = blk.match(/([-\d.]+) \/Int \(csrc\)/))) sh.csrc = +m[1];
            if ((m = blk.match(/([-\d.]+) \/Real \(dark\)/))) sh.dark = +m[1];
            var f = blk.indexOf('/FillStyle :');
            if (f >= 0) { var ls = blk.substring(f).split('\n'); if (ls.length > 1) sh.color = shadowColor(ls[1]); }
            r.shadows.push(sh);
            pos = end;
        }
        return r;
    }
    function shadowScan(d) {
        if (!Cands.length) return;
        var marks = [], i, tmp = null, f = new File(Folder.temp.fsName + '/psa_shadow_scan.ai'), txt = '';
        // метки на время: имя объекта → PSASH<n>, потом вернуть
        for (i = 0; i < Cands.length; i++) { try { marks.push(Cands[i].it.name); Cands[i].it.name = 'PSASH' + i; } catch (e) { marks.push(null); } }
        var bounds = [];
        for (i = 0; i < Cands.length; i++) { try { bounds.push(Cands[i].it.geometricBounds); } catch (e) { bounds.push(null); } }
        try {
            tmp = app.documents.add(d.documentColorSpace, 200, 200);
            var L = tmp.layers[0];
            for (i = 0; i < Cands.length; i++) { try { Cands[i].it.duplicate(L, ElementPlacement.PLACEATEND); } catch (e) { } }
            var o = new IllustratorSaveOptions(); o.compressed = false; o.pdfCompatible = false; o.embedICCProfile = false;
            tmp.saveAs(f, o);
        } catch (e) { logLine('тени: временный документ не сохранился — ' + e); }
        try { if (tmp) tmp.close(SaveOptions.DONOTSAVECHANGES); } catch (e) { }
        try { app.activeDocument = d; } catch (e) { }
        for (i = 0; i < Cands.length; i++) { try { if (marks[i] !== null) Cands[i].it.name = marks[i]; } catch (e) { } }
        try { f.encoding = 'BINARY'; if (f.open('r')) { txt = f.read(); f.close(); } f.remove(); } catch (e) { }
        if (!txt) return;
        var nl = txt.indexOf('\r\n') >= 0 ? '\r\n' : (txt.indexOf('\r') >= 0 ? '\r' : '\n');
        var styles = {}, anyRaster = false;
        for (i = 0; i < Cands.length; i++) {
            var mk = '(PSASH' + i + ') ; (AI10_ArtUID)', at = txt.indexOf(mk);
            if (at < 0) continue;
            var tail = txt.substring(at, at + 600).replace(/\r\n?/g, '\n'), nx = tail.indexOf('/XMLUID', 10); if (nx > 0) tail = tail.substring(0, nx);
            var m = tail.match(/\n\d+ \((.+)\) XW\n/);
            if (!m) continue;
            if (!styles.hasOwnProperty(m[1])) styles[m[1]] = styleInfo(txt, m[1], nl);
            var si = styles[m[1]];
            if (!si) continue;
            if (si.raster) anyRaster = true;
            for (var k = 0; k < si.shadows.length; k++) shadowHit(d, Cands[i], bounds[i], si.shadows[k]);
        }
        if (anyRaster && d.rasterEffectSettings.resolution < ShadowDpiV) hit('shadowres', Cands[0].it);
    }
    function shadowHit(d, cd, b, sh) {
        var it = cd.it, c = sh.color;
        if (sh.csrc == 0) hit(sh.dark >= 60 ? 'shadowrich' : 'shadowcolor', it);       // тень «по цвету объекта»
        else if (c.t == 'cmyk') { if (c.c + c.m + c.y > 0.5) hit(shadowNeutral(c) ? 'shadowrich' : 'shadowcolor', it); }
        else if (c.t == 'rgb') hit('shadowrgb', it);
        else if (c.t == 'spot') hit('shadowcolor', it);
        if (!b) return;
        // где лежит тень: объект, сдвинутый на смещение (в Illustrator вниз — плюс)
        var sb = [b[0] + sh.horz, b[1] - sh.vert, b[2] + sh.horz, b[3] - sh.vert], sp = SpotB[cd.ab] || [], i;
        for (i = 0; i < sp.length; i++) {
            if (sp[i].it == it) continue;
            var q = sp[i].b;
            if (sb[0] < q[2] && sb[2] > q[0] && sb[3] < q[1] && sb[1] > q[3]) { hit('shadowspot', it); break; }
        }
        var r = d.artboards[cd.ab].artboardRect, n = pt(Ins[cd.ab] || 0), e = pt(0.2);
        var lx = r[0] + n, rx = r[2] - n, by = r[3] + n, ty = r[1] - n;
        if (b[0] >= lx && b[2] <= rx && b[3] >= by && b[1] <= ty && (sb[0] < lx - e || sb[2] > rx + e || sb[3] < by - e || sb[1] > ty + e)) hit('shadowcut', it);
    }

    // ---- края ----
    function inset(r) { return insetOfSize(mm(r[2] - r[0]), mm(r[1] - r[3])); }
    function bleedOutside(d, ab) {
        var r = d.artboards[ab].artboardRect, all = [], i;
        for (i = 0; i < d.layers.length; i++) {
            var L = d.layers[i];
            if (L.printable && L.visible && L.name != CUT_LAYER && L.name != PREPRESS_LAYER) all = all.concat(topItemsOn(d, L, ab));
        }
        if (!all.length) return 0;
        // насколько рисунок выходит за каждый край: слева, справа, снизу, сверху
        var b = boundsOf(all), a = mm(r[0] - b[0]), bb = mm(b[2] - r[2]), c = mm(r[3] - b[3]), dd = mm(b[1] - r[1]);
        var mn = Math.min(a, bb, c, dd), mx = Math.max(a, bb, c, dd);
        return (mn >= 0.5 && mx <= 10 && mx - mn < 0.3) ? Math.round((a + bb + c + dd) / 4 * 100) / 100 : 0;
    }
    function needsBleed(it) {
        var t = it.typename;
        if (t == 'RasterItem' || t == 'PlacedItem' || t == 'GroupItem' || t == 'SymbolItem') return true;
        var p = t == 'CompoundPathItem' && it.pathItems.length ? it.pathItems[0] : it;
        try { return p.typename == 'PathItem' && p.filled && !isWhiteC(p.fillColor); } catch (e) { return false; }
    }
    function hasText(it) {
        if (it.typename != 'GroupItem') return false;
        for (var i = 0; i < it.pageItems.length; i++) if (it.pageItems[i].typename == 'TextFrame' || hasText(it.pageItems[i])) return true;
        return false;
    }
    function textNearEdge(it, r, z) {
        if (it.typename == 'TextFrame') {
            var b = visBounds(it);
            return b[0] < r[0] + pt(z) || b[2] > r[2] - pt(z) || b[3] < r[3] + pt(z) || b[1] > r[1] - pt(z);
        }
        for (var i = 0; i < it.pageItems.length; i++) if ((it.pageItems[i].typename == 'TextFrame' || it.pageItems[i].typename == 'GroupItem') && textNearEdge(it.pageItems[i], r, z)) return true;
        return false;
    }
    function pageChecks(d, it, ab) {
        var r = d.artboards[ab].artboardRect, b = visBounds(it), e = pt(0.05), B = pt(Prof.Bleed);
        if (b[2] < r[0] - B - pt(1) || b[0] > r[2] + B + pt(1) || b[1] < r[3] - B - pt(1) || b[3] > r[1] + B + pt(1)) { hit('outside', it); return; }
        var n = pt(Ins[ab] || 0), lx = r[0] + n, rx = r[2] - n, by = r[3] + n, ty = r[1] - n;
        var nm = d.artboards[ab].name;
        if (nm.substring(0, 7) == 'Лист — ' || nm == 'Лист' || nm == 'Рулон' || isField(it)) return;
        if (BOut.hasOwnProperty(ab)) return;
        if (Prof.Bleed > 0 && it.typename != 'TextFrame' && needsBleed(it)) {
            if ((b[0] <= lx + e && b[0] > lx - B + e) || (b[2] >= rx - e && b[2] < rx + B - e) || (b[3] <= by + e && b[3] > by - B + e) || (b[1] >= ty - e && b[1] < ty + B - e)) hit('nobleed', it);
        }
        if ((it.typename == 'TextFrame' || hasText(it)) && textNearEdge(it, r, Prof.Safe + (Ins[ab] || 0))) hit('safe', it);
    }

    // слой спецкраски: картинки, номера и разные цвета на нём — это рисунок, положенный не туда
    function inkLayerIdx(name) {
        for (var i = 1; i <= INK_COUNT; i++) { var nm = Inks.LayerName[i] || Inks.Title(i); if (name.toLowerCase() == nm.toLowerCase() || name.toLowerCase() == Inks.Title(i).toLowerCase()) return i; }
        return 0;
    }
    function inkArtCheck(d, L) {
        var cols = {}, nc = 0, flags = 0, top = topItemsOn(d, L, -1), lv = leavesOf(top), i;
        for (i = 0; i < lv.length; i++) {
            var it = lv[i];
            if (isField(it)) flags |= 2;
            if (it.typename == 'RasterItem' || it.typename == 'PlacedItem') { flags |= 1; continue; }
            var p = it.typename == 'CompoundPathItem' && it.pathItems.length ? it.pathItems[0] : it;
            try {
                var c = p.typename == 'TextFrame' ? p.textRange.characterAttributes.fillColor : (p.filled ? p.fillColor : null);
                if (c && c.typename == 'GradientColor') flags |= 4;
                else if (c) { var k = sig(c); if (!cols[k]) { cols[k] = 1; nc++; } }
            } catch (e) { }
        }
        if (!flags && nc <= 1) return;
        if (!InkArtLayer) { InkArtLayer = L.name; InkArtByColor = Inks.ByColor[inkLayerIdx(L.name)]; }
        for (i = 0; i < top.length; i++) hit('inkart', top[i]);
    }

    function isDupLayer(L) { return L.name == DUP_LAYER || L.name == DUP_OLD[0] || L.name == DUP_OLD[1]; }
    function pink(it) {
        var c = rgbColor(255, 0, 170), lv = leavesOf([it]);
        for (var i = 0; i < lv.length; i++) {
            var p = lv[i].typename == 'CompoundPathItem' ? lv[i].pathItems : [lv[i]];
            for (var k = 0; k < p.length; k++) try {
                if (p[k].typename == 'TextFrame') { p[k].textRange.characterAttributes.fillColor = c; continue; }
                if (p[k].typename != 'PathItem') continue;
                if (p[k].filled) p[k].fillColor = c;
                if (p[k].stroked) p[k].strokeColor = c;
            } catch (e) { }
        }
    }

    function check(profileKey, bleed, safe) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, ab, i, k;
        Prof = profileOf(profileKey);
        if (bleed >= 0) Prof.Bleed = bleed;
        if (safe >= 0) Prof.Safe = safe;
        Found = {}; Order = []; Info = {}; Seen = {}; Ins = {}; BOut = {}; HidNames = ''; InsNote = ''; InkArtLayer = ''; count = 0;
        Cands = []; SpotB = {}; ShadowDpiV = (Prof.MinDpi > 0 && Prof.MinDpi < 150) ? 150 : 300;
        for (ab = 0; ab < d.artboards.length; ab++) {
            if (d.artboards[ab].name == TEMPLATE_PAGE) continue;
            var r = d.artboards[ab].artboardRect;
            Ins[ab] = inset(r);
            BleedOutMm = bleedOutside(d, ab);
            if (BleedOutMm > 0) {
                Ins[ab] = 0; BOut[ab] = BleedOutMm;
                var big = null, ba = 0;
                for (i = 0; i < d.layers.length; i++) { var tl = topItemsOn(d, d.layers[i], ab); for (k = 0; k < tl.length; k++) if (tl[k].width * tl[k].height > ba) { ba = tl[k].width * tl[k].height; big = tl[k]; } }
                if (big) hit('bleedout', big);
            }
            if (Ins[ab] > 0 && !InsNote) InsNote = ' Область ' + mmText(mm(r[2] - r[0])) + ' × ' + mmText(mm(r[1] - r[3])) + ' мм — это макет ' + mmText(mm(r[2] - r[0]) - 2 * Ins[ab]) + ' × ' +
                mmText(mm(r[1] - r[3]) - 2 * Ins[ab]) + ' с вылетом ' + mmText(Ins[ab]) + ' мм: ' + (Prof.Key == 'uv' ? 'край карты' : 'край реза') + ' считается внутри области.';
            for (i = 0; i < d.layers.length; i++) {
                var L = d.layers[i], items = topItemsOn(d, L, ab);
                if (!items.length) continue;
                if (!L.printable || !L.visible) {
                    if (L.name == GUIDE_LAYER) continue;
                    for (k = 0; k < items.length; k++) hit(isDupLayer(L) ? 'dups' : 'hidden', items[k]);
                    if (!isDupLayer(L)) HidNames += (HidNames ? '; ' : '') + (d.artboards.length > 1 ? 'обл. «' + d.artboards[ab].name + '» — ' : '') + '«' + L.name + '» (' + items.length + ')';
                    continue;
                }
                if (L.name == CUT_LAYER || L.name == PREPRESS_LAYER) continue;
                if (inkLayerIdx(L.name) > 0) { inkArtCheck(d, L); for (k = 0; k < items.length; k++) spotAdd(items[k]); }
                for (k = 0; k < items.length; k++) { walk(items[k], ab); pageChecks(d, items[k], ab); }
            }
        }
        try { shadowScan(d); } catch (e) { logLine('тени: ' + e); }
        // найденные дубли — сразу на свой слой и в один цвет: видно, где они
        if (Found.dups) for (i = 0; i < Found.dups.length; i++) {
            var it = Found.dups[i];
            if (isDupLayer(it.layer)) continue;
            var DL = layerNamed(d, DUP_LAYER, false);
            DL.visible = true;
            it.move(DL, ElementPlacement.PLACEATBEGINNING);
            pink(it);
        }
        if (HidNames) Info.hidden = '0|Скрытые или непечатаемые слои с объектами|0|В печать не пойдут: ' + HidNames + '. Убедитесь, что так и задумано. «Показать» сделает слой видимым — печататься он всё равно не будет.';
        var t = '', errs = 0, warns = 0;
        for (i = 0; i < Order.length; i++) {
            k = Order[i];
            var lvl = Info[k].charAt(0);
            if (lvl == '2') errs++; else if (lvl == '1') warns++;
            t += '\n' + k + '|' + Info[k] + '|' + Found[k].length;
        }
        return 'Проверено объектов: ' + count + ' (' + Prof.Title + ', вылет ' + mmText(Prof.Bleed) + ' мм, безопасная зона ' + mmText(Prof.Safe) + ' мм). ' +
               (errs + warns == 0 ? 'Серьёзных проблем нет.' : 'Ошибок: ' + errs + ', предупреждений: ' + warns + '.') + InsNote + t;
    }

    // ---- показать ----
    function show(key) {
        if (!Found) return 'Сначала нажмите «Проверить».';
        var c = Found[key];
        if (!c) return 'Этой проблемы уже нет — проверьте заново.';
        var d = app.activeDocument, shown = '', i, n = 0, ab = -1;
        try {
            for (i = 0; i < c.length; i++) if (!c[i].layer.visible) { c[i].layer.visible = true; if (shown.indexOf('«' + c[i].layer.name + '»') < 0) shown += (shown ? ', ' : '') + '«' + c[i].layer.name + '»'; }
            d.selection = null;
            for (i = 0; i < c.length; i++) {
                var a = abIndexOf(d, c[i]);
                if (ab < 0) ab = a;
                if (a != ab) continue;
                try { c[i].selected = true; n++; } catch (e) { }
            }
            if (ab >= 0) {
                d.artboards.setActiveArtboardIndex(ab);
                var b = boundsOf(c.slice(0, 1));
                try { d.views[0].centerPoint = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2]; } catch (e) { }
            }
        } catch (e) { return 'Не удалось показать: ' + e.message; }
        return 'Выделено: ' + n + (n < c.length ? ' из ' + c.length + ' (остальные на других областях)' : '') + '.' +
               (shown ? ' Слой ' + shown + ' сделан видимым, чтобы показать; в печать он не идёт.' : '') +
               (key == 'dups' ? ' Дубли — на слое «Дубли», закрашены розовым. «Исправить» удалит их.' : '');
    }

    // ---- исправить ----
    function toCMYK(c) {
        try {
            if (c.typename == 'RGBColor') { var v = app.convertSampleColor(ImageColorSpace.RGB, [c.red, c.green, c.blue], ImageColorSpace.CMYK, ColorConvertPurpose.defaultpurpose); return cmykColor(v[0], v[1], v[2], v[3]); }
            if (c.typename == 'LabColor') { var w = app.convertSampleColor(ImageColorSpace.LAB, [c.l, c.a, c.b], ImageColorSpace.CMYK, ColorConvertPurpose.defaultpurpose); return cmykColor(w[0], w[1], w[2], w[3]); }
            if (c.typename == 'SpotColor') {
                var s = c.spot.color, t = c.tint / 100;
                if (s.typename == 'CMYKColor') return cmykColor(s.cyan * t, s.magenta * t, s.yellow * t, s.black * t);
                if (s.typename == 'RGBColor') { var x = toCMYK(s); return cmykColor(x.cyan * t, x.magenta * t, x.yellow * t, x.black * t); }
            }
        } catch (e) { }
        return null;
    }
    function needConv(c, key) {
        if (!c) return false;
        if (c.typename == 'SpotColor') return key == 'spot' && c.spot.colorType == ColorModel.SPOT && !isTechSpot(c) && !isInkSpotColor(c) && c.spot.name != '[Registration]';
        return key == 'rgb' && (c.typename == 'RGBColor' || c.typename == 'LabColor');
    }
    function fixColors(it, key) {
        var lv = leavesOf([it]);
        for (var i = 0; i < lv.length; i++) {
            var ps = lv[i].typename == 'CompoundPathItem' ? lv[i].pathItems : [lv[i]];
            for (var k = 0; k < ps.length; k++) {
                var p = ps[k];
                try {
                    if (p.typename == 'TextFrame') { var a = p.textRange.characterAttributes; if (needConv(a.fillColor, key)) a.fillColor = toCMYK(a.fillColor); continue; }
                    if (p.typename != 'PathItem') continue;
                    if (p.filled && needConv(p.fillColor, key)) p.fillColor = toCMYK(p.fillColor);
                    if (p.stroked && needConv(p.strokeColor, key)) p.strokeColor = toCMYK(p.strokeColor);
                } catch (e) { }
            }
        }
    }
    function tacColor(c) {
        if (!c || c.typename != 'CMYKColor') return null;
        var k = c.black, cmy = c.cyan + c.magenta + c.yellow;
        if (cmy + k <= Prof.TAC || cmy == 0) return null;
        var f = Math.max(0, (Prof.TAC - k) / cmy);
        return cmykColor(Math.floor(c.cyan * f), Math.floor(c.magenta * f), Math.floor(c.yellow * f), k);
    }
    function fixTac(it) {
        var lv = leavesOf([it]);
        for (var i = 0; i < lv.length; i++) {
            var ps = lv[i].typename == 'CompoundPathItem' ? lv[i].pathItems : [lv[i]];
            for (var k = 0; k < ps.length; k++) {
                var p = ps[k], n;
                try {
                    if (p.typename == 'TextFrame') { n = tacColor(p.textRange.characterAttributes.fillColor); if (n) p.textRange.characterAttributes.fillColor = n; continue; }
                    if (p.filled) { n = tacColor(p.fillColor); if (n) p.fillColor = n; }
                    if (p.stroked) { n = tacColor(p.strokeColor); if (n) p.strokeColor = n; }
                } catch (e) { }
            }
        }
    }
    function setFill(it, c, over) {
        var lv = leavesOf([it]);
        for (var i = 0; i < lv.length; i++) {
            var p = lv[i];
            try {
                if (p.typename == 'TextFrame') { var a = p.textRange.characterAttributes; a.fillColor = c; if (over !== undefined) a.overprintFill = over; }
                else if (p.typename == 'PathItem') { p.fillColor = c; if (over !== undefined) p.fillOverprint = over; }
            } catch (e) { }
        }
    }
    // вылет: сторону, что касается края, вытягиваем за край на величину вылета
    function fixBleed(d, it) {
        var ab = abIndexOf(d, it); if (ab < 0) return;
        var r = d.artboards[ab].artboardRect, n = pt(Ins[ab] || 0), e = pt(0.05), B = pt(Prof.Bleed);
        var lx = r[0] + n, rx = r[2] - n, by = r[3] + n, ty = r[1] - n, b = it.geometricBounds;
        var x0 = b[0], x1 = b[2], y0 = b[3], y1 = b[1];
        if (x0 <= lx + e && x0 > lx - B + e) x0 = lx - B;
        if (x1 >= rx - e && x1 < rx + B - e) x1 = rx + B;
        if (y0 <= by + e && y0 > by - B + e) y0 = by - B;
        if (y1 >= ty - e && y1 < ty + B - e) y1 = ty + B;
        it.resize((x1 - x0) / (b[2] - b[0]) * 100, (y1 - y0) / (b[1] - b[3]) * 100, true, true, true, true, 100, Transformation.TOPLEFT);
        var nb = it.geometricBounds;
        it.translate(x0 - nb[0], y1 - nb[1]);
    }
    function fixBleedOut(d, ab) {
        var e = bleedOutside(d, ab);
        if (e <= 0) return;
        var r = d.artboards[ab].artboardRect;
        Settings.set('Impose', 'CutW', Math.round(mm(r[2] - r[0]) * 100) / 100); Settings.set('Impose', 'CutH', Math.round(mm(r[1] - r[3]) * 100) / 100); Settings.set('Impose', 'Bleed', e);
        d.artboards[ab].artboardRect = [r[0] - pt(e), r[1] + pt(e), r[2] + pt(e), r[3] - pt(e)];
    }
    function fixOne(key) {
        var c = Found[key], n = 0, d = app.activeDocument, lay = null, i, it;
        if (!c) return 0;
        for (i = 0; i < c.length; i++) {
            it = c[i];
            try {
                switch (key) {
                    case 'rgb': case 'spot': fixColors(it, key); break;
                    case 'rgbbmp': d.selection = null; it.selected = true; app.executeMenuCommand('Colors8'); d.selection = null; break;   // «Преобразовать в CMYK»
                    case 'tac': fixTac(it); break;
                    case 'graytext': setFill(it, cmykColor(0, 0, 0, 100)); break;
                    case 'bleedout': fixBleedOut(d, abIndexOf(d, it)); break;
                    case 'richtext': case 'kover': setFill(it, cmykColor(0, 0, 0, 100), true); break;
                    case 'whiteop':
                        var lv = leavesOf([it]);
                        for (var k = 0; k < lv.length; k++) try { lv[k].fillOverprint = false; lv[k].strokeOverprint = false; } catch (e) { }
                        break;
                    case 'hair':
                        var lh = leavesOf([it]);
                        for (k = 0; k < lh.length; k++) try { if (lh[k].stroked) lh[k].strokeWidth = pt(Prof.MinLine); } catch (e) { }
                        break;
                    case 'text': if (it.typename == 'TextFrame') it.createOutline(); break;
                    case 'nobleed': fixBleed(d, it); break;
                    case 'shadowres': if (d.rasterEffectSettings.resolution < ShadowDpiV) d.rasterEffectSettings.resolution = ShadowDpiV; break;
                    case 'dups': if (isDupLayer(it.layer)) it.remove(); break;
                    case 'outside':
                        if (!lay) lay = layerNamed(d, 'Вне монтажной области (не печатается)', false);
                        it.move(lay, ElementPlacement.PLACEATBEGINNING);
                        break;
                    default: continue;
                }
                n++;
            } catch (e) { }
        }
        if (key == 'dups') for (i = d.layers.length - 1; i >= 0; i--) if (isDupLayer(d.layers[i]) && !d.layers[i].pageItems.length) d.layers[i].remove();
        delete Found[key];
        return n;
    }
    function fix(key) {
        if (!Found) return 'Сначала нажмите «Проверить».';
        var keys = key == 'all' ? ['rgb', 'rgbbmp', 'tac', 'richtext', 'kover', 'whiteop', 'hair', 'nobleed', 'shadowres'] : [key], total = 0, t = [], nd = Found.dups ? Found.dups.length : 0;
        for (var i = 0; i < keys.length; i++) {
            var n = fixOne(keys[i]);
            if (n > 0) { total += n; t.push((Info[keys[i]] || '||').split('|')[1] + ': ' + n); }
        }
        if (!total) return 'Исправлять нечего.';
        if (key == 'dups') return 'Удалено дублей: ' + nd + '. Отменить — Ctrl+Z.';
        return 'Исправлено объектов: ' + total + ' (' + t.join(', ') + '). Отменить — Ctrl+Z.';
    }

    return { check: check, show: show, fix: fix, profileOf: profileOf };
})();

// ---------- команды панели ----------

Bridge.PFCheck = function (profile, bleed, safe) {
    prepare();
    Settings.set('Preflight', 'Profile', profile); Settings.set('Preflight', 'Bleed', bleed); Settings.set('Preflight', 'Safe', safe);
    return Preflight.check(profile, toNum(bleed, -1), toNum(safe, -1));
};
Bridge.PFDefaults = function (profile) { var p = Preflight.profileOf(profile); return p.Bleed + '|' + p.Safe; };
Bridge.PFShow = function (key) { return Preflight.show(key); };
Bridge.PFFix = function (key) { prepare(); return Preflight.fix(key); };
