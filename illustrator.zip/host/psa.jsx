// PS • Автоматизация для Illustrator — вход. Панель подгружает этот файл, он — остальные части
// из той же папки (на общий уровень: их функции видны и панели, и проверкам).
// Панель зовёт PSA.call(["Имя", "арг", …]).
var PSA_LOAD_ERR = '';
(function () {
    var dir = File($.fileName).parent.fsName, parts = ['util.jsx', 'bridge.jsx', 'engine.jsx', 'output.jsx', 'dataio.jsx', 'records.jsx', 'impose.jsx', 'impose_bridge.jsx', 'bar1d.jsx', 'qr.jsx', 'dm.jsx', 'draw.jsx', 'inks.jsx', 'tools.jsx', 'preflight.jsx', 'gang.jsx', 'roll.jsx', 'signature.jsx', 'book.jsx', 'plate.jsx', 'prepress_out.jsx', 'cut.jsx', 'eyelets.jsx', 'laser.jsx', 'nest.jsx', 'letters.jsx', 'calendar.jsx', 'orderdocs.jsx'];
    PSA_PARTS = [];
    for (var i = 0; i < parts.length; i++) PSA_PARTS.push(dir + '/' + parts[i]);
    PSA_DIR = dir;
})();
for (var PSA_I = 0; PSA_I < PSA_PARTS.length; PSA_I++) {
    try { $.evalFile(new File(PSA_PARTS[PSA_I])); }
    catch (e) { PSA_LOAD_ERR += PSA_PARTS[PSA_I].replace(/^.*[\\\/]/, '') + ': ' + e.message + ' (строка ' + e.line + '); '; }
}

var PSA = (function () {
    // Ответ «не перенесено» — с особой меткой, панель скажет это по-человечески
    var NOT_PORTED = '\u0001np|';

    function call(a) {
        if (PSA_LOAD_ERR) return 'Ошибка загрузки программы в Illustrator: ' + PSA_LOAD_ERR;
        var name = a[0], f = Bridge[name];
        if (typeof f != 'function') return NOT_PORTED + name;
        try {
            var r = f.apply(null, a.slice(1));
            return (r === undefined || r === null) ? '' : String(r);
        } catch (e) {
            try { logLine('сбой ' + name + ': ' + e.message + ' (строка ' + e.line + ')'); } catch (x) { }
            return 'Ошибка в Illustrator (' + name + '): ' + e.message;
        }
    }

    // Какие части открыты по ключу (буквы) — ключ проверяет панель и сообщает сюда при каждом чтении состояния
    var mask = '';
    function setMask(m) { mask = String(m || ''); return ''; }
    // Можно ли часть m (пусто — ядро, бесплатно; несколько букв — хватит любой)
    function has(m) {
        if (!m) return true;
        for (var i = 0; i < m.length; i++) if (mask.indexOf(m.charAt(i)) >= 0) return true;
        return false;
    }

    // quiet — без окон «готово» (для проверок без человека)
    return { call: call, dir: PSA_DIR, setMask: setMask, has: has, quiet: false, loadErr: function () { return PSA_LOAD_ERR; } };
})();
