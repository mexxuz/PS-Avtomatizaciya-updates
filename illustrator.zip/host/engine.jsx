// Основная логика — как src/Engine.bas и src/VPField.cls: поля макета, заполнение листа, вывод.
// Поле — объекты с именем «VP#номер» (копии на листе носят то же имя). Настройки полей и вывода
// хранятся в самом документе (метаданные XMP), как в CorelDRAW — в свойствах документа.

var TAG_FIELD = 'VP#';
var TAG_GEN = 'VPgen#';
var FRAME_LAYER = 'PS • Автоматизация: рамки (не печатаются)';
var GEN_LAYER = 'PS • Автоматизация: коды и картинки';

// ---------- поле ----------

function VPField() {
    this.Id = 0; this.Kind = 'text'; this.Source = 0;
    this.NumStart = 1; this.NumStep = 1; this.NumDigits = 0; this.HasEnd = false; this.NumEnd = 0;
    this.Prefix = ''; this.Suffix = '';
    this.FilePath = ''; this.Column = 1; this.HasHeader = false; this.FirstRow = 1; this.Template = ''; this.Mask = '';
    this.CodeType = 'EAN-13'; this.ShowText = true; this.Rotation = 0; this.Quiet = true; this.Ecc = 'M';
    this.PicFolder = ''; this.PicFit = 0;
    this.Values = []; this.ValuesCount = -1; this.Loaded = false;
}

function zeroPad(s, n) { while (s.length < n) s = '0' + s; return s; }

// Число как Format$ в VBA: без лишних знаков, с ведущими нулями до NumDigits
function numText(v, digits) {
    var neg = v < 0, a = Math.abs(v), s;
    if (digits > 0) {
        s = String(Math.round(a));
        s = zeroPad(s, digits);
    } else if (a == Math.floor(a)) s = String(a);
    else s = String(Math.round(a * 1e10) / 1e10);
    return (neg ? '-' : '') + s;
}

VPField.prototype.KindName = function () {
    if (this.Kind == 'code') return 'Код: ' + this.CodeType;
    if (this.Kind == 'pic') return 'Картинка';
    return 'Текст';
};

VPField.prototype.SourceName = function () {
    if (this.Source == 0) {
        var s = 'нумерация с ' + this.ValueAt(0);
        if (this.HasEnd) s += ' по ' + this.ValueAt(this.Count() - 1) + ' (' + this.Count() + ' шт.)';
        return s;
    }
    var f = this.FilePath.replace(/^.*[\\\/]/, '');
    if (f == '') f = 'файл не выбран';
    return f + (this.Template.replace(/\s/g, '') != '' ? ', ' + this.Template : ', столбец ' + this.Column);
};

// Значение по номеру записи (с нуля)
VPField.prototype.ValueAt = function (i) {
    if (this.Source == 0) {
        var v = this.NumStart + i * this.NumStep;
        return this.Prefix + this.ApplyMask(numText(v, this.NumDigits)) + this.Suffix;
    }
    if (i >= 0 && i < this.ValuesCount) return this.ApplyMask(String(this.Values[i]));
    return '';
};

// Маска: каждый # — очередной символ значения, остальное — как написано
VPField.prototype.ApplyMask = function (v) {
    if (this.Mask.indexOf('#') < 0 || v === '') return v;
    var out = '', k = 0, i, ch;
    for (i = 0; i < this.Mask.length; i++) {
        ch = this.Mask.charAt(i);
        if (ch == '#') { if (k < v.length) out += v.charAt(k); k++; }
        else if (k < v.length) out += ch;
    }
    if (k < v.length) out += v.substring(k);
    return out;
};

// Сколько значений (-1 — без ограничения)
VPField.prototype.Count = function () {
    if (this.Source == 1) return this.ValuesCount;
    if (!this.HasEnd || this.NumStep == 0) return -1;
    var n = Math.floor((this.NumEnd - this.NumStart) / this.NumStep + 0.0000001) + 1;
    if (n < 0) n = 0;
    if (n > 100000000) n = 100000000;
    return n;
};

var FIELD_KEYS = ['Id', 'Kind', 'Source', 'NumStart', 'NumStep', 'NumDigits', 'HasEnd', 'NumEnd', 'Prefix', 'Suffix', 'FilePath', 'Column',
                  'HasHeader', 'FirstRow', 'Mask', 'Template', 'CodeType', 'ShowText', 'Rotation', 'Quiet', 'Ecc', 'PicFolder', 'PicFit'];

VPField.prototype.Save = function () {
    var o = {};
    for (var i = 0; i < FIELD_KEYS.length; i++) o[FIELD_KEYS[i]] = this[FIELD_KEYS[i]];
    return o;
};
VPField.prototype.Load = function (o) {
    for (var i = 0; i < FIELD_KEYS.length; i++) if (o.hasOwnProperty(FIELD_KEYS[i])) this[FIELD_KEYS[i]] = o[FIELD_KEYS[i]];
};

// ---------- настройки в документе (XMP) ----------

var PSA_NS = 'http://ns.psautomation.ru/1.0/';
function xmpReady() {
    if (!ExternalObject.AdobeXMPScript) ExternalObject.AdobeXMPScript = new ExternalObject('lib:AdobeXMPScript');
    XMPMeta.registerNamespace(PSA_NS, 'psa');
}
function docProp(d, name) {
    try {
        xmpReady();
        var x = new XMPMeta(d.XMPString), p = x.getProperty(PSA_NS, name);
        return p ? String(p.value) : '';
    } catch (e) { return ''; }
}
function setDocProp(d, name, v) {
    xmpReady();
    var x = new XMPMeta(d.XMPString);
    x.setProperty(PSA_NS, name, v);
    d.XMPString = x.serialize(XMPConst.SERIALIZE_USE_COMPACT_FORMAT);
}

var Engine = {
    Fields: [], SheetsCount: 1, SheetsAuto: true, OrderStack: false, StartRecord: 1, PdfOneFile: true, PdfPath: '',
    TiffDpi: 300, TiffFolder: '', Sides: 0, SideFolders: false, Client: '', Register: true, DataEnd: -1, Errors: [], AsIs: false, Reprint: null
};
var RUN_KEYS = ['SheetsCount', 'SheetsAuto', 'OrderStack', 'StartRecord', 'PdfOneFile', 'PdfPath', 'TiffDpi', 'TiffFolder', 'Sides', 'SideFolders', 'Client', 'Register'];

Engine.Reset = function () {
    Inks.Defaults();
    this.Fields = []; this.SheetsCount = 1; this.SheetsAuto = true; this.OrderStack = false; this.StartRecord = 1;
    this.PdfOneFile = true; this.PdfPath = ''; this.TiffDpi = 300; this.TiffFolder = ''; this.Sides = 0; this.SideFolders = false;
    this.Client = ''; this.Register = true; this.DataEnd = -1; this.Errors = [];
};

Engine.LoadConfig = function () {
    this.Reset();
    if (!hasDoc()) return;
    var o = fromJson(docProp(app.activeDocument, 'config'));
    if (!o) { Inks.GuessFromDoc(); return; }
    for (var i = 0; i < RUN_KEYS.length; i++) if (o.hasOwnProperty(RUN_KEYS[i])) this[RUN_KEYS[i]] = o[RUN_KEYS[i]];
    Inks.Load(o.inks || null);
    var fl = o.fields || [];
    for (i = 0; i < fl.length; i++) { var f = new VPField(); f.Load(fl[i]); this.Fields.push(f); }
};

Engine.SaveConfig = function () {
    if (!hasDoc()) return;
    var o = {}, i;
    for (i = 0; i < RUN_KEYS.length; i++) o[RUN_KEYS[i]] = this[RUN_KEYS[i]];
    o.inks = Inks.Save();
    o.fields = [];
    for (i = 0; i < this.Fields.length; i++) o.fields.push(this.Fields[i].Save());
    setDocProp(app.activeDocument, 'config', toJson(o));
};

Engine.FieldById = function (id) {
    for (var i = 0; i < this.Fields.length; i++) if (this.Fields[i].Id == id) return this.Fields[i];
    return null;
};

// ---------- объекты полей ----------

// Монтажные области — стороны листа: все до «Шаблона стола»
function sidePages(d) {
    var n = 0;
    for (var i = 0; i < d.artboards.length; i++) { if (d.artboards[i].name == TEMPLATE_PAGE) break; n = i + 1; }
    return n;
}

// В какой монтажной области центр объекта (-1 — ни в какой)
function abIndexOf(d, it) {
    var b = it.geometricBounds, cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
    for (var i = 0; i < d.artboards.length; i++) {
        var r = d.artboards[i].artboardRect;
        if (cx >= r[0] && cx <= r[2] && cy <= r[1] && cy >= r[3]) return i;
    }
    return -1;
}

// Где могут быть поля: надписи (текстовые поля и их копии под белила и лак) и рамки кодов и картинок
// на служебном слое. Не d.pageItems целиком: в раскладке это десятки тысяч объектов, и Illustrator
// отдаёт каждый следующий всё медленнее — перебор шёл десятки секунд.
function fieldCandidates(d) {
    var out = [], i, tf = d.textFrames, n = tf.length;
    for (i = 0; i < n; i++) out.push(tf[i]);
    for (i = 0; i < d.layers.length; i++) if (d.layers[i].name == FRAME_LAYER) {
        var L = d.layers[i], m = L.pageItems.length;
        for (var k = 0; k < m; k++) out.push(L.pageItems[k]);
    }
    return out;
}

// Все объекты документа с именем поля: { id: [объекты] } за один проход
function scanFields(d) {
    var m = {}, items = fieldCandidates(d), i, n, k;
    for (i = 0; i < items.length; i++) {
        n = items[i].name;
        if (n.substring(0, 3) != TAG_FIELD) continue;
        k = n.substring(3);
        // «VP#1~» — спутник поля: копия надписи под белила или лак (заполняется тем же значением)
        if (!/^\d+~?$/.test(k)) continue;
        if (!m[k]) m[k] = [];
        m[k].push(items[i]);
    }
    return m;
}

// Номер карты раскладки, в которую входит объект (группа «Карта N»); 0 — не в карте
function cardNo(it) {
    var g = it.parent, n = 0;
    while (g && g.typename == 'GroupItem' && n < 20) {
        if (g.name.substring(0, 6) == 'Карта ') return parseInt(g.name.substring(6), 10) || 0;
        g = g.parent; n++;
    }
    return 0;
}

// Объекты поля на одной стороне по порядку: по номерам карт, а без них — сверху вниз и слева направо
function sortedOnPage(d, list, ab) {
    var a = [], i, b;
    for (i = 0; i < list.length; i++) if (abIndexOf(d, list[i]) == ab) {
        b = list[i].geometricBounds;
        a.push({ it: list[i], cx: (b[0] + b[2]) / 2, cy: (b[1] + b[3]) / 2, h: b[1] - b[3], k: cardNo(list[i]) });
    }
    var allK = a.length > 0;
    for (i = 0; i < a.length; i++) if (!a[i].k) { allK = false; break; }
    if (allK) {
        a.sort(function (x, y) { return x.k - y.k; });
    } else {
        a.sort(function (x, y) { return y.cy - x.cy; });
        var r = 0, rowY = 1e30;
        for (i = 0; i < a.length; i++) {
            if (Math.abs(a[i].cy - rowY) > a[i].h / 2) { r++; rowY = a[i].cy; }
            a[i].row = r;
        }
        a.sort(function (x, y) { return x.row - y.row || x.cx - y.cx; });
    }
    var out = [];
    for (i = 0; i < a.length; i++) out.push(a[i].it);
    return out;
}

// Мест на листе у поля: копий на одной стороне (лицо и оборот одной карты — одно место)
Engine.FieldPlaces = function (id, scan) {
    var d = app.activeDocument, list = (scan || scanFields(d))[String(id)] || [], best = 0;
    var per = {};
    for (var i = 0; i < list.length; i++) { var ab = abIndexOf(app.activeDocument, list[i]); per[ab] = (per[ab] || 0) + 1; }
    var np = sidePages(d);
    for (var k in per) if (per.hasOwnProperty(k) && +k >= 0 && +k < np && per[k] > best) best = per[k];
    return best;
};

Engine.FieldShapes = function (id, scan) {
    var d = app.activeDocument, list = (scan || scanFields(d))[String(id)] || [], out = [], np = sidePages(d);
    for (var p = 0; p < np; p++) out = out.concat(sortedOnPage(d, list, p));
    return out;
};

// Создать поле из выделенного. Ответ — текст ошибки или ''.
function selectionItems(d) {
    var s = d.selection;
    if (!s) return [];
    // курсор в тексте — выделена часть текста: берём сам текстовый блок
    if (s.typename == 'TextRange') { try { return [s.story.textFrames[0]]; } catch (e) { return []; } }
    var a = [];
    for (var i = 0; i < s.length; i++) a.push(s[i]);
    return a;
}

function layerByName(d, name, printable) {
    for (var i = 0; i < d.layers.length; i++) if (d.layers[i].name == name) return d.layers[i];
    var l = d.layers.add();
    l.name = name;
    l.printable = printable;
    return l;
}

Engine.AddFieldFromSelection = function (kind) {
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument, sel = selectionItems(d), i;
    if (!sel.length) return 'Сначала выделите на листе объекты для этого поля (можно сразу все копии на листе).';
    for (i = 0; i < sel.length; i++) {
        if (sel[i].name.substring(0, 3) == TAG_FIELD) return 'Один из выделенных объектов уже входит в поле ' + sel[i].name.substring(3) + '. Сначала удалите то поле.';
        if (kind == 'text' && sel[i].typename != 'TextFrame') return 'Для текстового поля выделите только текстовые объекты.';
    }
    var scan = scanFields(d), f = new VPField();
    f.Id = 1;
    while ((this.FieldById(f.Id) || scan[String(f.Id)]) && f.Id < 1000) f.Id++;
    f.Kind = kind;
    for (i = 0; i < sel.length; i++) {
        sel[i].name = TAG_FIELD + f.Id;
        if (kind != 'text') sel[i].move(layerByName(d, FRAME_LAYER, false), ElementPlacement.PLACEATBEGINNING);
    }
    this.Fields.push(f);
    this.SaveConfig();
    return '';
};

// Коды и картинки поля — на своём слое (верхние объекты)
Engine.DeleteGenerated = function (id) {
    var d = app.activeDocument;
    for (var l = 0; l < d.layers.length; l++) {
        if (d.layers[l].name != GEN_LAYER) continue;
        var items = d.layers[l].pageItems;
        for (var i = items.length - 1; i >= 0; i--) if (items[i].name == TAG_GEN + id) items[i].remove();
    }
};

Engine.RemoveField = function (id) {
    var list = scanFields(app.activeDocument)[String(id)] || [];
    for (var i = 0; i < list.length; i++) list[i].name = '';
    this.DeleteGenerated(id);
    for (i = 0; i < this.Fields.length; i++) if (this.Fields[i].Id == id) { this.Fields.splice(i, 1); break; }
    this.SaveConfig();
};

// ---------- данные и листы ----------

Engine.PrepareData = function () {
    this.Errors = [];
    var i, f, e;
    for (i = 0; i < this.Fields.length; i++) {
        f = this.Fields[i];
        if (f.Source == 1) {
            e = DataIO.LoadField(f);
            if (e) this.Errors.push('Поле ' + f.Id + ': ' + e);
        }
    }
    this.DataEnd = -1;
    for (i = 0; i < this.Fields.length; i++) {
        f = this.Fields[i];
        if (f.Source == 1 && !f.Loaded) continue;
        if (f.Count() >= 0 && f.Count() > this.DataEnd) this.DataEnd = f.Count();
    }
    return this.Errors.length == 0;
};

Engine.SheetsNeeded = function (scan) {
    var best = 0;
    for (var i = 0; i < this.Fields.length; i++) {
        var f = this.Fields[i];
        if (f.Count() >= 0) {
            var k = this.FieldPlaces(f.Id, scan), n = f.Count() - (this.StartRecord - 1);
            if (k > 0 && n > 0) { var s = Math.ceil(n / k); if (s > best) best = s; }
        }
    }
    return best;
};

Engine.TotalSheets = function (whyOut, scan) {
    whyOut.why = '';
    if (this.Fields.length == 0 || this.AsIs) return 1;
    if (this.Reprint) return Math.ceil(this.Reprint.length / Math.max(1, this.FieldPlaces(Records.KeyField().Id, scan)));
    if (!this.SheetsAuto) return this.SheetsCount < 1 ? 1 : this.SheetsCount;
    var t = this.SheetsNeeded(scan);
    if (t == 0) {
        var empty = false;
        for (var i = 0; i < this.Fields.length; i++) { var f = this.Fields[i]; if (f.Source == 0 && f.HasEnd && f.Count() == 0) empty = true; }
        whyOut.why = empty ? 'диапазон нумерации пустой: «по» меньше «с»' : 'у нумерации не задан конец («по») — укажите его или число листов вручную';
    }
    return t;
};

Engine.RecordIndex = function (sheet, pos, perSheet, totalSheets) {
    // перепечатка: выбранные записи подряд с первого места, остальные места пустые
    if (this.Reprint) { var k = sheet * perSheet + pos; return k < this.Reprint.length ? this.Reprint[k] : -1; }
    if (this.OrderStack) return (this.StartRecord - 1) + pos * totalSheets + sheet;
    return (this.StartRecord - 1) + sheet * perSheet + pos;
};

Engine.MaxPlaces = function (scan) {
    var m = 0;
    for (var i = 0; i < this.Fields.length; i++) { var n = this.FieldPlaces(this.Fields[i].Id, scan); if (n > m) m = n; }
    return m;
};

// Карта, в которую входит объект: «Карта N|слой|сторона» (или '' — не в карте)
function cardKey(d, it, ab) {
    var g = it.parent, n = 0;
    while (g && g.typename == 'GroupItem' && n < 20) {
        if (g.name.substring(0, 6) == 'Карта ') return g.name + '|' + it.layer.name + '|' + ab;
        g = g.parent; n++;
    }
    return '';
}

// План заполнения: раскладка на всех листах одна, поэтому порядок мест, карты и копии под белила
// и лак находятся один раз, а на каждом листе только ставятся значения.
// [{ f, per, items: [{ it, pos, card, mates: [] }] }]
Engine.BuildPlan = function (scan) {
    var d = app.activeDocument, np = sidePages(d), plan = [], fi, i, p;
    for (fi = 0; fi < this.Fields.length; fi++) {
        var f = this.Fields[fi], list = scan[String(f.Id)] || [], mates = scan[f.Id + '~'] || [], byCard = {}, loose = [];
        for (i = 0; i < mates.length; i++) {
            if (mates[i].typename != 'TextFrame') continue;
            var mab = abIndexOf(d, mates[i]), mk = cardKey(d, mates[i], mab);
            if (mk) (byCard[mk] = byCard[mk] || []).push(mates[i]);
            else loose.push({ it: mates[i], ab: mab, b: mates[i].geometricBounds });
        }
        // прежние коды и картинки этого поля — убрать, нарисуются заново
        if (f.Kind != 'text') this.DeleteGenerated(f.Id);
        var e = { f: f, per: this.FieldPlaces(f.Id, scan), items: [] };
        for (p = 0; p < np; p++) {
            var sr = sortedOnPage(d, list, p);
            for (i = 0; i < sr.length; i++) {
                var k = cardKey(d, sr[i], p), m = k ? (byCard[k] || []) : nearMates(sr[i], p, loose);
                e.items.push({ it: sr[i], pos: i, card: k ? k.split('|')[0] + '|' + p : '', mates: m });
            }
        }
        plan.push(e);
    }
    return plan;
};

// Копии на образце без раскладки: ближайшие — и все, что стоят там же (белила и лак точно поверх надписи)
function nearMates(it, ab, loose) {
    var b = it.geometricBounds, cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2, near = [], bd = 1e30, out = [], i;
    for (i = 0; i < loose.length; i++) {
        if (loose[i].ab != ab) continue;
        var mb = loose[i].b, dd = Math.sqrt(Math.pow((mb[0] + mb[2]) / 2 - cx, 2) + Math.pow((mb[1] + mb[3]) / 2 - cy, 2));
        near.push({ it: loose[i].it, d: dd });
        if (dd < bd) bd = dd;
    }
    for (i = 0; i < near.length; i++) if (near[i].d <= bd + pt(3)) out.push(near[i].it);
    return out;
}

// Заполнить все стороны данными листа sheet (с нуля). Ответ — карты без данных { 'Карта N|сторона': 1 }.
Engine.FillSheet = function (sheet, totalSheets, scan, plan) {
    plan = plan || this.BuildPlan(scan || scanFields(app.activeDocument));
    var filled = {}, blank = {}, out = {}, k;
    for (var fi = 0; fi < plan.length; fi++) {
        var e = plan[fi], f = e.f, cnt = f.Count();
        for (var i = 0; i < e.items.length; i++) {
            var x = e.items[i], idx = this.RecordIndex(sheet, x.pos, e.per, totalSheets), v = f.ValueAt(idx);
            if (idx < 0 || (cnt >= 0 && idx >= cnt) || (this.DataEnd >= 0 && idx >= this.DataEnd)) v = '';
            if (f.Kind == 'text' && x.it.typename == 'TextFrame') {
                var t = v == '' ? ' ' : v;
                if (x.it.contents != t) x.it.contents = t;
                for (var j = 0; j < x.mates.length; j++) if (x.mates[j].contents != t) x.mates[j].contents = t;
            } else if (f.Kind == 'code' || f.Kind == 'pic') {
                // код или картинка — заново в рамке, на печатаемом слое кодов
                if (x.gen) { try { x.gen.remove(); } catch (e) { } x.gen = null; }
                if (v != '') {
                    var gl = layerByName(x.it.layer.parent, GEN_LAYER, true), b = x.it.geometricBounds, res;
                    if (f.Kind == 'code') res = Draw.code(gl, b, f.CodeType, v, f.ShowText, f.Rotation, f.Quiet, f.Ecc);
                    else {
                        var pf = findPicture(f.PicFolder, v);
                        res = pf ? Draw.picture(gl, b, pf, f.PicFit) : { error: 'нет картинки «' + v + '» в папке ' + f.PicFolder };
                    }
                    if (res.error) { if (this.Errors.length < 200) this.Errors.push('Лист ' + (sheet + 1) + ', поле ' + f.Id + ', место ' + (x.pos + 1) + ': ' + res.error); }
                    else { res.item.name = TAG_GEN + f.Id; x.gen = res.item; }
                }
            }
            if (x.card) { if (v.replace(/\s/g, '') == '') blank[x.card] = 1; else filled[x.card] = 1; }
        }
    }
    for (k in blank) if (blank.hasOwnProperty(k) && !filled[k]) out[k] = 1;
    return out;
};


