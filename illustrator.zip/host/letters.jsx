// Объёмные буквы и стоимость резки — как src/Letters.bas.
//
// Буквы. Борт — полоса (например, из ПВХ), которую гнут по краю буквы и по окнам («О», «А», «8»). Бортов два:
// внешний — на всю глубину буквы, и внутренний — вторая полоса изнутри, ниже (обычно 40 % высоты). Длина полосы
// считается по середине её толщины: у края буквы середина внутри и полоса короче края, у окна — длиннее. Из листа
// режут полосы шириной в высоту борта; сколько полос и листов уйдёт — с запасом и с тем, что длинный контур собирают
// из нескольких полос. По желанию рисуются:
//   задник  — буква, сжатая на толщину внешнего борта и зазор (окна при этом расширяются);
//   выборка — линия на лице буквы на толщину борта и зазор от края: по ней фреза снимает уступ;
//   полосы  — отдельные монтажные области размером с лист справа от макета, на них полосы под фрезеровку.
// Сжатие делает эффект Illustrator «Смещение контура» с острыми углами (как у CorelDRAW после замены скруглений):
// очень острый угол он срезает поперёк — так и подрезают полосу в углу.
//
// Стоимость. Длина реза, число врезок (каждый контур — одна врезка), время и цена — с разбивкой по цвету обводки.
//
// В Illustrator слои общие для всех монтажных областей: «своё» (задник, выборка, отметки) — это то, что лежит
// на нужном слое в пределах активной области.

var LT_BACK = 'Задник', LT_REB = 'Выборка', LT_STRIP = 'Борта', LT_FLAW = 'Проверка букв', LT_PART = 'PS • детали для раскладки', LT_TMP = 'PS • расчёт букв';

var Letters = (function () {
    var flaws = [], Z = [0, 0, 0, 0], SEQ = 0;

    function from(params) {
        var c = parseKV(params), N = function (k, dv) { return toNum(c.hasOwnProperty(k) ? c[k] : '', dv); };
        return { Height: N('ltH', 100), Wall: N('ltWall', 8), Inner: (c.hasOwnProperty('ltInner') ? c.ltInner : '1') == '1', InHeight: N('ltH2', 0),
                 InWall: N('ltT2', 5), GapBack: N('ltGapB', 1), GapFace: N('ltGapF', 1), SheetA: N('ltSA', 1220), SheetB: N('ltSB', 2440),
                 Margin: N('ltMargin', 5), Kerf: N('ltKerf', 6), Reserve: N('ltRes', 5), BackMode: 0, RebMode: 0, DrawStrips: false, Brief: false };
    }
    function f2(v) { return (Math.round(v * 100) / 100).toFixed(2).replace('.', ','); }
    function f3(v) { return (Math.round(v * 1000) / 1000).toFixed(3).replace('.', ','); }
    function f1(v) { return (Math.round(v * 10) / 10).toFixed(1).replace('.', ','); }

    // ---------- что считать ----------

    function skipL(L, ownToo) {
        if (!L.visible) return true;
        var n = L.name;
        if (n == LT_TMP || n == LT_FLAW || n == LT_PART || n == CUT_MARK_LAYER || n == CUT_JUNK_LAYER || n == LASER_MOVE_LAYER) return true;
        if (n == LT_BACK || n == LT_REB) return ownToo;
        return false;
    }
    // Выделенное, а если выделены только задник, выборка или отметки (или ничего) — всё на активной области
    function source(d, ab, ownToo) {
        var sel = selectionItems(d), i, out = [];
        for (i = 0; i < sel.length; i++) if (!skipL(cutTopLayer(sel[i]), ownToo)) return { items: sel, what: 'выделенное' };
        for (i = 0; i < d.layers.length; i++) if (!skipL(d.layers[i], ownToo)) out = out.concat(topItemsOn(d, d.layers[i], ab));
        return { items: out, what: 'всё на монтажной области' };
    }

    // Постоянная метка исходной фигуры: по ней задник узнаёт свою букву
    function tagOf(it) {
        try { for (var i = 0; i < it.tags.length; i++) if (it.tags[i].name == 'psaLt') return it.tags[i].value; } catch (e) { return ''; }
        var v = String((new Date().getTime() % 100000000) * 10 + (SEQ++ % 10));
        try { var t = it.tags.add(); t.name = 'psaLt'; t.value = v; } catch (e) { }
        return v;
    }
    function bnd(pi) { var b = pi.geometricBounds; return [mm(b[0]), mm(b[3]), mm(b[2]), mm(b[1])]; }
    function pieceOf(pi, tag) {
        var b = bnd(pi);
        return { pi: pi, tag: tag, poly: cutFlatten(pi, Z, 0.1), x0: b[0], y0: b[1], x1: b[2], y1: b[3], len: mm(pi.length), area: Math.abs(pi.area) * PT_MM * PT_MM };
    }
    function flaw(x, y, kind) {
        for (var i = 0; i < flaws.length; i++) if (Math.abs(flaws[i][0] - x) < 3 && Math.abs(flaws[i][1] - y) < 3) return;
        flaws.push([x, y, kind]);
    }
    // Каждый контур — отдельной частью. Группы раскрываются, текст переводится в кривые (на временной копии —
    // макет не трогается). Незамкнутые линии бортом не бывают: они только считаются, чтобы о них сказать.
    function addPieces(it, st, tag, ownToo) {
        var t = it.typename, i;
        try { if (it.hidden || it.guides) return; } catch (e) { }
        if (!tag && skipL(cutTopLayer(it), ownToo)) return;
        if (t == 'GroupItem') {
            for (i = 0; i < it.pageItems.length; i++) { var ch = it.pageItems[i]; if (it.clipped && ch.typename == 'PathItem' && ch.clipping) continue; addPieces(ch, st, null, ownToo); }
            return;
        }
        if (t == 'TextFrame') { var tg = tagOf(it), subs = cutSubs(it, st.tmp); for (i = 0; i < subs.length; i++) piece(subs[i], st, tg); return; }
        if (t == 'PathItem') { if (it.clipping) return; piece(it, st, tag || tagOf(it)); return; }
        if (t == 'CompoundPathItem') { var tg2 = tagOf(it); for (i = 0; i < it.pathItems.length; i++) piece(it.pathItems[i], st, tg2); }
    }
    function piece(pi, st, tag) {
        if (pi.pathPoints.length < 2) return;
        var b = bnd(pi);
        // крошка меньше миллиметра — мусор из DXF, а не буква и не окно
        if (b[2] - b[0] < 1 && b[3] - b[1] < 1) { flaw((b[0] + b[2]) / 2, (b[1] + b[3]) / 2, 3); return; }
        if (!pi.closed) { st.open++; return; }
        st.pcs.push(pieceOf(pi, tag));
    }

    // ---------- косяки шрифтов ----------
    // Пересечения отрезков ломаных: контур пересекает сам себя (петелька на стыке штрихов) и контуры разных букв
    // налезают друг на друга. По одной точке на контур и на пару; соседние отрезки и касание концами — не в счёт.
    function crossings(pcs) {
        var segs = [], i, k;
        for (i = 0; i < pcs.length; i++) {
            var p = pcs[i].poly, n = p.length;
            for (k = 0; k < n; k++) {
                var a = p[k], b = p[(k + 1) % n];
                segs.push({ i: i, k: k, n: n, ax: a[0], ay: a[1], bx: b[0], by: b[1], x0: Math.min(a[0], b[0]), x1: Math.max(a[0], b[0]), y0: Math.min(a[1], b[1]), y1: Math.max(a[1], b[1]) });
            }
        }
        segs.sort(function (s, t) { return s.x0 - t.x0; });
        var self = {}, seen = {}, pairs = [];
        for (i = 0; i < segs.length; i++) {
            var s = segs[i];
            for (var j = i + 1; j < segs.length && segs[j].x0 <= s.x1; j++) {
                var t = segs[j], key = '';
                if (t.y0 > s.y1 || t.y1 < s.y0) continue;
                if (s.i == t.i) {
                    if (self[s.i]) continue;
                    var dk = Math.abs(s.k - t.k);
                    if (dk <= 1 || dk == s.n - 1) continue;
                } else { key = Math.min(s.i, t.i) + '_' + Math.max(s.i, t.i); if (seen[key]) continue; }
                var x = segX(s, t);
                if (!x) continue;
                if (s.i == t.i) self[s.i] = x;
                else { seen[key] = 1; pairs.push([Math.min(s.i, t.i), Math.max(s.i, t.i), x[0], x[1]]); }
            }
        }
        return { self: self, pairs: pairs };
    }
    function segX(s, t) {
        var dx1 = s.bx - s.ax, dy1 = s.by - s.ay, dx2 = t.bx - t.ax, dy2 = t.by - t.ay, den = dx1 * dy2 - dy1 * dx2;
        if (Math.abs(den) < 1e-12) return null;
        var u = ((t.ax - s.ax) * dy2 - (t.ay - s.ay) * dx2) / den, v = ((t.ax - s.ax) * dy1 - (t.ay - s.ay) * dx1) / den, e = 1e-6;
        if (u <= e || u >= 1 - e || v <= e || v >= 1 - e) return null;
        return [s.ax + u * dx1, s.ay + u * dy1];
    }
    function pointIn(poly, x, y) {
        var inside = false;
        for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            var xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1];
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside;
        }
        return inside;
    }
    function pathsOf(x, out) {
        if (x.typename == 'PathItem') out.push(x);
        else if (x.typename == 'CompoundPathItem') for (var q = 0; q < x.pathItems.length; q++) out.push(x.pathItems[q]);
        else if (x.typename == 'GroupItem') for (var q2 = 0; q2 < x.pageItems.length; q2++) pathsOf(x.pageItems[q2], out);
        return out;
    }
    function absArea(items) { var ps = [], s = 0; for (var i = 0; i < items.length; i++) pathsOf(items[i], ps); for (i = 0; i < ps.length; i++) s += Math.abs(ps[i].area); return s * PT_MM * PT_MM; }
    function solid(x) { var ps = pathsOf(x, []); for (var i = 0; i < ps.length; i++) { ps[i].closed = true; ps[i].filled = true; ps[i].fillColor = cmykColor(0, 0, 0, 100); ps[i].stroked = false; } }

    // Слить контур с самим собой — как «Обработка контуров → Добавить»: петля уходит. Эффект Illustrator
    // применяет к группе (по голому выделению показывает окно), окна на это время заглушены
    function unite(d, it) {
        var g = it.layer.groupItems.add(), r = null;
        g.move(it, ElementPlacement.PLACEBEFORE);
        it.move(g, ElementPlacement.PLACEATEND);
        d.selection = null; g.selected = true;
        app.executeMenuCommand('Live Pathfinder Add');
        app.executeMenuCommand('expandStyle');
        r = d.selection.length ? d.selection[0] : null;
        while (r && r.typename == 'GroupItem' && r.pageItems.length == 1) { var only = r.pageItems[0]; only.move(r, ElementPlacement.PLACEBEFORE); r.remove(); r = only; }
        d.selection = null;
        return r;
    }
    // Петля в контуре буквы — убрать на копии; ответ — новые части (или null: петли нет, площадь не изменилась)
    function weldCopy(d, pc, L) {
        var dup = pc.pi.duplicate(L, ElementPlacement.PLACEATBEGINNING);
        solid(dup);
        var r = unite(d, dup);
        if (!r) return null;
        if (Math.abs(absArea([r]) - pc.area) < 0.5) { r.remove(); return null; }
        var ps = pathsOf(r, []), out = [];
        for (var i = 0; i < ps.length; i++) if (ps[i].closed && ps[i].pathPoints.length > 2) out.push(pieceOf(ps[i], pc.tag));
        return out.length ? out : null;
    }

    // Для каждого контура — сколько контуров вокруг него и какой ближайший. Чётная глубина — край буквы, нечётная — окно
    function nesting(pcs) {
        var n = pcs.length, depth = [], parent = [], i, j;
        for (i = 0; i < n; i++) { depth[i] = 0; parent[i] = -1; }
        for (i = 0; i < n; i++) {
            var a = pcs[i], best = -1, p0 = a.poly[0], aa = (a.x1 - a.x0) * (a.y1 - a.y0);
            for (j = 0; j < n; j++) {
                if (i == j) continue;
                var b = pcs[j], ba = (b.x1 - b.x0) * (b.y1 - b.y0);
                if (a.x0 >= b.x0 - 0.01 && a.y0 >= b.y0 - 0.01 && a.x1 <= b.x1 + 0.01 && a.y1 <= b.y1 + 0.01 && aa < ba && pointIn(b.poly, p0[0], p0[1])) {
                    depth[i]++;
                    if (best < 0 || ba < best) { best = ba; parent[i] = j; }
                }
            }
        }
        return { depth: depth, parent: parent };
    }

    // ---------- полосы ----------
    // Сколько полос длиной L уйдёт на куски: длинный контур режется на куски не длиннее полосы, куски — по полосам,
    // сначала самые длинные, каждый в первую полосу, где он помещается (обрезок одной буквы идёт на другую)
    function stripsFor(lens, L) {
        if (!lens.length || L <= 0) return 0;
        var pcs = [], i, j;
        for (i = 0; i < lens.length; i++) { var t = lens[i]; while (t > 0.001) { if (t > L) { pcs.push(L); t -= L; } else { pcs.push(t); t = 0; } } }
        if (!pcs.length) return 0;
        pcs.sort(function (a, b) { return b - a; });
        var rest = [];
        for (i = 0; i < pcs.length; i++) {
            var k = -1;
            for (j = 0; j < rest.length; j++) if (rest[j] >= pcs[i] - 0.001) { k = j; break; }
            if (k < 0) { rest.push(L); k = rest.length - 1; }
            rest[k] -= pcs[i];
        }
        return rest.length;
    }
    // Полоса идёт поперёк листа, по короткой стороне; полосы встают одна над другой вдоль длинной, между ними — фреза
    function geom(p) {
        var s = Math.min(p.SheetA, p.SheetB), l = Math.max(p.SheetA, p.SheetB);
        return { shortS: s, longS: l, stripLen: s - 2 * p.Margin, usable: l - 2 * p.Margin };
    }
    function perSheet(p, h) { var g = geom(p); if (h <= 0 || g.stripLen <= 0) return 0; return Math.max(0, Math.floor((g.usable + p.Kerf) / (h + p.Kerf))); }
    function inH(p) { return p.InHeight > 0 ? p.InHeight : Math.round(p.Height * 0.4 * 10) / 10; }
    function backOff(p) { return p.Wall + p.GapBack; }

    function describe(p) {
        var g = geom(p);
        if (!perSheet(p, p.Height)) return 'Полоса ' + mmText(p.Height) + ' мм на лист ' + mmText(g.shortS) + ' × ' + mmText(g.longS) + ' не встаёт — проверьте размеры.';
        var t = 'Полосы ' + mmText(g.stripLen) + ' мм поперёк листа ' + mmText(g.shortS) + ' × ' + mmText(g.longS) + ': внешних по ' + mmText(p.Height) + ' мм встаёт ' + perSheet(p, p.Height);
        if (p.Inner) t += ', внутренних по ' + mmText(inH(p)) + ' мм — ' + perSheet(p, inH(p));
        return t + ' на лист. Задник меньше буквы на ' + mmText(backOff(p)) + ' мм, выборка — ' + mmText(p.Wall + p.GapFace) + ' мм от края.';
    }

    // Полосы одного материала — по листам снизу вверх, между ними проход фрезы. draw — нарисовать на новых
    // монтажных областях «Борта <title> — лист k из N» справа от макета; иначе только посчитать листы
    function packStrips(d, p, hs, nm, title, draw, total, st) {
        var g = geom(p), y = 0, sheet = 0, R = null, L = null;
        for (var i = 0; i < hs.length; i++) {
            var need = hs[i];
            if (sheet > 0 && y > 0) need += p.Kerf;
            if (sheet == 0 || y + need > g.usable + 0.001) {
                sheet++; y = 0; need = hs[i];
                if (draw) {
                    R = freeBoard(d, g.shortS, g.longS, 30);
                    if (!R) throw new Error('листы с полосами не помещаются на холст Illustrator рядом с макетом');
                    d.artboards.add(R);
                    var k = d.artboards.length - 1;
                    d.artboards[k].name = LT_STRIP + (title ? ' ' + title : '') + ' — лист ' + sheet + ' из ' + total;
                    if (st.first < 0) st.first = k;
                    L = layerNamed(d, LT_STRIP, true); L.visible = true; L.locked = false;
                }
            }
            if (draw) {
                var r = L.pathItems.rectangle(R[3] + pt(p.Margin + y + need), R[0] + pt(p.Margin), pt(g.stripLen), pt(hs[i]));
                r.filled = false; r.stroked = true; r.strokeWidth = pt(0.2); r.strokeColor = rgbColor(255, 0, 0);
                r.name = nm[i];
            }
            y += need;
        }
        return sheet;
    }

    // ---------- слои на области ----------
    function layerItems(d, name, ab) { var L = cutFindLayer(d, name); return L ? topItemsOn(d, L, ab) : []; }
    function hasOwn(d, name, ab) { return layerItems(d, name, ab).length > 0; }
    function dropLayer(d, L) {
        if (d.activeLayer == L) for (var i = 0; i < d.layers.length; i++) if (d.layers[i] != L && d.layers[i].visible && !d.layers[i].locked) { d.activeLayer = d.layers[i]; break; }
        L.locked = false; L.visible = true;
        L.remove();
    }
    // своё на области — долой; слой опустел — и его
    function dropOn(d, name, ab) {
        var L = cutFindLayer(d, name);
        if (!L) return;
        L.locked = false; L.visible = true;
        var a = topItemsOn(d, L, ab);
        for (var i = a.length - 1; i >= 0; i--) a[i].remove();
        if (!L.pageItems.length) dropLayer(d, L);
    }
    // Перед новым задником убрать старый — у тех букв, что считаем сейчас. Считали всю область — убирается всё.
    // Свой задник буква узнаёт по метке в имени («Задник 5 · 1234»); без метки — тот, что лежит в рамке буквы
    // и не меньше половины её (задник мелкой цифры в окне «0» так не спутать с задником «0»)
    function clearFor(d, L, pcs, N, what, ab) {
        var all = topItemsOn(d, L, ab), i, k;
        if (what != 'выделенное') { for (i = all.length - 1; i >= 0; i--) all[i].remove(); return; }
        var tags = {};
        for (i = 0; i < pcs.length; i++) if (N.depth[i] % 2 == 0) tags[pcs[i].tag] = 1;
        for (i = all.length - 1; i >= 0; i--) {
            var s = all[i], nm = s.name, p = nm.lastIndexOf(' · ');
            if (p > 0) { if (tags[nm.substring(p + 3)]) s.remove(); continue; }
            var b = bnd(s), cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
            for (k = 0; k < pcs.length; k++) {
                if (N.depth[k] % 2) continue;
                var q = pcs[k];
                if (cx > q.x0 && cx < q.x1 && cy > q.y0 && cy < q.y1 && b[2] - b[0] > (q.x1 - q.x0) / 2 && b[3] - b[1] > (q.y1 - q.y0) / 2) { s.remove(); break; }
            }
        }
    }
    function markFlaws(d, ab) {
        dropOn(d, LT_FLAW, ab);
        if (!flaws.length) return;
        var L = layerNamed(d, LT_FLAW, false), red = rgbColor(230, 0, 0);
        L.printable = false; L.visible = true; L.locked = false;
        L.zOrder(ZOrderMethod.BRINGTOFRONT);
        for (var i = 0; i < flaws.length; i++) {
            var f = flaws[i], c = L.pathItems.ellipse(pt(f[1] + 3), pt(f[0] - 3), pt(6), pt(6));
            c.filled = false; c.stroked = true; c.strokeWidth = pt(0.7); c.strokeColor = red;
            c.name = f[2] == 1 ? 'Контур пересекает сам себя' : (f[2] == 2 ? 'Контуры налезают друг на друга' : 'Мусор меньше 1 мм');
        }
    }

    // ---------- задник и выборка ----------
    // Каждая буква вместе с окнами — одним контуром, сжатым внутрь на dist, на слой L поверх буквы. Все буквы
    // сжимаются за один заход: эффект на каждую, затем один разбор оформления (по одной — вчетверо дольше)
    function drawOffsets(d, pcs, N, dist, L, col, title, tmpL, out) {
        var jobs = [], i, j, k;
        for (i = 0; i < pcs.length; i++) {
            if (N.depth[i] % 2) continue;
            var cp = tmpL.compoundPathItems.add();
            pcs[i].pi.duplicate(cp, ElementPlacement.PLACEATEND);
            for (j = 0; j < pcs.length; j++) if (N.depth[j] % 2 == 1 && N.parent[j] == i) pcs[j].pi.duplicate(cp, ElementPlacement.PLACEATEND);
            // окна — пустые при любом направлении обхода
            for (k = 0; k < cp.pathItems.length; k++) { var q = cp.pathItems[k]; q.closed = true; q.evenodd = true; q.filled = true; q.fillColor = cmykColor(0, 0, 0, 100); q.stroked = false; }
            cp.name = 'psa:' + i;
            jobs.push({ i: i, it: cp, w: mm(cp.geometricBounds[2] - cp.geometricBounds[0]) });
        }
        if (dist > 0 && jobs.length) {
            for (k = 0; k < jobs.length; k++) jobs[k].it.applyEffect('<LiveEffect name="Adobe Offset Path"><Dict data="R mlim 5 R ofst ' + (-pt(dist)) + ' I jntp 2 "/></LiveEffect>');
            d.selection = null;
            for (k = 0; k < jobs.length; k++) jobs[k].it.selected = true;
            app.executeMenuCommand('expandStyle');
            var got = {}, sel = d.selection;
            for (k = 0; k < sel.length; k++) got[sel[k].name] = sel[k];
            d.selection = null;
            for (k = 0; k < jobs.length; k++) jobs[k].it = got['psa:' + jobs[k].i] || null;
        }
        for (k = 0; k < jobs.length; k++) {
            var J = jobs[k], it = J.it, pc = pcs[J.i], ps = it ? pathsOf(it, []) : [], ok = ps.length > 0;
            // контур, который не сжался (штрихи тоньше двух отступов), — не результат
            if (ok && dist > 0 && Math.abs(mm(it.geometricBounds[2] - it.geometricBounds[0]) - J.w) < dist * 0.5) ok = false;
            var area = 0;
            if (ok) {
                var polys = []; for (j = 0; j < ps.length; j++) polys.push(cutFlatten(ps[j], Z, 0.2));
                for (j = 0; j < ps.length; j++) {
                    var inside = 0; for (var m = 0; m < ps.length; m++) if (m != j && polys[j].length && pointIn(polys[m], polys[j][0][0], polys[j][0][1])) inside++;
                    area += (inside % 2 ? -1 : 1) * Math.abs(ps[j].area) * PT_MM * PT_MM;
                }
                if (area < 0.02 * pc.area) ok = false;
            }
            if (!ok) { out.lost++; if (it) try { it.remove(); } catch (e) { } continue; }
            var res;
            if (it.typename == 'CompoundPathItem') res = it;
            else {
                // один контур или группа контуров — в составной; пустую группу после этого — прочь
                res = tmpL.compoundPathItems.add();
                for (j = 0; j < ps.length; j++) ps[j].move(res, ElementPlacement.PLACEATEND);
                if (it.typename == 'GroupItem') try { it.remove(); } catch (e) { }
            }
            res.move(L, ElementPlacement.PLACEATBEGINNING);
            for (j = 0; j < res.pathItems.length; j++) { var x = res.pathItems[j]; x.filled = false; x.stroked = true; x.strokeWidth = pt(0.2); x.strokeColor = col; }
            out.made++;
            res.name = title + ' ' + out.made + ' · ' + pc.tag;
            out.area += area;
            for (j = 0; j < res.pathItems.length; j++) out.len += mm(res.pathItems[j].length);
        }
    }

    // ---------- монтажные области ----------
    function isOwnBoard(name) { name = String(name); return name.indexOf(LT_STRIP) == 0 || name.indexOf('Лица — ') == 0 || name.indexOf('Задники — ') == 0; }
    function backToLetters(d) {
        var k = parseInt(docProp(d, 'lettersAb'), 10);
        if (isNaN(k) || k < 0 || k >= d.artboards.length || isOwnBoard(d.artboards[k].name)) return false;
        d.artboards.setActiveArtboardIndex(k);
        d.selection = null;
        return true;
    }
    // прошлые области с полосами — вместе с полосами на них; ответ — новый номер области ab
    function dropStripBoards(d, ab) {
        var L = cutFindLayer(d, LT_STRIP);
        for (var k = d.artboards.length - 1; k >= 0; k--) {
            if (d.artboards[k].name.indexOf(LT_STRIP) != 0 || d.artboards.length < 2) continue;
            if (L) { L.locked = false; L.visible = true; var a = topItemsOn(d, L, k); for (var i = a.length - 1; i >= 0; i--) a[i].remove(); }
            d.artboards.remove(k);
            if (k < ab) ab--;
        }
        if (L && !L.pageItems.length) dropLayer(d, L);
        return ab;
    }

    // ---------- расчёт ----------
    function run(p) {
        if (!hasDoc()) return 'Нет открытого документа.';
        if (p.Height <= 0) return 'Укажите высоту внешнего борта.';
        if (p.Wall < 0) p.Wall = 0;
        if (p.InWall < 0) p.InWall = 0;
        var d = app.activeDocument, h2 = inH(p);
        // открыта область с полосами — считаем ту, с которой их делали
        if (isOwnBoard(activeAb(d).name) && !backToLetters(d))
            return 'Это монтажная область с полосами бортов. Перейдите на область с буквами и посчитайте там.';
        var ab = d.artboards.getActiveArtboardIndex(), S = source(d, ab, true), what = S.what;
        if (!S.items.length) return 'На монтажной области ничего нет. Выделите буквы или откройте макет с ними.';
        var stage = 'разбор букв', st = { pcs: [], open: 0, tmp: [] }, old = app.userInteractionLevel, tmpL = null, keepL = d.activeLayer, i, k;
        var back = { made: 0, area: 0, len: 0, lost: 0 }, reb = { made: 0, area: 0, len: 0, lost: 0 }, wasBack = false, wasReb = false;
        var outN = 0, holeN = 0, edgeL = 0, winL = 0, faceA = 0, m1 = 0, m2 = 0, s1 = 0, s2 = 0, sheets1 = 0, sheets2 = 0, same, g = geom(p), strips = { first: -1 };
        app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
        flaws = [];
        try {
            tmpL = d.layers.add(); tmpL.name = LT_TMP; tmpL.printable = false;
            for (i = 0; i < S.items.length; i++) addPieces(S.items[i], st, null, true);
            var pcs = st.pcs, n = pcs.length;
            if (!n) {
                return 'Нет замкнутых контуров (проверено ' + what + ') — бортом обводят только замкнутые.' + (st.open ? ' Незамкнутых линий: ' + st.open + '.' : '');
            }
            // петли убираем на копиях (макет не трогается), наложения — только отмечаем
            stage = 'проверка косяков';
            var X = crossings(pcs), fixedAny = false;
            for (k in X.self) if (X.self.hasOwnProperty(k)) {
                var fx = weldCopy(d, pcs[+k], tmpL);
                if (!fx) continue;
                flaw(X.self[k][0], X.self[k][1], 1);
                pcs[+k] = fx[0];
                for (i = 1; i < fx.length; i++) pcs.push(fx[i]);
                fixedAny = true;
            }
            n = pcs.length;
            if (fixedAny) X = crossings(pcs);
            for (i = 0; i < X.pairs.length; i++) flaw(X.pairs[i][2], X.pairs[i][3], 2);
            stage = 'окна букв';
            var N = nesting(pcs);

            // оба борта идут по каждому контуру; длина — по середине толщины: у края буквы контур короче
            // на 2π·отступ, у окна — длиннее
            stage = 'длина бортов';
            var len1 = [], len2 = [];
            for (i = 0; i < n; i++) {
                var L = pcs[i].len, side;
                if (N.depth[i] % 2 == 0) { outN++; edgeL += L; side = -1; faceA += pcs[i].area; }
                else { holeN++; winL += L; side = 1; faceA -= pcs[i].area; }
                len1[i] = Math.max(0, (L + side * 2 * Math.PI * (p.Wall / 2)) * (1 + p.Reserve / 100));
                len2[i] = Math.max(0, (L + side * 2 * Math.PI * (p.Wall + p.InWall / 2)) * (1 + p.Reserve / 100));
                m1 += len1[i]; m2 += len2[i];
            }
            if (perSheet(p, p.Height) > 0) s1 = stripsFor(len1, g.stripLen);
            if (p.Inner && perSheet(p, h2) > 0) s2 = stripsFor(len2, g.stripLen);
            // одна толщина материала — внешние и внутренние полосы режут из одних листов
            same = p.Inner && Math.abs(p.Wall - p.InWall) < 0.01;
            var hs = [], nm = [], hs2 = [], nm2 = [];
            for (i = 0; i < s1; i++) { hs.push(p.Height); nm.push('Внешний борт ' + (i + 1)); }
            for (i = 0; i < s2; i++) { hs2.push(h2); nm2.push('Внутренний борт ' + (i + 1)); }
            if (same) sheets1 = packStrips(d, p, hs.concat(hs2), nm.concat(nm2), '', false, 0, strips);
            else { sheets1 = packStrips(d, p, hs, nm, '', false, 0, strips); if (s2) sheets2 = packStrips(d, p, hs2, nm2, '', false, 0, strips); }

            // задник и выборка рисуются и убираются своими кнопками; расчёт бортов их не трогает
            stage = 'задник';
            if (p.BackMode == 1) {
                var bl = layerNamed(d, LT_BACK, true); bl.visible = true; bl.locked = false;
                clearFor(d, bl, pcs, N, what, ab);
                drawOffsets(d, pcs, N, backOff(p), bl, rgbColor(0, 160, 0), 'Задник', tmpL, back);
            } else if (p.BackMode == 2 && hasOwn(d, LT_BACK, ab)) {
                var bl2 = cutFindLayer(d, LT_BACK); bl2.visible = true; bl2.locked = false;
                clearFor(d, bl2, pcs, N, what, ab);
                if (!bl2.pageItems.length) dropLayer(d, bl2);
                wasBack = true;
            }
            stage = 'выборка';
            if (p.RebMode == 1) {
                var rl = layerNamed(d, LT_REB, true); rl.visible = true; rl.locked = false;
                clearFor(d, rl, pcs, N, what, ab);
                drawOffsets(d, pcs, N, p.Wall + p.GapFace, rl, rgbColor(0, 110, 255), 'Выборка', tmpL, reb);
            } else if (p.RebMode == 2 && hasOwn(d, LT_REB, ab)) {
                var rl2 = cutFindLayer(d, LT_REB); rl2.visible = true; rl2.locked = false;
                clearFor(d, rl2, pcs, N, what, ab);
                if (!rl2.pageItems.length) dropLayer(d, rl2);
                wasReb = true;
            }
            for (i = 0; i < st.tmp.length; i++) try { st.tmp[i].remove(); } catch (e) { }
            st.tmp = [];
            try { tmpL.remove(); } catch (e) { }
            tmpL = null;
            markFlaws(d, ab);
            // выделение — как было до расчёта
            d.selection = null;
            if (what == 'выделенное') for (i = 0; i < S.items.length; i++) try { S.items[i].selected = true; } catch (e) { }

            // области с полосами — справа от макета, прошлые заменяются
            stage = 'листы с полосами';
            if (p.DrawStrips && s1 + s2 > 0) {
                setDocProp(d, 'lettersAb', String(ab));
                ab = dropStripBoards(d, ab);
                setDocProp(d, 'lettersAb', String(ab));
                if (same) packStrips(d, p, hs.concat(hs2), nm.concat(nm2), mmText(p.Wall) + ' мм', true, sheets1, strips);
                else {
                    packStrips(d, p, hs, nm, 'внешние ' + mmText(p.Wall) + ' мм', true, sheets1, strips);
                    if (s2) packStrips(d, p, hs2, nm2, 'внутренние ' + mmText(p.InWall) + ' мм', true, sheets2, strips);
                }
                if (strips.first >= 0) { d.artboards.setActiveArtboardIndex(strips.first); d.selection = null; }
            }
        } catch (e) {
            logLine('СБОЙ в объёмных буквах на шаге «' + stage + '»: ' + e.message + ' (строка ' + e.line + ')');
            // недорисованные области с полосами — прочь, текущей — снова область с буквами
            if (stage == 'листы с полосами') try { ab = dropStripBoards(d, ab); d.artboards.setActiveArtboardIndex(ab); } catch (x) { }
            try { d.selection = null; if (what == 'выделенное') for (i = 0; i < S.items.length; i++) S.items[i].selected = true; } catch (x) { }
            return 'Посчитать буквы не получилось (шаг «' + stage + '»): ' + e.message + '\nНапишите разработчику: внизу панели «Помощь и настройки» → «Связь с разработчиком» — по отчёту видно, где именно сбой.';
        } finally {
            for (i = 0; i < st.tmp.length; i++) try { st.tmp[i].remove(); } catch (e) { }
            try { if (tmpL) tmpL.remove(); } catch (e) { }
            try { if (keepL && keepL.visible && !keepL.locked) d.activeLayer = keepL; } catch (e) { }
            app.userInteractionLevel = old;
        }

        // итог словами (для кнопок задника и выборки — только о них)
        var act = '', t, nl = '\r\n';
        if (p.BackMode == 1) act += 'Задник нарисован на слое «' + LT_BACK + '»: ' + back.made + ' шт., меньше буквы на ' + mmText(backOff(p)) + ' мм; ' + f3(back.area / 1e6) + ' кв. м, рез ' + f2(back.len / 1000) + ' м.' + nl;
        if (p.RebMode == 1) act += 'Линия выборки нарисована на слое «' + LT_REB + '»: ' + mmText(p.Wall + p.GapFace) + ' мм от края, ' + f2(reb.len / 1000) + ' м фрезеровки.' + nl;
        if (p.BackMode == 2) act += (wasBack ? 'Задник убран.' : 'Задника на этой области нет — убирать нечего.') + nl;
        if (p.RebMode == 2) act += (wasReb ? 'Линия выборки убрана.' : 'Линии выборки на этой области нет — убирать нечего.') + nl;
        t = 'Посчитано ' + what + ': ' + outN + ' ' + plural(outN, 'буква', 'буквы', 'букв') + (holeN ? ', окон ' + holeN : '') +
            '. Край букв ' + f2(edgeL / 1000) + ' м' + (holeN ? ', окна ' + f2(winL / 1000) + ' м' : '') + '.' + nl;
        t += 'Внешний борт ' + mmText(p.Height) + ' мм из ' + mmText(p.Wall) + ' мм: ' + f2(m1 / 1000) + ' м с запасом ' + mmText(p.Reserve) + ' %' +
             (s1 ? ' — ' + s1 + ' ' + plural(s1, 'полоса', 'полосы', 'полос') + ' ' + mmText(g.stripLen) + ' × ' + mmText(p.Height) : ' — полоса на лист не встаёт') + '.' + nl;
        if (p.Inner) t += 'Внутренний борт ' + mmText(h2) + ' мм из ' + mmText(p.InWall) + ' мм: ' + f2(m2 / 1000) + ' м' +
                          (s2 ? ' — ' + s2 + ' ' + plural(s2, 'полоса', 'полосы', 'полос') + ' ' + mmText(g.stripLen) + ' × ' + mmText(h2) : ' — полоса на лист не встаёт') + '.' + nl;
        if (same) t += 'Листов ' + mmText(g.shortS) + ' × ' + mmText(g.longS) + ' из ' + mmText(p.Wall) + ' мм: ' + sheets1 + ' (внешние и внутренние полосы вместе).' + nl;
        else t += 'Листов ' + mmText(g.shortS) + ' × ' + mmText(g.longS) + ': ' + mmText(p.Wall) + ' мм — ' + sheets1 + ' (на лист встаёт ' + perSheet(p, p.Height) + ')' +
                  (p.Inner ? ', ' + mmText(p.InWall) + ' мм — ' + sheets2 + ' (встаёт ' + perSheet(p, h2) + ')' : '') + '.' + nl;
        if (p.DrawStrips && s1 + s2 > 0) t += 'Полосы разложены на монтажных областях «' + LT_STRIP + ' …» справа от макета — красные прямоугольники, между ними ' + mmText(p.Kerf) + ' мм под фрезу.' + nl;
        if (faceA > 0) t += 'Площадь лица ' + f3(faceA / 1e6) + ' кв. м.';
        if (p.Brief) t = act; else if (act) t = act + t;
        t = t.replace(/\r\n$/, '');
        if (back.lost) t += nl + 'Задник не построился у ' + back.lost + ' ' + plural(back.lost, 'буквы', 'букв', 'букв') + ' — штрихи тоньше двух толщин борта с зазором.';
        if (reb.lost) t += nl + 'Выборка не построилась у ' + reb.lost + ' ' + plural(reb.lost, 'буквы', 'букв', 'букв') + ' — штрихи тоньше двух толщин борта с зазором.';
        if (st.open) t += nl + 'Незамкнутых линий: ' + st.open + ' — они не посчитаны. Замкните их, если это края букв.';
        if (flaws.length && p.Brief) t += nl + 'Косяков в буквах: ' + flaws.length + ' — отмечены красными кружками, убрать — «Исправить косяки в макете».';
        else if (flaws.length) {
            var c1 = 0, c2 = 0, c3 = 0;
            for (i = 0; i < flaws.length; i++) { if (flaws[i][2] == 1) c1++; else if (flaws[i][2] == 2) c2++; else c3++; }
            var fl = [];
            if (c1) fl.push(' контур пересекает сам себя — ' + c1 + ' ' + plural(c1, 'место', 'места', 'мест') + ' (в расчёте уже исправлено; в самом макете — кнопкой «Исправить косяки в макете»)');
            if (c2) fl.push(' контуры налезают друг на друга — ' + c2 + ' ' + plural(c2, 'место', 'места', 'мест') + ' (борт там посчитан дважды — слейте такие буквы или раздвиньте)');
            if (c3) fl.push(' мусор меньше 1 мм — ' + c3 + ' ' + plural(c3, 'место', 'места', 'мест') + ' (в расчёт не взят; удалите его, иначе станок сделает лишние врезки)');
            t += nl + 'Косяки в буквах отмечены красными кружками на слое «' + LT_FLAW + '»:' + fl.join(';') + '.';
        }
        logLine('объёмные буквы: ' + t.replace(/\r\n/g, ' / '));
        return t;
    }

    // ---------- «Исправить косяки в макете»: петли в контурах самих букв ----------
    function copyLook(to, from) {
        var s = from.typename == 'CompoundPathItem' && from.pathItems.length ? from.pathItems[0] : from, lv = pathsOf(to, []);
        for (var i = 0; i < lv.length; i++) {
            try { lv[i].filled = s.filled; if (s.filled) lv[i].fillColor = s.fillColor; } catch (e) { }
            try { lv[i].stroked = s.stroked; if (s.stroked) { lv[i].strokeColor = s.strokeColor; lv[i].strokeWidth = s.strokeWidth; } } catch (e) { }
        }
    }
    function fixLayout() {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, ab = d.artboards.getActiveArtboardIndex(), S = source(d, ab, true), leaves = [], txt = 0, n = 0, i;
        if (!S.items.length) return 'На монтажной области ничего нет.';
        (function walk(list) {
            for (var q = 0; q < list.length; q++) {
                var it = list[q];
                try { if (it.hidden || it.guides) continue; } catch (e) { }
                if (skipL(cutTopLayer(it), true)) continue;
                if (it.typename == 'GroupItem') { var ch = []; for (var k = 0; k < it.pageItems.length; k++) ch.push(it.pageItems[k]); walk(ch); }
                else if (it.typename == 'TextFrame') txt++;
                else if (it.typename == 'CompoundPathItem' || (it.typename == 'PathItem' && !it.clipping && it.closed)) leaves.push(it);
            }
        })(S.items);
        var old = app.userInteractionLevel;
        app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
        try {
            for (i = 0; i < leaves.length; i++) {
                var it = leaves[i], subs = it.typename == 'PathItem' ? [it] : pathsOf(it, []), pcs = [];
                for (var k = 0; k < subs.length; k++) if (subs[k].closed && subs[k].pathPoints.length > 2) pcs.push(pieceOf(subs[k], ''));
                var X = crossings(pcs), any = false;
                for (k in X.self) if (X.self.hasOwnProperty(k)) any = true;
                if (!any) continue;
                var a0 = absArea([it]), dup = it.duplicate(it, ElementPlacement.PLACEBEFORE);
                solid(dup);
                var r = unite(d, dup);
                if (!r) continue;
                if (Math.abs(absArea([r]) - a0) < 0.5) { r.remove(); continue; }
                copyLook(r, it);
                r.move(it, ElementPlacement.PLACEBEFORE);
                try { r.name = it.name; } catch (e) { }
                try { var tg = tagOf(it), t2 = r.tags.add(); t2.name = 'psaLt'; t2.value = tg; } catch (e) { }
                it.remove();
                n++;
            }
            dropOn(d, LT_FLAW, ab);
        } finally { app.userInteractionLevel = old; d.selection = null; if (S.what == 'выделенное') for (i = 0; i < S.items.length; i++) try { S.items[i].selected = true; } catch (e) { } }
        var t = n ? 'Исправлено ' + n + ' ' + plural(n, 'буква', 'буквы', 'букв') + ': петли в контурах убраны. Вернуть как было — Ctrl+Z.'
                  : 'Петель в контурах не нашлось — проверено ' + S.what + '.';
        if (txt) t += ' Надписи (' + txt + ') не тронуты — их сначала переводят в кривые.';
        return t;
    }

    // ---------- раскладка задников на листы ----------
    // Задник рисуется поверх лиц, а режут его из другого материала — ему нужна своя раскладка. Задники копируются
    // на служебный слой, укладка по форме кладёт их на новые монтажные области «Задники — лист …» справа
    function prepBacks() {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument;
        if (isOwnBoard(activeAb(d).name) && !backToLetters(d)) return 'Перейдите на монтажную область с буквами.';
        var ab = d.artboards.getActiveArtboardIndex(), own = layerItems(d, LT_BACK, ab), i;
        if (!own.length) {
            for (i = 0; i < d.artboards.length; i++) if (d.artboards[i].name.indexOf('Задники — ') == 0)
                return 'Задники уже разложены — на монтажных областях «Задники — лист …». Переразложить: нарисуйте задник заново (с другим зазором, если нужно) и нажмите ещё раз.';
            return 'Задника на этой области нет — сначала нажмите «Нарисовать задник».';
        }
        setDocProp(d, 'lettersAb', String(ab));
        dropParts(d);
        var L = layerNamed(d, LT_PART, false), out = [];
        L.visible = true; L.locked = false;
        for (i = 0; i < own.length; i++) { var a = own[i].duplicate(L, ElementPlacement.PLACEATBEGINNING); a.name = 'Задник ' + (i + 1); out.push(a); }
        return { items: out, ab: ab };
    }
    function dropParts(d) { var L = cutFindLayer(d || app.activeDocument, LT_PART); if (L) dropLayer(d || app.activeDocument, L); }

    // ---------- стоимость резки ----------
    function strokeKey(x) {
        var s = x.typename == 'CompoundPathItem' && x.pathItems.length ? x.pathItems[0] : x;
        try {
            if (!s.stroked) return 'нет';
            var c = s.strokeColor, rgb, tint = 1;
            if (c.typename == 'SpotColor') { tint = c.tint / 100; c = c.spot.color; }
            if (c.typename == 'RGBColor') rgb = [c.red, c.green, c.blue];
            else if (c.typename == 'CMYKColor') rgb = [255 * (1 - c.cyan / 100) * (1 - c.black / 100), 255 * (1 - c.magenta / 100) * (1 - c.black / 100), 255 * (1 - c.yellow / 100) * (1 - c.black / 100)];
            else if (c.typename == 'GrayColor') { var v = 255 * (1 - c.gray / 100); rgb = [v, v, v]; }
            else if (c.typename == 'NoColor') return 'нет';
            else rgb = [0, 0, 0];
            var h = '#';
            for (var i = 0; i < 3; i++) { var q = Math.round(255 - (255 - rgb[i]) * tint); q = Math.max(0, Math.min(255, q)); h += (q < 16 ? '0' : '') + q.toString(16).toUpperCase(); }
            return h;
        } catch (e) { return 'нет'; }
    }
    function costWalk(it, acc) {
        var t = it.typename, i;
        try { if (it.hidden || it.guides) return; } catch (e) { }
        if (skipL(cutTopLayer(it), false)) return;
        if (t == 'GroupItem') { for (i = 0; i < it.pageItems.length; i++) costWalk(it.pageItems[i], acc); return; }
        if (t != 'PathItem' && t != 'CompoundPathItem' && t != 'TextFrame') { acc.skipped++; return; }
        if (t == 'PathItem' && it.clipping) return;
        var key = t == 'TextFrame' ? (function () { try { var ca = it.textRange.characterAttributes; return ca.strokeWeight > 0 ? strokeKey({ typename: 'PathItem', stroked: true, strokeColor: ca.strokeColor }) : 'нет'; } catch (e) { return 'нет'; } })() : strokeKey(it);
        var subs = cutSubs(it, acc.tmp);
        if (!subs.length) { acc.skipped++; return; }
        if (!acc.lens.hasOwnProperty(key)) { acc.keys.push(key); acc.lens[key] = 0; acc.pierces[key] = 0; }
        for (i = 0; i < subs.length; i++) {
            var L = mm(subs[i].length);
            if (L > 0.01) { acc.lens[key] += L; acc.pierces[key]++; if (L < 3) acc.tiny++; }
        }
    }
    function timeText(mins) { return mins < 60 ? Math.round(mins) + ' мин' : Math.floor(mins / 60) + ' ч ' + Math.round(mins - Math.floor(mins / 60) * 60) + ' мин'; }
    // Первая строка — текст для человека, дальше строки по цветам «цвет|метров|врезок|минут|цена»
    function runCost(c) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, S = source(d, d.artboards.getActiveArtboardIndex(), false), i;
        if (!S.items.length) return 'На монтажной области ничего нет.';
        var acc = { keys: [], lens: {}, pierces: {}, skipped: 0, tiny: 0, tmp: [] };
        try { for (i = 0; i < S.items.length; i++) costWalk(S.items[i], acc); }
        catch (e) { logLine('сбой стоимости резки: ' + e.message + ' (строка ' + e.line + ')'); return 'Посчитать не получилось: ' + e.message; }
        finally { for (i = 0; i < acc.tmp.length; i++) try { acc.tmp[i].remove(); } catch (e) { } }
        if (!acc.keys.length) return 'Нет линий для резки (проверено ' + S.what + ').';
        var rows = '', totL = 0, totP = 0, totMin = 0, totPrice = 0;
        for (i = 0; i < acc.keys.length; i++) {
            var k = acc.keys[i], L = acc.lens[k] / 1000, np = acc.pierces[k], mins = c.Speed > 0 ? L / c.Speed + np * c.PierceSec / 60 : 0, price = L * c.PerM + np * c.PerPierce;
            totL += L; totP += np; totMin += mins; totPrice += price;
            rows += '\n' + k + '|' + f2(L) + '|' + np + '|' + Math.round(mins) + '|' + Math.round(price);
        }
        var t = 'Посчитано ' + S.what + ': рез ' + f2(totL) + ' м, врезок ' + totP + '.';
        if (c.Speed > 0) t += ' Время около ' + timeText(totMin) + '.';
        if (c.PerM > 0 || c.PerPierce > 0) t += ' Стоимость ' + Math.round(totPrice) + (c.Minimum > 0 && totPrice < c.Minimum ? ', меньше минимальной — берётся ' + Math.round(c.Minimum) : '') + '.';
        if (acc.skipped) t += ' Картинки и прочее без линий не посчитаны: ' + acc.skipped + '.';
        if (acc.tiny) t += ' Среди врезок ' + acc.tiny + ' — крошечные контуры меньше 3 мм: похоже на мусор из DXF, удалите их — станок сделает лишние врезки.';
        logLine('стоимость резки: ' + t);
        return t + rows;
    }

    return { from: from, describe: describe, run: run, fixLayout: fixLayout, hasOwn: hasOwn, prepBacks: prepBacks, dropParts: dropParts, runCost: runCost };
})();

// ---------- команды панели ----------

function ltNeed() { return PSA.has('M') ? '' : 'Объёмные буквы входят в часть «Фрезер» — её нет в вашем ключе.'; }
Bridge.LettersInfo = function (params) { return Letters.describe(Letters.from(params)); };
// «Посчитать борта»: только расчёт — метры, полосы, листы; в макете меняет лишь отметки косяков
Bridge.LettersRun = function (params) {
    var e = ltNeed(); if (e) return e;
    Settings.set('Letters', 'Params', params);
    return Letters.run(Letters.from(params));
};
// «Нарисовать задник / убрать», «Нарисовать выборку / убрать»: what — back или reb, mode — 1 нарисовать, 2 убрать
Bridge.LettersDraw = function (params, what, mode) {
    var e = ltNeed(); if (e) return e;
    Settings.set('Letters', 'Params', params);
    var n = Letters.from(params);
    if (what == 'back') n.BackMode = +mode || 0; else n.RebMode = +mode || 0;
    n.Brief = true;
    return Letters.run(n);
};
// «Исправить косяки в макете»: петли в контурах самих букв; задник и выборку — перерисовать по исправленным
Bridge.LettersFix = function (params) {
    var e = ltNeed(); if (e) return e;
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument, ab = d.artboards.getActiveArtboardIndex(), r = Letters.fixLayout(), n = Letters.from(params);
    if (Letters.hasOwn(d, LT_BACK, ab)) n.BackMode = 1;
    if (Letters.hasOwn(d, LT_REB, ab)) n.RebMode = 1;
    n.DrawStrips = false; n.Brief = true;
    if (n.BackMode == 1 || n.RebMode == 1) {
        r += (n.BackMode == 1 && n.RebMode == 1 ? ' Задник и выборка перерисованы' : (n.BackMode == 1 ? ' Задник перерисован' : ' Выборка перерисована')) + ' по исправленным буквам.';
        r = r.replace('Вернуть как было — Ctrl+Z.', 'Вернуть как было — Ctrl+Z два раза.');
        r += '\r\n\r\n' + Letters.run(n);
    }
    return r;
};
// «Разложить задники на листы»: в укладку по форме (лист, зазор, повороты — из «Раскладка · По форме»),
// листы — монтажными областями этого же документа. "started" — расчёт идёт, панель следит, как за укладкой
Bridge.LettersNest = function (nparams) {
    var e = ltNeed(); if (e) return e;
    if (!hasDoc()) return 'Нет открытого документа.';
    var r = Letters.prepBacks();
    if (typeof r == 'string') return r;
    try { return Nest.runPages(Nest.from(nparams), r.items, 'Задники', LT_PART, LT_BACK, r.ab); }
    catch (x) { Letters.dropParts(); logLine('СБОЙ LettersNest: ' + x.message); return 'Не получилось: ' + x.message; }
};
// «Листы с полосами»: тот же расчёт, задник и выборку не трогает, добавляет области с полосами
Bridge.LettersStrips = function (params) {
    var e = ltNeed(); if (e) return e;
    Settings.set('Letters', 'Params', params);
    var n = Letters.from(params);
    n.DrawStrips = true;
    return Letters.run(n);
};
Bridge.CostRun = function (params) {
    if (!PSA.has('PML')) return 'Стоимость резки входит в части «Плоттер», «Фрезер» и «Лазер» — их нет в вашем ключе.';
    var c = parseKV(params), N = function (k) { return toNum(c.hasOwnProperty(k) ? c[k] : '', 0); };
    Settings.set('Cost', 'Params', params);
    return Letters.runCost({ PerM: N('ctPerM'), PerPierce: N('ctPierce'), Speed: N('ctSpeed'), PierceSec: N('ctPierceSec'), Minimum: N('ctMin') });
};
