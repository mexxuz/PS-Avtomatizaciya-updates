// Мелочи перед печатью — как src/Tools.bas: чистка набранного текста, выделение однотипных объектов,
// замена цвета по документу, направляющие по полям, вылет по форме, лицо и оборот с одной области — по областям.
// Правки текста — по одной букве, а не переписыванием надписи: иначе слетит оформление внутри строки.

var Tools = {};
var SHORT_WORDS = '|в|во|на|над|под|при|про|за|из|изо|от|ото|до|по|со|с|к|ко|у|о|об|обо|и|а|но|да|не|ни|же|бы|ли|что|как|для|без|или|это|его|её|их|мы|вы|он|она|они|я|ты|то|так|уж|вот|там|тут|где|чем|чтоб|если|';
var CUT_LAYER_ROLL = 'CutContour';

// Все объекты-листья документа или выделения (группы раскрыты, обтравочные рамки — тоже)
function leavesOf(items) {
    var out = [];
    function walk(it) {
        if (it.typename == 'GroupItem') { for (var k = 0; k < it.pageItems.length; k++) walk(it.pageItems[k]); return; }
        out.push(it);
    }
    for (var i = 0; i < items.length; i++) walk(items[i]);
    return out;
}
function allTop(d, ab) {
    var out = [];
    for (var i = 0; i < d.layers.length; i++) if (!d.layers[i].locked) out = out.concat(topItemsOn(d, d.layers[i], ab));
    return out;
}

// ---------- чистка текста ----------

function isLetter(ch) {
    if (!ch) return false;
    var c = ch.charCodeAt(0);
    return (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || (c >= 1040 && c <= 1103) || c == 1025 || c == 1105;
}
function isTail(ch) { return ch !== '' && ',.;:!?)»…'.indexOf(ch) >= 0; }

Tools.CleanText = function (o) {
    if (!hasDoc()) return 'Нет открытого документа.';
    if (!(o.Spaces || o.Dashes || o.Quotes || o.Hanging)) return 'Ничего не выбрано — отметьте, что чистить.';
    var d = app.activeDocument, sel = selectionItems(d), items = sel.length ? sel : allTop(d, d.artboards.getActiveArtboardIndex());
    var leaves = leavesOf(items), texts = 0, cSp = 0, cDa = 0, cQu = 0, cHa = 0;
    for (var n = 0; n < leaves.length; n++) {
        var s = leaves[n];
        if (s.typename != 'TextFrame') continue;
        // поля переменной печати не трогаем: их текст подставляется из файла
        if (s.name.substring(0, TAG_FIELD.length) == TAG_FIELD) continue;
        texts++;
        try {
            var t = s.contents, i, ch;
            if (t.length < 2) continue;
            if (o.Quotes) {
                var open = true;
                for (i = 0; i < t.length; i++) {
                    ch = t.charAt(i);
                    if (ch == '"' || ch == '“' || ch == '”') {
                        var prev = i > 0 ? t.charAt(i - 1) : ' ';
                        if (ch == '“') open = true;
                        else if (ch == '”') open = false;
                        else open = prev == ' ' || prev == '(' || prev == '\r' || prev == '\n';
                        s.characters[i].contents = open ? '«' : '»';
                        cQu++;
                    }
                }
                t = s.contents;
            }
            // с конца: номера букв впереди не съезжают после удаления
            for (i = t.length - 1; i >= 0; i--) {
                ch = t.charAt(i);
                var pr = i > 0 ? t.charAt(i - 1) : '', nx = i < t.length - 1 ? t.charAt(i + 1) : '';
                if (o.Spaces && ch == ' ' && (nx == ' ' || isTail(nx))) { s.characters[i].remove(); cSp++; continue; }
                if (o.Dashes && (ch == '-' || ch == '–') && pr == ' ' && nx == ' ') { s.characters[i].contents = '—'; cDa++; }
            }
            if (o.Hanging) {
                // короткое слово не остаётся в конце строки — пробел после него неразрывный
                t = s.contents;
                for (i = t.length - 1; i >= 1; i--) {
                    if (t.charAt(i) != ' ') continue;
                    var j = i - 1, w = '';
                    while (j >= 0 && isLetter(t.charAt(j))) { w = t.charAt(j) + w; j--; }
                    if (w && w.length <= 4 && SHORT_WORDS.indexOf('|' + w.toLowerCase() + '|') >= 0 && (j < 0 || !isLetter(t.charAt(j)))) {
                        s.characters[i].contents = ' '; cHa++;
                    }
                }
            }
        } catch (e) { }
    }
    var total = cSp + cDa + cQu + cHa, part = function (v, w) { return v > 0 ? '; ' + w + ': ' + v : ''; };
    if (!texts) return 'Надписей не нашлось. Выделите текст или откройте монтажную область с текстом.';
    if (!total) return 'Просмотрено надписей: ' + texts + '. Чистить нечего — всё уже в порядке.';
    return 'Просмотрено надписей: ' + texts + ', правок ' + total + part(cSp, 'лишних пробелов') + part(cDa, 'дефисов заменено на тире') +
           part(cQu, 'кавычек выправлено') + part(cHa, 'коротких слов притянуто к следующему') + '. Отменить — Ctrl+Z.';
};

// ---------- выделить такие же ----------

function colorKey(c) {
    try {
        switch (c.typename) {
            case 'CMYKColor': return 'c' + Math.round(c.cyan) + '.' + Math.round(c.magenta) + '.' + Math.round(c.yellow) + '.' + Math.round(c.black);
            case 'RGBColor': return 'r' + Math.round(c.red) + '.' + Math.round(c.green) + '.' + Math.round(c.blue);
            case 'GrayColor': return 'g' + Math.round(c.gray);
            case 'SpotColor': return 's' + c.spot.name + '.' + Math.round(c.tint);
            case 'NoColor': return '';
            default: return 'x' + c.typename;
        }
    } catch (e) { return '?'; }
}
// у составного контура цвет — у первой части
function shapeOf(it) { return it.typename == 'CompoundPathItem' && it.pathItems.length ? it.pathItems[0] : it; }

Tools.SameName = function (by) { return ['цвет заливки', 'цвет обводки', 'толщина обводки', 'тип объекта', 'размер'][by] || 'цвет заливки'; };
function sameKey(it, by) {
    try {
        var p = shapeOf(it);
        if (by == 0) { if (p.typename == 'TextFrame') return 'f' + colorKey(p.textRange.characterAttributes.fillColor); if (!p.filled) return ''; return 'f' + colorKey(p.fillColor); }
        if (by == 1) { if (p.typename == 'TextFrame' || !p.stroked) return ''; return 'o' + colorKey(p.strokeColor); }
        if (by == 2) { if (p.typename == 'TextFrame' || !p.stroked) return ''; return 'w' + Math.round(mm(p.strokeWidth) * 1000); }
        if (by == 3) return 't' + it.typename;
        if (by == 4) return 'z' + Math.round(mm(it.width) * 100) + 'x' + Math.round(mm(it.height) * 100);
    } catch (e) { }
    return '';
}

Tools.SelectSame = function (by) {
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument, sel = selectionItems(d);
    if (!sel.length) return 'Сначала выделите один объект — образец, по которому искать.';
    var key = sameKey(leavesOf([sel[0]])[0] || sel[0], by);
    if (!key) return 'У этого объекта нечего сравнивать — выберите другой признак.';
    var leaves = leavesOf(allTop(d, d.artboards.getActiveArtboardIndex())), hit = [];
    for (var i = 0; i < leaves.length; i++) if (sameKey(leaves[i], by) == key) hit.push(leaves[i]);
    if (!hit.length) return 'Похожих объектов не нашлось.';
    d.selection = null;
    for (i = 0; i < hit.length; i++) try { hit[i].selected = true; } catch (e) { }
    return 'Выделено объектов: ' + hit.length + ' (по признаку «' + this.SameName(by) + '»). Дальше меняйте их все сразу.';
};

// ---------- замена цвета по всему документу ----------

Tools.ColorOfSelection = function () {
    if (!hasDoc()) return '';
    var sel = selectionItems(app.activeDocument);
    if (!sel.length) return '';
    try {
        var p = shapeOf(leavesOf([sel[0]])[0]), c = p.typename == 'TextFrame' ? p.textRange.characterAttributes.fillColor : p.fillColor;
        if (c.typename == 'CMYKColor') return Math.round(c.cyan) + '|' + Math.round(c.magenta) + '|' + Math.round(c.yellow) + '|' + Math.round(c.black);
    } catch (e) { }
    return '';
};

Tools.ReplaceColor = function (c, m, y, k, what) {
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument, sel = selectionItems(d);
    if (!sel.length) return 'Сначала выделите объект того цвета, который нужно заменить.';
    var ref = shapeOf(leavesOf([sel[0]])[0]), key;
    try { key = colorKey(ref.typename == 'TextFrame' ? ref.textRange.characterAttributes.fillColor : (ref.filled ? ref.fillColor : null)); } catch (e) { key = ''; }
    if (!key || key == '?') return 'У выделенного объекта нет простой заливки — по ней и ищется цвет.';
    var leaves = leavesOf(allTop(d, -1)), nf = 0, no = 0, nc = cmykColor(c, m, y, k);
    for (var i = 0; i < leaves.length; i++) {
        var it = leaves[i], parts = it.typename == 'CompoundPathItem' ? [] : [it];
        if (it.typename == 'CompoundPathItem') for (var q = 0; q < it.pathItems.length; q++) parts.push(it.pathItems[q]);
        for (q = 0; q < parts.length; q++) {
            var p = parts[q];
            try {
                if (p.typename == 'TextFrame') {
                    var a = p.textRange.characterAttributes;
                    if (colorKey(a.fillColor) == key) { a.fillColor = nc; nf++; }
                    continue;
                }
                if (p.typename != 'PathItem') continue;
                if (p.filled && colorKey(p.fillColor) == key) { p.fillColor = nc; nf++; }
                if (what == 1 && p.stroked && colorKey(p.strokeColor) == key) { p.strokeColor = nc; no++; }
            } catch (e) { }
        }
    }
    if (!nf && !no) return 'Этот цвет больше нигде не встретился.';
    return 'Заменено: заливок ' + nf + (what == 1 ? ', обводок ' + no : '') + ' — во всём документе, включая группы. Отменить — Ctrl+Z.';
};

// ---------- направляющие по полям ----------

Tools.Guides = function (margin, center, clear) {
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument, ab = d.artboards.getActiveArtboardIndex(), r = d.artboards[ab].artboardRect, n = 0, i;
    if (clear) {
        var lv = leavesOf(allTop(d, -1));
        for (i = lv.length - 1; i >= 0; i--) try { if (lv[i].typename == 'PathItem' && lv[i].guides) lv[i].remove(); } catch (e) { }
    }
    var L = d.activeLayer;
    function guide(x1, y1, x2, y2) { var p = L.pathItems.add(); p.setEntirePath([[x1, y1], [x2, y2]]); p.guides = true; n++; }
    var big = pt(5000);
    if (margin > 0) {
        guide(r[0] + pt(margin), r[1] + big, r[0] + pt(margin), r[3] - big); guide(r[2] - pt(margin), r[1] + big, r[2] - pt(margin), r[3] - big);
        guide(r[0] - big, r[3] + pt(margin), r[2] + big, r[3] + pt(margin)); guide(r[0] - big, r[1] - pt(margin), r[2] + big, r[1] - pt(margin));
    }
    if (center) {
        var cx = (r[0] + r[2]) / 2, cy = (r[1] + r[3]) / 2;
        guide(cx, r[1] + big, cx, r[3] - big); guide(r[0] - big, cy, r[2] + big, cy);
    }
    if (!n) return 'Нечего ставить: укажите поле больше нуля или отметьте средние линии.';
    return 'Направляющих поставлено: ' + n + (margin > 0 ? ', поле ' + mmText(margin) + ' мм от края' : '') + (center ? ', плюс середина листа' : '') + '. Отменить — Ctrl+Z.';
};

// ---------- вылет по форме ----------

function cutContourColor(d) {
    var sp;
    try { sp = d.spots.getByName('CutContour'); } catch (e) { sp = null; }
    if (!sp) { sp = d.spots.add(); sp.name = 'CutContour'; sp.colorType = ColorModel.SPOT; sp.color = cmykColor(0, 100, 0, 0); }
    var c = new SpotColor(); c.spot = sp; c.tint = 100;
    return c;
}

// Общий контур объектов (копий): текст в кривые, объединение. null — не вышло.
function unionOf(d, items) {
    var L = items[0].layer, g = L.groupItems.add(), k;
    for (k = items.length - 1; k >= 0; k--) items[k].duplicate(g, ElementPlacement.PLACEATBEGINNING);
    d.selection = null; g.selected = true;
    try {
        app.executeMenuCommand('outline');
        app.executeMenuCommand('Live Pathfinder Add');
        app.executeMenuCommand('expandStyle');
    } catch (e) { }
    var u = d.selection.length ? d.selection[0] : null;
    d.selection = null;
    return u;
}
function offsetBy(d, it, dd) {
    try {
        it.applyEffect('<LiveEffect name="Adobe Offset Path"><Dict data="R mlim 4 R ofst ' + pt(dd) + ' I jntp 0 "/></LiveEffect>');
        d.selection = null; it.selected = true;
        app.executeMenuCommand('expandStyle');
        var r = d.selection.length ? d.selection[0] : null;
        d.selection = null;
        return r;
    } catch (e) { return null; }
}

// Вылет не прямоугольником, а по контуру фигуры (наклейки, фигурная резка): общий контур выделенного,
// раздутый наружу, — под рисунок. mode 0 — цвет нижнего объекта, 1 — растянутая копия рисунка.
// cutLine — исходный контур остаётся линией реза (CutContour на своём слое).
Tools.ShapeBleed = function (width, mode, cutLine) {
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument, sel = selectionItems(d);
    if (!sel.length) return 'Сначала выделите рисунок, вокруг которого нужен вылет.';
    if (width <= 0) return 'Укажите вылет больше нуля.';
    // нижний объект выделения — под него ляжет вылет, его цвет — заливка вылета
    var low = sel[sel.length - 1], col = cmykColor(0, 0, 0, 0);
    try { var lp = shapeOf(leavesOf([low])[0]); if (lp.filled) col = lp.fillColor; } catch (e) { }
    var u = unionOf(d, sel);
    if (!u) return 'Не получилось обвести выделенное общим контуром. Так бывает на сложных рисунках: сгруппируйте их или обведите контур вручную.';
    var cut = cutLine ? u.duplicate() : null;
    var bs = offsetBy(d, u, width);
    if (!bs) { try { u.remove(); } catch (e) { } return 'Не получилось раздуть контур на ' + mmText(width) + ' мм.'; }
    bs.move(low, ElementPlacement.PLACEAFTER);
    bs.name = 'Вылет по форме';
    var lv = leavesOf([bs]);
    for (var i = 0; i < lv.length; i++) { var p = shapeOf(lv[i]); try { p.filled = true; p.fillColor = col; p.stroked = false; } catch (e) { } }
    if (mode == 1) {
        // копия рисунка, растянутая на вылет и обрезанная фигурой вылета
        var g = low.layer.groupItems.add();
        g.move(bs, ElementPlacement.PLACEBEFORE);
        var art = g.groupItems.add();
        for (i = sel.length - 1; i >= 0; i--) sel[i].duplicate(art, ElementPlacement.PLACEATBEGINNING);
        var bb = bs.geometricBounds, ab = art.geometricBounds, fx = Math.max((bb[2] - bb[0]) / (ab[2] - ab[0]), (bb[1] - bb[3]) / (ab[1] - ab[3]));
        art.resize(fx * 100, fx * 100);
        ab = art.geometricBounds;
        art.translate((bb[0] + bb[2]) / 2 - (ab[0] + ab[2]) / 2, (bb[1] + bb[3]) / 2 - (ab[1] + ab[3]) / 2);
        var clip = bs.duplicate(g, ElementPlacement.PLACEATBEGINNING);
        g.clipped = true;
        try { shapeOf(leavesOf([clip])[0]).clipping = true; } catch (e) { }
        bs.remove();
        bs = g;
        bs.name = 'Вылет по форме';
    }
    if (cut) {
        var cl = layerNamed(d, CUT_LAYER_ROLL, true);
        cut.move(cl, ElementPlacement.PLACEATBEGINNING);
        var cc = cutContourColor(d), cv = leavesOf([cut]);
        for (i = 0; i < cv.length; i++) { var q = shapeOf(cv[i]); try { q.filled = false; q.stroked = true; q.strokeWidth = pt(0.1); q.strokeColor = cc; } catch (e) { } }
        cut.name = 'Линия реза';
    }
    d.selection = null;
    for (i = 0; i < sel.length; i++) try { sel[i].selected = true; } catch (e) { }
    return 'Готово: вылет ' + mmText(width) + ' мм по форме рисунка, положен под него' + (mode == 1 ? ' и заполнен растянутой копией рисунка' : ' и залит цветом рисунка') +
           (cut ? '. Линия реза — по краю рисунка, цветом CutContour на слое «' + CUT_LAYER_ROLL + '».' : '. Резать по краю самого рисунка.') + ' Отменить — Ctrl+Z.';
};

// ---------- лицо и оборот с одной области — по областям ----------

// Всё печатаемое на области делится пустым промежутком (слева направо, потом сверху вниз) ровно на две части.
// same — ещё и стороны одного размера (±15 %). Ответ: { face: [], back: [], vert } или null.
Tools.FindSides = function (d, ab, same) {
    var all = [], i, k;
    for (i = 0; i < d.layers.length; i++) if (d.layers[i].printable && d.layers[i].visible) all = all.concat(topItemsOn(d, d.layers[i], ab));
    // направляющие не печатаются и тянутся через всю область — не рисунок
    var art = [];
    for (i = 0; i < all.length; i++) { var g = false; try { g = all[i].typename == 'PathItem' && all[i].guides; } catch (e) { } if (!g) art.push(all[i]); }
    all = art;
    if (all.length < 2 || all.length > 300) return null;
    var gap = pt(0.5), bounds = [];
    for (i = 0; i < all.length; i++) bounds.push(visBounds(all[i]));
    for (var pass = 0; pass < 2; pass++) {
        var vert = pass == 1, idx = [], A = [], B = [];
        for (i = 0; i < all.length; i++) { A.push(vert ? -bounds[i][1] : bounds[i][0]); B.push(vert ? -bounds[i][3] : bounds[i][2]); idx.push(i); }
        idx.sort(function (x, y) { return A[x] - A[y]; });
        var reach = B[idx[0]], found = false, splitAt = 0, many = false;
        for (k = 1; k < idx.length; k++) {
            if (A[idx[k]] > reach + gap) { if (found) { many = true; break; } found = true; splitAt = (reach + A[idx[k]]) / 2; }
            if (B[idx[k]] > reach) reach = B[idx[k]];
        }
        if (!found || many) continue;
        var face = [], back = [];
        for (i = 0; i < all.length; i++) (A[i] < splitAt ? face : back).push(all[i]);
        if (same) {
            var fb = boundsOf(face), bb = boundsOf(back), fw = fb[2] - fb[0], fh = fb[1] - fb[3], bw = bb[2] - bb[0], bh = bb[1] - bb[3];
            if (fw <= 0 || fh <= 0 || bw <= 0 || bh <= 0 || Math.abs(fw - bw) > 0.15 * fw || Math.abs(fh - bh) > 0.15 * fh) return null;
        }
        return { face: face, back: back, vert: vert };
    }
    return null;
};
function boundsOf(items) {
    var b = visBounds(items[0]).slice(0);
    for (var i = 1; i < items.length; i++) { var v = visBounds(items[i]); b[0] = Math.min(b[0], v[0]); b[1] = Math.max(b[1], v[1]); b[2] = Math.max(b[2], v[2]); b[3] = Math.min(b[3], v[3]); }
    return b;
}

// Для панели: одна область, на ней рядом две стороны одного размера — предложить разнести
Tools.LooksTwoSided = function () {
    try {
        if (!hasDoc()) return false;
        var d = app.activeDocument;
        return d.artboards.length == 1 && !!this.FindSides(d, 0, true);
    } catch (e) { return false; }
};

Tools.SplitSides = function (bleed) {
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument;
    if (d.artboards.length > 1) return 'В документе уже несколько монтажных областей. Разносить нужно файл, где лицо и оборот лежат на одной области.';
    var s = this.FindSides(d, 0, false);
    if (!s) return 'Не нашёл на области ровно двух сторон с промежутком между ними. Положите лицо и оборот рядом или одно над другим.';
    var fb = boundsOf(s.face), bb = boundsOf(s.back), bl = bleed > 0 ? bleed : 0;
    var pw = Math.round(Math.max(mm(fb[2] - fb[0]), mm(bb[2] - bb[0])) * 10) / 10, ph = Math.round(Math.max(mm(fb[1] - fb[3]), mm(bb[1] - bb[3])) * 10) / 10;
    var W = pt(pw + 2 * bl), H = pt(ph + 2 * bl), r0 = d.artboards[0].artboardRect;
    // лицо — область 1, оборот — область 2 правее; каждая сторона по центру своей
    var a1 = [r0[0], r0[1], r0[0] + W, r0[1] - H], a2 = [r0[0] + W + pt(20), r0[1], r0[0] + 2 * W + pt(20), r0[1] - H];
    d.artboards[0].artboardRect = a1;
    d.artboards.add(a2);
    d.artboards[0].name = 'Лицо';
    d.artboards[1].name = 'Оборот';
    function centerOn(items, a) {
        var b = boundsOf(items), dx = (a[0] + a[2]) / 2 - (b[0] + b[2]) / 2, dy = (a[1] + a[3]) / 2 - (b[1] + b[3]) / 2;
        for (var i = 0; i < items.length; i++) items[i].translate(dx, dy);
    }
    centerOn(s.face, a1); centerOn(s.back, a2);
    // раскладке — сразу верные «Макет по резу» и «Вылет за рез»
    Settings.set('Impose', 'CutW', pw); Settings.set('Impose', 'CutH', ph); Settings.set('Impose', 'Bleed', bl);
    var msg = 'Готово: лицо — область 1, оборот — область 2, по резу ' + mmText(pw) + ' × ' + mmText(ph) + ' мм' + (s.vert ? ' (стороны лежали одна над другой)' : '') + '.';
    if (bl > 0) {
        var e1 = mirrorBleed(d, s.face, a1, bl), e2 = mirrorBleed(d, s.back, a2, bl);
        msg += (!e1 && !e2) ? ' Вылет ' + mmText(bl) + ' мм — зеркалом, области с вылетом ' + mmText(pw + 2 * bl) + ' × ' + mmText(ph + 2 * bl) + ' мм.' : ' Вылет не встал: ' + (e1 || e2);
    } else msg += ' Без вылета.';
    d.selection = null;
    return msg + ' Теперь — «Весь документ» и «Разложить».';
};

// Вылет зеркалом: за каждым краем — отражение полоски рисунка у края, за углами — отражение угла.
// Восемь отражённых копий стороны, каждая обрезана своей полосой; всё — группой «Вылет зеркалом» поверх
// кромки (на 0,4 мм внутрь). '' — получилось, иначе текст ошибки.
function mirrorBleed(d, items, a, b) {
    try {
        var ov = pt(0.4), B = pt(b), x0 = a[0] + B, x1 = a[2] - B, yT = a[1] - B, yB = a[3] + B, w = x1 - x0, h = yT - yB;
        var L = items[items.length - 1].layer, grp = L.groupItems.add(), base = L.groupItems.add(), k;
        grp.name = 'Вылет зеркалом';
        for (k = items.length - 1; k >= 0; k--) items[k].duplicate(base, ElementPlacement.PLACEATBEGINNING);
        for (k = 0; k < 9; k++) {
            var dx = (k % 3) - 1, dy = Math.floor(k / 3) - 1;
            if (!dx && !dy) continue;
            var cg = grp.groupItems.add(), cp = base.duplicate(cg, ElementPlacement.PLACEATBEGINNING);
            // отражение относительно оси на ov внутри от края: копия встаёт вплотную к краю, зеркально к нему
            var cb = cp.geometricBounds;
            if (dx) { cp.resize(-100, 100, true, true, true, true, 100, Transformation.CENTER); cp.translate(dx * (w - 2 * ov), 0); }
            if (dy) { cp.resize(100, -100, true, true, true, true, 100, Transformation.CENTER); cp.translate(0, -dy * (h - 2 * ov)); }
            var fx0 = dx < 0 ? x0 - B : (dx > 0 ? x1 - ov : x0), fx1 = dx < 0 ? x0 + ov : (dx > 0 ? x1 + B : x1);
            var fyT = dy < 0 ? yT + B : (dy > 0 ? yB + ov : yT), fyB = dy < 0 ? yT - ov : (dy > 0 ? yB - B : yB);
            var fr = cg.pathItems.rectangle(fyT, fx0, fx1 - fx0, fyT - fyB);
            fr.zOrder(ZOrderMethod.BRINGTOFRONT);
            cg.clipped = true;
            fr.clipping = true;
        }
        base.remove();
        grp.zOrder(ZOrderMethod.BRINGTOFRONT);
        return '';
    } catch (e) { return e.message; }
}

// ---------- команды панели ----------

Bridge.TextClean = function (params) {
    prepare();
    var c = parseKV(params), G = function (k) { return (c.hasOwnProperty(k) ? c[k] : '1') == '1'; };
    var o = { Spaces: G('tcSpaces'), Dashes: G('tcDashes'), Quotes: G('tcQuotes'), Hanging: G('tcHang') };
    Settings.set('Tools', 'tcSpaces', o.Spaces ? '1' : '0'); Settings.set('Tools', 'tcDashes', o.Dashes ? '1' : '0');
    Settings.set('Tools', 'tcQuotes', o.Quotes ? '1' : '0'); Settings.set('Tools', 'tcHang', o.Hanging ? '1' : '0');
    return Tools.CleanText(o);
};
Bridge.SameSelect = function (by) { Settings.set('Tools', 'same', by); return Tools.SelectSame(Math.round(toNum(by, 0))); };
Bridge.PickColor = function () { return Tools.ColorOfSelection(); };
Bridge.SwapColor = function (cmyk, what) {
    prepare();
    var a = (cmyk + '|||').split('|');
    return Tools.ReplaceColor(toNum(a[0], 0), toNum(a[1], 0), toNum(a[2], 0), toNum(a[3], 0), Math.round(toNum(what, 0)));
};
Bridge.GuidesRun = function (margin, center, clear) {
    prepare();
    Settings.set('Tools', 'gMargin', margin); Settings.set('Tools', 'gCenter', center);
    return Tools.Guides(toNum(margin, 0), center == '1', clear == '1');
};
Bridge.BleedShape = function (width, mode, cut) {
    if (!PSA.has('WP')) return 'Вылет по форме входит в части «Рулонная печать» и «Плоттерная резка» — их нет в вашем ключе.';
    prepare();
    Settings.set('Tools', 'bleedW', width); Settings.set('Tools', 'bleedMode', mode); Settings.set('Tools', 'bleedCut', cut || '0');
    return Tools.ShapeBleed(toNum(width, 0), Math.round(toNum(mode, 0)), cut == '1');
};
Bridge.SplitSides = function (bleed) {
    prepare();
    Settings.set('Tools', 'splitBleed', bleed);
    return Tools.SplitSides(toNum(bleed, 0));
};
