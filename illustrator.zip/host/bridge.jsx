// Связь панели с Illustrator — как src/Bridge.bas в CorelDRAW: панель зовёт функцию по имени,
// получает ответ строкой (состояние — JSON). Имена и ответы те же, что у макроса CorelDRAW,
// поэтому панель у двух программ общая. Что ещё не перенесено — в Bridge нет, панель так и скажет.

var VERSION = '1.9.2';
var TEMPLATE_PAGE = 'Шаблон стола';
var CODE_TYPES = 'EAN-13|EAN-8|UPC-A|UPC-E|Code 128|GS1-128|Code 39|ITF-14|QR|DataMatrix|Честный знак';

var Bridge = {};

// ---------- документ ----------

function hasDoc() {
    try { return app.documents.length > 0 && !!app.activeDocument; } catch (e) { return false; }
}

// Монтажная область — то, что в CorelDRAW страница
function abRect(ab) { var r = ab.artboardRect; return { l: r[0], t: r[1], r: r[2], b: r[3], w: r[2] - r[0], h: r[1] - r[3] }; }
function activeAb(d) { return d.artboards[d.artboards.getActiveArtboardIndex()]; }

// Образец — все монтажные области не больше 300 мм (одна карта на область);
// раскладка узнаётся и по именам («Лист — …», «Шаблон стола»)
function isSampleDoc(d) {
    for (var i = 0; i < d.artboards.length; i++) {
        var ab = d.artboards[i];
        if (mm(abRect(ab).w) > 300) return false;
        if (ab.name.substring(0, 7) == 'Лист — ' || ab.name == TEMPLATE_PAGE) return false;
    }
    return true;
}

// Вылет по размеру области, если она — ходовой формат плюс одинаковый вылет со всех сторон (как в CorelDRAW)
function insetOfSize(w, h) {
    var sz = [85.6, 54, 90, 50, 85, 55, 90, 55, 210, 297, 148, 210, 105, 148, 99, 210, 100, 210, 100, 70,
              Settings.num('Impose', 'CutW', 85.6), Settings.num('Impose', 'CutH', 54)], i, b;
    for (i = 0; i < sz.length - 3; i += 2)
        if ((Math.abs(w - sz[i]) < 0.06 && Math.abs(h - sz[i + 1]) < 0.06) || (Math.abs(w - sz[i + 1]) < 0.06 && Math.abs(h - sz[i]) < 0.06)) return 0;
    for (i = 0; i < sz.length - 1; i += 2) {
        b = insetFor(w, h, sz[i], sz[i + 1]); if (b > 0) return b;
        b = insetFor(w, h, sz[i + 1], sz[i]); if (b > 0) return b;
    }
    return 0;
}
function insetFor(w, h, cw, ch) {
    if (cw <= 0 || ch <= 0) return 0;
    var a = (w - cw) / 2, b = (h - ch) / 2;
    if (a >= 0.5 && a <= 10 && Math.abs(a - b) < 0.06) return Math.floor((a + b) / 2 * 100 + 0.5) / 100;
    return 0;
}

function layerNames(d) {
    var a = [];
    for (var i = 0; i < d.layers.length; i++) a.push(d.layers[i].name);
    return a;
}
function spotNames(d) {
    var a = [];
    for (var i = 0; i < d.spots.length; i++) {
        var n = d.spots[i].name;
        if (n != '[Registration]' && n != '[Совмещение]') a.push(n);
    }
    return a;
}

// ---------- состояние ----------

// Лёгкий отпечаток документа: панель перечитывает всё, только если он сменился
Bridge.DocKey = function () {
    if (!hasDoc()) return '';
    var d = app.activeDocument, p = '';
    try { p = d.fullName.fsName; } catch (e) { }
    return p + '|' + d.name + '|' + d.artboards.length + '|' + d.artboards.getActiveArtboardIndex() + '|' +
        d.pageItems.length + '|' + d.layers.length;
};

function S(sec, key, dflt) { return Settings.get(sec, key, dflt); }
function SN(sec, key, dflt) { return Settings.num(sec, key, dflt); }


function updState(o) {
    o.ver = VERSION; o.upd = ''; o.updPend = ''; o.updLast = S('Update', 'LastCheck', '');
    return o;
}

Bridge.State = function () {
    if (!hasDoc()) return toJson(updState({ doc: null }));
    prepare();
    Engine.PrepareData();
    var d = app.activeDocument, ab = activeAb(d), r = abRect(ab), sample = isSampleDoc(d), scan = scanFields(d);
    var o = {};
    o.doc = { name: d.name, sample: sample, pages: d.artboards.length, page: ab.name, twoSides: Tools.LooksTwoSided(),
              choke: SN('White', 'Choke', 0.2), chokePct: SN('White', 'ChokePct', 10) };
    o.inks = inksState(d);
    o.fields = fieldsState(scan);
    o.run = runState(scan);

    var b = SN('Impose', 'Bleed', 1), pw, ph, lp = {}, srcPath = '';
    if (sample) {
        // образец: карта по резу = область минус вылет; ходовой формат с одинаковым вылетом — берём этот вылет
        pw = mm(r.w); ph = mm(r.h);
        var ins = insetOfSize(pw, ph);
        if (ins > 0) b = ins;
        pw -= 2 * b; ph -= 2 * b;
    } else {
        // раскладка: параметры, с которыми она сделана
        srcPath = layoutSource(d, lp);
        pw = SN('Impose', 'CutW', 85.6); ph = SN('Impose', 'CutH', 54);
    }
    // метки, шкала, кресты, клапан и пластина в новой работе выключены; раскладка помнит свои
    function I(k, dflt) { return SN('Impose', k, dflt); }
    function LV(k, dflt) { return lp.hasOwnProperty(k) ? toNum(lp[k], dflt) : dflt; }
    o.imp = { sheetW: LV('sheetW', I('SheetW', 900)), sheetH: LV('sheetH', I('SheetH', 600)), cutW: Math.round(LV('cutW', pw) * 100) / 100,
              cutH: Math.round(LV('cutH', ph) * 100) / 100, bleed: LV('bleed', b), radius: LV('radius', I('Radius', 3.18)),
              gapX: LV('gapX', I('GapX', 5)), gapY: LV('gapY', I('GapY', 5)), margin: LV('margin', I('Margin', 5)), mirror: LV('mirror', I('Mirror', 0)) == 1,
              guides: LV('guides', I('Guides', 1)) == 1, markLen: I('MarkLen', 5), markW: I('MarkW', 0.5), markGap: I('MarkGap', 0),
              orient: LV('orient', I('Orient', 0)), alignH: LV('alignH', I('AlignH', 0)), alignV: LV('alignV', I('AlignV', 1)),
              marginSides: LV('marginSides', I('MarginSides', 0)) == 1, regMarks: LV('regMarks', 0) == 1, colorBar: LV('colorBar', 0) == 1,
              sheetInfo: LV('sheetInfo', 0) == 1, gripper: LV('gripper', I('Gripper', 10)), gripperSide: LV('gripperSide', 0),
              marginL: LV('marginL', I('MarginL', 5)), marginR: LV('marginR', I('MarginR', 5)), marginT: LV('marginT', I('MarginT', 5)), marginB: LV('marginB', I('MarginB', 5)),
              cutMarks: LV('cutMarks', 0) == 1, cutLen: LV('cutLen', I('CutLen', 5)), cutOff: LV('cutOff', I('CutOff', 3)), cutLine: LV('cutLine', I('CutWidth', 0.1)),
              workTurn: LV('workTurn', 0) == 1, wtMode: LV('wtMode', 1), wtCal: LV('wtCal', 0) == 1, backDX: LV('backDX', I('BackDX', 0)), backDY: LV('backDY', I('BackDY', 0)),
              plate: LV('plate', 0) == 1, plateW: LV('plateW', I('PlateW', 745)), plateH: LV('plateH', I('PlateH', 605)), klapan: LV('klapan', I('Klapan', 60)),
              plateCenter: LV('plateCenter', I('PlateCenter', 0)) == 1, plateStyle: LV('plateStyle', I('PlateStyle', 1)), plateStrip: LV('plateStrip', I('PlateStrip', 1)) == 1,
              src: srcPath.replace(/^.*[\\\/]/, '') };
    o.roll = { w: SN('Roll', 'Width', 1370), side: SN('Roll', 'Side', 15), qty: SN('Roll', 'Qty', 100), cut: SN('Roll', 'CutMode', 1),
               marks: SN('Roll', 'Marks', 0), msize: SN('Roll', 'MarkSize', 3), mgap: SN('Roll', 'MarkGap', 10) };
    o.tools = { tcSpaces: S('Tools', 'tcSpaces', '1') == '1', tcDashes: S('Tools', 'tcDashes', '1') == '1', tcQuotes: S('Tools', 'tcQuotes', '1') == '1',
                tcHang: S('Tools', 'tcHang', '1') == '1', same: S('Tools', 'same', '0'), gMargin: S('Tools', 'gMargin', '5'),
                gCenter: S('Tools', 'gCenter', '0'), bleedW: S('Tools', 'bleedW', '3'), bleedMode: S('Tools', 'bleedMode', '1') };
    o.nestRes = false; o.nestQty = '';
    try { o.nestRes = Nest.isResult(d); o.nestQty = Nest.storedQty(d); } catch (e) { }
    o.askOut = S('Out', 'Ask', '0') == '1';
    o.cal = S('Calendar', 'Params', ''); o.laser = S('Laser', 'Params', ''); o.letters = S('Letters', 'Params', ''); o.cost = S('Cost', 'Params', '');
    o.nest = { w: SN('Nest', 'W', 1370), h: SN('Nest', 'H', 0), margin: SN('Nest', 'Margin', 10), gap: SN('Nest', 'Gap', 3), rot: SN('Nest', 'Rot', 4),
               qual: S('Nest', 'Qual', 'good'), more: S('Nest', 'More', '1') == '1', mirror: S('Nest', 'Mirror', '0') == '1',
               dxf: S('Nest', 'Dxf', '0') == '1', inHoles: S('Nest', 'InHoles', '1') == '1', speed: SN('Nest', 'Speed', 0), busy: (function () { try { return Nest.busy(); } catch (e) { return false; } })(),
               qty: S('Nest', 'Qty', '') };
    o.eye = { hole: SN('Eyelets', 'Hole', 11), edge: SN('Eyelets', 'Edge', 25), step: SN('Eyelets', 'Step', 500), sides: SN('Eyelets', 'Sides', 0),
              hem: SN('Eyelets', 'Hem', 0), target: SN('Eyelets', 'Target', 0), print: SN('Eyelets', 'Print', 0) == 1 };
    o.book = { bleed: S('Booklet', 'Bleed', '2'), creep: S('Booklet', 'Creep', '0.1'), pages: d.artboards.length };
    o.gangQty = S('Gang', 'Qty', '');
    o.pf = { profile: S('Preflight', 'Profile', 'offset'), bleed: S('Preflight', 'Bleed', ''), safe: S('Preflight', 'Safe', '') };
    o.codeTypes = CODE_TYPES;
    o.repAuto = false;
    return toJson(updState(o));
};

Bridge.LogLine = function (t) { logLine(t); return ''; };
// Для «Перезапустить и обновить»: имена несохранённых документов через запятую ('' — всё сохранено)
Bridge.UnsavedDocs = function () {
    var a = [];
    for (var i = 0; i < app.documents.length; i++) if (!app.documents[i].saved) a.push('«' + app.documents[i].name + '»');
    return a.join(', ');
};
// Фото к сообщению о проблеме: окно выбора файла Illustrator; '' — отказались
Bridge.PickPhoto = function () {
    var f = File.openDialog('Фото для разработчика', 'Картинки:*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tif;*.tiff,Все файлы:*.*', false);
    return f ? f.fsName : '';
};
// Для отчёта о проблеме: Illustrator, открытые документы, активная область и её слои
Bridge.ReportInfo = function () {
    var t = 'Illustrator: ' + app.version + '\r\n\r\n--- Открытые документы ---\r\n', i;
    try {
        var ad = hasDoc() ? app.activeDocument : null;
        for (i = 0; i < app.documents.length; i++) {
            var d = app.documents[i], p = '';
            try { p = d.fullName.fsName; } catch (e) { }
            t += d.name + (d == ad ? '  [активный]' : '') + (d.saved ? '' : '  [не сохранён]') + ', областей ' + d.artboards.length + ', ' + p + '\r\n';
        }
        if (ad) {
            var k = ad.artboards.getActiveArtboardIndex(), r = abRect(ad.artboards[k]);
            t += 'Активная область «' + ad.artboards[k].name + '» ' + f1(mm(r.w)) + ' × ' + f1(mm(r.h)) + ' мм, выделено объектов: ' + selectionItems(ad).length + '\r\n';
            for (i = 0; i < ad.layers.length; i++) { var L = ad.layers[i]; t += '   слой «' + L.name + '»: ' + L.pageItems.length + (L.printable ? '' : ' (не печатается)') + (L.visible ? '' : ' (скрыт)') + '\r\n'; }
        }
    } catch (e) { t += 'сведения не собрались: ' + e.message + '\r\n'; }
    return t;
};

// ---------- поля ----------

var FREE_NUMBERS = 50;
function prepare() { Engine.LoadConfig(); }

// Сводка для списка полей: сколько значений, первое и последнее, что не так
function fieldSummary(f) {
    var n = 0, a = '', z = '', e = '';
    if (f.Kind == 'pic') return { count: 0, first: '', last: '', err: '' };
    if (f.Source == 0) {
        n = f.Count();
        if (f.HasEnd && n <= 0) e = 'диапазон пустой: проверьте «с», «по» и шаг';
    } else if (f.FilePath == '') e = 'не выбран файл клиента';
    else if (!f.Loaded) e = 'файл не прочитан';
    else { n = f.ValuesCount; if (n == 0) e = 'в выбранном столбце нет значений'; }
    if (e == '') { a = f.ValueAt(0); if (n > 0) z = f.ValueAt(n - 1); }
    return { count: n, first: a.replace(/\u001d/g, '<GS>'), last: z.replace(/\u001d/g, '<GS>'), err: e };
}

function fieldsState(scan) {
    var out = [];
    for (var i = 0; i < Engine.Fields.length; i++) {
        var f = Engine.Fields[i], s = fieldSummary(f);
        out.push({ id: f.Id, kind: f.Kind, kindName: f.KindName(), places: Engine.FieldPlaces(f.Id, scan), sourceName: f.SourceName(),
                   source: f.Source, numStart: f.NumStart, hasEnd: f.HasEnd, numEnd: f.NumEnd, numStep: f.NumStep, numDigits: f.NumDigits,
                   prefix: f.Prefix, suffix: f.Suffix, filePath: f.FilePath, column: f.Column,
                   firstRow: f.FirstRow > 1 ? f.FirstRow : (f.HasHeader ? 2 : 1), mask: f.Mask, template: f.Template, codeType: f.CodeType,
                   showText: f.ShowText, quiet: f.Quiet, rotation: f.Rotation, ecc: f.Ecc, picFolder: f.PicFolder, picFit: f.PicFit,
                   count: s.count, first: s.first, last: s.last, err: s.err });
    }
    return out;
}

function runState(scan) {
    var why = {}, total = Engine.TotalSheets(why, scan);
    return { sheetsAuto: Engine.SheetsAuto, sheetsCount: Engine.SheetsCount, orderStack: Engine.OrderStack, startRecord: Engine.StartRecord,
             pdfOneFile: Engine.PdfOneFile, tiffDpi: Engine.TiffDpi, tiffRotate: 0, sides: Engine.Sides, sideFolders: Engine.SideFolders,
             total: total, why: why.why, places: Engine.MaxPlaces(scan), records: Engine.DataEnd, client: Engine.Client,
             clientAuto: hasDoc() ? app.activeDocument.name.replace(/\.[^.]*$/, '') : '', register: Engine.Register };
}

function freeWhy(what) {
    return what + ' — только с ключом. Без ключа можно одно поле с номером по порядку, до ' + FREE_NUMBERS + ' номеров в заказе. ' + require_('D');
}
// Как License.Require: '' — можно; иначе почему нельзя
function require_(m) {
    if (PSA.has(m)) return '';
    return 'Эта функция входит в часть «Нумерация и данные» — её нет в вашем ключе, а пробный период закончился. Напишите за ключом: ' +
           '+998 90 328-47-04 · Telegram @iMexx · mexx.gm@gmail.com.';
}
// Без ключа — одно текстовое поле с нумерацией и не больше FREE_NUMBERS номеров
function freeData(scan) {
    if (PSA.has('D')) return '';
    if (Engine.Fields.length > 1) return freeWhy('Больше одного поля на карте');
    for (var i = 0; i < Engine.Fields.length; i++) {
        var f = Engine.Fields[i];
        if (f.Kind != 'text') return freeWhy('Штрихкод, QR и картинки на каждой карте');
        if (f.Source != 0) return freeWhy('Номера из файла клиента');
        var n = f.HasEnd ? f.Count() : -1;
        if (!f.HasEnd) { var t = Engine.TotalSheets({}, scan); n = t > 0 ? t * Math.max(1, Engine.FieldPlaces(f.Id, scan)) : -1; }
        if (n < 0 || n > FREE_NUMBERS) return freeWhy('Больше ' + FREE_NUMBERS + ' номеров в заказе' + (n > 0 ? ' (в этом — ' + n + ')' : ''));
    }
    return '';
}

Bridge.AddField = function (kind) {
    prepare();
    if (!hasDoc()) return 'Нет открытого документа.';
    if (!PSA.has('D')) {
        if (kind != 'text') return freeWhy('Штрихкод, QR и картинки на каждой карте');
        if (Engine.Fields.length >= 1) return freeWhy('Второе поле на карте');
    }
    return Engine.AddFieldFromSelection(kind);
};

Bridge.RemoveField = function (id) {
    prepare();
    if (!confirm('Удалить поле № ' + id + '? Объекты на листе останутся, но заполняться не будут.', true, 'PS • Автоматизация')) return '';
    Engine.RemoveField(+id);
    return 'ok';
};

Bridge.ShowField = function (id) {
    prepare();
    var d = app.activeDocument, list = Engine.FieldShapes(+id);
    d.selection = null;
    for (var i = 0; i < list.length; i++) list[i].selected = true;
    return '';
};

Bridge.SetField = function (id, key, value) {
    prepare();
    var f = Engine.FieldById(+id);
    if (!f) return '';
    if (!PSA.has('D') && ((key == 'source' && String(value).replace(/\s/g, '') != '0') || (key == 'filePath' && String(value).replace(/\s/g, '') != '')))
        return freeWhy('Номера из файла клиента');
    var v = String(value), tr = v.replace(/^\s+|\s+$/g, '');
    switch (key) {
        case 'source': f.Source = parseInt(v, 10) || 0; break;
        case 'numStart': f.NumStart = toNum(v, 1); break;
        case 'numEnd': f.HasEnd = tr != ''; if (f.HasEnd) f.NumEnd = toNum(v, 0); break;
        case 'numStep': f.NumStep = toNum(v, 1); break;
        case 'numDigits': f.NumDigits = Math.round(toNum(v, 0)); break;
        case 'prefix': f.Prefix = v; break;
        case 'suffix': f.Suffix = v; break;
        case 'filePath': f.FilePath = tr; break;
        case 'column': f.Column = Math.max(1, Math.round(toNum(v, 1))); break;
        case 'firstRow': f.FirstRow = Math.max(1, Math.round(toNum(v, 1))); f.HasHeader = false; break;
        case 'mask': f.Mask = v; break;
        case 'template': f.Template = tr; break;
        case 'codeType': f.CodeType = v; break;
        case 'showText': f.ShowText = v == '1'; break;
        case 'quiet': f.Quiet = v == '1'; break;
        case 'rotation': f.Rotation = parseInt(v, 10) || 0; break;
        case 'ecc': f.Ecc = v; break;
        case 'picFolder': f.PicFolder = tr; break;
        case 'picFit': f.PicFit = parseInt(v, 10) || 0; break;
    }
    f.Loaded = false;
    Engine.SaveConfig();
    return 'ok';
};

Bridge.SetRun = function (key, value) {
    prepare();
    var v = String(value);
    switch (key) {
        case 'sheetsAuto': Engine.SheetsAuto = v == '1'; break;
        case 'sheetsCount': Engine.SheetsCount = Math.max(1, Math.round(toNum(v, 1))); Engine.SheetsAuto = false; break;
        case 'orderStack': Engine.OrderStack = v == '1'; break;
        case 'startRecord': Engine.StartRecord = Math.max(1, Math.round(toNum(v, 1))); break;
        case 'pdfOneFile': Engine.PdfOneFile = v == '1'; break;
        case 'sides': Engine.Sides = Math.round(toNum(v, 0)); break;
        case 'sideFolders': Engine.SideFolders = v == '1'; break;
        case 'tiffDpi': Engine.TiffDpi = Math.max(72, Math.round(toNum(v, 300))); break;
        case 'client': Engine.Client = v.replace(/^\s+|\s+$/g, ''); break;
        case 'register': Engine.Register = v == '1'; break;
        // проба (пробный лист или галочка «Проба» у всего заказа): номера в журнал заказчика не пишутся
    }
    Engine.SaveConfig();
    return 'ok';
};

// Строка «что будет выведено» для выбранного диапазона
Bridge.Plan = function (a, b) {
    prepare();
    if (!hasDoc()) return '';
    Engine.PrepareData();
    var d = app.activeDocument, scan = scanFields(d);
    if (!Engine.Fields.length) return 'Без номеров: страницы документа (' + sidePages(d) + ') выводятся как есть.';
    var why = {}, total = Engine.TotalSheets(why, scan);
    if (total == 0) return 'Число листов не определить: ' + why.why + '.';
    var x = Math.round(toNum(a, 1)), y = Math.round(toNum(b, 0));
    if (y == 0) y = total;
    if (x < 1) x = 1;
    if (y < x) y = x;
    if (y > total) y = total;
    if (x > total) return 'Листа ' + x + ' нет: всего листов ' + total + '.';
    var n = y - x + 1, k = Engine.MaxPlaces(scan);
    if (n == 1) {
        if (Engine.OrderStack) return '1 лист — № ' + x + ' (порядок «стопкой»).';
        var r1 = Engine.RecordIndex(x - 1, 0, k, total) + 1, r2 = r1 + k - 1;
        if (Engine.DataEnd > 0 && r2 > Engine.DataEnd) r2 = Engine.DataEnd;
        return '1 лист — № ' + x + ', записи ' + r1 + '–' + r2 + '.';
    }
    return 'Листов: ' + n + ' (№ ' + x + '–' + y + ').';
};


// Куда выводить: один PDF — файл, по листу — папка
function pickOut(mode) {
    if (mode == 'tiff') {
        // папка запоминается в файле: сделанный на другом компьютере файл может помнить чужую папку
        var tf = (Engine.TiffFolder && new Folder(Engine.TiffFolder).exists ? new Folder(Engine.TiffFolder) : Folder.myDocuments).selectDlg('Папка для TIFF');
        if (!tf) return false;
        Engine.TiffFolder = tf.fsName;
        return true;
    }
    if (mode != 'pdf') return true;
    var d = app.activeDocument, p;
    if (Engine.PdfOneFile) {
        var nm = d.name.replace(/\.[^.]*$/, ''), dir = '';
        try { dir = d.fullName.parent.fsName; } catch (e) { }
        if (!d.saved && !dir) nm = 'листы';
        var start = new File((Engine.PdfPath ? new File(Engine.PdfPath).parent.fsName : dir || Folder.myDocuments.fsName) + '/' + nm + '.pdf');
        var f = start.saveDlg('Сохранить PDF', 'PDF:*.pdf');
        if (!f) return false;
        p = f.fsName;
        if (!/\.pdf$/i.test(p)) p += '.pdf';
    } else {
        var fo = (Engine.PdfPath ? new Folder(Engine.PdfPath) : Folder.myDocuments).selectDlg('Папка для PDF (по файлу на лист)');
        if (!fo) return false;
        p = fo.fsName;
    }
    Engine.PdfPath = p;
    return true;
}

// Быстрый вывод идёт из копии файла — для неё файл должен быть сохранён. Сохраняется молча: чаще всего
// «изменения» — номера, подставленные для показа, а при выводе номера подставляются заново.
// Без сохранения каждый лист переносился бы в новый документ — минуты на лист.
function saveForOutput() {
    var d = app.activeDocument, path = '';
    try { path = d.fullName.fsName; } catch (e) { }
    var named = path && /\.ai$/i.test(path) && new File(path).exists;
    if (d.saved && named) return;
    if (named) d.save();
    else alert('Документ не сохранён в файл Illustrator — вывод пойдёт медленно (минуты на лист). Быстрее — сохранить его (Файл — Сохранить как, .ai) и вывести снова.', 'Вывод');
}

// mode: preview, pdf. a, b — листы (b = 0 — до последнего).
Bridge.Run = function (mode, a, b) {
    prepare();
    if (!hasDoc()) return 'Нет открытого документа.';
    if (mode == 'tiff' && !PSA.has('UW')) return 'Вывод в TIFF входит в части «УФ-планшет» и «Рулонная печать» — их нет в вашем ключе.';
    if (!Engine.Fields.length && mode == 'preview') return 'Сначала добавьте поля на шаге «Номера».';
    var d = app.activeDocument, scan = scanFields(d);
    if (isSampleDoc(d) && mode != 'preview' && Engine.Fields.length)
        if (!confirm('Сейчас открыт образец — одна карта, а не раскладка на лист. Всё равно выводить?', true, 'PS • Автоматизация')) return '';
    Engine.PrepareData();
    var why = {}, total = Engine.TotalSheets(why, scan);
    var e = freeData(scan);
    if (e) return e;
    if (total == 0 && mode != 'preview') return 'Число листов не определить: ' + why.why + '.';
    var x = Math.round(toNum(a, 1)), y = Math.round(toNum(b, 0));
    if (total == 0) total = 1;
    if (y == 0) y = total;
    if (x < 1) x = 1;
    if (y < x) y = x;
    if (y > total) y = total;
    if (x > total) return 'Листа ' + x + ' нет: всего листов ' + total + '.';
    var n = y - x + 1;
    if (mode == 'preview') y = x;
    else if (n > 1 && !confirm('Будет выведено листов: ' + n + ' (№ ' + x + '–' + y + ').\r\nВсё это время Illustrator будет занят.\r\n\r\nПробный лист уже проверен?', false, 'Вывод ' + n + ' листов')) return '';
    if (mode != 'preview') {
        // журнал: эти номера уже печатались для заказчика другим файлом?
        var ex = {}, ov = Records.JournalOverlap(x, y, total, ex, scan);
        if (ov > 0 && !confirm('Номеров, которые уже выпускались для «' + Records.ClientName() + '»: ' + ov + '.' + ex.text + (ov > 5 ? '\r\n  …' : '') +
            '\r\n\r\nНомера на картах не должны повторяться. Всё равно выводить?', true, 'Повтор номеров')) return '';
    }
    if (mode != 'preview' && !PSA.quiet) {
        var miss = missingFonts(d);
        if (miss.length && !confirm('В макете шрифты, которых нет в Illustrator: ' + miss.join(', ') + '.\r\n\r\n' +
            'Illustrator подставит похожий — номера и текст выйдут другим шрифтом, чем в макете. ' +
            'Лучше установить шрифт и вывести снова.\r\n\r\nВсё равно выводить?', true, 'Нет шрифта')) return '';
    }
    if (!pickOut(mode)) return '';
    Engine.SaveConfig();
    if (mode != 'preview') saveForOutput();
    return Engine.RunJob(mode, x, y);
};

// Шрифты текста макета, которых нет среди шрифтов Illustrator (установленных и подключённых Adobe Fonts)
function missingFonts(d) {
    var seen = {}, out = [], n = Math.min(d.textFrames.length, 3000);
    for (var i = 0; i < n; i++) {
        var f = null;
        try { f = d.textFrames[i].textRange.characterAttributes.textFont; } catch (e) { f = null; }
        if (!f || seen[f.name]) continue;
        seen[f.name] = 1;
        try { app.textFonts.getByName(f.name); } catch (e) { out.push(f.family ? f.family + (f.style ? ' ' + f.style : '') : f.name); }
    }
    return out;
}
