// Рисование кодов и картинок в рамке — как src/Draw.bas. Рамка — прямоугольник документа
// [лево, верх, право, низ] в пунктах (ось y вверх). Ответ — { item } или { error }.

var Draw = {};

Draw.is2D = function (t) { return t == 'QR' || t == 'DataMatrix' || t == 'Честный знак'; };

function blackFill() { var c = new CMYKColor(); c.cyan = 0; c.magenta = 0; c.yellow = 0; c.black = 100; return c; }

// Составной контур из прямоугольников [x0, y0, x1, y1] — одна фигура на весь код
function rectsPath(cont, rects) {
    var cp = cont.compoundPathItems.add();
    for (var i = 0; i < rects.length; i++) {
        var r = rects[i], p = cp.pathItems.add();
        p.setEntirePath([[r[0], r[1]], [r[2], r[1]], [r[2], r[3]], [r[0], r[3]]]);
        p.closed = true;
    }
    var k = blackFill();
    for (i = 0; i < cp.pathItems.length; i++) { cp.pathItems[i].filled = true; cp.pathItems[i].fillColor = k; cp.pathItems[i].stroked = false; }
    return cp;
}

// Код в рамке b. rotation — по часовой, градусы (0, 90, 180, 270)
Draw.code = function (cont, b, type, value, showText, rotation, quiet, ecc) {
    var w = b[2] - b[0], h = b[1] - b[3], cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2, bw = w, bh = h, r;
    if (rotation == 90 || rotation == 270) { bw = h; bh = w; }
    var g = cont.groupItems.add();
    r = this.is2D(type) ? this.draw2D(g, cx - bw / 2, cy - bh / 2, bw, bh, type, value, quiet, ecc)
                        : this.draw1D(g, cx - bw / 2, cy - bh / 2, bw, bh, type, value, showText, quiet);
    if (r) { g.remove(); return { error: r }; }
    if (rotation) rotateAbout(g, -rotation, cx, cy);
    return { item: g };
};

// x, y — левый нижний угол рамки (пункты)
Draw.draw1D = function (g, x, y, w, h, type, value, showText, quiet) {
    var r = Bar1D.encode(type, value), n, qL = 0, qR = 0, i;
    if (r.error) return r.error;
    n = r.modules.length;
    if (quiet) { qL = r.quietL; qR = r.quietR; }
    else if (showText && r.guard) {
        // без полей всё равно оставляем место под вынесенные цифры EAN/UPC
        var minX = 0, maxX = n;
        for (i = 0; i < r.labels.length; i++) { minX = Math.min(minX, r.labels[i].cx - 3.5); maxX = Math.max(maxX, r.labels[i].cx + 3.5); }
        qL = -minX; qR = maxX - n;
    }
    var mw = w / (n + qL + qR), fontH = 0, textZone = 0, bearer = 0, guardExt = 0;
    if (showText) { fontH = Math.min(mw * 8, h * 0.22); textZone = fontH * 1.35; }
    if (r.bearer) bearer = mw * 3;
    var barBottom = y + textZone, barTop = y + h - bearer, rects = [];
    if (r.guard && showText) guardExt = fontH * 0.65;
    for (i = 0; i < n; i++) {
        if (r.modules.charAt(i) != '1') continue;
        var a = i;
        while (i + 1 < n && r.modules.charAt(i + 1) == '1') i++;
        var isGuard = r.guard && r.guard.charAt(a) == '1';
        rects.push([x + (qL + a) * mw, barTop, x + (qL + i + 1) * mw, isGuard ? barBottom - guardExt : barBottom]);
    }
    if (r.bearer) { rects.push([x, barBottom, x + w, barBottom - bearer]); rects.push([x, barTop + bearer, x + w, barTop]); }
    rectsPath(g, rects);
    if (showText) for (i = 0; i < r.labels.length; i++) {
        var t = g.textFrames.pointText([0, 0]);
        t.contents = r.labels[i].text;
        var ca = t.textRange.characterAttributes;
        try { ca.textFont = app.textFonts.getByName('ArialMT'); } catch (e) { }
        ca.size = fontH / 0.716;
        ca.fillColor = blackFill();
        var gb = t.geometricBounds;
        if (!r.guard) {
            // одна подпись по центру — не шире кода
            var maxW = w * 0.96, tw = gb[2] - gb[0];
            if (tw > maxW) { t.resize(maxW / tw * 100, maxW / tw * 100); gb = t.geometricBounds; }
        }
        var lx = x + (qL + r.labels[i].cx) * mw, by = y + (textZone - fontH) * 0.35;
        t.translate(lx - (gb[0] + gb[2]) / 2, by - gb[3]);
    }
    return '';
};

Draw.draw2D = function (g, x, y, w, h, type, value, quiet, ecc) {
    var r, q;
    if (type == 'QR') { r = QR.encode(value, ecc); q = 4; }
    else if (type == 'Честный знак') { r = DM.encode(DM.normalizeGS1(value), true); q = 1; }
    else { r = DM.encode(value, false); q = 1; }
    if (r.error) return r.error;
    if (!quiet) q = 0;
    var n = r.n, m = r.m, side = Math.min(w, h), mw = side / (n + 2 * q);
    var x0 = x + (w - side) / 2 + q * mw, y0 = y + (h - side) / 2 + side - q * mw, rects = [];   // y0 — верх матрицы
    for (var row = 0; row < n; row++) for (var col = 0; col < n; col++) {
        if (m[row][col] != 1) continue;
        var a = col;
        while (col + 1 < n && m[row][col + 1] == 1) col++;
        rects.push([x0 + a * mw, y0 - row * mw, x0 + (col + 1) * mw, y0 - (row + 1) * mw]);
    }
    rectsPath(g, rects);
    return '';
};

// Картинка из файла в рамку: fit 0 — пропорционально, 1 — растянуть
Draw.picture = function (cont, b, file, fit) {
    try {
        var p = cont.placedItems.add();
        p.file = new File(file);
        var w = b[2] - b[0], h = b[1] - b[3], iw = p.width, ih = p.height, sx, sy;
        if (fit == 1) { sx = w / iw; sy = h / ih; } else { sx = sy = Math.min(w / iw, h / ih); }
        p.resize(sx * 100, sy * 100);
        var gb = p.geometricBounds;
        p.translate((b[0] + b[2]) / 2 - (gb[0] + gb[2]) / 2, (b[1] + b[3]) / 2 - (gb[1] + gb[3]) / 2);
        return { item: p };
    } catch (e) { return { error: 'картинка ' + file + ': ' + e.message }; }
};

// Файл картинки по значению: полный путь или имя в папке, с расширением или без
function findPicture(folder, name) {
    var p = /^[a-z]:\\|^\\\\/i.test(name) ? name : (folder ? folder.replace(/[\\\/]$/, '') + '\\' : '') + name;
    if (/\.[^.\\\/]+$/.test(p) && new File(p).exists) return p;
    var ext = ['.png', '.jpg', '.jpeg', '.tif', '.tiff', '.bmp', '.gif', '.psd', '.ai', '.eps', '.pdf', '.svg'];
    for (var i = 0; i < ext.length; i++) if (new File(p + ext[i]).exists) return p + ext[i];
    return '';
}
