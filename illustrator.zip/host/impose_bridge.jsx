// Команды панели для раскладки — как ImposeInfo, ImposeRun, ImposeSelection, TemplateRun, SelInfo в src/Bridge.bas

// Куда сохранять: запомненный файл (если не «спрашивать каждый раз») или спросить. '' — отказались.
function outKey(kind) { var s = ''; try { s = app.activeDocument.fullName.fsName.toLowerCase(); } catch (e) { } return kind + '|' + s; }
function outPath(kind, title, defName, folder) {
    var f = '';
    if (S('Out', 'Ask', '0') != '1') { f = Settings.get('Out', outKey(kind), ''); if (f && !new File(f).exists) f = ''; }
    if (!f) {
        var start = new File((folder || Folder.myDocuments.fsName) + '/' + defName), r = start.saveDlg(title, 'Illustrator:*.ai');
        if (!r) return '';
        f = r.fsName;
        if (!/\.ai$/i.test(f)) f += '.ai';
    }
    var cur = '';
    try { cur = app.activeDocument.fullName.fsName; } catch (e) { }
    if (f.toLowerCase() == cur.toLowerCase()) { alert('Нельзя сохранить поверх исходного файла. Выберите другое имя.', 'Куда сохранять'); return ''; }
    // прошлый файл открыт — закрыть, чтобы записать заново (с правками — спросить)
    for (var i = app.documents.length - 1; i >= 0; i--) {
        var d = app.documents[i], p = '';
        try { p = d.fullName.fsName; } catch (e) { }
        if (p.toLowerCase() != f.toLowerCase()) continue;
        if (!d.saved && !confirm('В файле «' + d.name + '» есть несохранённые правки — они пропадут, он заменится новой раскладкой.\r\n\r\nЗаменить?', true, 'Заменить файл')) return '';
        d.close(SaveOptions.DONOTSAVECHANGES);
    }
    Settings.set('Out', outKey(kind), f);
    return f;
}

Bridge.SetAskOut = function (v) { Settings.set('Out', 'Ask', v == '1' ? '1' : '0'); return ''; };

// Параметры, с которыми сделана открытая раскладка (в lp), и путь её образца; '' — не найден
function layoutSource(d, lp) {
    var s = docProp(d, 'layout'), path = '';
    if (s) { var c = parseKV(s); for (var k in c) if (c.hasOwnProperty(k)) lp[k] = c[k]; path = c.src || ''; }
    else { try { path = d.fullName.fsName; var k2 = path.indexOf(' — раскладка'); path = k2 > 0 ? path.substring(0, k2) + '.ai' : ''; } catch (e) { path = ''; } }
    if (path && !new File(path).exists) path = '';
    return path;
}

function saveImposeSettings(p) {
    var I = function (k, v) { Settings.set('Impose', k, v === true ? '1' : (v === false ? '0' : v)); };
    I('SheetW', p.SheetW); I('SheetH', p.SheetH); I('Bleed', p.Bleed); I('Radius', p.Radius); I('GapX', p.GapX); I('GapY', p.GapY); I('Margin', p.Margin);
    I('Mirror', p.MirrorBack); I('Guides', p.Guides); I('Orient', p.Orient); I('AlignH', p.AlignH); I('AlignV', p.AlignV);
    I('MarginL', p.MarginL); I('MarginR', p.MarginR); I('MarginT', p.MarginT); I('MarginB', p.MarginB); I('CutMarks', p.CutMarks);
    I('CutLen', p.CutLen); I('CutOff', p.CutOff); I('CutWidth', p.CutLineW); I('MarginSides', p.MarginsOn); I('RegMarks', p.RegMarks);
    I('ColorBar', p.ColorBar); I('SheetInfo', p.SheetInfo); I('GripperSide', p.GripperSide); if (p.Gripper > 0) I('Gripper', p.Gripper);
    I('Plate', p.PlateOn); I('PlateW', p.PlateW); I('PlateH', p.PlateH); I('Klapan', p.Klapan); I('PlateCenter', p.PlateCenter);
    I('PlateStyle', p.PlateStyle); I('PlateStrip', !p.PlateNoStrip); I('BackDX', p.BackDX); I('BackDY', p.BackDY);
}

Bridge.ImposeInfo = function (params) {
    var p = Impose.ParamsFrom(params), f = Impose.Fit(p), o = Impose.Origin(p, f.cols, f.rows);
    var s = f.cols + '|' + f.rows + '|' + (p.Rotated ? '1' : '0') + '|' + Math.round(o.x * 100) / 100 + '|' + Math.round(o.y * 100) / 100 + '|' + Impose.Describe(p);
    prepare();
    if (f.cols * f.rows > 0 && hasDoc()) {
        var recs = 0;
        for (var i = 0; i < Engine.Fields.length; i++) { var fl = Engine.Fields[i]; if (fl.Source == 1) DataIO.LoadField(fl); if (fl.Count() > recs) recs = fl.Count(); }
        if (recs > 0) s += ' На ' + recs + ' записей нужно листов: ' + Math.ceil(recs / (f.cols * f.rows)) + '.';
    }
    return s;
};

// Раскладка с офсетными метками — часть «Офсет»
function needOffset(p) { return p.PlateOn || p.RegMarks || p.ColorBar || p.SheetInfo || p.WorkTurn || p.Gripper > 0 ? 'O' : ''; }

Bridge.ImposeRun = function (params) {
    var p = Impose.ParamsFrom(params), need = needOffset(p);
    if (need && !PSA.has(need)) return 'Офсетные метки, пластина и свой оборот входят в часть «Офсет» — её нет в вашем ключе.';
    prepare();
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument, oldLay = null, sample = null, openedHere = false, defName = '';
    if (!isSampleDoc(d)) {
        // переразложить: берём образец этой раскладки
        oldLay = d;
        var lp = {}, srcPath = layoutSource(d, lp);
        if (!srcPath) {
            alert('Не нашёл образец карты, из которого сделана эта раскладка. Выберите его.', 'Переразложить');
            var pick = File.openDialog('Образец карты для раскладки', 'Illustrator:*.ai', false);
            if (!pick) return '';
            srcPath = pick.fsName;
        }
        for (var i = 0; i < app.documents.length; i++) { try { if (app.documents[i].fullName.fsName.toLowerCase() == srcPath.toLowerCase()) sample = app.documents[i]; } catch (e) { } }
        if (!sample) { sample = app.open(new File(srcPath)); openedHere = true; }
        if (!isSampleDoc(sample)) {
            if (openedHere) sample.close(SaveOptions.DONOTSAVECHANGES);
            oldLay.activate();
            return '«' + srcPath.replace(/^.*[\\\/]/, '') + '» — не образец карты (монтажная область больше 300 мм).';
        }
        // настройки полей могли поменять уже в раскладке — переносим их в образец
        var cfg = docProp(oldLay, 'config');
        sample.activate();
        if (cfg) setDocProp(sample, 'config', cfg);
        prepare();
        try { defName = oldLay.fullName.fsName; } catch (e) { }
        d = sample;
    }
    var path = '';
    try { path = d.fullName.fsName; } catch (e) { }
    if (!path || path.indexOf('\\') < 0) return 'Сначала сохраните образец в файл.';
    p = Impose.ParamsFrom(params);
    saveImposeSettings(p);
    Settings.set('Impose', 'CutW', p.CutW); Settings.set('Impose', 'CutH', p.CutH);
    Engine.SaveConfig();
    if (!d.saved) d.save();
    var base = path.replace(/\.[^.\\\/]*$/, '');
    if (!defName) defName = base + ' — раскладка.ai';
    var f = outPath('impose', oldLay ? 'Сохранить новую раскладку (можно поверх старой)' : 'Сохранить раскладку', defName.replace(/^.*[\\\/]/, ''), defName.replace(/[\\\/][^\\\/]*$/, ''));
    if (!f) { if (oldLay) try { oldLay.activate(); } catch (e) { } return ''; }
    p.InfoText = f.replace(/^.*[\\\/]/, '');
    if (p.WorkTurn) {
        if (Engine.Fields.length) return 'Свой оборот не подходит для номеров и данных: на двух половинах листа они повторятся. Снимите галочку «Свой оборот».';
        if (sidePages(d) != 2) return 'Для своего оборота в образце нужны две монтажные области: лицо и оборот.';
    }
    var res = Impose.Run(p, f);
    if (openedHere && sample.saved) try { sample.close(SaveOptions.DONOTSAVECHANGES); } catch (e) { }
    if (!PSA.quiet) alert(res.substring(0, 6) == 'Готово' ? 'Раскладка готова и открыта в новой вкладке.\r\n\r\n' + res.substring(8) : res, 'Раскладка');
    return res;
};

Bridge.ImposeSelection = function (params) {
    prepare();
    var p = Impose.ParamsFrom(params);
    saveImposeSettings(p);
    if (!hasDoc()) return 'Нет открытого документа.';
    var d = app.activeDocument, base = 'Макет', folder = '';
    try { folder = d.fullName.parent.fsName; base = d.name.replace(/\.[^.]*$/, ''); } catch (e) { }
    var f = outPath('sel', 'Сохранить раскладку выделенного', base + ' — раскладка.ai', folder);
    if (!f) return '';
    p.InfoText = f.replace(/^.*[\\\/]/, '');
    var res = Impose.RunSelection(p, f);
    if (!PSA.quiet) alert(res.substring(0, 6) == 'Готово' ? 'Раскладка готова и открыта в новой вкладке.\r\n\r\n' + res.substring(8) : res, 'Раскладка выделенного');
    return res;
};

// Шаблон стола: уголки по местам карт + PDF рядом с раскладкой
Bridge.TemplateRun = function (params, marks) {
    if (!PSA.has('U')) return 'Шаблон стола входит в часть «УФ-планшет» — её нет в вашем ключе.';
    prepare();
    if (!hasDoc()) return 'Откройте раскладку.';
    var d = app.activeDocument;
    if (isSampleDoc(d)) {
        var m0 = 'Шаблон стола делается в файле раскладки — монтажной областью «' + TEMPLATE_PAGE + '» в конце. Откройте раскладку или разложите этот образец.';
        if (!PSA.quiet) alert(m0, 'Шаблон стола');
        return m0;
    }
    var path = '';
    try { path = d.fullName.fsName; } catch (e) { }
    if (!path || path.indexOf('\\') < 0) return 'Сначала сохраните раскладку в файл.';
    var c = parseKV(marks), len = toNum(c.markLen, 5), w = toNum(c.markW, 0.5), gap = toNum(c.markGap, 0);
    Settings.set('Impose', 'MarkLen', len); Settings.set('Impose', 'MarkW', w); Settings.set('Impose', 'MarkGap', gap);
    var props = docProp(d, 'layout'), p = Impose.ParamsFrom(props || '');
    // формат — как у выбранного принтера: TIFF (с его разрешением и поворотом) или PDF
    var tif = Settings.get('Output', 'Format', 'tiff') != 'pdf';
    var res = Impose.Template(d, p, !!props, len, w, gap, path.replace(/\.[^.\\\/]*$/, '') + ' — шаблон стола.' + (tif ? 'tif' : 'pdf'));
    if (res.charAt(0) == '\u0001') return res;    // TIFF с поворотом: доделает панель
    if (!PSA.quiet) alert(res.substring(0, 6) == 'Готово' ? (tif ? 'TIFF' : 'PDF') + ' шаблона стола сохранён рядом с раскладкой.\r\n\r\n' + res.substring(8) : res, 'Шаблон стола');
    return res;
};

// Размер выделенного, мм: «ширина|высота» или пусто
Bridge.SelInfo = function () {
    if (!hasDoc()) return '';
    var sel = selectionItems(app.activeDocument);
    if (!sel.length) return '';
    var b = visBounds(sel[0]).slice(0);
    for (var i = 1; i < sel.length; i++) { var v = visBounds(sel[i]); b[0] = Math.min(b[0], v[0]); b[1] = Math.max(b[1], v[1]); b[2] = Math.max(b[2], v[2]); b[3] = Math.min(b[3], v[3]); }
    return Math.round(mm(b[2] - b[0]) * 100) / 100 + '|' + Math.round(mm(b[1] - b[3]) * 100) / 100;
};
