// Раскладка на печатный лист — как src/Impose.bas. Каждая монтажная область образца — сторона карты.
// Каждый печатаемый слой образца раскладывается в одноимённый слой листа. Переменные поля (VP#…)
// остаются отдельными надписями поверх; неизменная часть слоя становится символом (кроме слоёв белил
// и лака). Размеры — в мм; на странице: x — от левого края области, y — от верхнего.

var GUIDE_LAYER = 'Заготовки (не печатается)';
var CUT_LAYER = 'Метки реза';
var PREPRESS_LAYER = 'Препресс';
var BAR_H = 5, BAR_EDGE = 2;

var Impose = {};

// ---------- параметры ----------

Impose.ParamsFrom = function (s) {
    var c = parseKV(s), G = function (k, d) { return c.hasOwnProperty(k) ? c[k] : d; }, N = function (k, d) { return toNum(G(k, ''), d); };
    var p = {
        SheetW: N('sheetW', 900), SheetH: N('sheetH', 600), CutW: N('cutW', 85.6), CutH: N('cutH', 54), Bleed: N('bleed', 1), Radius: N('radius', 0),
        GapX: N('gapX', 5), GapY: N('gapY', 5), Margin: N('margin', 5), Cols: Math.round(N('cols', 0)), Rows: Math.round(N('rows', 0)),
        MirrorBack: G('mirror', '0') == '1', Guides: G('guides', '1') == '1', Orient: Math.round(N('orient', 0)),
        AlignH: Math.round(N('alignH', 0)), AlignV: Math.round(N('alignV', 0)), MarginsOn: G('marginSides', '0') == '1',
        RegMarks: G('regMarks', '0') == '1', ColorBar: G('colorBar', '0') == '1', SheetInfo: G('sheetInfo', '0') == '1',
        Gripper: N('gripper', 0), GripperSide: Math.round(N('gripperSide', 0)),
        PlateOn: G('plate', '0') == '1', PlateW: N('plateW', 745), PlateH: N('plateH', 605), Klapan: N('klapan', 60), PlateCenter: G('plateCenter', '0') == '1',
        Printer: G('printer', ''), PlateStyle: Math.round(N('plateStyle', 1)), PlateNoStrip: G('plateStrip', '1') == '0',
        WorkTurn: G('workTurn', '0') == '1', WtMode: Math.round(N('wtMode', 1)), WtCal: G('wtCal', '0') == '1', BackDX: N('backDX', 0), BackDY: N('backDY', 0),
        MarginL: N('marginL', 5), MarginR: N('marginR', 5), MarginT: N('marginT', 5), MarginB: N('marginB', 5),
        CutMarks: G('cutMarks', '0') == '1', CutLen: N('cutLen', 5), CutOff: N('cutOff', 3), CutLineW: N('cutLine', 0.1),
        NumFromStart: G('numCorner', '0') == '1', NumStart: G('numStart', ''), NoTemplate: G('noTemplate', '0') == '1',
        Rotated: false, InfoText: ''
    };
    if (p.GripperSide == 0) p.Gripper = 0;
    if (p.PlateOn) { p.Gripper = 0; p.GripperSide = 0; }
    // уголки шаблона стола — в «Раскладке»: последние использованные
    if (G('markLen', '') !== '') {
        Settings.set('Impose', 'MarkLen', N('markLen', 5)); Settings.set('Impose', 'MarkW', N('markW', 0.5)); Settings.set('Impose', 'MarkGap', N('markGap', 0));
    }
    return p;
};

Impose.ParamsText = function (p) {
    var b = function (v) { return v ? 1 : 0; };
    return 'sheetW=' + p.SheetW + '|sheetH=' + p.SheetH + '|cutW=' + p.CutW + '|cutH=' + p.CutH + '|bleed=' + p.Bleed + '|radius=' + p.Radius +
        '|gapX=' + p.GapX + '|gapY=' + p.GapY + '|margin=' + p.Margin + '|cols=' + p.Cols + '|rows=' + p.Rows + '|mirror=' + b(p.MirrorBack) +
        '|guides=' + b(p.Guides) + '|orient=' + p.Orient + '|alignH=' + p.AlignH + '|alignV=' + p.AlignV + '|numCorner=' + b(p.NumFromStart) + '|numStart=' + p.NumStart +
        '|marginL=' + p.MarginL + '|marginR=' + p.MarginR + '|marginT=' + p.MarginT + '|marginB=' + p.MarginB +
        '|regMarks=' + b(p.RegMarks) + '|colorBar=' + b(p.ColorBar) + '|sheetInfo=' + b(p.SheetInfo) + '|gripper=' + p.Gripper + '|gripperSide=' + p.GripperSide +
        '|plate=' + b(p.PlateOn) + '|plateW=' + p.PlateW + '|plateH=' + p.PlateH + '|klapan=' + p.Klapan + '|plateCenter=' + b(p.PlateCenter) +
        '|plateStyle=' + p.PlateStyle + '|plateStrip=' + (p.PlateNoStrip ? 0 : 1) + '|workTurn=' + b(p.WorkTurn) + '|wtMode=' + p.WtMode + '|wtCal=' + b(p.WtCal) +
        '|backDX=' + p.BackDX + '|backDY=' + p.BackDY + '|marginSides=' + b(p.MarginsOn) + '|cutMarks=' + b(p.CutMarks) + '|cutLen=' + p.CutLen +
        '|cutOff=' + p.CutOff + '|cutLine=' + p.CutLineW;
};

// Число без лишней запятой: 60 -> «60», 2,5 -> «2,5»
function mmText(v) { var s = (Math.round(v * 10) / 10).toFixed(1).replace('.', ','); return /,0$/.test(s) ? s.slice(0, -2) : s; }
function f1(v) { return (Math.round(v * 10) / 10).toFixed(1).replace('.', ','); }

// ---------- геометрия листа ----------

Impose.Tumble = function (p) { return p.WorkTurn && p.WtMode == 2; };
Impose.HalfW = function (p) { return p.WorkTurn && !this.Tumble(p) ? p.SheetW / 2 : p.SheetW; };
Impose.HalfH = function (p) { return this.Tumble(p) ? p.SheetH / 2 : p.SheetH; };
Impose.BackTurn = function (p) { return p.WorkTurn && (this.Tumble(p) != p.WtCal) ? 180 : 0; };
Impose.PageW = function (p) { return p.PlateOn ? p.PlateW : p.SheetW; };
Impose.PageH = function (p) { return p.PlateOn ? p.PlateH : p.SheetH; };
Impose.PaperX = function (p) { return p.PlateOn ? (p.PlateW - p.SheetW) / 2 : 0; };
Impose.PaperY = function (p) { if (!p.PlateOn) return 0; return p.PlateCenter ? (p.PlateH - p.SheetH) / 2 : p.PlateH - p.Klapan - p.SheetH; };
Impose.CutOffset = function (p) { return Math.max(p.CutOff, p.Bleed + 1); };
Impose.RegDist = function (p) { return p.CutMarks ? this.CutOffset(p) + p.CutLen + 1 + 4.5 : this.CutOffset(p) + 4.5; };
Impose.TailSide = function (p) { return { 1: 2, 2: 1, 3: 4, 4: 3 }[p.GripperSide] || 2; };

// Сколько места нужно у стороны (1 — верх, 2 — низ, 3 — лево, 4 — право): клапан, метки реза, у хвоста — шкала
Impose.SideNeed = function (p, side, base) {
    var marks = 0;
    if (p.CutMarks) { marks = this.CutOffset(p) + p.CutLen + 1; if (base < marks) base = marks; }
    if (p.RegMarks && !(p.PlateOn && p.PlateStyle == 2)) { marks = this.RegDist(p) + 4.5; if (base < marks + 1) base = marks + 1; }
    if (p.PlateOn) return base;
    if (p.GripperSide == side && p.Gripper > 0 && base < p.Gripper + marks) base = p.Gripper + marks;
    if ((p.ColorBar || p.SheetInfo) && side == this.TailSide(p) && base < marks + 2 + BAR_H + BAR_EDGE) base = marks + 2 + BAR_H + BAR_EDGE;
    return base;
};
Impose.ML = function (p) { return this.SideNeed(p, 3, p.MarginsOn ? p.MarginL : p.Margin); };
Impose.MR = function (p) { return this.SideNeed(p, 4, p.MarginsOn ? p.MarginR : p.Margin); };
Impose.MT = function (p) { return this.SideNeed(p, 1, p.MarginsOn ? p.MarginT : p.Margin); };
Impose.MB = function (p) { return this.SideNeed(p, 2, p.MarginsOn ? p.MarginB : p.Margin); };

Impose.CellW = function (p) { return p.Rotated ? p.CutH : p.CutW; };
Impose.CellH = function (p) { return p.Rotated ? p.CutW : p.CutH; };

Impose.FitCells = function (p, w, h) {
    var cols, rows, m;
    if (p.WorkTurn && !this.Tumble(p)) {
        m = Math.max(this.ML(p), this.MR(p));
        cols = Math.floor((this.HalfW(p) - m - p.GapX / 2 + p.GapX) / (w + p.GapX) + 0.000001);
    } else cols = Math.floor((this.HalfW(p) - this.ML(p) - this.MR(p) + p.GapX) / (w + p.GapX) + 0.000001);
    if (this.Tumble(p)) {
        m = Math.max(this.MT(p), this.MB(p));
        rows = Math.floor((this.HalfH(p) - m - p.GapY / 2 + p.GapY) / (h + p.GapY) + 0.000001);
    } else rows = Math.floor((p.SheetH - this.MT(p) - this.MB(p) + p.GapY) / (h + p.GapY) + 0.000001);
    if (p.Cols > 0 && p.Cols < cols) cols = p.Cols;
    if (p.Rows > 0 && p.Rows < rows) rows = p.Rows;
    return { cols: Math.max(0, cols), rows: Math.max(0, rows) };
};

// Сколько карт влезает; заодно решает, класть ли карты боком (p.Rotated)
Impose.Fit = function (p) {
    var a = this.FitCells(p, p.CutW, p.CutH), b = this.FitCells(p, p.CutH, p.CutW);
    p.Rotated = p.Orient == 2 ? true : (p.Orient == 1 ? false : (b.cols * b.rows > a.cols * a.rows));
    return p.Rotated ? b : a;
};

// Левый верхний угол блока карт: x0 — от левого края листа, y0 — от верхнего (мм)
Impose.Origin = function (p, cols, rows) {
    var bw = cols * this.CellW(p) + (cols - 1) * p.GapX, bh = rows * this.CellH(p) + (rows - 1) * p.GapY, x0, y0;
    if (p.AlignH == 1) x0 = this.ML(p);
    else if (p.AlignH == 2) x0 = this.HalfW(p) - this.MR(p) - bw;
    else x0 = this.ML(p) + (this.HalfW(p) - this.ML(p) - this.MR(p) - bw) / 2;
    if (p.WorkTurn && !this.Tumble(p)) x0 = this.HalfW(p) - p.GapX / 2 - bw;
    if (p.AlignV == 1) y0 = p.SheetH - this.MB(p) - bh;
    else if (p.AlignV == 2) y0 = this.MT(p);
    else y0 = this.MT(p) + (p.SheetH - this.MT(p) - this.MB(p) - bh) / 2;
    if (this.Tumble(p)) y0 = this.HalfH(p) - p.GapY / 2 - bh;
    return { x: x0, y: y0 };
};

// Номер карты по месту в блоке; с точкой старта счёт идёт от угла, к которому прижат блок
Impose.CardIndex = function (p, r, c, rows, cols) {
    if (p.NumFromStart) {
        if (p.NumStart) {
            if (p.NumStart.charAt(0) == 'b') r = rows - 1 - r;
            if (p.NumStart.charAt(p.NumStart.length - 1) == 'r') c = cols - 1 - c;
        } else {
            if (p.AlignV == 1) r = rows - 1 - r;
            if (p.AlignH == 2) c = cols - 1 - c;
        }
    }
    return r * cols + c + 1;
};

// Рез в одну линию (зазор меньше двух вылетов): вылет соседних макетов прячется в рамку
Impose.OneCut = function (p) { return p.Bleed > 0 && (p.GapX < 2 * p.Bleed || p.GapY < 2 * p.Bleed); };

Impose.Describe = function (p) {
    var f = this.Fit(p), c = f.cols, r = f.rows, w = '';
    if (!c || !r) return 'Не помещается на лист с такими отступами.';
    var o = this.Origin(p, c, r), bw = c * this.CellW(p) + (c - 1) * p.GapX, bh = r * this.CellH(p) + (r - 1) * p.GapY;
    var right = p.WorkTurn && !this.Tumble(p) ? o.x : this.HalfW(p) - o.x - bw, bottom = this.Tumble(p) ? o.y : p.SheetH - o.y - bh;
    var s = 'Поместится ' + c + ' × ' + r + ' = ' + (c * r) + ' шт.' + (p.Rotated ? ', повёрнуты на 90°' : ', лёжа') +
            '. От краёв листа: слева ' + f1(o.x) + ', справа ' + f1(right) + ', сверху ' + f1(o.y) + ', снизу ' + f1(bottom) + ' мм.';
    if (this.OneCut(p))
        w += (p.GapX == 0 || p.GapY == 0 ? ' Рез в одну линию:' : ' Зазор меньше двух вылетов (' + mmText(2 * p.Bleed) + ' мм):') +
             ' между макетами вылет срезается по линии реза, по краям блока — полный ' + mmText(p.Bleed) + ' мм.';
    if (p.CutMarks) {
        var need = this.CutOffset(p) + p.CutLen, mn = o.x;
        if (!p.WorkTurn && right < mn) mn = right;
        if (o.y < mn) mn = o.y;
        if (!this.Tumble(p) && bottom < mn) mn = bottom;
        if (mn < need) w += ' Внимание: для меток реза нужно не меньше ' + mmText(need) + ' мм от блока до края листа, а есть ' + mmText(mn) + ' — метки обрежутся краем листа.';
    }
    if (p.PlateOn) {
        if (p.SheetW > p.PlateW || this.PaperY(p) < 0 || p.SheetH > p.PlateH)
            w += ' Внимание: бумага ' + Math.round(p.SheetW) + ' × ' + Math.round(p.SheetH) + ' не помещается на пластину ' + Math.round(p.PlateW) + ' × ' + Math.round(p.PlateH) + (p.PlateCenter ? '' : ' с клапаном ' + mmText(p.Klapan) + ' мм') + '.';
        else {
            s += ' На пластине ' + Math.round(p.PlateW) + ' × ' + Math.round(p.PlateH) + ': ' + (p.PlateCenter ? 'бумага по центру' : 'клапан ' + mmText(p.Klapan) + ' мм') +
                 ', по бокам ' + mmText(this.PaperX(p)) + ', над бумагой ' + mmText(this.PaperY(p)) + ' мм.';
            if (p.ColorBar && p.PlateStyle != 2 && this.PaperY(p) < BAR_H + 1) w += ' Внимание: над бумагой нет места под шкалу.';
        }
    }
    if (p.WorkTurn) s += ' Свой оборот: это на каждой половине листа — ' + (this.Tumble(p) ? 'лица сверху, обороты снизу' : 'лица слева, обороты справа') +
                        (this.BackTurn(p) ? ' (обороты повёрнуты на 180°)' : '') + ', с листа выходит по два комплекта.';
    return s + w;
};

// ---------- рисование ----------

// Точка (мм от левого верхнего угла прямоугольника r области) -> точка документа
function imPt(r, x, y) { return [r[0] + pt(x), r[1] - pt(y)]; }

function regColor() { var c = new SpotColor(); c.spot = app.activeDocument.spots.getByName('[Registration]'); c.tint = 100; return c; }
function cmykColor(c, m, y, k) { var x = new CMYKColor(); x.cyan = c; x.magenta = m; x.yellow = y; x.black = k; return x; }
function rgbColor(r, g, b) { var x = new RGBColor(); x.red = r; x.green = g; x.blue = b; return x; }

function layerNamed(d, name, printable) {
    for (var i = 0; i < d.layers.length; i++) if (d.layers[i].name == name) return d.layers[i];
    var l = d.layers.add();
    l.name = name;
    l.printable = printable;
    if (!printable) l.color = rgbColor(0, 160, 220);
    return l;
}

// Отрезок в мм области: из (x1, y1) в (x2, y2), тонкий, регистрационный
function imLine(cont, r, x1, y1, x2, y2, w) {
    var l = cont.pathItems.add();
    l.setEntirePath([imPt(r, x1, y1), imPt(r, x2, y2)]);
    l.filled = false; l.stroked = true; l.strokeWidth = pt(w || 0.1); l.strokeColor = regColor();
    return l;
}
// Прямоугольник: левый верх (x, y), размер w x h — мм
function imRect(cont, r, x, y, w, h) { var a = imPt(r, x, y); return cont.pathItems.rectangle(a[1], a[0], pt(w), pt(h)); }
function imEllipse(cont, r, cx, cy, rad) { var a = imPt(r, cx - rad, cy - rad); return cont.pathItems.ellipse(a[1], a[0], pt(2 * rad), pt(2 * rad)); }
function noFillRegStroke(s) { s.filled = false; s.stroked = true; s.strokeWidth = pt(0.1); s.strokeColor = regColor(); }

// Метки реза: чёрточки снаружи блока на продолжении линий реза. xs, y0 — левый верх блока (мм от угла области)
Impose.DrawCutMarks = function (d, ab, p, cols, rows, xs, y0) {
    if (p.CutLen <= 0) return;
    var r = d.artboards[ab].artboardRect, l = layerNamed(d, CUT_LAYER, true), g = l.groupItems.add(), c, k, x, y;
    g.name = 'Метки реза';
    var bw = cols * this.CellW(p) + (cols - 1) * p.GapX, bh = rows * this.CellH(p) + (rows - 1) * p.GapY, o = this.CutOffset(p), ln = p.CutLen, w = p.CutLineW > 0 ? p.CutLineW : 0.1;
    for (c = 0; c < cols; c++) for (k = 0; k <= 1; k++) {
        x = xs + c * (this.CellW(p) + p.GapX) + k * this.CellW(p);
        if (!(this.Tumble(p) && y0 - this.PaperY(p) >= this.HalfH(p) - 0.01)) imLine(g, r, x, y0 - o, x, y0 - o - ln, w);
        if (!(this.Tumble(p) && y0 - this.PaperY(p) < this.HalfH(p) - 0.01)) imLine(g, r, x, y0 + bh + o, x, y0 + bh + o + ln, w);
    }
    for (c = 0; c < rows; c++) for (k = 0; k <= 1; k++) {
        y = y0 + c * (this.CellH(p) + p.GapY) + k * this.CellH(p);
        if (!(p.WorkTurn && xs - this.PaperX(p) >= this.HalfW(p) - 0.01)) imLine(g, r, xs - o, y, xs - o - ln, y, w);
        if (!(p.WorkTurn && xs - this.PaperX(p) < this.HalfW(p) - 0.01)) imLine(g, r, xs + bw + o, y, xs + bw + o + ln, y, w);
    }
};

// Крест приводки: окружность 5 мм и перекрестие 8 мм
function regCross(cont, r, x, y) {
    var g = cont.groupItems.add(); g.name = 'Крест приводки';
    noFillRegStroke(imEllipse(g, r, x, y, 2.5));
    imLine(g, r, x - 4, y, x + 4, y); imLine(g, r, x, y - 4, x, y + 4);
    return g;
}
// Мишень: окружность 4 мм, точка 2 мм, перекрестие 6 мм
function imTarget(cont, r, x, y) {
    var g = cont.groupItems.add(); g.name = 'Мишень';
    noFillRegStroke(imEllipse(g, r, x, y, 2));
    imLine(g, r, x - 3, y, x + 3, y); imLine(g, r, x, y - 3, x, y + 3);
    var dot = imEllipse(g, r, x, y, 1); dot.stroked = false; dot.filled = true; dot.fillColor = regColor();
}
// Уголок 5 мм снаружи угла бумаги (x, y) и мишень внутри; sx, sy — куда наружу (-1/1, y вниз)
function cornerMark(cont, r, x, y, sx, sy) {
    var g = cont.groupItems.add(); g.name = 'Угол бумаги';
    imLine(g, r, x, y, x + 5 * sx, y); imLine(g, r, x, y, x, y + 5 * sy);
    var cx = x + 2.5 * sx, cy = y + 2.5 * sy;
    noFillRegStroke(imEllipse(g, r, cx, cy, 1.2));
    imLine(g, r, cx - 2, cy, cx + 2, cy); imLine(g, r, cx, cy - 2, cx, cy + 2);
}
function imLabel(cont, r, x, y, s, size, color, name) {
    var t = cont.textFrames.pointText(imPt(r, x, y));
    t.contents = s;
    t.textRange.characterAttributes.size = size;
    t.textRange.characterAttributes.fillColor = color;
    if (name) t.name = name;
    return t;
}
var BAR_CMYK = [[100, 0, 0, 0], [0, 100, 0, 0], [0, 0, 100, 0], [0, 0, 0, 100], [50, 0, 0, 0], [0, 50, 0, 0], [0, 0, 50, 0], [0, 0, 0, 50],
                [100, 100, 0, 0], [100, 0, 100, 0], [0, 100, 100, 0], [100, 100, 100, 0], [50, 40, 40, 0], [0, 0, 0, 50], [25, 0, 0, 0], [0, 25, 0, 0], [0, 0, 25, 0], [0, 0, 0, 25]];
function colorBar(cont, r, x0, y0, n, vertical) {
    var g = cont.groupItems.add(); g.name = 'Шкала цветового контроля';
    for (var i = 0; i < n; i++) {
        var k = BAR_CMYK[i % BAR_CMYK.length], s = vertical ? imRect(g, r, x0, y0 - (i + 1) * BAR_H, BAR_H, BAR_H) : imRect(g, r, x0 + i * BAR_H, y0, BAR_H, BAR_H);
        s.stroked = false; s.fillColor = cmykColor(k[0], k[1], k[2], k[3]);
    }
}
function today() { var d = new Date(), z = function (n) { return (n < 10 ? '0' : '') + n; }; return z(d.getDate()) + '.' + z(d.getMonth() + 1) + '.' + d.getFullYear(); }

// Офсетный препресс: клапан, кресты приводки, шкала и подпись у хвоста, обвязка пластины
Impose.DrawPrepress = function (d, ab, p, cols, rows, xs, y0, sideName) {
    var r = d.artboards[ab].artboardRect, l = layerNamed(d, PREPRESS_LAYER, true), W = this.PageW(p), H = this.PageH(p);
    var bw = cols * this.CellW(p) + (cols - 1) * p.GapX, bh = rows * this.CellH(p) + (rows - 1) * p.GapY;
    var bl = xs, bt = y0, br = bl + bw, bb = bt + bh;
    if (p.WorkTurn && !this.Tumble(p)) br = 2 * this.PaperX(p) + p.SheetW - xs;
    if (this.Tumble(p)) bb = 2 * (this.PaperY(p) + p.SheetH / 2) - bt;
    if (p.PlateOn) this.DrawPlate(d, ab, l, p, sideName);
    if (p.Gripper > 0 && p.GripperSide > 0) {
        var gl = layerNamed(d, GUIDE_LAYER, false), gr;
        if (p.GripperSide == 1) gr = imRect(gl, r, 0, 0, W, p.Gripper);
        else if (p.GripperSide == 2) gr = imRect(gl, r, 0, H - p.Gripper, W, p.Gripper);
        else if (p.GripperSide == 3) gr = imRect(gl, r, 0, 0, p.Gripper, H);
        else gr = imRect(gl, r, W - p.Gripper, 0, p.Gripper, H);
        gr.fillColor = rgbColor(255, 230, 200); gr.strokeColor = rgbColor(220, 120, 40); gr.strokeWidth = pt(0.2);
        gr.name = 'Клапан ' + p.Gripper + ' мм';
    }
    if (p.RegMarks && !(p.PlateOn && p.PlateStyle == 2)) {
        var dd = this.RegDist(p);
        regCross(l, r, (bl + br) / 2, bt - dd); regCross(l, r, (bl + br) / 2, bb + dd);
        regCross(l, r, bl - dd, (bt + bb) / 2); regCross(l, r, br + dd, (bt + bb) / 2);
    }
    if ((p.ColorBar || p.SheetInfo) && !p.PlateOn) this.DrawTail(d, ab, l, p, sideName);
};

// Обвязка пластины (Visa Print, Yuva Print): контур бумаги, уголки с мишенями, «КЛАПАН», подпись и шкала над бумагой
Impose.DrawPlate = function (d, ab, l, p, sideName) {
    var r = d.artboards[ab].artboardRect, pl = this.PaperX(p), pr = pl + p.SheetW, ptp = this.PaperY(p), pb = ptp + p.SheetH, i;
    var gl = layerNamed(d, GUIDE_LAYER, false), paper = imRect(gl, r, pl, ptp, p.SheetW, p.SheetH);
    paper.filled = false; paper.strokeColor = rgbColor(220, 120, 40); paper.strokeWidth = pt(0.3);
    paper.name = 'Бумага ' + Math.round(p.SheetW) + ' × ' + Math.round(p.SheetH);
    for (i = 0; i < 4; i++) {
        var sx = i % 2 == 0 ? -1 : 1, sy = i < 2 ? 1 : -1;
        cornerMark(l, r, sx < 0 ? pl : pr, sy > 0 ? pb : ptp, sx, sy);
    }
    if (!p.PlateCenter) {
        var t = imLabel(l, r, pl + 8, pb + 4, 'КЛАПАН ' + mmText(p.Klapan) + ' мм' + (p.Printer ? ' · ' + p.Printer : '') + ' · пластина ' + Math.round(p.PlateW) + ' × ' + Math.round(p.PlateH), 7, regColor(), 'Клапан');
        t.top = r[1] - pt(pb + 1.5);
    }
    if (p.PlateStyle == 2) { this.DrawPlateEA(d, ab, l, p, pl, pr, ptp, pb, sideName); return; }
    if ((p.ColorBar || p.SheetInfo) && this.PaperY(p) >= BAR_H + 1) {
        var y = ptp - 0.5 - BAR_H, a0 = pl + 10, a1 = pr - 10;
        if (p.SheetInfo) {
            var s = (p.InfoText ? p.InfoText + ' · ' : '') + sideName + ' · ' + today() + ' · C M Y K';
            var tt = imLabel(l, r, a0, y + BAR_H - 1, s, 6, cmykColor(0, 0, 0, 100), 'Подпись листа');
            a0 = mm(tt.geometricBounds[2] - r[0]) + 5;
        }
        if (p.ColorBar) colorBar(l, r, a0, y, Math.floor((a1 - a0) / BAR_H), false);
    }
};

// Обвязка как в файле под EURO ASIA: шкалы тонов по бокам, мишени, контрольная полоса по низу пластины
Impose.DrawPlateEA = function (d, ab, l, p, pl, pr, ptp, pb, sideName) {
    var r = d.artboards[ab].artboardRect, cy = (ptp + pb) / 2, W = this.PageW(p), H = this.PageH(p), i, j, x;
    if (p.ColorBar) {
        toneWedge(l, r, pl, cy - 3, 0, -1); toneWedge(l, r, pl, cy + 3, 1, -1);
        toneWedge(l, r, pr, cy - 3, 2, 1); toneWedge(l, r, pr, cy + 3, 3, 1);
    }
    if (p.RegMarks) {
        imTarget(l, r, pl, ptp + 3); imTarget(l, r, pr, ptp + 3); imTarget(l, r, pl, pb - 3); imTarget(l, r, pr, pb - 3);
        imTarget(l, r, pl - 3.5, cy); imTarget(l, r, pr + 3.5, cy);
    }
    var y0 = H - 10;     // низ полосы — 10 мм от нижнего края пластины
    if (y0 - pb > 12) {
        x = 5;
        if (p.PlateNoStrip) x = W;
        var g = null;
        while (x + 80 <= W - 5) {
            if (!g) { g = l.groupItems.add(); g.name = 'Контрольная полоса пластины'; }
            for (i = 0; i <= 5; i++) for (j = 0; j <= 1; j++) if ((i + j) % 2 == 0) {
                var s = imRect(g, r, x + i * 3.5, y0 - (j + 1) * 3.5, 3.5, 3.5); s.stroked = false; s.fillColor = regColor();
            }
            var a = imRect(g, r, x + 21, y0 - 6, 24, 6); a.stroked = false; a.fillColor = regColor();
            var b = imRect(g, r, x + 45, y0 - 7, 35, 7); b.stroked = false; b.fillColor = regColor();
            x += 80;
        }
        imLabel(l, r, 5, H - 2.5, sideName + ' · ' + (p.InfoText ? p.InfoText + ' · ' : '') + today(), 12, regColor(), 'Подпись пластины');
        var names = ['Cyan', 'Magenta', 'Yellow', 'Black'], cols = [[100, 0, 0, 0], [0, 100, 0, 0], [0, 0, 100, 0], [0, 0, 0, 100]], xr = W - 5;
        for (var ink = 3; ink >= 0; ink--) {
            var t = imLabel(l, r, xr, H - 3, names[ink], 9, cmykColor(cols[ink][0], cols[ink][1], cols[ink][2], cols[ink][3]), 'Краска ' + names[ink]);
            t.left = r[0] + pt(xr) - t.width;
            xr = mm(t.left - r[0]) - 3;
        }
    }
};

// Шкала тонов у края бумаги x: 10 ступеней по 4 мм от y; светлые (1–10 %) у края, тёмные (90–99 %) дальше
function toneWedge(cont, r, x, y, ink, side) {
    var g = cont.groupItems.add(), dir = (ink == 0 || ink == 2) ? -1 : 1;     // y вниз: голубая и жёлтая — вверх
    g.name = 'Шкала тонов — ' + ['голубой', 'пурпурный', 'жёлтый', 'чёрный'][ink];
    for (var i = 0; i < 10; i++) for (var k = 0; k <= 1; k++) {
        var v = k == 0 ? i + 1 : 90 + i, ya = y + dir * i * 4, yb = ya + dir * 4, xa = k == 0 ? x : x + 2.5 * side, xb = k == 0 ? x + 2.5 * side : x + 5 * side;
        var s = imRect(g, r, Math.min(xa, xb), Math.min(ya, yb), 2.5, 4);
        s.stroked = false;
        s.fillColor = cmykColor(ink == 0 ? v : 0, ink == 1 ? v : 0, ink == 2 ? v : 0, ink == 3 ? v : 0);
    }
}

// Шкала цветового контроля и подпись листа вдоль хвостового края
Impose.DrawTail = function (d, ab, l, p, sideName) {
    var r = d.artboards[ab].artboardRect, W = this.PageW(p), H = this.PageH(p), side = this.TailSide(p), a0, a1, y, x, t;
    var txt = (p.InfoText ? p.InfoText + ' · ' : '') + sideName + ' · ' + today() + ' · PS Avtomatizaciya';
    if (side == 1 || side == 2) {
        a0 = 10; a1 = W - 10;
        y = side == 2 ? H - BAR_EDGE - BAR_H : BAR_EDGE;
        if (p.SheetInfo) { t = imLabel(l, r, a0, y + BAR_H - 1, txt, 6, cmykColor(0, 0, 0, 100), 'Подпись листа'); a0 = mm(t.geometricBounds[2] - r[0]) + 5; }
        if (p.ColorBar) colorBar(l, r, a0, y, Math.floor((a1 - a0) / BAR_H), false);
    } else {
        a0 = H - 10; a1 = 10;
        x = side == 3 ? BAR_EDGE : W - BAR_EDGE - BAR_H;
        if (p.SheetInfo) {
            t = imLabel(l, r, x + 1, a0, txt, 6, cmykColor(0, 0, 0, 100), 'Подпись листа');
            t.rotate(90);
            t.left = r[0] + pt(x + 1); t.top = r[1] - pt(a0) + t.height;
            a0 = mm(r[1] - t.geometricBounds[1]) - 5;
        }
        if (p.ColorBar) colorBar(l, r, x, a0, Math.floor((a0 - a1) / BAR_H), true);
    }
};

// Повернуть вокруг точки (x, y документа): у группы — временный большой квадрат с центром в точке,
// тогда «центр группы» — ровно эта точка, как бы ни выступал рисунок
function rotateAbout(it, ang, x, y) {
    var g = it, wrap = null;
    if (it.typename != 'GroupItem' || it.clipped) { wrap = it.layer.groupItems.add(); wrap.move(it, ElementPlacement.PLACEBEFORE); it.move(wrap, ElementPlacement.PLACEATEND); g = wrap; }
    var b = visBounds(g), half = Math.max(b[2] - b[0], b[1] - b[3], Math.abs(x - b[0]), Math.abs(x - b[2]), Math.abs(y - b[1]), Math.abs(y - b[3])) + 100;
    var t = g.pathItems.rectangle(y + half, x - half, 2 * half, 2 * half);
    t.filled = false; t.stroked = false;
    g.rotate(ang, true, true, true, true, Transformation.CENTER);
    t.remove();
    if (wrap) { it.move(wrap, ElementPlacement.PLACEBEFORE); wrap.remove(); }
}

// ---------- подготовка стороны ----------

function isInkLayerName(n) { return Inks.IsInkLayer(n) || n == 'Белила' || n == 'Лак'; }

// Объекты слоя, задевающие область r: поля (вынутые из групп на слой) и неизменная часть.
// Ответ: [{ layer, parts: [объекты для каждой карты] }] — снизу вверх по слоям; frames — рамки кодов.
Impose.PrepareSide = function (d, ab, sideName) {
    var r = d.artboards[ab].artboardRect, out = [], frames = [], li, i, it;
    // старые сгенерированные коды не нужны
    for (li = 0; li < d.layers.length; li++) if (d.layers[li].name == GEN_LAYER) {
        var gi = d.layers[li].pageItems;
        for (i = gi.length - 1; i >= 0; i--) if (gi[i].name.substring(0, TAG_GEN.length) == TAG_GEN && abIndexOf(d, gi[i]) == ab) gi[i].remove();
    }
    var cand = fieldCandidates(d);
    for (li = d.layers.length - 1; li >= 0; li--) {
        var L = d.layers[li];
        if (L.name == GUIDE_LAYER || L.name == GEN_LAYER) continue;
        var isFrame = L.name == FRAME_LAYER;
        if (!isFrame && (!L.printable || !L.visible)) continue;
        if (L.locked) L.locked = false;
        // поля и спутники — из групп на слой
        var fields = [];
        for (i = cand.length - 1; i >= 0; i--) {
            it = cand[i];
            if (it.layer == L && it.name.substring(0, TAG_FIELD.length) == TAG_FIELD && abIndexOf(d, it) == ab) fields.push(it);
        }
        if (isFrame) { frames = frames.concat(fields); continue; }
        for (i = 0; i < fields.length; i++) if (fields[i].parent != L) fields[i].move(L, ElementPlacement.PLACEATBEGINNING);
        // копии под белила — над номером, лак — ещё выше
        for (i = 0; i < fields.length; i++) if (/~$/.test(fields[i].name) && !isVarnishCopy(fields[i])) fields[i].zOrder(ZOrderMethod.BRINGTOFRONT);
        for (i = 0; i < fields.length; i++) if (/~$/.test(fields[i].name) && isVarnishCopy(fields[i])) fields[i].zOrder(ZOrderMethod.BRINGTOFRONT);
        // неизменная часть: верхние объекты слоя на этой стороне, кроме полей
        var rest = [];
        for (i = 0; i < L.pageItems.length; i++) {
            it = L.pageItems[i];
            if (it.parent != L || it.name.substring(0, TAG_FIELD.length) == TAG_FIELD) continue;
            if (rectsMeet(visBounds(it), r)) rest.push(it);
        }
        var parts = [], inkPart = null;
        // белила и лак, отмеченные цветом, — отдельно от рисунка: рисунок станет символом, а краски при
        // выводе перекрашиваются в плашки — внутри символа пришлось бы разбирать его в каждой карте,
        // и фото уходило бы в файл столько раз, сколько карт
        if (!isInkLayerName(L.name)) {
            var inkLv = [];
            for (i = 0; i < rest.length; i++) {
                var lv0 = [];
                inkLeaves([rest[i]], lv0, false);
                for (var q = 0; q < lv0.length; q++) if (Inks.IsInkSpot(lv0[q], 1) || Inks.IsInkSpot(lv0[q], 2)) inkLv.push({ it: lv0[q], top: rest[i] });
            }
            if (inkLv.length) {
                inkPart = L.groupItems.add();
                inkPart.name = 'Белила и лак';
                var keep = [];
                // объект целиком — краска, или частица краски из группы: в обоих случаях — к краскам
                for (i = 0; i < inkLv.length; i++) inkLv[i].it.move(inkPart, ElementPlacement.PLACEATEND);
                for (i = 0; i < rest.length; i++) { try { if (rest[i].parent != inkPart) keep.push(rest[i]); } catch (e) { } }
                rest = keep;
            }
        }
        if (rest.length) {
            var g = L.groupItems.add();
            for (i = rest.length - 1; i >= 0; i--) rest[i].move(g, ElementPlacement.PLACEATBEGINNING);
            var fixed = g;
            if (!isInkLayerName(L.name)) {
                // символ: в каждой карте одна и та же картинка — файл меньше
                var sym = d.symbols.add(g);
                sym.name = (sideName + ' — ' + L.name + ' ' + new Date().getTime() % 100000).substring(0, 60);
                fixed = L.symbolItems.add(sym);
                var gb = g.geometricBounds, fb = fixed.geometricBounds;
                fixed.translate(gb[0] - fb[0], gb[1] - fb[1]);
                g.remove();
            }
            fixed.zOrder(ZOrderMethod.SENDTOBACK);
            parts.push(fixed);
        }
        if (inkPart) parts.push(inkPart);   // краски — сразу над рисунком, под полями
        // порядок снизу вверх: рисунок, сами поля, копии под белила, выше — копии под лак
        var plain = [], white = [], varn = [];
        for (i = 0; i < fields.length; i++) {
            if (!/~$/.test(fields[i].name)) plain.push(fields[i]);
            else if (isVarnishCopy(fields[i])) varn.push(fields[i]);
            else white.push(fields[i]);
        }
        parts = parts.concat(plain, white, varn);
        if (parts.length) out.push({ layer: L, parts: parts });
    }
    return { sets: out, frames: frames };
};


// Обрезка вылета соседних макетов при резе в одну линию: копия — в обтравочную рамку
Impose.ClipCell = function (g, L, r, p, cx, cy, c, rr, cols, rows, axis) {
    if (!this.OneCut(p)) return g;
    if (g.name.substring(0, TAG_FIELD.length) == TAG_FIELD) return g;
    if (g.typename == 'GroupItem') for (var i = 0; i < g.pageItems.length; i++) if (g.pageItems[i].name.substring(0, TAG_FIELD.length) == TAG_FIELD) return g;
    var ix = Math.min(p.GapX / 2, p.Bleed), iy = Math.min(p.GapY / 2, p.Bleed);
    var bL = c == 0 && axis != 2 ? p.Bleed : ix, bR = c == cols - 1 && axis != 1 ? p.Bleed : ix;
    var bT = rr == 0 && axis != 4 ? p.Bleed : iy, bB = rr == rows - 1 && axis != 3 ? p.Bleed : iy;
    var cg = L.groupItems.add();
    cg.move(g, ElementPlacement.PLACEAFTER);
    var fr = imRect(cg, r, cx - this.CellW(p) / 2 - bL, cy - this.CellH(p) / 2 - bT, this.CellW(p) + bL + bR, this.CellH(p) + bT + bB);
    g.move(cg, ElementPlacement.PLACEATEND);
    fr.zOrder(ZOrderMethod.BRINGTOFRONT);
    cg.clipped = true;
    fr.clipping = true;
    cg.name = g.name;
    return cg;
};

// ---------- раскладка образца ----------

// Раскладывает образец (область = сторона) в новый файл outPath. Ответ — сообщение.
Impose.Run = function (p, outPath) {
    var src = app.activeDocument;
    try { if (!src.saved || !src.fullName) return 'Сначала сохраните документ-образец (одна карта, монтажная область = сторона).'; }
    catch (e) { return 'Сначала сохраните документ-образец (одна карта, монтажная область = сторона).'; }
    var f = this.Fit(p), cols = f.cols, rows = f.rows;
    if (!cols || !rows) return 'Карта не помещается на лист с такими полями.';
    if (new File(outPath).fsName.toLowerCase() == src.fullName.fsName.toLowerCase()) return 'Раскладку нельзя сохранить поверх образца.';
    var o = this.Origin(p, cols, rows), x0 = o.x, y0 = o.y + this.PaperY(p);
    var target = new File(outPath);
    if (target.exists) target.remove();
    if (!src.fullName.copy(target)) return 'Не удалось записать файл раскладки: ' + outPath;
    var d = app.open(target), np = sidePages(d), W = this.PageW(p), H = this.PageH(p), GAP = 50, i, k;
    try {
        // стороны — рядом, каждая размером с лист (холст Illustrator общий для всех областей)
        var r0 = d.artboards[0].artboardRect, rects = [];
        for (i = 0; i < np; i++) rects.push([r0[0] + pt(i * (W + GAP)), r0[1], r0[0] + pt(i * (W + GAP) + W), r0[1] - pt(H)]);
        // шаблон стола и прочие области после сторон — убрать, нарисуем заново
        for (i = d.artboards.length - 1; i >= np; i--) d.artboards.remove(i);
        var prep = [];
        for (i = 0; i < np; i++) {
            var nm = d.artboards[i].name || ('Сторона ' + (i + 1));
            var ar = d.artboards[i].artboardRect;
            prep.push({ name: nm, ox: (ar[0] + ar[2]) / 2, oy: (ar[1] + ar[3]) / 2, s: this.PrepareSide(d, i, nm) });
        }
        for (i = 0; i < np; i++) {
            d.artboards[i].artboardRect = rects[i];
            d.artboards[i].name = ('Лист — ' + prep[i].name).substring(0, 30);
        }
        for (i = 0; i < np; i++) {
            var side = i + 1, R = rects[i], pr = prep[i], even = side % 2 == 0;
            var xs = x0, yb = y0;
            if ((p.MirrorBack || (p.WorkTurn && !this.Tumble(p))) && even) xs = this.HalfW(p) - x0 - (cols * this.CellW(p) + (cols - 1) * p.GapX);
            if (p.WorkTurn && !this.Tumble(p) && even) xs += this.HalfW(p);
            xs += this.PaperX(p);
            if (even && !p.WorkTurn) { xs += p.BackDX; yb = y0 - p.BackDY; }
            if (this.Tumble(p) && even) yb = y0 + rows * this.CellH(p) + rows * p.GapY;
            for (var rr = 0; rr < rows; rr++) for (var c = 0; c < cols; c++) {
                var cc = (p.MirrorBack || (p.WorkTurn && !this.Tumble(p))) && even ? cols - 1 - c : c;
                var cxm = xs + cc * (this.CellW(p) + p.GapX) + this.CellW(p) / 2, cym = yb + rr * (this.CellH(p) + p.GapY) + this.CellH(p) / 2;
                var cpt = imPt(R, cxm, cym);
                var ang = 0;
                if (p.Rotated) ang = even && (p.MirrorBack || p.WorkTurn) ? -90 : 90;
                if (even) ang += this.BackTurn(p);
                var name = 'Карта ' + this.CardIndex(p, rr, c, rows, cols);
                for (k = 0; k < pr.s.sets.length; k++) {
                    var set = pr.s.sets[k], L = set.layer, g = L.groupItems.add();
                    // parts — снизу вверх; каждая следующая копия ложится поверх предыдущих
                    for (var j = 0; j < set.parts.length; j++) {
                        var dup = set.parts[j].duplicate(g, ElementPlacement.PLACEATBEGINNING);
                        dup.translate(cpt[0] - pr.ox, cpt[1] - pr.oy);
                    }
                    if (ang) rotateAbout(g, ang, cpt[0], cpt[1]);
                    g.name = name;
                    this.ClipCell(g, L, R, p, cxm, cym, cc, rr, cols, rows, p.WorkTurn ? (this.Tumble(p) ? 2 : 0) + (even ? 2 : 1) : 0);
                }
                for (k = 0; k < pr.s.frames.length; k++) {
                    var fd = pr.s.frames[k].duplicate();
                    fd.translate(cpt[0] - pr.ox, cpt[1] - pr.oy);
                    if (ang) rotateAbout(fd, ang, cpt[0], cpt[1]);
                }
            }
            // исходная карта образца больше не нужна
            for (k = 0; k < pr.s.sets.length; k++) for (j = 0; j < pr.s.sets[k].parts.length; j++) pr.s.sets[k].parts[j].remove();
            for (k = 0; k < pr.s.frames.length; k++) pr.s.frames[k].remove();
            if (p.Guides) {
                var gl = layerNamed(d, GUIDE_LAYER, false);
                for (rr = 0; rr < rows; rr++) for (c = 0; c < cols; c++) {
                    var lx = xs + c * (this.CellW(p) + p.GapX), ty = yb + rr * (this.CellH(p) + p.GapY), a = imPt(R, lx, ty);
                    var rc = gl.pathItems.roundedRectangle(a[1], a[0], pt(this.CellW(p)), pt(this.CellH(p)), pt(p.Radius), pt(p.Radius));
                    rc.filled = false; rc.stroked = true; rc.strokeWidth = pt(0.2); rc.strokeColor = rgbColor(0, 160, 220);
                }
            }
            if (p.CutMarks) this.DrawCutMarks(d, i, p, cols, rows, xs, yb);
            if ((p.RegMarks || p.ColorBar || p.SheetInfo || p.Gripper > 0 || p.PlateOn) && !(p.WorkTurn && even)) this.DrawPrepress(d, i, p, cols, rows, xs, yb, pr.name);
        }
        if (p.WorkTurn) this.JoinWorkTurn(d, p);
        if (!p.PlateOn && !p.NoTemplate && !p.WorkTurn) {
            var m = this.MarkSettings();
            this.MakeTemplatePage(d, this.TemplateRects(d, p, true), p.SheetW, p.SheetH, m.len, m.w, m.gap);
            setDocProp(d, 'marks', this.MarkKey(m.len, m.w, m.gap));
        }
        setDocProp(d, 'layout', 'src=' + src.fullName.fsName + '|' + this.ParamsText(p));
        d.artboards.setActiveArtboardIndex(0);
        d.save();
    } catch (e) {
        try { d.close(SaveOptions.DONOTSAVECHANGES); } catch (x) { }
        try { target.remove(); } catch (x) { }
        try { src.activate(); } catch (x) { }
        logLine('сбой раскладки: ' + e.message + ' (строка ' + e.line + ')');
        return 'Сбой раскладки: ' + e.message;
    }
    if (p.WorkTurn)
        return 'Готово: свой оборот — ' + cols + ' × ' + rows + (this.Tumble(p) ? ' лиц сверху и столько же оборотов снизу' : ' лиц слева и столько же оборотов справа') + ' на одном листе' +
               (this.BackTurn(p) ? ', обороты повёрнуты на 180°' : '') + '. После печати лист переворачивают ' +
               (this.Tumble(p) ? 'через голову (снизу вверх) — клапаном становится другой край' : 'слева направо') + ' и печатают теми же пластинами; с листа — два комплекта.\r\n' + outPath;
    return 'Готово: ' + cols + ' × ' + rows + ' = ' + (cols * rows) + ' шт. на лист, сторон: ' + sidePages(d) +
           (p.PlateOn ? ', лист стоит на пластине печатника.' : ', в конце — монтажная область «' + TEMPLATE_PAGE + '».') + '\r\n' + outPath;
};

// Свой оборот: всё со стороны оборота — на лист лица (сдвигом на место), область оборота убирается
Impose.JoinWorkTurn = function (d, p) {
    if (d.artboards.length < 2) return;
    var a = d.artboards[0].artboardRect, b = d.artboards[1].artboardRect, dx = a[0] - b[0], dy = a[1] - b[1], i, it, list = [];
    for (i = 0; i < d.layers.length; i++) list = list.concat(topItemsOn(d, d.layers[i], 1));
    for (i = 0; i < list.length; i++) list[i].translate(dx, dy);
    d.artboards.remove(1);
    d.artboards[0].name = 'Лист — свой оборот';
    var l = layerNamed(d, CUT_LAYER, true), g = l.groupItems.add(), x;
    g.name = 'Середина листа (ось переворота)';
    if (this.Tumble(p)) {
        x = this.PaperY(p) + p.SheetH / 2;
        imLine(g, a, this.PaperX(p), x, this.PaperX(p) + 4, x); imLine(g, a, this.PaperX(p) + p.SheetW, x, this.PaperX(p) + p.SheetW - 4, x);
    } else {
        x = this.PaperX(p) + p.SheetW / 2;
        imLine(g, a, x, this.PaperY(p), x, this.PaperY(p) + 4); imLine(g, a, x, this.PaperY(p) + p.SheetH, x, this.PaperY(p) + p.SheetH - 4);
    }
};

// ---------- шаблон стола: уголки по местам карт ----------

Impose.MarkSettings = function () {
    var len = Settings.num('Impose', 'MarkLen', 5), w = Settings.num('Impose', 'MarkW', 0.5), gap = Settings.num('Impose', 'MarkGap', 0);
    if (w <= 0) w = 0.5;
    if (len <= w) len = 5;
    return { len: len, w: w, gap: gap };
};
Impose.MarkKey = function (a, b, c) { return a + '|' + b + '|' + c; };

// Места карт: [x, y, w, h] мм от левого верхнего угла листа. По параметрам, а без них — по контурам заготовок.
Impose.TemplateRects = function (d, p, hasP) {
    var out = [], i;
    if (hasP) {
        var f = this.Fit(p), o = this.Origin(p, f.cols, f.rows);
        for (var r = 0; r < f.rows; r++) for (var c = 0; c < f.cols; c++)
            out.push([o.x + c * (this.CellW(p) + p.GapX), o.y + r * (this.CellH(p) + p.GapY), this.CellW(p), this.CellH(p)]);
        out.sw = p.SheetW; out.sh = p.SheetH;
    } else {
        var ar = d.artboards[0].artboardRect;
        for (i = 0; i < d.layers.length; i++) if (d.layers[i].name == GUIDE_LAYER) {
            var L = d.layers[i];
            for (var k = 0; k < L.pathItems.length; k++) {
                var b = L.pathItems[k].geometricBounds;
                if (abIndexOf(d, L.pathItems[k]) == 0) out.push([mm(b[0] - ar[0]), mm(ar[1] - b[1]), mm(b[2] - b[0]), mm(b[1] - b[3])]);
            }
        }
        out.sw = mm(ar[2] - ar[0]); out.sh = mm(ar[1] - ar[3]);
    }
    return out;
};

Impose.TemplateIndex = function (d) {
    for (var i = 0; i < d.artboards.length; i++) if (d.artboards[i].name == TEMPLATE_PAGE) return i;
    return -1;
};

// Рисует (заново) монтажную область «Шаблон стола» после листов: уголки обнимают углы мест снаружи
Impose.MakeTemplatePage = function (d, rects, sw, sh, len, w, gap) {
    var i = this.TemplateIndex(d), L, k;
    if (i >= 0) {
        var old = d.artboards[i].artboardRect;
        for (k = 0; k < d.layers.length; k++) { var tl = topItemsOn(d, d.layers[k], i); for (var q = tl.length - 1; q >= 0; q--) tl[q].remove(); }
        d.artboards.remove(i);
    }
    var last = d.artboards[d.artboards.length - 1].artboardRect, left = last[2] + pt(50);
    var R = [left, last[1], left + pt(sw), last[1] - pt(sh)];
    d.artboards.add(R);
    d.artboards[d.artboards.length - 1].name = TEMPLATE_PAGE;
    L = layerNamed(d, 'Уголки', true);
    for (k = 0; k < rects.length; k++) {
        var rc = rects[k], a = Math.min(len, rc[2] / 2, rc[3] / 2), t = w;
        var lx = rc[0] - gap, rx = rc[0] + rc[2] + gap, yt = rc[1] - gap, yb = rc[1] + rc[3] + gap;
        var g = L.groupItems.add();
        g.name = 'Место ' + (k + 1);
        var bars = [[lx - t, yt - t, a + t, t], [lx - t, yt, t, a], [rx - a, yt - t, a + t, t], [rx, yt, t, a],
                    [lx - t, yb, a + t, t], [lx - t, yb - a, t, a], [rx - a, yb, a + t, t], [rx, yb - a, t, a]];
        for (var j = 0; j < bars.length; j++) { var s = imRect(g, R, bars[j][0], bars[j][1], bars[j][2], bars[j][3]); s.stroked = false; s.fillColor = cmykColor(0, 0, 0, 100); }
    }
    return d.artboards.length - 1;
};

// ---------- раскладка выделенного (визитки, флаеры — без образца и номеров) ----------

Impose.RunSelection = function (p, outPath) {
    var src = app.activeDocument, sel = selectionItems(src), i, k;
    if (!sel.length) return 'Сначала выделите макет — визитку, флаер — вместе с вылетами.';
    var b = visBounds(sel[0]).slice(0);
    for (i = 1; i < sel.length; i++) { var v = visBounds(sel[i]); b[0] = Math.min(b[0], v[0]); b[1] = Math.max(b[1], v[1]); b[2] = Math.max(b[2], v[2]); b[3] = Math.min(b[3], v[3]); }
    p.CutW = mm(b[2] - b[0]) - 2 * p.Bleed; p.CutH = mm(b[1] - b[3]) - 2 * p.Bleed;
    if (p.CutW <= 0 || p.CutH <= 0) return 'Вылет больше самого макета — проверьте «Вылет за рез».';
    var f = this.Fit(p), cols = f.cols, rows = f.rows;
    if (!cols || !rows) return 'Макет ' + f1(p.CutW) + ' × ' + f1(p.CutH) + ' мм не помещается на лист с такими отступами.';
    var o = this.Origin(p, cols, rows), x0 = o.x + this.PaperX(p), y0 = o.y + this.PaperY(p);
    var d = app.documents.add(src.documentColorSpace, pt(this.PageW(p)), pt(this.PageH(p)));
    try {
        d.artboards[0].name = 'Лист';
        var R = d.artboards[0].artboardRect, groups = [];
        while (d.layers.length < src.layers.length) d.layers.add();
        for (i = 0; i < src.layers.length; i++) d.layers[i].name = src.layers[i].name;
        // выделенное — по слоям, каждый слой одной группой
        for (i = src.layers.length - 1; i >= 0; i--) {
            var g = null;
            for (k = sel.length - 1; k >= 0; k--) {
                var lay = sel[k].layer;
                if (lay.name != src.layers[i].name) continue;
                if (!g) g = d.layers[i].groupItems.add();
                // из другого документа Illustrator копирует только на слой, не сразу в группу
                sel[k].duplicate(d.layers[i], ElementPlacement.PLACEATBEGINNING).move(g, ElementPlacement.PLACEATBEGINNING);
            }
            if (g) groups.push(g);
        }
        // центр макета — по копиям в новом документе: при переносе между документами Illustrator
        // пересчитывает координаты от своего начала
        var nb = boundsOf(groups), cxo = (nb[0] + nb[2]) / 2, cyo = (nb[1] + nb[3]) / 2, n = 0;
        for (var rr = 0; rr < rows; rr++) for (var c = 0; c < cols; c++) {
            n++;
            var cxm = x0 + c * (this.CellW(p) + p.GapX) + this.CellW(p) / 2, cym = y0 + rr * (this.CellH(p) + p.GapY) + this.CellH(p) / 2, cpt = imPt(R, cxm, cym);
            for (k = 0; k < groups.length; k++) {
                var gd = groups[k].duplicate();
                gd.translate(cpt[0] - cxo, cpt[1] - cyo);
                if (p.Rotated) rotateAbout(gd, 90, cpt[0], cpt[1]);
                gd.name = 'Макет ' + n;
                this.ClipCell(gd, gd.layer, R, p, cxm, cym, c, rr, cols, rows, 0);
            }
        }
        for (k = 0; k < groups.length; k++) groups[k].remove();
        if (p.Guides) {
            var gl = layerNamed(d, GUIDE_LAYER, false);
            for (rr = 0; rr < rows; rr++) for (c = 0; c < cols; c++) {
                var a = imPt(R, x0 + c * (this.CellW(p) + p.GapX), y0 + rr * (this.CellH(p) + p.GapY));
                var rc = gl.pathItems.roundedRectangle(a[1], a[0], pt(this.CellW(p)), pt(this.CellH(p)), pt(p.Radius), pt(p.Radius));
                rc.filled = false; rc.stroked = true; rc.strokeWidth = pt(0.2); rc.strokeColor = rgbColor(0, 160, 220);
            }
        }
        if (p.CutMarks) this.DrawCutMarks(d, 0, p, cols, rows, x0, y0);
        if (p.RegMarks || p.ColorBar || p.SheetInfo || p.Gripper > 0 || p.PlateOn) this.DrawPrepress(d, 0, p, cols, rows, x0, y0, 'Лист');
        if (!p.PlateOn && !p.NoTemplate && !p.WorkTurn) {
            var m = this.MarkSettings();
            this.MakeTemplatePage(d, this.TemplateRects(d, p, true), p.SheetW, p.SheetH, m.len, m.w, m.gap);
            setDocProp(d, 'marks', this.MarkKey(m.len, m.w, m.gap));
        }
        setDocProp(d, 'layout', 'src=|' + this.ParamsText(p));
        d.artboards.setActiveArtboardIndex(0);
        var t = new File(outPath);
        if (t.exists) t.remove();
        d.saveAs(t, new IllustratorSaveOptions());
    } catch (e) {
        try { d.close(SaveOptions.DONOTSAVECHANGES); } catch (x) { }
        logLine('сбой раскладки выделенного: ' + e.message + ' (строка ' + e.line + ')');
        return 'Сбой раскладки: ' + e.message;
    }
    return 'Готово: ' + cols + ' × ' + rows + ' = ' + (cols * rows) + ' шт., макет по резу ' + f1(p.CutW) + ' × ' + f1(p.CutH) + ' мм' + (p.Rotated ? ', повёрнут на 90°' : '') + '.\r\n' + outPath;
};

// Перерисовать шаблон в открытой раскладке и сохранить его PDF (пока только PDF)
Impose.Template = function (d, p, hasP, len, w, gap, outPath) {
    if (w <= 0) return 'Толщина уголка должна быть больше нуля.';
    if (len <= w) return 'Длина уголка должна быть больше его толщины.';
    var rects = this.TemplateRects(d, p, hasP);
    if (!rects.length) return 'В раскладке не нашлось мест под карты (нет контуров заготовок). Переразложите образец.';
    var idx = this.TemplateIndex(d), key = docProp(d, 'marks'), redraw = idx < 0 || (key && key != this.MarkKey(len, w, gap));
    if (redraw) { idx = this.MakeTemplatePage(d, rects, rects.sw, rects.sh, len, w, gap); setDocProp(d, 'marks', this.MarkKey(len, w, gap)); }
    var t = sheetDoc(d, [idx], {}), tifJob = null;
    try {
        if (/\.tif$/i.test(outPath)) {
            // TIFF ровно размером листа: белая подложка во весь лист входит в выгрузку (как у CorelDRAW)
            var bl = t.layers.add(); bl.name = 'PS • Автоматизация: подложка'; bl.zOrder(ZOrderMethod.SENDTOBACK);
            var r0 = t.artboards[0].artboardRect, bg = bl.pathItems.rectangle(r0[1], r0[0], r0[2] - r0[0], r0[1] - r0[3]);
            bg.filled = true; bg.fillColor = cmykColor(0, 0, 0, 0); bg.stroked = false;
            // поворот для принтера — той же программой, что склеивает листы (её запускает панель)
            if (tiffRotate()) { tifJob = { fon: exportTiff(t, 0, Folder.temp.fsName + '/VarPrint_template_' + new Date().getTime() + '.tif', false), out: new File(outPath).fsName, masks: [] }; }
            else exportTiff(t, 0, outPath, false);
        } else savePdf(t, outPath, '1');
    } finally { t.close(SaveOptions.DONOTSAVECHANGES); d.activate(); }
    var done = 'Готово: мест ' + rects.length + ', уголок ' + len + ' мм, толщина ' + w + ' мм' + (redraw ? ' (уголки перерисованы — сохраните раскладку)' : '') + '.\r\n' + outPath;
    if (tifJob) return '\u0001tiff|' + toJson({ jobs: [tifJob], rot: tiffRotate(), msg: done });
    return done;
};
