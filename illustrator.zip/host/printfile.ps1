﻿# Окно Illustrator «Print to File» (печать в файл PostScript) — вписать имя файла и нажать «Сохранить».
# Запускается перед печатью форм по краскам; ждёт окно до Wait секунд, потом выходит.
param([Parameter(Mandatory = $true)][string]$Path, [int]$Wait = 120, [string]$Log = '')
Add-Type @"
using System; using System.Text; using System.Runtime.InteropServices; using System.Collections.Generic;
public class PF {
  public delegate bool P(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(P p, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr w, P p, IntPtr l);
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, string l);
  [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  public static IntPtr Find(uint pid, string cls) { IntPtr r = IntPtr.Zero; EnumWindows((h, l) => { uint p; GetWindowThreadProcessId(h, out p); var c = new StringBuilder(64); GetClassName(h, c, 64); if (p == pid && IsWindowVisible(h) && c.ToString() == cls) { var s = new StringBuilder(256); GetWindowText(h, s, 256); if (s.ToString().IndexOf("File", StringComparison.OrdinalIgnoreCase) >= 0 || s.ToString().IndexOf("файл", StringComparison.OrdinalIgnoreCase) >= 0) r = h; } return true; }, IntPtr.Zero); return r; }
  public static List<string> Children(IntPtr w) { var r = new List<string>(); EnumChildWindows(w, (h, l) => { var c = new StringBuilder(64); GetClassName(h, c, 64); var s = new StringBuilder(256); GetWindowText(h, s, 256); r.Add(h.ToInt64() + "|" + c + "|" + GetDlgCtrlID(h) + "|" + s); return true; }, IntPtr.Zero); return r; }
}
"@
$p = Get-Process Illustrator -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $p) { exit 1 }
$t0 = Get-Date
while (((Get-Date) - $t0).TotalSeconds -lt $Wait) {
    $h = [PF]::Find([uint32]$p.Id, '#32770')
    if ($h -ne [IntPtr]::Zero) {
        Start-Sleep -Milliseconds 300
        $kids = [PF]::Children($h)
        if ($Log) { $kids | Out-File -FilePath $Log -Encoding utf8 }
        # поле имени файла: Edit с номером 1148 (новые окна — внутри ComboBox) или 1152 (старые)
        $edit = $null
        foreach ($k in $kids) { $a = $k.Split('|'); if ($a[1] -eq 'Edit' -and ($a[2] -eq '1148' -or $a[2] -eq '1152' -or $a[2] -eq '1001')) { $edit = [IntPtr][long]$a[0] } }
        if (-not $edit) { foreach ($k in $kids) { $a = $k.Split('|'); if ($a[1] -eq 'Edit') { $edit = [IntPtr][long]$a[0]; break } } }
        if ($edit) {
            [PF]::SendMessage($edit, 0x000C, [IntPtr]::Zero, $Path) | Out-Null          # WM_SETTEXT
            Start-Sleep -Milliseconds 200
            foreach ($k in $kids) { $a = $k.Split('|'); if ($a[1] -eq 'Button' -and $a[2] -eq '1') { [PF]::SendMessage([IntPtr][long]$a[0], 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero) | Out-Null } }   # BM_CLICK «Сохранить»
            Start-Sleep -Milliseconds 800
            # спросил «заменить файл?» — да
            $h2 = [PF]::Find([uint32]$p.Id, '#32770')
            if ($h2 -ne [IntPtr]::Zero -and $h2 -ne $h) { foreach ($k in [PF]::Children($h2)) { $a = $k.Split('|'); if ($a[1] -eq 'Button' -and ($a[2] -eq '6' -or $a[2] -eq '1')) { [PF]::SendMessage([IntPtr][long]$a[0], 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero) | Out-Null; break } } }
        }
        exit 0
    }
    Start-Sleep -Milliseconds 250
}
exit 2
