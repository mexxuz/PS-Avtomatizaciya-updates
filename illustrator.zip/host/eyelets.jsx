// Люверсы для баннера — как src/Eyelets.bas: круги с перекрестием по периметру с равным шагом, углы заняты.
// Шаг — «не реже, чем», по длине стороны он выравнивается сам. Метки — на своём слое, по умолчанию не печатаются.
// Подгиб — линия, по которой край заворачивается: люверсы сидят в двойном слое ткани.

var EYE_LAYER = 'Люверсы';

var Eyelets = (function () {
    var MARK_OUT = 0.25, CROSS_K = 1.6;

    function from(params) {
        var c = parseKV(params), N = function (k, dv) { return toNum(c.hasOwnProperty(k) ? c[k] : '', dv); };
        return { Target: Math.round(N('eyeTarget', 0)), Hole: N('eyeHole', 11), Edge: N('eyeEdge', 25), MaxStep: N('eyeStep', 500),
                 Sides: Math.round(N('eyeSides', 0)), Hem: N('eyeHem', 0), Printed: c.eyePrint == '1' };
    }
    function sidesName(s) { return ['все четыре стороны', 'верх и низ', 'левая и правая', 'только верх'][s] || 'все четыре стороны'; }

    // Сколько люверсов встанет на стороне длиной L и с каким шагом
    function planSide(L, e) {
        var span = L - 2 * e.Edge;
        if (span <= 0.01) return { n: 1, gap: 0 };
        var st = Math.max(10, e.MaxStep), parts = Math.max(1, Math.ceil(span / st));
        return { n: parts + 1, gap: span / parts };
    }
    // Область: монтажная область или выделенное. Ответ — { R } (пт: л, в, п, н) или строка-ошибка
    function area(e) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument;
        if (e.Target == 1) {
            var s = selectionItems(d);
            if (!s.length) return 'Сначала выделите баннер — или переключитесь на «по странице».';
            return { R: boundsOf(s) };
        }
        return { R: d.artboards[d.artboards.getActiveArtboardIndex()].artboardRect };
    }
    function hemWarn(e) {
        if (e.Hem <= 0 || e.Edge + e.Hole / 2 <= e.Hem) return '';
        return ' Внимание: люверс выходит за линию подгиба — там ткань одинарная и он вырвется. Отступ от края должен быть меньше подгиба хотя бы на половину отверстия.';
    }

    function describe(e) {
        var a = area(e);
        if (typeof a == 'string') return a;
        var w = mm(a.R[2] - a.R[0]), h = mm(a.R[1] - a.R[3]);
        if (e.Edge * 2 >= w && e.Edge * 2 >= h) return 'Отступ от края больше самого баннера — уменьшите отступ.';
        var H = planSide(w, e), V = planSide(h, e), total, t;
        if (e.Sides == 1) { total = H.n * 2; t = 'по верху и низу через ' + mmText(H.gap) + ' мм'; }
        else if (e.Sides == 2) { total = V.n * 2; t = 'по бокам через ' + mmText(V.gap) + ' мм'; }
        else if (e.Sides == 3) { total = H.n; t = 'по верху через ' + mmText(H.gap) + ' мм'; }
        else { total = V.n <= 2 ? H.n * 2 : H.n * 2 + (V.n - 2) * 2; t = 'по верху и низу через ' + mmText(H.gap) + ' мм, по бокам через ' + mmText(V.gap) + ' мм'; }
        return 'Баннер ' + mmText(w) + ' × ' + mmText(h) + ' мм. Люверсов: ' + total + ' (' + t + ').' + (e.Hem > 0 ? ' Подгиб ' + mmText(e.Hem) + ' мм.' : '') + hemWarn(e);
    }

    // метка: круг с перекрестием; x, y — мм от левого нижнего угла области R
    function mark(g, R, cx, cy, dd, num) {
        var r = dd / 2, c = r * CROSS_K, red = cmykColor(0, 100, 100, 0);
        var P = function (x, y) { return [R[0] + pt(x), R[3] + pt(y)]; };
        var tl = P(cx - r, cy + r), e = g.pathItems.ellipse(tl[1], tl[0], pt(2 * r), pt(2 * r));
        e.filled = false; e.stroked = true; e.strokeWidth = pt(MARK_OUT); e.strokeColor = red; e.name = 'Люверс ' + num;
        var l1 = g.pathItems.add(); l1.setEntirePath([P(cx - c, cy), P(cx + c, cy)]);
        var l2 = g.pathItems.add(); l2.setEntirePath([P(cx, cy - c), P(cx, cy + c)]);
        l1.filled = l2.filled = false; l1.stroked = l2.stroked = true; l1.strokeWidth = l2.strokeWidth = pt(MARK_OUT); l1.strokeColor = l2.strokeColor = red;
    }
    function line(g, R, e, x1, y1, x2, y2, n, first, last, st) {
        for (var i = first; i <= n - 1 - last; i++) {
            st.num++;
            if (n == 1) mark(g, R, x1, y1, e.Hole, st.num);
            else mark(g, R, x1 + (x2 - x1) * i / (n - 1), y1 + (y2 - y1) * i / (n - 1), e.Hole, st.num);
        }
    }

    function run(e) {
        var a = area(e);
        if (typeof a == 'string') return a;
        if (e.Hole <= 0) e.Hole = 11;
        var d = app.activeDocument, R = a.R, w = mm(R[2] - R[0]), h = mm(R[1] - R[3]);
        if (e.Edge * 2 >= w && e.Edge * 2 >= h) return 'Отступ от края больше самого баннера — уменьшите отступ.';
        try {
            var L = layerNamed(d, EYE_LAYER, e.Printed);
            L.printable = e.Printed; L.visible = true; L.locked = false;
            // старые метки этой области — долой, чтобы при повторном запуске не копились
            var ab = d.artboards.getActiveArtboardIndex(), old = topItemsOn(d, L, e.Target == 1 ? -1 : ab);
            for (var i = old.length - 1; i >= 0; i--) old[i].remove();
            var g = L.groupItems.add(); g.name = 'Люверсы';
            var lx = e.Edge, rx = w - e.Edge, by = e.Edge, ty = h - e.Edge, H = planSide(w, e), V = planSide(h, e), st = { num: 0 };
            if (e.Sides == 1) { line(g, R, e, lx, ty, rx, ty, H.n, 0, 0, st); line(g, R, e, lx, by, rx, by, H.n, 0, 0, st); }
            else if (e.Sides == 2) { line(g, R, e, lx, ty, lx, by, V.n, 0, 0, st); line(g, R, e, rx, ty, rx, by, V.n, 0, 0, st); }
            else if (e.Sides == 3) line(g, R, e, lx, ty, rx, ty, H.n, 0, 0, st);
            else {
                // верх и низ целиком, бока — без углов, они уже стоят
                line(g, R, e, lx, ty, rx, ty, H.n, 0, 0, st); line(g, R, e, lx, by, rx, by, H.n, 0, 0, st);
                line(g, R, e, lx, ty, lx, by, V.n, 1, 1, st); line(g, R, e, rx, ty, rx, by, V.n, 1, 1, st);
            }
            if (e.Hem > 0) {
                var hm = g.pathItems.rectangle(R[1] - pt(e.Hem), R[0] + pt(e.Hem), pt(w - 2 * e.Hem), pt(h - 2 * e.Hem));
                hm.filled = false; hm.stroked = true; hm.strokeWidth = pt(MARK_OUT); hm.strokeColor = cmykColor(100, 0, 100, 0);
                hm.strokeDashes = [pt(2), pt(1.5)]; hm.name = 'Линия подгиба';
            }
            var msg = 'Готово: люверсов ' + st.num + ', ' + sidesName(e.Sides) + ', отверстие ' + mmText(e.Hole) + ' мм, отступ от края ' + mmText(e.Edge) + ' мм. ' +
                      'Шаг по верху ' + mmText(H.gap) + ' мм' + (e.Sides == 0 || e.Sides == 2 ? ', по боку ' + mmText(V.gap) + ' мм' : '') + '.' +
                      (e.Hem > 0 ? ' Линия подгиба — ' + mmText(e.Hem) + ' мм от края.' : '') +
                      (e.Printed ? ' Метки печатаются.' : ' Слой «' + EYE_LAYER + '» не печатается.') + ' Отменить — Ctrl+Z.' + hemWarn(e);
            logLine('люверсы: ' + msg);
            return msg;
        } catch (x) {
            logLine('сбой люверсов: ' + x.message + ' (строка ' + x.line + ')');
            return 'Не получилось расставить люверсы: ' + x.message;
        }
    }

    function remove() {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, L = null;
        for (var i = 0; i < d.layers.length; i++) if (d.layers[i].name == EYE_LAYER) L = d.layers[i];
        if (!L) return 'Меток люверсов в документе нет.';
        L.locked = false; L.visible = true;
        L.remove();
        return 'Метки люверсов убраны.';
    }

    return { from: from, describe: describe, run: run, remove: remove };
})();

Bridge.EyeInfo = function (params) { return Eyelets.describe(Eyelets.from(params)); };
Bridge.EyeRun = function (params) {
    if (!PSA.has('W')) return 'Люверсы входят в часть «Рулонная печать» — её нет в вашем ключе.';
    var e = Eyelets.from(params);
    Settings.set('Eyelets', 'Hole', e.Hole); Settings.set('Eyelets', 'Edge', e.Edge); Settings.set('Eyelets', 'Step', e.MaxStep);
    Settings.set('Eyelets', 'Sides', e.Sides); Settings.set('Eyelets', 'Hem', e.Hem); Settings.set('Eyelets', 'Target', e.Target);
    Settings.set('Eyelets', 'Print', e.Printed ? '1' : '0');
    return Eyelets.run(e);
};
Bridge.EyeClear = function () {
    if (!PSA.has('W')) return 'Люверсы входят в часть «Рулонная печать» — её нет в вашем ключе.';
    return Eyelets.remove();
};
