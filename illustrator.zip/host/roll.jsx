// Рулонная печать — как src/Roll.bas: лист = ширина рулона × длина по тиражу. Раскладка выделенного,
// поверх — контур реза плашкой CutContour и метки для плоттера: Summa OPOS, Graphtec ARMS — квадраты;
// Mimaki — уголки; SignMaster (ARMS 5.0) — кружки, как в его файлах печати.
// Холст Illustrator — не длиннее 5,7 м: длиннее раскладка не помещается, тираж делится на файлы.

var MARK_LAYER = 'Метки плоттера';
var Roll = (function () {
    var END_FIELD = 10, MID_STEP = 500, MAX_LEN = 5700;

    function markName(m) { return ['', 'Summa OPOS', 'Graphtec ARMS', 'Mimaki', 'SignMaster'][m] || ''; }
    function markZone(r) { return r.Marks > 0 ? r.MarkGap + r.MarkSize : 0; }

    function from(s) {
        var c = parseKV(s), N = function (k, d) { return toNum(c[k], d); };
        return { Width: N('rollW', 1370), Side: N('rollSide', 15), Qty: Math.round(N('rollQty', 100)), CutMode: Math.round(N('rollCut', 1)),
                 Marks: Math.round(N('rollMarks', 0)), MarkSize: N('rollMSize', 3), MarkGap: N('rollMGap', 10) };
    }
    function save(r) {
        Settings.set('Roll', 'Width', r.Width); Settings.set('Roll', 'Side', r.Side); Settings.set('Roll', 'Qty', r.Qty); Settings.set('Roll', 'CutMode', r.CutMode);
        Settings.set('Roll', 'Marks', r.Marks); Settings.set('Roll', 'MarkSize', r.MarkSize); Settings.set('Roll', 'MarkGap', r.MarkGap);
    }

    // Подгоняет p под рулон (лист, поля, поворот, ряды). out: { cols, rows }. Ответ — '' или ошибка.
    function plan(p, r, out) {
        if (r.Width <= 0) return 'Укажите ширину рулона.';
        if (r.Qty < 1) r.Qty = 1;
        p.SheetW = r.Width;
        p.MarginsOn = true;
        p.MarginL = p.MarginR = r.Side + markZone(r) + p.Margin;
        p.MarginT = p.MarginB = END_FIELD + markZone(r) + p.Margin;
        p.AlignH = 0; p.AlignV = 0; p.Cols = 0; p.Rows = 0;
        p.PlateOn = false; p.Gripper = 0; p.GripperSide = 0;
        var forced = p.Orient, best = -1, bestO = 0, f, n, L;
        for (var o = 1; o <= 2; o++) {
            if (forced != 0 && forced != o) continue;
            p.Orient = o; p.SheetH = 100000;
            f = Impose.Fit(p);
            if (f.cols > 0) {
                n = Math.ceil(r.Qty / f.cols);
                L = Impose.MT(p) + Impose.MB(p) + n * Impose.CellH(p) + (n - 1) * p.GapY;
                if (best < 0 || L < best - 0.01) { best = L; bestO = o; }
            }
        }
        if (best < 0) return 'Макет не помещается по ширине рулона ' + mmText(r.Width) + ' мм с полями принтера.';
        p.Orient = bestO; p.SheetH = 100000;
        f = Impose.Fit(p);
        out.cols = f.cols; out.rows = Math.ceil(r.Qty / f.cols);
        p.Rows = out.rows;
        p.SheetH = Math.round((Impose.MT(p) + Impose.MB(p) + out.rows * Impose.CellH(p) + (out.rows - 1) * p.GapY) * 10) / 10;
        if (p.SheetH > MAX_LEN) {
            var rowsMax = Math.floor((MAX_LEN - Impose.MT(p) - Impose.MB(p) + p.GapY) / (Impose.CellH(p) + p.GapY));
            return 'Длина ' + (p.SheetH / 1000).toFixed(2).replace('.', ',') + ' м — больше, чем вмещает Illustrator (5,7 м в одном файле). В один файл помещается до ' +
                   rowsMax * out.cols + ' шт.: разбейте тираж на ' + Math.ceil(r.Qty / (rowsMax * out.cols)) + ' файла(ов).';
        }
        return '';
    }

    function describe(p, r) {
        var out = {}, e = plan(p, r, out);
        if (e) return e;
        return 'По ширине ' + out.cols + ' шт., рядов ' + out.rows + (p.Rotated ? ', макеты повёрнуты' : '') + '. Длина ' + (p.SheetH / 1000).toFixed(2).replace('.', ',') + ' м, материала ' +
               (r.Width * p.SheetH / 1e6).toFixed(2).replace('.', ',') + ' кв. м. Выйдет ' + out.cols * out.rows + ' шт.' +
               (out.cols * out.rows > r.Qty ? ' (заказано ' + r.Qty + ', последний ряд добит до полного)' : '') + '.';
    }

    function blackFillOf(it) { it.filled = true; it.fillColor = cmykColor(0, 0, 0, 100); it.stroked = false; return it; }
    // прямоугольник: левый верх (x, y), мм от угла листа, y вниз
    function bar(g, R, x, y, w, h) { return blackFillOf(imRect(g, R, x, y, w, h)); }
    function dot(g, R, x, y, dd) { return blackFillOf(imEllipse(g, R, x, y, dd / 2)); }

    // SignMaster (ARMS 5.0): сплошные кружки Ø4 слева и справа от блока; пары через равный шаг ~300 мм;
    // треугольник-«верх» над серединой верхних меток; номера промежуточных — мелко у левого края, боком
    function signMaster(g, R, bl, br, bt, bb, dd, gap) {
        if (dd <= 0) dd = 4;
        var xl = bl - gap - dd / 2, xr = br + gap + dd / 2, n = Math.max(1, Math.round((bb - bt) / 300)), stp = (bb - bt) / n, i;
        for (i = 0; i <= n; i++) {
            var y = bt + stp * i;
            dot(g, R, xl, y, dd); dot(g, R, xr, y, dd);
            if (i > 0 && i < n) {
                var t = g.textFrames.pointText(imPt(R, xl, y));
                t.contents = String(i);
                try { t.textRange.characterAttributes.textFont = app.textFonts.getByName('ArialMT'); } catch (e) { }
                t.textRange.characterAttributes.size = 8.5;
                t.textRange.characterAttributes.fillColor = cmykColor(0, 0, 0, 100);
                t.rotate(90);
                var tb = t.geometricBounds, c = imPt(R, xl, y - dd / 2 + stp * 0.3285);
                t.translate(c[0] - (tb[0] + tb[2]) / 2, c[1] - tb[1]);
                try { t.createOutline(); } catch (e) { }
            }
        }
        var cx = (xl + xr) / 2, tri = g.pathItems.add();
        tri.setEntirePath([imPt(R, cx - dd / 2, bt - dd / 2), imPt(R, cx + dd / 2, bt - dd / 2), imPt(R, cx, bt - dd / 2 - dd * 0.866)]);
        tri.closed = true;
        blackFillOf(tri);
    }

    function marks(d, p, r, cols, rows, x0, y0) {
        var R = d.artboards[0].artboardRect, g = layerNamed(d, MARK_LAYER, true).groupItems.add();
        g.name = 'Метки ' + markName(r.Marks);
        var bl = x0, br = bl + cols * Impose.CellW(p) + (cols - 1) * p.GapX, bt = y0, bb = bt + rows * Impose.CellH(p) + (rows - 1) * p.GapY;
        var gap = r.MarkGap, m = r.MarkSize;
        if (r.Marks == 4) { signMaster(g, R, bl, br, bt, bb, m, gap); return; }
        // углы: снаружи блока на расстоянии MarkGap
        var corners = [[bl - gap, bt - gap, -1, -1], [br + gap, bt - gap, 1, -1], [bl - gap, bb + gap, -1, 1], [br + gap, bb + gap, 1, 1]];
        for (var i = 0; i < 4; i++) {
            var x = corners[i][0], y = corners[i][1], sx = corners[i][2], sy = corners[i][3];
            if (r.Marks == 3) {
                // Mimaki: уголок из двух полос толщиной 1 мм, вершина — наружу
                var tt = 1;
                bar(g, R, sx < 0 ? x - m : x, sy < 0 ? y - m : y + m - tt, m, tt);
                bar(g, R, sx < 0 ? x - m : x + m - tt, sy < 0 ? y - m : y, tt, m);
            } else bar(g, R, sx < 0 ? x - m : x, sy < 0 ? y - m : y, m, m);
        }
        // промежуточные по бокам — Summa и Graphtec читают метки вдоль длинной раскладки
        if (r.Marks != 3 && bb - bt > 2 * MID_STEP) {
            var n = Math.ceil((bb - bt) / MID_STEP);
            for (i = 1; i < n; i++) {
                var yy = bt + (bb - bt) * i / n;
                bar(g, R, bl - gap - m, yy - m / 2, m, m);
                bar(g, R, br + gap, yy - m / 2, m, m);
            }
        }
    }

    function cut(d, p, r, cols, rows, x0, y0) {
        var L = layerNamed(d, CUT_LAYER_ROLL, true), c = cutContourColor(d), R = d.artboards[0].artboardRect, k;
        L.printable = true;
        if (r.CutMode == 2) {
            // свой контур из макета: он уже разложен на слое CutContour — только перекрасить
            var lv = leavesOf(topItemsOn(d, L, -1));
            for (k = 0; k < lv.length; k++) {
                var ps = lv[k].typename == 'CompoundPathItem' ? lv[k].pathItems : [lv[k]];
                for (var q = 0; q < ps.length; q++) try { ps[q].filled = false; if (!ps[q].stroked) ps[q].strokeWidth = pt(0.1); ps[q].stroked = true; ps[q].strokeColor = c; } catch (e) { }
            }
            if (lv.length) return;
        }
        for (var i = 0; i < rows; i++) for (var j = 0; j < cols; j++) {
            var a = imPt(R, x0 + j * (Impose.CellW(p) + p.GapX), y0 + i * (Impose.CellH(p) + p.GapY));
            var s = L.pathItems.roundedRectangle(a[1], a[0], pt(Impose.CellW(p)), pt(Impose.CellH(p)), pt(p.Radius), pt(p.Radius));
            s.filled = false; s.stroked = true; s.strokeWidth = pt(0.1); s.strokeColor = c;
            s.name = 'Рез ' + (i * cols + j + 1);
        }
    }

    function run(p, r, outPath) {
        var d0 = app.activeDocument, sel = selectionItems(d0);
        if (!sel.length) return 'Сначала выделите макет вместе с вылетами.';
        var b = boundsOf(sel), out = {};
        p.CutW = mm(b[2] - b[0]) - 2 * p.Bleed; p.CutH = mm(b[1] - b[3]) - 2 * p.Bleed;
        var e = plan(p, r, out);
        if (e) return e;
        p.NoTemplate = true;
        var res = Impose.RunSelection(p, outPath);
        if (res.substring(0, 6) != 'Готово') return res;
        try {
            var d = app.activeDocument;
            d.artboards[0].name = 'Рулон';
            var o = Impose.Origin(p, out.cols, out.rows);
            if (r.CutMode > 0) cut(d, p, r, out.cols, out.rows, o.x, o.y);
            if (r.Marks > 0) marks(d, p, r, out.cols, out.rows, o.x, o.y);
            d.save();
        } catch (x) { logLine('сбой рулона: ' + x.message + ' (строка ' + x.line + ')'); return 'Раскладка сделана, но контур или метки не нарисовались: ' + x.message; }
        return 'Готово: рулон ' + mmText(r.Width) + ' мм, длина ' + (p.SheetH / 1000).toFixed(2).replace('.', ',') + ' м (' + (r.Width * p.SheetH / 1e6).toFixed(2).replace('.', ',') + ' кв. м), ' +
               out.cols + ' × ' + out.rows + ' = ' + out.cols * out.rows + ' шт.' + (r.CutMode > 0 ? ' Контур реза — плашка CutContour на слое «' + CUT_LAYER_ROLL + '».' : '') +
               (r.Marks > 0 ? ' Метки ' + markName(r.Marks) + '.' : '') + '\r\n' + outPath;
    }

    return { from: from, save: save, plan: plan, describe: describe, run: run, signMaster: signMaster, markName: markName };
})();

// «колонок|рядов|повёрнуто|длина|текст»
Bridge.RollInfo = function (params) {
    var p = Impose.ParamsFrom(params), r = Roll.from(params), out = {}, e = Roll.plan(p, r, out);
    if (e) return '0|0|0|0|' + e;
    return out.cols + '|' + out.rows + '|' + (p.Rotated ? 1 : 0) + '|' + p.SheetH + '|' + Roll.describe(Impose.ParamsFrom(params), r);
};
Bridge.ImposeRoll = function (params) {
    if (!PSA.has('WP')) return 'Раскладка на рулон входит в части «Рулонная печать» и «Плоттерная резка» — их нет в вашем ключе.';
    prepare();
    if (!hasDoc()) return 'Нет открытого документа.';
    var p = Impose.ParamsFrom(params), r = Roll.from(params), d = app.activeDocument, base = 'Макет', folder = '';
    Roll.save(r);
    Settings.set('Impose', 'Bleed', p.Bleed); Settings.set('Impose', 'Radius', p.Radius); Settings.set('Impose', 'GapX', p.GapX); Settings.set('Impose', 'GapY', p.GapY);
    try { folder = d.fullName.parent.fsName; base = d.name.replace(/\.[^.]*$/, ''); } catch (e) { }
    var f = outPath('roll', 'Сохранить раскладку на рулон', base + ' — рулон ' + r.Width + '.ai', folder);
    if (!f) return '';
    p.InfoText = f.replace(/^.*[\\\/]/, '');
    return Roll.run(p, r, f);
};
