// Вывод листов — как Engine.RunJob в CorelDRAW.
// Холст Illustrator — около 5,7 x 5,7 м: все листы заказа в один документ не помещаются. Поэтому каждый
// лист после подстановки номеров переносится во временный документ и сохраняется в PDF отдельно;
// «одним файлом» — потом листы склеиваются. Открытый документ не пересохраняется и не меняет имени.

function rectsMeet(a, r) { return a[0] < r[2] && a[2] > r[0] && a[1] > r[3] && a[3] < r[1]; }

// Печатаемое со стороны листа: верхние объекты видимых печатаемых слоёв, задевающие монтажную область,
// кроме карт без данных. Список собирается, пока исходник — текущий документ: у фонового Illustrator
// перебирает объекты в сотни раз медленнее (шаблон стола Central Park собирался больше двух минут)
function sideItems(src, ab, empty) {
    var r = src.artboards[ab].artboardRect, out = [];
    function walk(layer, path) {
        if (!layer.visible || !layer.printable) return;
        // объекты слоя — снизу вверх, чтобы в копии порядок наложения был тот же
        var items = layer.pageItems, list = [], i;
        for (i = 0; i < items.length; i++) if (items[i].parent == layer) list.push(items[i]);
        for (i = list.length - 1; i >= 0; i--) {
            var it = list[i];
            if (it.hidden) continue;
            if (it.typename == 'GroupItem' && empty[it.name + '|' + ab]) continue;
            if (!rectsMeet(visBounds(it), r)) continue;
            out.push({ it: it, path: path });
        }
        for (i = layer.layers.length - 1; i >= 0; i--) walk(layer.layers[i], path.concat([i]));
    }
    for (var l = src.layers.length - 1; l >= 0; l--) walk(src.layers[l], [l]);
    return out;
}

// Временный документ со сторонами листа (монтажные области sides — номера областей исходника)
function sheetDoc(src, sides, empty) {
    var plans = [], i, k;
    for (i = 0; i < sides.length; i++) plans.push(sideItems(src, sides[i], empty));
    var r0 = src.artboards[sides[0]].artboardRect;
    var t = app.documents.add(src.documentColorSpace, r0[2] - r0[0], r0[1] - r0[3]);
    t.artboards[0].artboardRect = r0;
    for (i = 1; i < sides.length; i++) t.artboards.add(src.artboards[sides[i]].artboardRect);
    // слои — те же, в том же порядке; вложенные — по мере надобности
    while (t.layers.length < src.layers.length) t.layers.add();
    for (i = 0; i < src.layers.length; i++) t.layers[i].name = src.layers[i].name;
    var subs = {};
    function layerFor(path) {
        var key = path.join('/');
        if (subs[key]) return subs[key];
        var L = t.layers[path[0]], S = src.layers[path[0]];
        for (var q = 1; q < path.length; q++) {
            S = S.layers[path[q]];
            var k2 = path.slice(0, q + 1).join('/');
            if (!subs[k2]) { var nl = L.layers.add(); nl.name = S.name; subs[k2] = nl; }
            L = subs[k2];
        }
        subs[key] = L;
        return L;
    }
    for (i = 0; i < plans.length; i++) for (k = 0; k < plans[i].length; k++) plans[i][k].it.duplicate(layerFor(plans[i][k].path), ElementPlacement.PLACEATBEGINNING);
    return t;
}

function savePdf(t, path, range) {
    var o = pdfOptions();
    o.artboardRange = range;
    // шрифт целиком, а не только нужные знаки: в каждом листе свои цифры, урезанный шрифт везде разный
    // и при склейке в один PDF повторялся бы в каждом листе; целый — один на весь файл
    o.fontSubsetThreshold = 0;
    t.saveAs(new File(path), o);
}

// Стороны, которые выводятся: 1, 3… — лица, 2, 4… — обороты; одна сторона — всегда
function sideWanted(i, n) {
    if (n < 2 || Engine.Sides == 0) return true;
    return Engine.Sides == 1 ? (i % 2 == 1) : (i % 2 == 0);
}

function sheetFileName(s) { return Engine.FilePrefix() + 'лист_' + zeroPad(String(s), 4) + '.pdf'; }

// Перепечатка — в начале имени файла, чтобы не перезаписать основной вывод
Engine.FilePrefix = function () { return this.Reprint ? 'Перепечатка — ' : ''; };

// После вывода: ведомость листов рядом с файлами и номера в журнал заказчика. Ответ — путь ведомости или ''.
Engine.AfterOutput = function (folder, a, b, total, scan) {
    var reg = '';
    try {
        if (this.Register && folder) reg = Records.WriteRegister(folder, a, b, total, this.FilePrefix(), scan);
        if (!this.Reprint) Records.JournalRecord(a, b, total, scan);
    } catch (e) { this.Errors.push('Ведомость или журнал: ' + e.message); }
    return reg;
};

// Группы карт раскладки по сторонам: { 'Карта N|сторона': [группы на всех слоях] } — чтобы прятать пустые
function cardGroups(d) {
    var m = {}, g = d.groupItems, i, it, k;
    for (i = 0; i < g.length; i++) {
        it = g[i];
        if (it.name.substring(0, 6) != 'Карта ' || it.parent.typename != 'Layer') continue;
        k = it.name + '|' + abIndexOf(d, it);
        (m[k] = m[k] || []).push(it);
    }
    return m;
}
function showCards(groups, empty, hide) {
    for (var k in empty) if (empty.hasOwnProperty(k) && groups[k]) for (var i = 0; i < groups[k].length; i++) groups[k][i].hidden = hide;
}

// mode: preview, pdf, tiff, print. a, b — листы с 1.
// Вывод идёт в копии файла: открытый документ не меняется (ни номера, ни имя). Каждый лист заполняется
// там и выводится своими монтажными областями; карты без данных на это время прячутся.
// Краски в копии готовятся один раз: для PDF — плашки с именами для печати и наложением, для TIFF — маски.
// Документ не сохранён — по-старому (только PDF): каждый лист переносится во временный документ.
Engine.RunJob = function (mode, a, b) {
    var d = app.activeDocument, why = {}, scan = scanFields(d), np = sidePages(d);
    if (!this.AsIs && !this.PrepareData()) return 'Не удалось загрузить данные:\r\n' + this.Errors.slice(0, 10).join('\r\n');
    var total = this.TotalSheets(why, scan);
    if (total == 0) { if (mode == 'preview') total = 1; else return 'Число листов не определить: ' + why.why + '.'; }
    if (a < 1) a = 1;
    if (b < 1 || b > total) b = total;
    if (mode == 'preview') {
        this.FillSheet(a - 1, a > total ? a : total, scan);
        app.redraw();
        return 'Лист ' + a + ' заполнен.';
    }
    var sides = [], i;
    for (i = 1; i <= np; i++) if (sideWanted(i, np)) sides.push(i - 1);
    if (!sides.length) return 'Нет сторон для вывода.';
    var printer = null;
    if (mode == 'print') { printer = askPrinter(); if (!printer) return 'Печать отменена.'; }

    var one = mode == 'pdf' && this.PdfOneFile, folder = '', tmp = [], jobs = [], done = 0, err = '';
    if (one) { folder = Folder.temp.fsName + '/PS Automation ' + new Date().getTime(); new Folder(folder).create(); }
    else if (mode == 'pdf') folder = this.PdfPath;
    else if (mode == 'tiff') folder = this.TiffFolder;

    // рабочая копия
    Progress.start(mode == 'pdf' ? 'Вывод в PDF' : (mode == 'tiff' ? 'Вывод в TIFF' : 'Печать'));
    Progress.step(0, b - a + 1, 'готовлю рабочую копию файла');
    var work = null, workFile = null, path = '';
    try { path = d.fullName.fsName; } catch (e) { }
    if (d.saved && path && /\.ai$/i.test(path) && new File(path).exists) {
        workFile = new File(Folder.temp.fsName + '/psa_out_' + new Date().getTime() + '.ai');
        if (new File(path).copy(workFile)) {
            var old = app.userInteractionLevel;
            app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
            try { work = app.open(workFile); } catch (e) { work = null; }
            app.userInteractionLevel = old;
        }
    }
    if (!work && mode != 'pdf') return 'Для вывода в ' + (mode == 'tiff' ? 'TIFF' : 'печать') + ' сохраните документ (Файл — Сохранить) и выведите снова.';
    var inkNote = '';
    if (work) {
        try {
            if (mode == 'tiff') Inks.PrepareTiff(work, sides);
            else Inks.PreparePdf(work, sides);
        } catch (e) { inkNote = ' (краски не подготовились: ' + e.message + ')'; }
    }
    var wscan = work ? scanFields(work) : scan, plan = this.AsIs ? null : this.BuildPlan(wscan), groups = work ? cardGroups(work) : null;
    var range = [];
    for (i = 0; i < sides.length; i++) range.push(sides[i] + 1);
    var digits = String(total).length;
    try {
        for (var s = a; s <= b; s++) {
            if (Progress.stopped()) { err = 'Остановлено кнопкой «Стоп».'; break; }
            Progress.step(done, b - a + 1, 'лист № ' + s);
            var empty = this.AsIs ? {} : this.FillSheet(s - 1, total, wscan, plan);
            if (work) showCards(groups, empty, true);
            if (mode == 'pdf') {
                var p = folder + '/' + (one ? zeroPad(String(s), 5) + '.pdf' : sheetFileName(s));
                if (work) savePdf(work, p, range.join(','));
                else { var t = sheetDoc(d, sides, empty); savePdf(t, p, '1-' + sides.length); t.close(SaveOptions.DONOTSAVECHANGES); d.activate(); }
                tmp.push(p);
            } else if (mode == 'tiff') {
                for (i = 0; i < sides.length; i++) jobs.push(tiffSide(work, sides[i], s, digits, np));
            } else {
                printSides(work, range.join(','), printer);
            }
            if (work) showCards(groups, empty, false);
            done++;
        }
    } catch (e) {
        err = 'Сбой на листе ' + (a + done) + ': ' + e.message;
        logLine('сбой вывода: ' + e.message + ' (строка ' + e.line + ')');
        try { if (!work && app.activeDocument != d) app.activeDocument.close(SaveOptions.DONOTSAVECHANGES); } catch (x) { }
    }
    if (work) {
        try { work.close(SaveOptions.DONOTSAVECHANGES); } catch (x) { }
        try { workFile.remove(); } catch (x) { }
    }
    Progress.end();
    try { d.activate(); } catch (x) { }
    var NL = '\r\n', reg = '', rng = a == b ? ' (лист ' + a + ')' : ' (листы ' + a + '–' + b + ')';
    var sidesTxt = np > 1 && this.Sides ? (this.Sides == 1 ? ', только лица' : ', только обороты') : '';
    if (done > 0 && this.Fields.length && !this.AsIs) {
        var rf = mode == 'pdf' ? (one ? new File(this.PdfPath).parent.fsName : this.PdfPath) : (mode == 'tiff' ? this.TiffFolder : (path ? new File(path).parent.fsName : ''));
        reg = this.AfterOutput(rf, a, a + done - 1, total, scan);
    }
    var msg, inks = Inks.OutText();
    if (mode == 'pdf') msg = 'Сохранено в PDF листов: ' + done + ' из ' + (b - a + 1) + rng + sidesTxt + (inks && work ? ', спецкраски плашками ' + inks : '') +
                             (Inks.Mirror ? ', зеркально' : '') + pdfOptText() + '.' + NL + this.PdfPath;
    else if (mode == 'tiff') msg = 'Сохранено в TIFF листов: ' + done + ' из ' + (b - a + 1) + rng + sidesTxt + ', ' + this.TiffDpi + ' dpi, CMYK' +
                                   (inks ? ' + каналы ' + inks : '') + (Inks.Mirror ? ', зеркально' : '') + rotText() + '.' + NL + this.TiffFolder;
    else msg = 'Отправлено на печать листов: ' + done + ' из ' + (b - a + 1) + rng + sidesTxt + ' (' + printer.name + ').';
    if ((this.Fields.length == 0 || this.AsIs)) msg = msg.replace('листов: ' + done + ' из ' + (b - a + 1) + rng, 'страниц: ' + sides.length);
    if (inkNote) msg += inkNote;
    if (this.Reprint) msg = 'Перепечатка брака: карт ' + this.Reprint.length + '.' + NL + msg;
    if (reg) msg += NL + 'Ведомость листов: ' + reg;
    if (err) msg = err + NL + msg;
    if (this.Errors.length) msg += NL + NL + 'Были ошибки (' + this.Errors.length + '):' + NL + this.Errors.slice(0, 12).join(NL);
    // один PDF и TIFF доделывает панель: склейка листов, склейка фона с каналами красок
    if (one && done > 0) return '\u0001merge|' + toJson({ out: this.PdfPath, files: tmp, folder: folder, msg: msg });
    if (mode == 'tiff' && jobs.length) return '\u0001tiff|' + toJson({ jobs: jobs, rot: tiffRotate(), msg: msg });
    return msg;
};

// ---------- TIFF ----------

function tiffRotate() { return Math.round(toNum(Settings.get('Output', 'Rotate', '0'), 0)); }
function rotText() { var r = tiffRotate(); return r == 90 ? ', повёрнуты на 90° по часовой' : (r == -90 ? ', повёрнуты на 90° против часовой' : ''); }

function sideFileName(d, ab) {
    var n = d.artboards[ab].name.replace(/^Лист — /, '');
    return (n || 'стр ' + (ab + 1)).replace(/[\\\/:*?"<>|]/g, '-');
}

// Выгрузить монтажную область ab в TIFF (cmyk или серой шкалой). Illustrator дописывает к имени файла
// имя области — поэтому во временную папку, а потом найти, что получилось.
function exportTiff(d, ab, path, gray) {
    var dir = new Folder(Folder.temp.fsName + '/psa_tif_' + new Date().getTime() + '_' + Math.floor(Math.random() * 1e6));
    dir.create();
    var o = new ExportOptionsTIFF();
    o.imageColorSpace = gray ? ImageColorSpace.GrayScale : ImageColorSpace.CMYK;
    o.resolution = Engine.TiffDpi;
    o.antiAliasing = AntiAliasingMethod.ARTOPTIMIZED;
    o.lZWCompression = true;
    o.saveMultipleArtboards = true;
    o.artboardRange = String(ab + 1);
    d.exportFile(new File(dir.fsName + '/x.tif'), ExportType.TIFF, o);
    var got = dir.getFiles('*.tif');
    if (!got.length) throw new Error('Illustrator не записал TIFF');
    var f = new File(path);
    if (f.exists) f.remove();
    got[0].copy(f);
    for (var i = 0; i < got.length; i++) got[i].remove();
    dir.remove();
    return f.fsName;
}

// Одна сторона листа: фон (всё, кроме спецкрасок) и маска каждой включённой краски. Ответ — задание склейки.
function tiffSide(d, ab, sheetNo, digits, np) {
    var base = Engine.TiffFolder.replace(/[\\\/]$/, '');
    if (Engine.SideFolders && np >= 2) { base += '/' + (ab % 2 == 0 ? 'Лица' : 'Обороты'); new Folder(base).create(); }
    var name = Engine.FilePrefix() + 'Лист ' + zeroPad(String(sheetNo), digits) + ' — ' + sideFileName(d, ab);
    var tmp = Folder.temp.fsName + '/VarPrint_' + zeroPad(String(sheetNo), 4) + '_' + (ab + 1);
    var vis = [], i, k, job = { out: new File(base + '/' + name + '.tif').fsName, fon: '', masks: [] };
    for (k = 0; k < d.layers.length; k++) vis.push(d.layers[k].visible);
    try {
        // фон: печатаемые слои без спецкрасок и без служебных непечатаемых
        for (k = 0; k < d.layers.length; k++) { var L = d.layers[k]; L.visible = vis[k] && L.printable && !Inks.IsInkLayer(L.name); }
        job.fon = exportTiff(d, ab, tmp + '_fon.tif', false);
        for (i = 1; i <= INK_COUNT; i++) {
            if (!Inks.Active(i)) continue;
            var nm = Inks.ByColor[i] ? INK_TMP_LAYER + i : Inks.LayerName[i], lay = null;
            for (k = 0; k < d.layers.length; k++) if (d.layers[k].name == nm) lay = d.layers[k];
            if (!lay || !topItemsOn(d, lay, ab).length) continue;
            for (k = 0; k < d.layers.length; k++) d.layers[k].visible = d.layers[k] == lay;
            job.masks.push([exportTiff(d, ab, tmp + '_ink' + i + '.tif', true), Inks.OutName[i]]);
        }
    } finally {
        for (k = 0; k < d.layers.length; k++) d.layers[k].visible = vis[k];
    }
    return job;
}

// ---------- печать ----------

// Выбор принтера и числа копий — окно Illustrator. null — отказались.
function askPrinter() {
    var list = [], i;
    try { for (i = 0; i < app.printerList.length; i++) list.push(app.printerList[i].name); } catch (e) { }
    if (!list.length) { alert('Не найдено ни одного принтера.', 'Печать'); return null; }
    var w = new Window('dialog', 'Печать — PS • Автоматизация');
    w.add('statictext', undefined, 'Принтер:');
    var dd = w.add('dropdownlist', undefined, list);
    var last = Settings.get('Out', 'Printer', '');
    dd.selection = 0;
    for (i = 0; i < list.length; i++) if (list[i] == last) dd.selection = i;
    var g = w.add('group'); g.add('statictext', undefined, 'Копий каждого листа:');
    var cp = g.add('edittext', undefined, '1'); cp.characters = 4;
    var bt = w.add('group'); bt.add('button', undefined, 'Печатать', { name: 'ok' }); bt.add('button', undefined, 'Отмена', { name: 'cancel' });
    if (w.show() != 1) return null;
    Settings.set('Out', 'Printer', dd.selection.text);
    return { name: dd.selection.text, copies: Math.max(1, Math.round(toNum(cp.text, 1))) };
}

function printSides(d, range, printer) {
    var o = new PrintOptions(), j = new PrintJobOptions();
    j.printerName = printer.name;
    j.copies = printer.copies;
    j.printArea = PrintingBounds.ARTBOARDBOUNDS;
    j.printAllArtboards = false;
    j.artboardRange = range;
    o.jobOptions = j;
    o.printerName = printer.name;
    d.print(o);
}

// ---------- PDF по профилю принтера ----------

function pdfOptText() {
    var v = Settings.get('Output', 'PdfVer', '15');
    return ', PDF ' + (v == 'x4' ? 'X-4' : v.charAt(0) + '.' + v.substring(1)) + (Settings.get('Output', 'PdfCmyk', '1') == '1' ? ', CMYK' : '');
}
function pdfOptions() {
    var o = new PDFSaveOptions(), v = Settings.get('Output', 'PdfVer', '15');
    o.compatibility = v == '14' ? PDFCompatibility.ACROBAT5 : (v == '17' ? PDFCompatibility.ACROBAT8 : (v == 'x4' ? PDFCompatibility.ACROBAT7 : PDFCompatibility.ACROBAT6));
    if (v == 'x4') try { o.pDFXStandard = PDFXStandard.PDFX42007; } catch (e) { }
    o.preserveEditability = false;
    o.generateThumbnails = false;
    o.viewAfterSaving = false;
    o.acrobatLayers = false;
    o.fontSubsetThreshold = 100;
    if (Settings.get('Output', 'PdfCmyk', '1') == '1') try { o.colorConversionID = ColorConversion.COLORCONVERSIONREPURPOSE; o.colorDestinationID = ColorDestination.COLORDESTINATIONWORKINGCMYK; } catch (e) { }   // CMYK как есть, RGB — в CMYK
    if (Settings.get('Output', 'PdfNoDown', '1') == '1') try {
        o.colorDownsamplingMethod = DownsampleMethod.NODOWNSAMPLE; o.grayscaleDownsamplingMethod = DownsampleMethod.NODOWNSAMPLE; o.monochromeDownsamplingMethod = DownsampleMethod.NODOWNSAMPLE;
    } catch (e) { }
    return o;
}

// ---------- профили принтеров (как в CorelDRAW: список хранит панель) ----------

Bridge.PrinterList = function () { return Settings.get('Printers', 'List', '') + '\n' + Settings.get('Printers', 'Active', ''); };
Bridge.PrinterSave = function (json, active) { Settings.set('Printers', 'List', json); Settings.set('Printers', 'Active', active); return 'ok'; };
// p: fmt, dpi, rot, w, v, mark, mir, ver, curves, cmyk, nodown, crop — «ключ=значение|…»
Bridge.PrinterApply = function (p) {
    prepare();
    var c = parseKV(p), G = function (k, d) { return c.hasOwnProperty(k) ? c[k] : d; };
    Settings.set('Output', 'Format', G('fmt', 'tiff')); Settings.set('Output', 'Rotate', Math.round(toNum(G('rot', '0'), 0)));
    Settings.set('Output', 'PdfVer', G('ver', '15')); Settings.set('Output', 'PdfCurves', G('curves', '1'));
    Settings.set('Output', 'PdfCmyk', G('cmyk', '1')); Settings.set('Output', 'PdfNoDown', G('nodown', '1')); Settings.set('Output', 'CropContent', G('crop', '0'));
    if (hasDoc()) {
        Engine.TiffDpi = Math.max(72, Math.round(toNum(G('dpi', '720'), 720)));
        if (trimS(G('w', ''))) Inks.OutName[1] = trimS(G('w', ''));
        if (trimS(G('v', ''))) Inks.OutName[2] = trimS(G('v', ''));
        // как отмечены в макете: плашками или слоями (какой цвет в макете — не трогаем)
        var mk = G('mark', '');
        if (mk == 'spot') {
            Inks.ByColor[1] = true; if (!trimS(Inks.SpotName[1])) Inks.SpotName[1] = Inks.OutName[1];
            Inks.ByColor[2] = true; if (!trimS(Inks.SpotName[2])) Inks.SpotName[2] = Inks.OutName[2];
        } else if (mk == 'layer') { Inks.ByColor[1] = false; Inks.ByColor[2] = false; }
        Inks.Mirror = G('mir', '0') == '1';
        Engine.SaveConfig();
        Inks.SaveDefaults();
    }
    return 'ok';
};
