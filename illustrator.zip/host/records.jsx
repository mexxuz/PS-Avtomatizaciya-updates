// Записи заказа — как src/Records.bas: перепечатка брака, ведомость листов, журнал выпущенных номеров,
// проверка файла клиента. Журнал — та же папка, что у CorelDRAW: номера, выпущенные из любой программы,
// видны в обеих.

var Records = {};

function trimS(s) { return String(s).replace(/^\s+|\s+$/g, ''); }
function digitsOf(v) { return String(v).replace(/\D/g, ''); }

// Ключевое поле — первое не-картинка (по нему ищут брак и ведут журнал)
Records.KeyField = function () {
    for (var i = 0; i < Engine.Fields.length; i++) if (Engine.Fields[i].Kind != 'pic') return Engine.Fields[i];
    return Engine.Fields.length ? Engine.Fields[0] : null;
};

// Сравнение без пробелов и регистра: «100 000 123» = «100000123»
Records.Norm = function (v) { return trimS(String(v).replace(/[   \t]/g, '')).toUpperCase(); };

Records.HasRecord = function (f, rec) {
    if (rec < 0) return false;
    if (f.Count() >= 0 && rec >= f.Count()) return false;
    if (Engine.DataEnd >= 0 && rec >= Engine.DataEnd) return false;
    return true;
};

function docBase() {
    var n = app.activeDocument.name.replace(/\.[^.]*$/, '');
    return n || 'раскладка';
}

// ---------- перепечатка брака ----------

// Список: через запятую, точку с запятой или с новой строки; «120–125» — диапазон (до 2000 номеров)
Records.ParseList = function (text) {
    var out = [], parts = String(text).replace(/[;\r\n]/g, ',').split(','), i, t, m;
    for (i = 0; i < parts.length; i++) {
        t = trimS(parts[i]);
        if (!t) continue;
        m = /^(\d+)[-–—](\d+)$/.exec(t.replace(/ /g, ''));
        if (m) {
            var a = parseFloat(m[1]), b = parseFloat(m[2]), w = m[1].length;
            if (b >= a && b - a <= 2000) { for (var x = a; x <= b; x++) out.push(zeroPad(String(x), w)); continue; }
        }
        out.push(t);
    }
    return out;
};

// Записи по значениям (во всех полях с текстом и кодами); rep.text — что где было и что не нашлось
Records.FindReprint = function (text, rep, scan) {
    var items = this.ParseList(text), out = [];
    if (!items.length) { rep.text = 'Впишите номера испорченных карт.'; return out; }
    var d = {}, dd = {}, got = {}, i, j, f, s, miss = [], lst = '';
    for (j = 0; j < Engine.Fields.length; j++) {
        f = Engine.Fields[j];
        if (f.Kind == 'pic' || f.Source != 1 || !f.Loaded) continue;
        for (i = 0; i < f.ValuesCount; i++) {
            s = this.Norm(f.ValueAt(i));
            if (s && !d.hasOwnProperty(s)) d[s] = i;
            s = digitsOf(s);
            if (s && !dd.hasOwnProperty(s)) dd[s] = i;
        }
    }
    var total = Engine.TotalSheets({}, scan), kf = this.KeyField(), per = Engine.FieldPlaces(kf.Id, scan);
    for (var k = 0; k < items.length; k++) {
        var rec = -1;
        s = this.Norm(items[k]);
        if (d.hasOwnProperty(s)) rec = d[s];
        else if (dd.hasOwnProperty(digitsOf(s))) rec = dd[digitsOf(s)];
        else {
            // нумерация по порядку: номер -> запись арифметикой
            for (j = 0; j < Engine.Fields.length; j++) {
                f = Engine.Fields[j];
                if (f.Kind == 'pic' || f.Source != 0 || f.NumStep == 0) continue;
                var v = this.Norm(items[k]), pr = this.Norm(f.Prefix), su = this.Norm(f.Suffix);
                if (pr && v.substring(0, pr.length) == pr) v = v.substring(pr.length);
                if (su && v.substring(v.length - su.length) == su) v = v.substring(0, v.length - su.length);
                v = digitsOf(v);
                if (v && v.length < 16) {
                    var x = (parseFloat(v) - f.NumStart) / f.NumStep;
                    if (x >= 0 && x == Math.floor(x) && (!f.HasEnd || x < f.Count())) { rec = x; break; }
                }
            }
        }
        if (rec < 0) miss.push(items[k]);
        else if (!got[rec]) {
            got[rec] = 1;
            out.push(rec);
            var r0 = rec - (Engine.StartRecord - 1);
            if (per > 0 && total > 0 && r0 >= 0) {
                var sh, pl;
                if (Engine.OrderStack) { sh = (r0 % total) + 1; pl = Math.floor(r0 / total) + 1; } else { sh = Math.floor(r0 / per) + 1; pl = (r0 % per) + 1; }
                lst += '\r\n  ' + kf.ValueAt(rec) + ' — лист ' + sh + ', место ' + pl;
            } else lst += '\r\n  ' + kf.ValueAt(rec);
        }
    }
    var t = 'Найдено ' + out.length + ' из ' + items.length + '.' + lst;
    if (items.length - miss.length > out.length) t += '\r\nОдна и та же карта указана несколько раз — выведется один раз.';
    if (miss.length) t += '\r\nНе найдено (' + miss.length + '): ' + miss.join(', ');
    if (out.length && per > 0) t += '\r\nПерепечатка — листов: ' + Math.ceil(out.length / per) + ' (карты подряд с первого места).';
    rep.text = t;
    return out;
};

// ---------- ведомость листов ----------

function csvCell(v) {
    v = String(v);
    var c = (v.indexOf(';') >= 0 || v.indexOf('"') >= 0) ? '"' + v.replace(/"/g, '""') + '"' : v;
    // Excel не должен превращать длинный номер в 1,00E+08: номер из цифр — как текст
    if (v.length > 10 && /^\d+$/.test(v)) c = '="' + v + '"';
    return c;
}

Records.WriteRegister = function (folder, fromSheet, toSheet, total, prefix, scan) {
    var kf = this.KeyField();
    if (!kf) return '';
    var per = Engine.FieldPlaces(kf.Id, scan), maxP = 0, head = '', i, f, places = [];
    for (i = 0; i < Engine.Fields.length; i++) {
        f = Engine.Fields[i]; places[i] = Engine.FieldPlaces(f.Id, scan);
        if (places[i] > maxP) maxP = places[i];
        head += ';Поле ' + f.Id + ' — ' + f.KindName();
    }
    var NL = '\r\n', t1 = 'Лист;Карт на листе;С записи;По запись;Первый номер;Последний номер' + NL, t2 = 'Лист;Место;Запись' + head + NL;
    for (var s = fromSheet - 1; s <= toSheet - 1; s++) {
        var a = '', b = '', ra = 0, rb = 0, cnt = 0;
        for (var p = 0; p < maxP; p++) {
            var row = '', anyV = false, rec, v;
            for (i = 0; i < Engine.Fields.length; i++) {
                f = Engine.Fields[i]; v = '';
                if (p < places[i]) {
                    rec = Engine.RecordIndex(s, p, places[i], total);
                    if (this.HasRecord(f, rec)) { v = f.ValueAt(rec); if (trimS(v)) anyV = true; }
                }
                row += ';' + csvCell(v);
            }
            if (!anyV) continue;
            rec = Engine.RecordIndex(s, p, per, total);
            t2 += (s + 1) + ';' + (p + 1) + ';' + (rec >= 0 ? rec + 1 : '') + row + NL;
            if (p < per && this.HasRecord(kf, rec)) {
                cnt++;
                if (a == '') { a = kf.ValueAt(rec); ra = rec + 1; }
                b = kf.ValueAt(rec); rb = rec + 1;
            }
        }
        t1 += (s + 1) + ';' + cnt + ';' + ra + ';' + rb + ';' + csvCell(a) + ';' + csvCell(b) + NL;
    }
    // с меткой BOM — Excel узнаёт UTF-8
    var base = folder + '/' + prefix + docBase();
    writeText(base + ' — ведомость листов.csv', '﻿' + t1);
    writeText(base + ' — все карты.csv', '﻿' + t2);
    return new File(base + ' — ведомость листов.csv').fsName;
};

// ---------- журнал выпущенных номеров ----------

Records.JournalDir = function () { return Folder.userData.fsName + '/PS-Avtomatizaciya/Журнал номеров'; };

Records.ClientName = function () {
    var c = trimS(Engine.Client);
    if (!c && hasDoc()) { c = docBase(); if (c.indexOf(' — ') > 0) c = c.substring(0, c.indexOf(' — ')); }
    return c;
};

function journalFile(client) { return Records.JournalDir() + '/' + client.replace(/[\\\/:*?"<>|]/g, '-') + '.txt'; }

Records.LoadJournal = function (client) {
    var d = { _n: 0 }, t = readText(journalFile(client)), lines = t.replace(/\r/g, '').split('\n');
    for (var i = 0; i < lines.length; i++) {
        var p = lines[i].indexOf('\t');
        if (p > 0) { var k = lines[i].substring(0, p); if (!d.hasOwnProperty('#' + k)) { d['#' + k] = lines[i].substring(p + 1); d._n++; } }
    }
    return d;
};

// Номера ключевого поля на листах from..to, каждый по разу
Records.SheetValues = function (fromSheet, toSheet, total, scan) {
    var c = [], kf = this.KeyField(), seen = {};
    if (!kf) return c;
    var per = Engine.FieldPlaces(kf.Id, scan);
    for (var s = fromSheet - 1; s <= toSheet - 1; s++)
        for (var p = 0; p < per; p++) {
            var rec = Engine.RecordIndex(s, p, per, total);
            if (!this.HasRecord(kf, rec)) continue;
            var v = this.Norm(kf.ValueAt(rec));
            if (v && !seen[v]) { seen[v] = 1; c.push(v); }
        }
    return c;
};

// Номер уже выпускался другим файлом (повторный вывод этого же файла — не повтор)
function otherFile(d, v) {
    if (!d.hasOwnProperty('#' + v)) return false;
    var e = d['#' + v];
    return e.substring(e.indexOf('\t') + 1) != app.activeDocument.name;
}

Records.JournalOverlap = function (fromSheet, toSheet, total, ex, scan) {
    var d = this.LoadJournal(this.ClientName()), n = 0, vals, i;
    ex.text = '';
    if (!d._n) return 0;
    vals = this.SheetValues(fromSheet, toSheet, total, scan);
    for (i = 0; i < vals.length; i++) if (otherFile(d, vals[i])) {
        n++;
        if (n <= 5) ex.text += '\r\n  ' + vals[i] + ' — ' + d['#' + vals[i]].replace(/\t/g, ', ');
    }
    return n;
};

Records.JournalRecord = function (fromSheet, toSheet, total, scan) {
    if (!this.KeyField()) return 0;
    var dir = new Folder(this.JournalDir());
    if (!dir.exists) { new Folder(dir.parent.fsName).create(); dir.create(); }
    var d = this.LoadJournal(this.ClientName()), now = new Date(), z = function (n) { return (n < 10 ? '0' : '') + n; };
    var stamp = z(now.getDate()) + '.' + z(now.getMonth() + 1) + '.' + now.getFullYear() + ' ' + z(now.getHours()) + ':' + z(now.getMinutes()) + '\t' + app.activeDocument.name;
    var vals = this.SheetValues(fromSheet, toSheet, total, scan), t = '', n = 0;
    for (var i = 0; i < vals.length; i++) if (!d.hasOwnProperty('#' + vals[i])) { d['#' + vals[i]] = stamp; t += vals[i] + '\t' + stamp + '\r\n'; n++; }
    if (n) writeText(journalFile(this.ClientName()), t, true);
    return n;
};

Records.JournalInfo = function (scan) {
    if (!this.KeyField()) return '';
    var d = this.LoadJournal(this.ClientName()), total = Engine.TotalSheets({}, scan), cl = this.ClientName();
    if (!total) return '';
    if (!d._n) return '0|Для «' + cl + '» номера ещё не выпускались.';
    var vals = this.SheetValues(1, total, total, scan), n = 0, ex = [];
    for (var i = 0; i < vals.length; i++) if (otherFile(d, vals[i])) { n++; if (n <= 3) ex.push(vals[i]); }
    if (!n) return '0|Для «' + cl + '» уже выпущено номеров: ' + d._n + '. Этот заказ с ними не повторяется.';
    return n + '|Внимание: ' + n + ' номеров этого заказа уже печатались для «' + cl + '» (' + ex.join(', ') + (n > 3 ? '…' : '') + ').';
};

// ---------- проверка файла клиента ----------
// Повторы, пустые, другой длины, лишние знаки в номерах, пропуски, длиннее образца, годится ли для кода

Records.CheckData = function (f, scan) {
    if (f.Source != 1) return 'ok|Номера идут по порядку — повторов и пропусков быть не может.';
    f.Loaded = false;
    var e = DataIO.LoadField(f);
    if (e) return 'bad|' + e;
    var n = f.ValuesCount;
    if (n <= 0) return 'bad|В выбранном столбце нет данных.';
    var first = f.FirstRow < 1 ? 1 : f.FirstRow;
    if (first == 1 && f.HasHeader) first = 2;
    var d = {}, lens = {}, sample = 0, i, v;
    var list = Engine.FieldShapes(f.Id, scan);
    if (list.length && list[0].typename == 'TextFrame') sample = list[0].contents.length;
    var empt = [], nEmpt = 0, dup = '', nDup = 0, nNum = 0, lng = [], nLng = 0, codeBad = '', nCode = 0;
    for (i = 0; i < n; i++) {
        v = trimS(f.Values[i]);
        if (!v) { nEmpt++; if (nEmpt <= 8) empt.push(first + i); continue; }
        if (d.hasOwnProperty('#' + v)) { nDup++; if (nDup <= 5) dup += '\r\n  «' + v + '» — строки ' + d['#' + v] + ' и ' + (first + i); }
        else d['#' + v] = first + i;
        lens[v.length] = (lens[v.length] || 0) + 1;
        if (digitsOf(v) == v) nNum++;
        if (sample > 0 && f.ApplyMask(v).length > sample + 2) { nLng++; if (nLng <= 5) lng.push(first + i); }
        if (f.Kind == 'code') {
            var why = Records.CodeProblem(f.CodeType, v);
            if (why) { nCode++; if (nCode <= 5) codeBad += '\r\n  строка ' + (first + i) + ': «' + v + '» — ' + why; }
        }
    }
    var modeLen = 0, best = 0, k;
    for (k in lens) if (lens.hasOwnProperty(k) && lens[k] > best) { best = lens[k]; modeLen = +k; }
    var isNum = nNum >= (n - nEmpt) * 0.9;
    if (!isNum && f.Kind != 'code') { nDup = 0; dup = ''; }
    var bad = '';
    if (isNum && nNum < n - nEmpt)
        for (i = 0; i < n; i++) {
            v = trimS(f.Values[i]);
            if (v && digitsOf(v) != v) { bad += ', ' + (first + i) + ' («' + v + '»)'; if (bad.length > 200) { bad += '…'; break; } }
        }
    var mn = 1e300, mx = -1e300, nd = {}, ndN = 0, oddLen = [], nOdd = 0, x;
    for (i = 0; i < n; i++) {
        v = trimS(f.Values[i]);
        if (isNum && v && v.length != modeLen) { nOdd++; if (nOdd <= 6) oddLen.push((first + i) + ' («' + v + '»)'); }
        if (isNum && v.length == modeLen && modeLen < 16 && digitsOf(v) == v) {
            x = parseFloat(v);
            if (x < mn) mn = x;
            if (x > mx) mx = x;
            if (!nd[v]) { nd[v] = 1; ndN++; }
        }
    }
    var gaps = [], nGap = 0;
    if (isNum && mx >= mn && mx - mn < 500000) {
        var span = mx - mn + 1;
        if (span - ndN > 0 && span - ndN <= span * 0.1)
            for (x = mn; x <= mx; x++) {
                var fx = zeroPad(String(x), modeLen);
                if (!d.hasOwnProperty('#' + fx) && !d.hasOwnProperty('#' + String(x))) { nGap++; if (nGap <= 8) gaps.push(fx); }
            }
    }
    var NL = '\r\n', t = 'Строк с данными: ' + n + ' (строки ' + first + '–' + (first + n - 1) + ' файла).';
    if (nDup) t += NL + '• Повторы: ' + nDup + dup + (nDup > 5 ? NL + '  …' : '');
    if (nEmpt) t += NL + '• Пустые строки: ' + nEmpt + ' (' + empt.join(', ') + (nEmpt > 8 ? '…' : '') + ') — на этих картах поле будет пустым.';
    if (nOdd) t += NL + '• Другой длины, чем обычно (' + modeLen + ' знаков): ' + nOdd + ' — строки ' + oddLen.join(', ') + (nOdd > 6 ? '…' : '');
    if (bad) t += NL + '• Не только цифры, хотя остальные — цифры: строки ' + bad.substring(2);
    if (nGap) t += NL + '• Пропуски в номерах: ' + nGap + ' (' + gaps.join(', ') + (nGap > 8 ? '…' : '') + ')';
    if (nLng) t += NL + '• Длиннее образца на карте: ' + nLng + ' — строки ' + lng.join(', ') + (nLng > 5 ? '…' : '') + ' — могут не влезть в поле.';
    if (nCode) t += NL + '• Не годятся для кода ' + f.CodeType + ': ' + nCode + codeBad;
    if (!nDup && !nEmpt && !nOdd && !nGap && !nLng && !nCode && !bad) return 'ok|' + t + NL + 'Повторов, пропусков и пустых строк нет.';
    return 'bad|' + t;
};

// Годится ли значение для вида кода; '' — годится
Records.CodeProblem = function (kind, v) {
    var n = v.length, i, c, num = digitsOf(v) == v;
    switch (kind) {
        case 'EAN-13':
            if (!num) return 'нужны только цифры';
            if (n != 12 && n != 13) return 'нужно 12 или 13 цифр, а их ' + n;
            if (n == 13 && v.charAt(12) != Records.CheckDigit(v.substring(0, 12))) return 'неверная контрольная цифра (должна быть ' + Records.CheckDigit(v.substring(0, 12)) + ')';
            break;
        case 'EAN-8':
            if (!num) return 'нужны только цифры';
            if (n != 7 && n != 8) return 'нужно 7 или 8 цифр, а их ' + n;
            if (n == 8 && v.charAt(7) != Records.CheckDigit(v.substring(0, 7))) return 'неверная контрольная цифра (должна быть ' + Records.CheckDigit(v.substring(0, 7)) + ')';
            break;
        case 'UPC-A':
            if (!num) return 'нужны только цифры';
            if (n != 11 && n != 12) return 'нужно 11 или 12 цифр, а их ' + n;
            break;
        case 'ITF-14':
            if (!num) return 'нужны только цифры';
            if (n != 13 && n != 14) return 'нужно 13 или 14 цифр, а их ' + n;
            break;
        case 'Code 39':
            for (i = 0; i < n; i++) {
                c = v.charAt(i).toUpperCase();
                if ('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%'.indexOf(c) < 0) return 'знак «' + v.charAt(i) + '» нельзя: только латиница, цифры и - . $ / + %';
            }
            break;
        case 'Code 128': case 'GS1-128':
            for (i = 0; i < n; i++) if (v.charCodeAt(i) > 127) return 'знак «' + v.charAt(i) + '» нельзя: только латиница, цифры и знаки';
            break;
    }
    return '';
};

// Контрольная цифра EAN/UPC (веса 3 и 1 справа налево)
Records.CheckDigit = function (body) {
    var s = 0, w = 3;
    for (var i = body.length - 1; i >= 0; i--) { s += parseInt(body.charAt(i), 10) * w; w = 4 - w; }
    return String((10 - (s % 10)) % 10);
};

// ---------- команды панели ----------

Bridge.CheckData = function (id) {
    if (!PSA.has('D')) return 'bad|' + require_('D');
    prepare();
    var f = Engine.FieldById(+id);
    if (!f) return '';
    return Records.CheckData(f, scanFields(app.activeDocument));
};

Bridge.JournalInfo = function () {
    prepare();
    if (!hasDoc() || !Engine.Fields.length) return '';
    Engine.PrepareData();
    return Records.JournalInfo(scanFields(app.activeDocument));
};

Bridge.JournalOpen = function () {
    var d = new Folder(Records.JournalDir());
    if (!d.exists) return 'Журнал пока пуст: номера ещё не выводились.';
    d.execute();
    return 'ok';
};

Bridge.ReprintFind = function (text) {
    prepare();
    if (!hasDoc() || !Engine.Fields.length) return '0|Нет полей с номерами.';
    Engine.PrepareData();
    var rep = {}, c = Records.FindReprint(text, rep, scanFields(app.activeDocument));
    return c.length + '|' + rep.text;
};

Bridge.RunReprint = function (mode, text) {
    if (!PSA.has('D')) return require_('D');
    prepare();
    if (!hasDoc() || !Engine.Fields.length) return 'Нет полей с номерами.';
    if (!Engine.PrepareData()) return 'Не удалось загрузить данные:\r\n' + Engine.Errors.slice(0, 10).join('\r\n');
    var rep = {}, c = Records.FindReprint(text, rep, scanFields(app.activeDocument));
    if (!c.length) return rep.text;
    if (mode != 'preview' && !confirm(rep.text + '\r\n\r\nВывести эти карты?', false, 'Перепечатка брака')) return '';
    if (mode == 'tiff' || mode == 'print') return 'Перепечатка в Illustrator — пока в PDF.';
    if (!pickOut(mode)) return '';
    Engine.SaveConfig();
    if (mode != 'preview') saveForOutput();
    Engine.Reprint = c;
    try { return Engine.RunJob(mode, 1, 0); } finally { Engine.Reprint = null; }
};
