// Календарь — как src/Calendar.bas. Раскладку и стиль считает панель (там же живое превью), сюда страница
// приходит готовым списком фигур, здесь только рисуется. Формат страницы — в src/Calendar.bas:
//   P ширина высота имя роль; L b|c|m; G; g имя; R x y w h скругление заливка обводка толщина пунктир имя;
//   O cx cy rx ry заливка обводка толщина; P cx cy r угол1 угол2 заливка; N x1 y1 x2 y2 обводка толщина пунктир;
//   T x базовая выравнивание шрифт кегль жирный курсив цвет макс.ширина разрядка куски текст
// Координаты — мм от левого верхнего угла страницы, ось вниз. Цвет — «C,M,Y,K», «reg» — совмещение, пусто — нет.
//
// Страница — монтажная область; страницы встают сеткой по четыре в ряд. Слои общие для всех областей:
// «Фон календаря» — под всеми, свой слой человека («Слой 1») — для картинок, над ним «Календарь», сверху
// непечатаемая «Разметка». При смене стиля перерисовывается только своё на этих слоях, картинки остаются.
// Роль страницы и настройки календаря — в описании документа.

var CAL_MARK = 'Разметка', CAL_LAYER = 'Календарь', CAL_BG = 'Фон календаря';

var Calendar = (function () {
    var D = null, T0 = 0, clr = {}, fontCache = null, faces = {}, grid = null;

    function num(s) { var n = parseFloat(String(s).replace(',', '.')); return isNaN(n) ? 0 : n; }
    function colorOf(s) {
        if (clr.hasOwnProperty(s)) return clr[s];
        var c = null;
        if (s == 'reg') {
            for (var i = 0; i < D.swatches.length && !c; i++) try { var sc = D.swatches[i].color; if (sc.typename == 'SpotColor' && sc.spot.colorType == ColorModel.REGISTRATION) c = sc; } catch (e) { }
            if (!c) c = cmykColor(100, 100, 100, 100);
        } else {
            var a = String(s).replace(/[; ]/g, ',').split(','), v = [];
            for (var k = 0; k < a.length && v.length < 4; k++) if (a[k] !== '') v.push(num(a[k]));
            while (v.length < 4) v.push(0);
            c = cmykColor(v[0], v[1], v[2], v[3]);
        }
        clr[s] = c;
        return c;
    }
    function paint(s, fill, stroke, w, dash) {
        if (fill === '' || fill == null) s.filled = false; else { s.filled = true; s.fillColor = colorOf(fill); }
        if (!stroke || w <= 0) s.stroked = false;
        else { s.stroked = true; s.strokeColor = colorOf(stroke); s.strokeWidth = pt(w); if (dash) s.strokeDashes = [pt(w * 6), pt(w * 4)]; }
    }

    // ---------- шрифты: семейство + жирный/курсив → шрифт Illustrator ----------
    function fonts() {
        if (fontCache) return fontCache;
        fontCache = {};
        var tf = app.textFonts, n = tf.length;
        for (var i = 0; i < n; i++) {
            var f = tf[i], fam = '', st = '';
            try { fam = f.family; st = f.style; } catch (e) { continue; }
            if (!fam) continue;
            (fontCache[fam] = fontCache[fam] || []).push({ f: f, st: String(st) });
        }
        return fontCache;
    }
    function face(fam, bold, ital) {
        var key = fam + '|' + (bold ? 1 : 0) + (ital ? 1 : 0);
        if (faces.hasOwnProperty(key)) return faces[key];
        var list = fonts()[fam] || fonts()['Arial'] || [], best = null, bs = -1;
        for (var i = 0; i < list.length; i++) {
            var s = list[i].st.toLowerCase(), b = /bold|heavy|black/.test(s) && !/semi|demi/.test(s), it = /italic|oblique/.test(s);
            var sc = (b == !!bold ? 4 : 0) + (it == !!ital ? 2 : 0) + (/^(regular|roman|normal|book|bold|italic|bold italic|oblique|bold oblique)$/.test(s) ? 1 : 0);
            if (sc > bs) { bs = sc; best = list[i].f; }
        }
        faces[key] = best;
        return best;
    }
    function familyList() {
        var a = [], fc = fonts();
        for (var k in fc) if (fc.hasOwnProperty(k)) a.push(k);
        return a.join('\n');
    }

    // ---------- документ ----------
    function begin(mode) {
        clr = {}; faces = {}; T0 = new Date().getTime(); grid = null;
        if (mode == 'restyle') {
            if (!hasDoc()) return 'Нет открытого документа.';
            if (!docProp(app.activeDocument, 'cal')) return 'Открытый документ — не календарь из этой панели.';
            D = app.activeDocument;
        } else {
            D = app.documents.add(DocumentColorSpace.CMYK, pt(210), pt(297));
            // справка зовёт слой для картинок «Слой 1» — в английском Illustrator он «Layer 1»
            try { D.layers[0].name = 'Слой 1'; } catch (e) { }
        }
        return 'ok';
    }
    function read() {
        if (!hasDoc()) return '';
        var d = app.activeDocument, s = docProp(d, 'cal');
        return s ? s + '\t' + d.artboards.length : '';
    }
    function layers() {
        var lb = cutFindLayer(D, CAL_BG), lc = cutFindLayer(D, CAL_LAYER), lm = cutFindLayer(D, CAL_MARK);
        if (!lc) { lc = D.layers.add(); lc.name = CAL_LAYER; }
        if (!lm) { lm = D.layers.add(); lm.name = CAL_MARK; lm.color = rgbColor(0, 160, 220); }
        lm.printable = false;
        if (!lb) { lb = D.layers.add(); lb.name = CAL_BG; }
        lb.zOrder(ZOrderMethod.SENDTOBACK);
        var all = [lb, lc, lm];
        for (var i = 0; i < 3; i++) { all[i].visible = true; all[i].locked = false; }
        return { b: lb, c: lc, m: lm };
    }
    function wipe(L, ab) { var a = topItemsOn(D, L, ab); for (var i = a.length - 1; i >= 0; i--) a[i].remove(); }
    function abByRole(role) {
        for (var i = 0; i < D.artboards.length; i++) if (docProp(D, 'calrole_' + i) == role) return i;
        return -1;
    }
    // Новая страница — в сетку по четыре в ряд справа-вниз от первой; ответ — номер области
    function boardFor(idx, w, h) {
        var W = pt(w), H = pt(h), G = pt(20);
        if (idx == 1) {
            var r0 = D.artboards[0].artboardRect;
            D.artboards[0].artboardRect = [r0[0], r0[1], r0[0] + W, r0[1] - H];
            grid = { x0: r0[0], x: r0[0] + W + G, top: r0[1], rowH: H, col: 1 };
            return 0;
        }
        if (idx - 1 < D.artboards.length) {
            var r = D.artboards[idx - 1].artboardRect;
            D.artboards[idx - 1].artboardRect = [r[0], r[1], r[0] + W, r[1] - H];
            return idx - 1;
        }
        if (!grid) { var q = D.artboards[D.artboards.length - 1].artboardRect; grid = { x0: D.artboards[0].artboardRect[0], x: q[2] + G, top: q[1], rowH: q[1] - q[3], col: D.artboards.length % 4 }; }
        if (grid.col >= 4) { grid.top -= grid.rowH + G; grid.x = grid.x0; grid.rowH = 0; grid.col = 0; }
        var R = [grid.x, grid.top, grid.x + W, grid.top - H], c = canvasCenter(D), half = 8191 - pt(100);
        if (R[0] < c[0] - half || R[2] > c[0] + half || R[3] < c[1] - half || R[1] > c[1] + half) R = freeBoard(D, w, h, 20);
        if (!R) throw new Error('страница не помещается на холст Illustrator — страниц слишком много для такого размера');
        D.artboards.add(R);
        grid.x = R[2] + G; grid.rowH = Math.max(grid.rowH, H); grid.col++;
        return D.artboards.length - 1;
    }

    function page(idx, spec) {
        if (!D) return 'Календарь не начат — нажмите кнопку ещё раз.';
        var ln = String(spec).split('\n'), f = ln[0].split('\t'), i = 0, ab;
        try {
            if (idx == 0) { ab = abByRole(f[4]); if (ab < 0) return 'skip'; }
            ab = idx == 0 ? ab : boardFor(idx, num(f[1]), num(f[2]));
            if (idx == 0) { var r0 = D.artboards[ab].artboardRect; D.artboards[ab].artboardRect = [r0[0], r0[1], r0[0] + pt(num(f[1])), r0[1] - pt(num(f[2]))]; }
            D.artboards[ab].name = f[3];
            setDocProp(D, 'calrole_' + ab, f[4]);
            var R = D.artboards[ab].artboardRect, Ls = layers();
            wipe(Ls.b, ab); wipe(Ls.c, ab); wipe(Ls.m, ab);
            var cur = Ls.c, cont = cur, grp = null;
            var X = function (x) { return R[0] + pt(num(x)); }, Y = function (y) { return R[1] - pt(num(y)); };
            for (i = 1; i < ln.length; i++) {
                f = ln[i].split('\t');
                var s = null;
                switch (f[0]) {
                    case 'L': cur = f[1] == 'b' ? Ls.b : (f[1] == 'm' ? Ls.m : Ls.c); if (!grp) cont = cur; break;
                    case 'G': grp = cur.groupItems.add(); cont = grp; break;
                    case 'g':
                        if (grp) {
                            if (grp.pageItems.length == 1) { var one = grp.pageItems[0]; one.move(cur, ElementPlacement.PLACEATBEGINNING); one.name = f[1] || ''; grp.remove(); }
                            else if (!grp.pageItems.length) grp.remove();
                            else grp.name = f[1] || '';
                        }
                        grp = null; cont = cur;
                        break;
                    case 'R':
                        var x = num(f[1]), y = num(f[2]), w = num(f[3]), h = num(f[4]), r = num(f[5]);
                        if (w > 0.01 && h > 0.01) {
                            r = Math.min(r, w / 2, h / 2);
                            s = r > 0 ? cont.pathItems.roundedRectangle(Y(y), X(x), pt(w), pt(h), pt(r), pt(r)) : cont.pathItems.rectangle(Y(y), X(x), pt(w), pt(h));
                            paint(s, f[6], f[7], num(f[8]), f[9] == '1');
                            if (f.length > 10 && f[10]) s.name = f[10];
                        }
                        break;
                    case 'O':
                        var rx = num(f[3]), ry = num(f[4]);
                        s = cont.pathItems.ellipse(Y(num(f[2]) - ry), X(num(f[1]) - rx), pt(2 * rx), pt(2 * ry));
                        paint(s, f[5], f[6], num(f[7]), false);
                        break;
                    case 'P': s = pie(cont, X(f[1]), Y(f[2]), pt(num(f[3])), num(f[4]), num(f[5])); paint(s, f[6], '', 0, false); break;
                    case 'N':
                        s = cont.pathItems.add(); s.setEntirePath([[X(f[1]), Y(f[2])], [X(f[3]), Y(f[4])]]); s.closed = false;
                        paint(s, '', f[5], num(f[6]), f[7] == '1');
                        break;
                    case 'T': text(cont, f, X, Y); break;
                }
            }
            return 'ok';
        } catch (e) {
            logLine('сбой календаря: страница ' + idx + ' строка ' + i + ': ' + e.message + ' (строка кода ' + e.line + ')');
            return 'Страница ' + idx + ' не нарисовалась: ' + e.message;
        }
    }
    // сектор (фазы Луны): от угла a1 до a2 против часовой, углы — от «трёх часов», ось вверх
    function pie(cont, cx, cy, r, a1, a2) {
        var sweep = a2 - a1; while (sweep <= 0) sweep += 360; if (sweep > 360) sweep = 360;
        var n = Math.ceil(sweep / 90), st = sweep / n * Math.PI / 180, a = a1 * Math.PI / 180, k = 4 / 3 * Math.tan(st / 4) * r;
        var p = cont.pathItems.add(), anchors = [[cx, cy]];
        for (var i = 0; i <= n; i++) { var t = a + st * i; anchors.push([cx + r * Math.cos(t), cy + r * Math.sin(t)]); }
        p.setEntirePath(anchors);
        for (i = 0; i <= n; i++) {
            var tt = a + st * i, q = p.pathPoints[i + 1], ux = -Math.sin(tt), uy = Math.cos(tt);
            if (i > 0) q.leftDirection = [q.anchor[0] - k * ux, q.anchor[1] - k * uy];
            if (i < n) q.rightDirection = [q.anchor[0] + k * ux, q.anchor[1] + k * uy];
        }
        p.closed = true;
        return p;
    }
    // надпись: x — точка выравнивания, y — базовая линия (как в превью панели)
    function text(cont, f, X, Y) {
        var s = f.slice(12).join('\t');
        if (!s) return null;
        var t;
        // изредка Illustrator отвечает на первую надпись страницы «неверный параметр» — со второго раза проходит
        try { t = cont.textFrames.pointText([X(f[1]), Y(f[2])]); } catch (e) { app.redraw(); t = cont.textFrames.pointText([X(f[1]), Y(f[2])]); }
        t.contents = s;
        var tr = t.textRange, ca = tr.characterAttributes, fc = face(f[4], f[6] == '1', f[7] == '1');
        if (fc) ca.textFont = fc;
        ca.size = Math.max(0.5, num(f[5]));
        ca.fillColor = colorOf(f[8]);
        ca.strokeWeight = 0;
        try { ca.strokeColor = new NoColor(); } catch (e) { }
        // разрядка панели — доля четверти кегля; у Illustrator — тысячные кегля
        if (num(f[10])) ca.tracking = Math.round(num(f[10]) * 2.5);
        tr.paragraphAttributes.justification = f[3] == 'l' ? Justification.LEFT : (f[3] == 'r' ? Justification.RIGHT : Justification.CENTER);
        if (f[11]) runs(t, f[11]);
        var maxW = num(f[9]);
        if (maxW > 0) {
            var b = t.geometricBounds, w = mm(b[2] - b[0]);
            // ужать целиком: кегли кусков меняются вместе, базовая линия и точка выравнивания — на месте
            if (w > maxW) { var k = maxW / w, ch = tr.characters; for (var i = 0; i < ch.length; i++) ch[i].characterAttributes.size = ch[i].characterAttributes.size * k; }
        }
        return t;
    }
    // части надписи другим шрифтом, кеглем, начертанием, цветом: «начало:длина:шрифт:кегль:жирный:курсив:цвет»
    function runs(t, spec) {
        var a = String(spec).split(';'), base = t.textRange.characterAttributes, fam0 = '', ch = t.textRange.characters;
        try { fam0 = base.textFont.family; } catch (e) { }
        for (var i = 0; i < a.length; i++) {
            var q = a[i].split(':');
            if (q.length < 7) continue;
            var st = Math.round(num(q[0])), n = Math.round(num(q[1]));
            for (var j = st; j < st + n && j < ch.length; j++) {
                var c = ch[j].characterAttributes;
                if (q[2] || q[4] !== '' || q[5] !== '') {
                    var cf = c.textFont, isB = /bold|heavy|black/i.test(cf.style), isI = /italic|oblique/i.test(cf.style);
                    var fc = face(q[2] || cf.family || fam0, q[4] !== '' ? q[4] == '1' : isB, q[5] !== '' ? q[5] == '1' : isI);
                    if (fc) c.textFont = fc;
                }
                if (q[3]) c.size = num(q[3]);
                if (q[6]) c.fillColor = colorOf(q[6]);
            }
        }
    }

    // Закончить: лишние страницы убрать, настройки запомнить в документе
    function end(params, pages) {
        if (!D) return 'Календарь не начат.';
        try {
            while (pages > 0 && D.artboards.length > pages) {
                var k = D.artboards.length - 1;
                for (var i = 0; i < D.layers.length; i++) if (!D.layers[i].locked) { var a = topItemsOn(D, D.layers[i], k); for (var q = a.length - 1; q >= 0; q--) a[q].remove(); }
                D.artboards.remove(k);
                setDocProp(D, 'calrole_' + k, '');
            }
            setDocProp(D, 'cal', params);
            D.artboards.setActiveArtboardIndex(0);
            D.selection = null;
            try { app.executeMenuCommand('fitall'); } catch (e) { }
            var r = 'ok\t' + Math.round((new Date().getTime() - T0) / 1000);
            D = null;
            return r;
        } catch (e) {
            logLine('сбой календаря в конце: ' + e.message + ' (строка ' + e.line + ')');
            return 'Не удалось закончить: ' + e.message;
        }
    }

    // ---------- свои стили ----------
    function styles() {
        var k = Settings.keys('CalendarStyles'), a = [];
        for (var i = 0; i < k.length; i++) a.push(k[i] + '\t' + Settings.get('CalendarStyles', k[i], ''));
        return a.join('\n');
    }

    return { begin: begin, read: read, page: page, end: end, families: familyList, styles: styles };
})();

Bridge.CalBegin = function (mode) {
    if (!PSA.has('K')) return 'Календарь — отдельная часть «Календарь» — её нет в вашем ключе.';
    return Calendar.begin(mode);
};
Bridge.CalPage = function (idx, spec) { return Calendar.page(+idx || 0, spec); };
// params — настройки календаря (запоминаются в документе для смены стиля), saved — поля панели
Bridge.CalEnd = function (params, pages, saved) {
    Settings.set('Calendar', 'Params', saved);
    var r = Calendar.end(params, +pages || 0);
    logLine('календарь: ' + r);
    return r;
};
Bridge.CalRead = function () { return Calendar.read(); };
Bridge.CalFonts = function () { return Calendar.families(); };
Bridge.CalStyles = function () { return Calendar.styles(); };
Bridge.CalStyleSave = function (name, style) {
    if (!String(name).replace(/\s/g, '')) return 'Назовите стиль.';
    Settings.set('CalendarStyles', name, style);
    return 'ok';
};
Bridge.CalStyleDel = function (name) { Settings.del('CalendarStyles', name); return 'ok'; };
