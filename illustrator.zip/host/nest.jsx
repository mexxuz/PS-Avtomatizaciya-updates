// Укладка деталей по их настоящей форме — как src/Nest.bas. Силуэт каждой детали — картинкой (PNG),
// раскладку подбирает bin/VarPrint_nest.exe в фоне (панель показывает ход и может остановить),
// потом детали раскладываются по листам нового файла (или переразложить готовую укладку в её же файле).
// Детали помнятся по своему номеру (метка psaId на объекте) — что выделено в момент «Уложить», не важно.

var NEST_RESULT = 'Укладка по форме', NEST_TPL_LAYER = 'PS • образцы деталей', NEST_PARTS_LAYER = 'Детали', NEST_STRIP_LINE = 'Полосы · линия реза';
var NEST_QTY_HINT = 'Впишите в поле «Тиражи», сколько штук каждой детали: через запятую, в том же порядке, что детали в файле, — например 8, 10, 8. Одно число — столько каждой.';

var Nest = (function () {
    var P = null;   // расчёт идёт в фоне: что доделать, когда он закончится

    function from(params) {
        var c = parseKV(params), G = function (k, dv) { return c.hasOwnProperty(k) ? c[k] : dv; }, N = function (k, dv) { return toNum(G(k, ''), dv); };
        var n = { SheetW: N('nsW', 1370), SheetH: N('nsH', 0), Margin: N('nsMargin', 10), Gap: N('nsGap', 3), Rot: Math.round(N('nsRot', 4)),
                  InHoles: G('nsInHoles', '1') == '1', Sheets: G('nsMore', '1') == '1' ? 0 : 1, Mirror: G('nsMirror', '0') == '1', Dxf: G('nsDxf', '0') == '1',
                  Speed: N('nsSpeed', 0), Mill: G('nsMill', '0') == '1', StripCut: G('nsStripCut', '1') == '1', StripLines: G('nsStripLines', '1') == '1',
                  Method: G('nsMethod', 'shape'), FillCols: G('nsFill', 'rows') == 'cols', Start: G('nsStart', 'bl'), Marks: G('nsMarks', '0') == '1' };
        var q = G('nsQual', 'good');
        if (q == 'fast') { n.Dpi = 25; n.Time = 5; } else if (q == 'max') { n.Dpi = 76; n.Time = 45; } else { n.Dpi = 51; n.Time = 20; }
        n.StripsFirst = G('nsStrips', n.Mill ? '1' : '0') == '1';
        if (n.Marks && n.Margin < 8) n.Margin = 8;
        return n;
    }
    function rotName(r) { return { 1: 'без поворота', 2: 'можно перевернуть', 24: 'любой угол' }[r] || 'поворот на четверть'; }
    function qtyOf(qtys, i) {
        var a = String(qtys).replace(/[ ]/g, '').replace(/;/g, ',').split(',');
        if (a.length == 1) { var v = parseInt(a[0], 10); return v > 0 ? v : 1; }
        if (i - 1 >= a.length) return 1;
        var w = parseInt(a[i - 1], 10); return w > 0 ? w : 1;
    }
    function noQty(qtys) { return !(parseInt(String(qtys).replace(/[ ,]/g, ''), 10) > 0); }
    function sz(it) { var b = it.geometricBounds; return [mm(b[2] - b[0]), mm(b[1] - b[3])]; }
    function n3(v) { var s = String(Math.round(v * 1000) / 1000); return s; }
    function sheetsWord(c) { return c + ' ' + plural(c, 'лист', 'листа', 'листов'); }

    // ---------- номера деталей ----------
    // номер — по времени и счётчику (запись в описание документа на каждую деталь — секунды)
    var ID_SEQ = 0;
    function idOf(it, make) {
        try { for (var i = 0; i < it.tags.length; i++) if (it.tags[i].name == 'psaId') return +it.tags[i].value; } catch (e) { return 0; }
        if (!make) return 0;
        var id = (new Date().getTime() % 100000000) * 10 + (ID_SEQ++ % 10);
        var t = it.tags.add(); t.name = 'psaId'; t.value = String(id);
        return id;
    }
    // у копии детали своего номера нет: номер — только у образца (иначе копию примут за образец)
    function dropId(it) { try { for (var i = it.tags.length - 1; i >= 0; i--) if (it.tags[i].name == 'psaId') it.tags[i].remove(); } catch (e) { } }
    function topItems(d) {
        var out = [];
        for (var i = 0; i < d.layers.length; i++) { var L = d.layers[i]; for (var k = 0; k < L.pageItems.length; k++) if (L.pageItems[k].parent == L) out.push(L.pageItems[k]); }
        return out;
    }
    function byId(d, id) { var t = topItems(d); for (var i = 0; i < t.length; i++) if (idOf(t[i], false) == id) return t[i]; return null; }

    // ---------- имена ----------
    function templNo(n) { return n.substring(0, 8) == 'Образец ' ? parseInt(n.substring(8), 10) || 0 : 0; }
    function partNo(n) { return n.substring(0, 7) == 'Деталь ' ? parseInt(n.substring(7), 10) || 0 : 0; }
    function stripNo(name) {
        name = String(name || '');
        if (partNo(name) > 0 || templNo(name) > 0) { var k = name.indexOf(' · '); name = k > 0 ? name.substring(k + 3) : ''; }
        while (name.length >= 2 && name.charAt(0) == '«' && name.charAt(name.length - 1) == '»') name = name.substring(1, name.length - 1);
        if (/^деталь \d+$/i.test(name)) name = '';
        return name;
    }
    function baseName(n, i) { return stripNo(n) || 'деталь ' + i; }
    function label(i, n) { n = stripNo(n); return 'Деталь ' + i + (n ? ' · ' + n : ''); }
    function humanName(it) {
        var n = stripNo(it.name);
        if (n) return n;
        return { GroupItem: 'Группа', PathItem: 'Фигура', CompoundPathItem: 'Фигура', TextFrame: 'Надпись', RasterItem: 'Картинка', PlacedItem: 'Картинка' }[it.typename] || 'Деталь';
    }
    function colorHex(it) {
        var c = null;
        (function walk(x) {
            if (c) return;
            if (x.typename == 'GroupItem') { for (var i = 0; i < x.pageItems.length; i++) walk(x.pageItems[i]); return; }
            var s = x.typename == 'CompoundPathItem' && x.pathItems.length ? x.pathItems[0] : x;
            try { if (s.typename == 'PathItem' && s.filled) c = s.fillColor; } catch (e) { }
        })(it);
        var rgb = null;
        try {
            if (c.typename == 'RGBColor') rgb = [c.red, c.green, c.blue];
            else if (c.typename == 'CMYKColor') rgb = [255 * (1 - c.cyan / 100) * (1 - c.black / 100), 255 * (1 - c.magenta / 100) * (1 - c.black / 100), 255 * (1 - c.yellow / 100) * (1 - c.black / 100)];
            else if (c.typename == 'GrayColor') { var v = 255 * (1 - c.gray / 100); rgb = [v, v, v]; }
            else if (c.typename == 'SpotColor') { var sc = c.spot.color; rgb = sc.typename == 'CMYKColor' ? [255 * (1 - sc.cyan / 100) * (1 - sc.black / 100), 255 * (1 - sc.magenta / 100) * (1 - sc.black / 100), 255 * (1 - sc.yellow / 100) * (1 - sc.black / 100)] : [sc.red, sc.green, sc.blue]; }
        } catch (e) { rgb = null; }
        if (!rgb) return '#888888';
        var h = function (v) { v = Math.max(0, Math.min(255, Math.round(v))); return (v < 16 ? '0' : '') + v.toString(16); };
        return '#' + h(rgb[0]) + h(rgb[1]) + h(rgb[2]);
    }

    // ---------- готовая укладка ----------
    function isResult(d) { try { return d.artboards[0].name.substring(0, NEST_RESULT.length) == NEST_RESULT; } catch (e) { return false; } }
    function storedQty(d) { return docProp(d, 'nestQty'); }
    function tplLayer(d) { return cutFindLayer(d, NEST_TPL_LAYER); }
    // по одной копии каждой детали по порядку номеров: образцы, а в старых укладках — первые копии
    function resultParts(d) {
        var found = {}, maxNo = 0, k, it, out = [], L = tplLayer(d), list;
        if (L) { for (k = 0; k < L.pageItems.length; k++) { it = L.pageItems[k]; var t = templNo(it.name); if (t > 0 && !found[t]) { found[t] = it; maxNo = Math.max(maxNo, t); } } }
        if (!maxNo) { list = topItems(d); for (k = 0; k < list.length; k++) { var pn = partNo(list[k].name); if (pn > 0 && !found[pn]) { found[pn] = list[k]; maxNo = Math.max(maxNo, pn); } } }
        for (k = 1; k <= maxNo; k++) if (found[k]) out.push(found[k]);
        return out;
    }
    function copiesOf(d, n) { var c = 0, t = topItems(d); for (var i = 0; i < t.length; i++) if (t[i].layer.name != NEST_TPL_LAYER && partNo(t[i].name) == n) c++; return c; }
    function currentParts(d) { return isResult(d) ? resultParts(d) : selectionItems(d); }

    function describe(p, qtys) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, again = isResult(d), sr = currentParts(d), t = '', i, total = 0;
        if (!sr.length) return 'Выделите детали, которые надо уложить. Каждый выделенный объект — одна деталь.';
        if (again) { var nm = []; for (i = 0; i < sr.length; i++) nm.push(baseName(sr[i].name, i + 1)); t = 'Это готовая укладка. Видов деталей ' + sr.length + ': ' + nm.join(', ') + '. '; }
        if (noQty(qtys)) return t + (again ? '' : 'Выделено деталей: ' + sr.length + '. ') + NEST_QTY_HINT;
        for (i = 1; i <= sr.length; i++) total += qtyOf(qtys, i);
        return t + (again ? 'Всего будет штук: ' + total + '. ' : 'Деталей разных: ' + sr.length + ', всего штук: ' + total + '. ') +
               'Материал ' + mmText(p.SheetW) + (p.SheetH > 0 ? ' × ' + mmText(p.SheetH) + ' мм' : ' мм, рулон') + ', зазор ' + mmText(p.Gap) + ' мм, ' + rotName(p.Rot) + '. ' +
               (again ? 'Нажмите «Переразложить» — этот же файл обновится.' : 'Нажмите «Уложить» — расчёт займёт несколько секунд.');
    }

    // ---------- силуэты и картинки ----------
    // Картинки деталей делаются в самом документе: копия детали — на временный слой, остальные слои на миг
    // прячутся, картинка — по временной монтажной области. Отдельный документ не годится: Illustrator сохраняет
    // картинку только текущего документа, а переключение документов у него — секунды.
    var TMP = null, TMP_LAYER = 'PS • силуэт';
    function tmpOpen() {
        if (TMP) return;
        var d = app.activeDocument, L = d.layers.add();
        L.name = TMP_LAYER;
        TMP = { d: d, L: L };
    }
    function tmpClose() { if (TMP) { try { TMP.L.remove(); } catch (e) { } TMP = null; } }
    function tmpDocWith(items) {
        var own = !TMP; tmpOpen();
        var dups = [];
        for (var i = items.length - 1; i >= 0; i--) {
            var L0 = cutTopLayer(items[i]), vis = L0.visible, lk = L0.locked;
            L0.visible = true; L0.locked = false;
            dups.push(items[i].duplicate(TMP.L, ElementPlacement.PLACEATBEGINNING));
            L0.visible = vis; L0.locked = lk;
        }
        return { d: TMP.d, items: dups, own: own, L: TMP.L };
    }
    function tmpDone(t) {
        if (!t) return;
        try { var L = t.L; for (var i = L.pageItems.length - 1; i >= 0; i--) L.pageItems[i].remove(); } catch (e) { }
        if (t.own) tmpClose();
    }
    function leavesAll(it, out) {
        if (it.typename == 'GroupItem') { for (var k = 0; k < it.pageItems.length; k++) leavesAll(it.pageItems[k], out); return; }
        out.push(it);
    }
    // залить: замкнутое — заливкой (окна пустые, если inHoles), открытое — обводкой. Без команд меню —
    // они трогают выделение человека
    function paint(items, L, color, inHoles, strokeW) {
        var lv = [], i, k;
        for (i = 0; i < items.length; i++) leavesAll(items[i], lv);
        for (i = 0; i < lv.length; i++) {
            var x = lv[i];
            try {
                if (x.typename == 'TextFrame') { x.textRange.characterAttributes.fillColor = color; continue; }
                if (x.typename == 'CompoundPathItem') {
                    if (!inHoles) {
                        // окна не нужны — части порознь, каждая залита: окна закрашены
                        var ps = []; for (k = 0; k < x.pathItems.length; k++) ps.push(x.pathItems[k]);
                        for (k = 0; k < ps.length; k++) { ps[k].move(L, ElementPlacement.PLACEATBEGINNING); ps[k].closed = true; ps[k].filled = true; ps[k].fillColor = color; ps[k].stroked = false; }
                        try { x.remove(); } catch (e) { }
                    } else for (k = 0; k < x.pathItems.length; k++) { x.pathItems[k].filled = true; x.pathItems[k].fillColor = color; x.pathItems[k].stroked = false; }
                    continue;
                }
                if (x.typename == 'PathItem') {
                    if (x.closed) { x.filled = true; x.fillColor = color; x.stroked = false; }
                    else { x.filled = false; x.stroked = true; x.strokeColor = color; x.strokeWidth = pt(strokeW || 0.5); }
                }
            } catch (e) { }
        }
    }
    // деталь и её окна — одним составным контуром (окна остаются пустыми)
    function joinHoles(L, items) {
        var cp = L.compoundPathItems.add();
        for (var i = 0; i < items.length; i++) {
            var x = items[i];
            if (x.typename == 'PathItem') x.move(cp, ElementPlacement.PLACEATEND);
            else if (x.typename == 'CompoundPathItem') { while (x.pathItems.length) x.pathItems[0].move(cp, ElementPlacement.PLACEATEND); try { x.remove(); } catch (e) { } }
        }
        // контуры, обведённые в одну сторону, при обычном правиле залились бы сплошь — окно пропало бы
        for (i = 0; i < cp.pathItems.length; i++) try { cp.pathItems[i].evenodd = true; } catch (e) { }
        return cp;
    }
    function exportPng(d, items, path, dpi, aa) {
        var b = boundsOf(items), keepAb = d.artboards.getActiveArtboardIndex(), vis = [], i;
        d.artboards.add([b[0], b[1], b[2], b[3]]);
        var ab = d.artboards.length - 1;
        try {
            d.artboards.setActiveArtboardIndex(ab);
            for (i = 0; i < d.layers.length; i++) { vis.push(d.layers[i].visible); if (d.layers[i].name != TMP_LAYER) d.layers[i].visible = false; }
            var o = new ExportOptionsPNG24(); o.artBoardClipping = true; o.transparency = true; o.antiAliasing = !!aa;
            o.horizontalScale = o.verticalScale = Math.min(776, dpi / 72 * 100);
            var f = new File(path); if (f.exists) f.remove();
            d.exportFile(f, ExportType.PNG24, o);
        } finally {
            for (i = 0; i < vis.length; i++) try { d.layers[i].visible = vis[i]; } catch (e) { }
            d.artboards.setActiveArtboardIndex(keepAb);
            d.artboards.remove(ab);
        }
    }
    function silhouette(it, holes, p, png) {
        var old = app.userInteractionLevel, t = null;
        app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
        try {
            t = tmpDocWith([it].concat(holes || []));
            var L = t.L;
            if (holes && holes.length && p.InHoles) t.items = [joinHoles(L, t.items)];
            paint(t.items, L, cmykColor(0, 0, 0, 100), p.InHoles, 0.5);
            var all = []; for (var i = 0; i < L.pageItems.length; i++) if (L.pageItems[i].parent == L) all.push(L.pageItems[i]);
            exportPng(t.d, all, png, p.Dpi, false);
            return '';
        } catch (e) { return 'не получилось сохранить силуэт детали «' + humanName(it) + '»: ' + e.message; }
        finally { tmpDone(t); app.userInteractionLevel = old; }
    }
    // маленькая картинка детали для строки списка панели
    function thumb(it, holes) {
        var old = app.userInteractionLevel, t = null, dir = new Folder(Folder.temp.fsName + '/PS-Avtomatizaciya-thumbs');
        if (!dir.exists) dir.create();
        var f = dir.fsName + '\\t' + new Date().getTime() + '_' + Math.round(Math.random() * 1e6) + '.png';
        app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
        try {
            t = tmpDocWith([it].concat(holes || []));
            var L = t.L;
            if (holes && holes.length) t.items = [joinHoles(L, t.items)];
            paint(t.items, L, rgbColor(200, 204, 210), true, 1.5);
            var s = sz(it), side = Math.max(1, s[0], s[1]), all = [];
            for (var i = 0; i < L.pageItems.length; i++) if (L.pageItems[i].parent == L) all.push(L.pageItems[i]);
            exportPng(t.d, all, f, Math.max(1, Math.min(600, 52 / (side / 25.4))), true);
            return f;
        } catch (e) { return ''; }
        finally { tmpDone(t); app.userInteractionLevel = old; }
    }

    // ---------- фрезер: полосы ----------
    function isRect(it) {
        if (it.typename != 'PathItem' || !it.closed) return false;
        var b = it.geometricBounds, pp = it.pathPoints, e = pt(0.05);
        for (var i = 0; i < pp.length; i++) {
            var a = pp[i].anchor;
            if (Math.abs(a[0] - b[0]) > e && Math.abs(a[0] - b[2]) > e) return false;
            if (Math.abs(a[1] - b[1]) > e && Math.abs(a[1] - b[3]) > e) return false;
            if (Math.abs(pp[i].leftDirection[0] - a[0]) + Math.abs(pp[i].leftDirection[1] - a[1]) + Math.abs(pp[i].rightDirection[0] - a[0]) + Math.abs(pp[i].rightDirection[1] - a[1]) > e) return false;
        }
        return true;
    }
    function isStrip(it) { var s = sz(it); return Math.max(s[0], s[1]) >= 5 * Math.min(s[0], s[1]) && isRect(it); }
    function stripsPlan(p, qtys, sr, flags) {
        P.str = []; P.shift = 0; P.cutN = 0; P.alongY = p.SheetH <= 0 || p.SheetH >= p.SheetW;
        if (!p.StripsFirst) return;
        var across = P.alongY ? p.SheetW : p.SheetH, usable = across - 2 * p.Margin, depth = 0, cnt = 0;
        for (var i = 0; i < sr.length; i++) {
            if (!isStrip(sr[i])) continue;
            var s = sz(sr[i]), L = Math.max(s[0], s[1]), T = Math.min(s[0], s[1]), q = qtyOf(qtys, i + 1);
            if (L > across + 0.01 || q <= 0) continue;
            if (L > usable + 0.01) { if (p.StripCut) { L = usable; P.cutN += q; } else continue; }
            flags[i] = true; P.str.push([i, q, L, T]); depth += T * q; cnt += q;
        }
        if (!cnt) return;
        P.str.sort(function (a, b) { return b[3] - a[3]; });          // толстые полосы — первыми
        P.shift = depth + (cnt - 1) * p.Gap + p.Gap;
    }
    function allBoxy(sr, flags) {
        for (var i = 0; i < sr.length; i++) {
            if (flags[i]) continue;
            var it = sr[i];
            if (it.typename == 'GroupItem' || it.typename == 'TextFrame') return false;
            var subs = it.typename == 'CompoundPathItem' ? it.pathItems : [it], big = 0, b = it.geometricBounds;
            for (var k = 0; k < subs.length; k++) try { big = Math.max(big, Math.abs(subs[k].area)); } catch (e) { return false; }
            if (big < 0.85 * (b[2] - b[0]) * (b[1] - b[3])) return false;
        }
        return true;
    }
    // габаритами или сеткой: --pack, ответ — в том же виде, что у расчёта по форме
    function packBoxes(p, qtys, sr, flags, sw, sh, outName) {
        var roll = sh <= 0, ph = roll ? 100000 : sh, items = 0, area = 0, i;
        var job = 'sheetW=' + n3(sw) + '\nsheetH=' + n3(ph) + '\nmargin=' + n3(p.Margin) + '\ngap=' + n3(p.Gap) + '\ncols=' + (p.FillCols ? '1' : '0') +
                  '\nrot=' + (p.Rot == 1 ? '0' : '1') + '\nsquare=' + (p.Method == 'grid' ? '1' : '0') + '\n';
        for (i = 0; i < sr.length; i++) if (!flags[i]) { var s = sz(sr[i]); job += 'item=' + (i + 1) + '|' + n3(s[0]) + '|' + n3(s[1]) + '|' + qtyOf(qtys, i + 1) + '\n'; area += s[0] * s[1] * qtyOf(qtys, i + 1); items++; }
        if (!items) { writeText(P.dir + outName, 'ok=1\nsheets=1\nusedH=' + n3(roll ? p.Margin * 2 : sh) + '\nusedLen=0\nfill=0\n'); return ''; }
        var res = cutRunExe('--pack', job);
        if (cutVal(res, 'ok') != '1') return 'Раскладка не получилась: ' + cutVal(res, 'error');
        var sheets = Math.max(1, Math.round(cutNum(cutVal(res, 'sheets')))), out = '', top = 0, pl = cutLines(res, 'placed');
        for (i = 0; i < pl.length; i++) {
            var f = pl[i].split('|');
            if (+f[4] + 1 == sheets) { var z = sz(sr[+f[0] - 1]), hh = f[3] == '1' ? z[0] : z[1]; top = Math.max(top, cutNum(f[2]) + hh); }
            out += 'placed=' + f[0] + '|' + f[1] + '|' + f[2] + '|' + (f[3] == '1' ? '90' : '0') + '|' + (+f[4] + 1) + '|0\n';
        }
        var un = cutLines(res, 'unplaced'); for (i = 0; i < un.length; i++) out += 'unplaced=' + un[i] + '\n';
        var uw = sw - 2 * p.Margin, uh = ph - 2 * p.Margin;
        writeText(P.dir + outName, 'ok=1\nsheets=' + sheets + '\nusedH=' + n3(roll ? top + p.Margin : sh) + '\nusedLen=' + n3(top + p.Margin) +
                  '\nfill=' + n3(area / (sheets * uw * (roll ? top - p.Margin + 0.001 : uh)) * 100) + '\n' + out);
        return '';
    }

    // ---------- запуск в фоне ----------
    function exePath() { return new File(PSA_DIR + '/../bin/VarPrint_nest.exe'); }
    function launch(p, qtys, sr, holes) {
        if (!exePath().exists) return 'Нет программы расчёта укладки VarPrint_nest.exe — переустановите панель.';
        var dir = new Folder(Folder.temp.fsName + '/PS-Avtomatizaciya-nest-' + new Date().getTime()); dir.create();
        P.dir = dir.fsName + '\\'; P.note = '';
        var t = p.Time > 0 ? p.Time : 20, flags = [], i;
        for (i = 0; i < sr.length; i++) flags.push(false);
        stripsPlan(p, qtys, sr, flags);
        var sw = p.SheetW, sh = p.SheetH;
        if (P.shift > 0) { if (P.alongY) { if (sh > 0) sh -= P.shift; } else sw -= P.shift; }
        if (p.Method != 'box' && p.Method != 'grid' && allBoxy(sr, flags)) { p.Method = 'box'; P.note = 'Все детали прямоугольные — уложено габаритами, одинаковые блоками. '; }
        if (p.Method == 'box' || p.Method == 'grid') { P.sync = true; return packBoxes(p, qtys, sr, flags, sw, sh, 'out.txt'); }
        packBoxes(p, qtys, sr, flags, sw, sh, 'out_box.txt');
        var job = 'sheetW=' + n3(sw) + '\nsheetH=' + n3(sh) + '\nmargin=' + n3(p.Margin) + '\ngap=' + n3(p.Gap) + '\nrot=' + p.Rot + '\npx=' + n3(p.Dpi / 25.4) +
                  '\nsheets=' + p.Sheets + '\nmirror=' + (p.Mirror ? 1 : 0) + '\ntime=' + n3(t) + '\nprogress=' + P.dir + 'progress.txt\nstop=' + P.dir + 'stop.txt\n', nParts = 0;
        tmpOpen();
        for (i = 0; i < sr.length; i++) {
            if (flags[i]) continue;
            var png = P.dir + 'part' + (i + 1) + '.png', e = silhouette(sr[i], holes ? holes[i] : null, p, png);
            if (e) { tmpClose(); return e; }
            var s = sz(sr[i]);
            job += 'part=' + (i + 1) + '|' + png + '|' + qtyOf(qtys, i + 1) + '|' + n3(s[0]) + '|' + n3(s[1]) + '\n';
            nParts++;
        }
        tmpClose();
        if (!nParts) { writeText(P.dir + 'out.txt', 'ok=1\nsheets=1\nusedH=' + n3(p.SheetH > 0 ? p.SheetH : (P.alongY ? P.shift + p.Margin : p.SheetW)) + '\nusedLen=0\nfill=0\n'); P.sync = true; return ''; }
        writeText(P.dir + 'job.txt', job);
        var vbs = new File(P.dir + 'run.vbs');
        vbs.encoding = 'UTF-16'; vbs.open('w');
        vbs.write('CreateObject("WScript.Shell").Run """' + exePath().fsName + '"" ""' + P.dir + 'job.txt"" ""' + P.dir + 'out.txt""", 0, False\r\n');
        vbs.close();
        vbs.execute();
        P.sync = false;
        return '';
    }
    function readRes(name) {
        var t = readText(P.dir + name).replace(/^﻿/, '').replace(/\r/g, '').split('\n'), out = [];
        for (var i = 0; i < t.length; i++) { var s = t[i].replace(/^\s+|\s+$/g, ''); if (s) out.push(s); }
        return out;
    }
    function rv(res, key) { for (var i = 0; i < res.length; i++) if (res[i].substring(0, key.length + 1) == key + '=') return res[i].substring(key.length + 1); return ''; }
    function notPlaced(res) { var n = 0; for (var i = 0; i < res.length; i++) if (res[i].substring(0, 9) == 'unplaced=') n += +(res[i].substring(9).split('|')[1]) || 0; return n; }
    function boxWins(bx, fm) {
        var a = notPlaced(bx), b = notPlaced(fm);
        if (a != b) return a < b;
        a = +rv(bx, 'sheets'); b = +rv(fm, 'sheets');
        if (a != b) return a < b;
        return +rv(bx, 'usedLen') < +rv(fm, 'usedLen') * 0.99;
    }

    // «run|лучшая длина|листов|прошло|всего|вариантов|не влезло», «done», «wait», «none», «fail|почему»
    function progress() {
        if (!P || !P.on) return 'none';
        if (new File(P.dir + 'out.txt').exists) return 'done';
        if ((new Date().getTime() - P.start) / 1000 > P.p.Time + 60) { P.on = false; if (P.kind == 'pages') pagesDrop(P.doc, P.drop); return 'fail|Программа расчёта остановилась, не закончив. Попробуйте ещё раз; если повторится — напишите разработчику: «Помощь и настройки» → «Связь с разработчиком».'; }
        if (!new File(P.dir + 'progress.txt').exists) return 'wait';
        var r = readRes('progress.txt');
        return 'run|' + rv(r, 'best') + '|' + rv(r, 'sheets') + '|' + rv(r, 'elapsed') + '|' + rv(r, 'time') + '|' + rv(r, 'evals') + '|' + rv(r, 'failed');
    }
    function stopNow() { if (P && P.on) writeText(P.dir + 'stop.txt', 'stop'); return 'Останавливаю перебор — беру лучший найденный вариант…'; }
    function busy() { return !!(P && P.on); }

    function finish() {
        if (!P || !P.on) return 'Расчёт не запущен.';
        if (!new File(P.dir + 'out.txt').exists) return 'Расчёт ещё идёт.';
        P.on = false;
        var res = readRes('out.txt'), note = '';
        if (rv(res, 'ok') != '1') { if (P.kind == 'pages') pagesDrop(P.doc, P.drop); return 'Расчёт не получился: ' + rv(res, 'error'); }
        if (new File(P.dir + 'out_box.txt').exists) {
            var alt = readRes('out_box.txt');
            if (rv(alt, 'ok') == '1' && boxWins(alt, res)) {
                note = 'По форме выходило ' + sheetsWord(+rv(res, 'sheets')) + (notPlaced(res) ? ', не влезло ' + notPlaced(res) + ' шт.' : '') + ' — габаритами плотнее, уложено габаритами. ';
                res = alt; P.p.Method = 'box';
            }
        }
        var r = P.kind == 'new' ? finishNew(res) : (P.kind == 'pages' ? finishPages(res) : finishRerun(res));
        return P.note + note + r;
    }

    // ---------- укладка ----------
    function runList(p, list, outPath) {
        if (!hasDoc()) return 'Нет открытого документа.';
        if (P && P.on) return 'Уже идёт расчёт — дождитесь его или остановите.';
        if (p.SheetW <= 0) return 'Укажите ширину материала.';
        var d = app.activeDocument, a = String(list).split(';'), sr = [], holes = [], qty = [], lost = [], i;
        for (i = 0; i < a.length; i++) {
            if (!a[i]) continue;
            var b = a[i].split(':'), it = byId(d, +b[0]);
            if (!it) { lost.push(i + 1); continue; }
            sr.push(it); qty.push(Math.round(+b[1] || 0));
            var hs = [];
            if (b.length > 2 && b[2]) { var hv = b[2].split(','); for (var k = 0; k < hv.length; k++) { var h = byId(d, +hv[k]); if (h) hs.push(h); } }
            holes.push(hs);
        }
        if (lost.length) return 'Детали № ' + lost.join(', ') + ' из списка в документе уже нет. Уберите их и повторите.';
        if (!sr.length) return 'Список пуст: выделите детали на листе и нажмите «Добавить в укладку».';
        P = { kind: 'new', src: d, sr: sr, holes: holes, labels: [], out: outPath, p: p, qtys: qty.join(', ') };
        for (i = 0; i < sr.length; i++) P.labels.push(label(i + 1, humanName(sr[i])));
        var e = launch(p, P.qtys, sr, holes);
        if (e) { P = null; return e; }
        P.on = true; P.start = new Date().getTime();
        return P.sync ? finish() : 'started';
    }
    function rerunList(p, list) {
        var d = app.activeDocument;
        if (P && P.on) return 'Уже идёт расчёт — дождитесь его или остановите.';
        if (!savedPath(d) && !d.saved) { try { d.fullName; } catch (e) { return 'Сохраните файл укладки — переразложить можно только сохранённый.'; } }
        if (p.SheetW <= 0) return 'Укажите ширину материала.';
        var a = String(list).split(';'), sr = [], qty = [], lost = [], i;
        for (i = 0; i < a.length; i++) {
            if (!a[i]) continue;
            var b = a[i].split(':'), it = byId(d, +b[0]);
            if (!it) { lost.push(i + 1); continue; }
            sr.push(it); qty.push(Math.round(+b[1] || 0));
        }
        if (lost.length) return 'Детали № ' + lost.join(', ') + ' из списка в документе уже нет. Уберите их или замените и повторите.';
        if (!sr.length) return 'Список пуст: выделите детали на листе и нажмите «Добавить в укладку».';
        P = { kind: 'rerun', doc: d, sr: sr, holes: null, labels: [], p: p, qtys: qty.join(', ') };
        for (i = 0; i < sr.length; i++) P.labels.push(label(i + 1, humanName(sr[i])));
        var e = launch(p, P.qtys, sr, null);
        if (e) { P = null; return e; }
        P.on = true; P.start = new Date().getTime();
        return P.sync ? finish() : 'started';
    }

    // Новый файл: листы-области, образцы деталей — на скрытом слое, по листам — их копии
    function finishNew(res) {
        var src = P.src, nd = null;
        try {
            nd = app.documents.add(src.documentColorSpace, pt(100), pt(100));
            var tl = nd.layers[0]; tl.name = NEST_TPL_LAYER;
            var tpl = [];
            for (var i = 0; i < P.sr.length; i++) {
                var items = [P.sr[i]].concat(P.holes && P.holes[i] ? P.holes[i] : []), dups = [];
                for (var k = items.length - 1; k >= 0; k--) dups.push(items[k].duplicate(tl, ElementPlacement.PLACEATBEGINNING));
                var t = dups[0];
                // буква с окнами — один контур: так её и режут
                if (dups.length > 1) { nd.selection = null; for (k = 0; k < dups.length; k++) dups[k].selected = true; app.executeMenuCommand('compoundPath'); if (nd.selection.length) t = nd.selection[0]; nd.selection = null; }
                tpl.push(t);
            }
            var r = place(nd, tpl, P.labels, res, P.p, P.qtys, true);
            var f = new File(P.out); if (f.exists) f.remove();
            nd.saveAs(f, new IllustratorSaveOptions());
            if (P.p.Dxf) r = r.replace('\u0001DXF', exportDxf(nd));
            else r = r.replace('\u0001DXF', '');
            return r + '\r\n' + P.out;
        } catch (e) {
            try { if (nd) nd.close(SaveOptions.DONOTSAVECHANGES); } catch (x) { }
            logLine('сбой укладки по форме: ' + e.message + ' (строка ' + e.line + ')');
            return 'Укладка не получилась: ' + e.message;
        }
    }
    function finishRerun(res) {
        var d = P.doc, i, keep = {};
        try {
            d.activate();
            for (i = 0; i < P.sr.length; i++) keep[idOf(P.sr[i], true)] = 1;
            var tl = tplLayer(d) || (function () { var L = d.layers.add(); L.name = NEST_TPL_LAYER; return L; })();
            tl.visible = true; tl.locked = false;
            var all = topItems(d);
            for (i = all.length - 1; i >= 0; i--) {
                var it = all[i];
                if (keep[idOf(it, false)]) continue;
                if (it.layer == tl || partNo(it.name) > 0 || it.name.substring(0, NEST_STRIP_LINE.length) == NEST_STRIP_LINE) it.remove();
            }
            // листы после первого — убрать, разложим заново
            for (i = d.artboards.length - 1; i >= 1; i--) d.artboards.remove(i);
            var tpl = [];
            for (i = 0; i < P.sr.length; i++) { if (P.sr[i].layer != tl) P.sr[i].move(tl, ElementPlacement.PLACEATBEGINNING); tpl.push(P.sr[i]); }
            var r = place(d, tpl, P.labels, res, P.p, P.qtys, false);
            d.save();
            r = r.replace('\u0001DXF', P.p.Dxf ? exportDxf(d) : '');
            return r + '\r\n' + d.fullName.fsName;
        } catch (e) {
            logLine('сбой переразложить: ' + e.message + ' (строка ' + e.line + ')');
            return 'Переразложить не получилось: ' + e.message;
        }
    }
    // Раскладка в этом же документе (задники букв): листы — новые монтажные области «<prefix> — лист k из N»
    // справа от макета, детали — копиями на слой деталей. drop — служебный слой с деталями, убрать после;
    // move — слой, с которого детали ушли на листы (на области moveAb): после раскладки он там больше не нужен
    function runPages(p, sr, prefix, drop, move, moveAb) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument;
        if (P && P.on) { pagesDrop(d, drop); return 'Уже идёт расчёт — дождитесь его или остановите.'; }
        if (!sr.length) { pagesDrop(d, drop); return 'Нет деталей для раскладки.'; }
        if (p.SheetW <= 0) { pagesDrop(d, drop); return 'Укажите ширину листа в «Раскладка · По форме».'; }
        P = { kind: 'pages', doc: d, sr: sr, holes: null, labels: [], p: p, qtys: '1', prefix: prefix, drop: drop, move: move, moveAb: moveAb };
        for (var i = 0; i < sr.length; i++) P.labels.push(stripNo(sr[i].name) || 'деталь ' + (i + 1));
        var e = launch(p, P.qtys, sr, null);
        if (e) { P = null; pagesDrop(d, drop); return e; }
        P.on = true; P.start = new Date().getTime();
        return P.sync ? finish() : 'started';
    }
    function pagesDrop(d, name) {
        var L = name ? cutFindLayer(d, name) : null;
        if (!L) return;
        try {
            if (d.activeLayer == L) for (var i = 0; i < d.layers.length; i++) if (d.layers[i] != L && d.layers[i].visible && !d.layers[i].locked) { d.activeLayer = d.layers[i]; break; }
            L.locked = false; L.remove();
        } catch (e) { }
    }
    function finishPages(res) {
        var d = P.doc, p = P.p, pre = P.prefix, i, k, n = 0, cut = 0, lost = [], moved = false, dxf = '';
        try {
            if (app.activeDocument != d) d.activate();
            var usedH = cutNum(rv(res, 'usedH')), usedLen = cutNum(rv(res, 'usedLen')), fill = cutNum(rv(res, 'fill')), sheets = Math.max(1, Math.round(+rv(res, 'sheets') || 1));
            if (usedH <= 0) { pagesDrop(d, P.drop); return 'Расчёт вернул пустую раскладку.'; }
            if (P.shift > 0 && P.alongY) { usedH += P.shift; if (usedLen > 0) usedLen += P.shift; }
            var pageH = p.SheetH > 0 ? p.SheetH : usedH;
            // прошлые листы этой раскладки — прочь вместе с тем, что на них
            for (k = d.artboards.length - 1; k >= 0; k--) {
                if (d.artboards[k].name.indexOf(pre + ' — ') != 0 || d.artboards.length < 2) continue;
                for (i = 0; i < d.layers.length; i++) { var L0 = d.layers[i]; if (L0.locked) continue; var a0 = topItemsOn(d, L0, k); for (var q = a0.length - 1; q >= 0; q--) try { a0[q].remove(); } catch (e) { } }
                d.artboards.remove(k);
                if (P.moveAb > k) P.moveAb--;
            }
            var rects = [], first = d.artboards.length;
            for (k = 0; k < sheets; k++) {
                var R = freeBoard(d, p.SheetW, pageH, 30);
                if (!R) throw new Error('листов ' + sheets + ' по ' + mmText(p.SheetW) + ' × ' + mmText(pageH) + ' мм не помещаются на холст Illustrator рядом с макетом');
                d.artboards.add(R);
                d.artboards[d.artboards.length - 1].name = pre + ' — лист ' + (k + 1) + ' из ' + sheets;
                rects.push(R);
            }
            var pl = partsLayer(d), sx = P.alongY ? 0 : (P.shift || 0), sy = P.alongY ? (P.shift || 0) : 0;
            for (i = 0; i < res.length; i++) {
                if (res[i].substring(0, 7) == 'placed=') {
                    var a = res[i].substring(7).split('|'), ix = +a[0], sh = a.length > 4 ? +a[4] : 1;
                    if (sh < 1 || sh > sheets) sh = 1;
                    if (ix < 1 || ix > P.sr.length) continue;
                    var dup = P.sr[ix - 1].duplicate(pl, ElementPlacement.PLACEATBEGINNING);
                    if (a.length > 5 && a[5] == '1') dup.resize(-100, 100);
                    if (cutNum(a[3])) dup.rotate(cutNum(a[3]));
                    var b = dup.geometricBounds, at = cutPt(rects[sh - 1], cutNum(a[1]) + sx, cutNum(a[2]) + sy);
                    dup.translate(at[0] - b[0], at[1] - b[3]);
                    cut += shapeLen(dup); n++;
                } else if (res[i].substring(0, 9) == 'unplaced=') {
                    var u = res[i].substring(9).split('|');
                    if (+u[0] >= 1 && +u[0] <= P.labels.length) lost.push('«' + P.labels[+u[0] - 1] + '»');
                }
            }
            pagesDrop(d, P.drop);
            if (P.move && n > 0) {
                var ml = cutFindLayer(d, P.move);
                if (ml) {
                    ml.locked = false; ml.visible = true;
                    var mv = topItemsOn(d, ml, P.moveAb);
                    for (i = mv.length - 1; i >= 0; i--) mv[i].remove();
                    moved = mv.length > 0;
                    if (!ml.pageItems.length) pagesDrop(d, P.move);
                }
            }
            if (p.Dxf) {
                var base = ''; try { if (d.fullName.exists) base = d.fullName.fsName; } catch (e) { }
                if (!base) dxf = 'DXF не сохранён: сначала сохраните файл.';
                else {
                    base = base.replace(/\.[^.\\\/]*$/, '') + ' — ' + pre.toLowerCase();
                    var made = 0;
                    for (k = 0; k < sheets; k++) { var it = sheetItems(d, first + k); if (!it.length) continue; CutFile.saveDxf(base + (sheets > 1 ? ' — лист ' + (k + 1) : '') + '.dxf', it, rects[k]); made++; }
                    dxf = made ? 'DXF для станка: ' + made + ' ' + plural(made, 'файл', 'файла', 'файлов') + ' рядом с файлом, нуль — в левом нижнем углу листа.' : '';
                }
            }
            d.artboards.setActiveArtboardIndex(first);
            d.selection = null;
        } catch (e) {
            pagesDrop(d, P.drop);
            logLine('сбой раскладки страницами: ' + e.message + ' (строка ' + e.line + ')');
            return 'Разложить не получилось: ' + e.message;
        }
        var t = pre + ': ' + n + ' шт. на ' + sheets + ' ' + (sheets == 1 ? 'листе' : 'листах') + ' ' + mmText(p.SheetW) + ' × ' + mmText(pageH) +
                ' мм — монтажные области «' + pre + ' — лист …» справа от макета. Деталями занято ' + mmText(fill) + ' %.';
        if (p.SheetH > 0 && usedLen > 0 && p.SheetH - usedLen > 20) t += ' На ' + (sheets > 1 ? 'последнем листе' : 'листе') + ' сверху свободно ' + mmText(p.SheetH - usedLen) + ' мм.';
        if (cut > 0) t += ' Длина реза ' + (Math.round(cut / 100) / 10).toFixed(1).replace('.', ',') + ' м.';
        if (lost.length) t += ' Не поместилось: ' + lost.join(', ') + '.';
        if (dxf) t += ' ' + dxf;
        if (moved) t += ' С области с буквами они убраны — теперь они только здесь.';
        logLine('раскладка страницами: ' + t);
        return t;
    }

    function partsLayer(d) { var L = cutFindLayer(d, NEST_PARTS_LAYER); if (!L) { L = d.layers.add(); L.name = NEST_PARTS_LAYER; } L.visible = true; L.locked = false; return L; }
    function shapeLen(it) {
        var t = it.typename, s = 0, k;
        if (t == 'GroupItem') { for (k = 0; k < it.pageItems.length; k++) if (it.pageItems[k].name.substring(0, 7) != 'Выборка') s += shapeLen(it.pageItems[k]); return s; }
        if (t == 'PathItem') return mm(it.length);
        if (t == 'CompoundPathItem') { for (k = 0; k < it.pathItems.length; k++) s += mm(it.pathItems[k].length); return s; }
        if (t == 'TextFrame') { var tmp = []; var subs = cutSubs(it, tmp); for (k = 0; k < subs.length; k++) s += mm(subs[k].length); for (k = 0; k < tmp.length; k++) try { tmp[k].remove(); } catch (e) { } return s; }
        return 0;
    }
    // листы: первая область — лист 1 (размер подгоняется), остальные — рядом, только внутри холста
    function sheetsFor(d, n, W, H, fresh) {
        var R0 = d.artboards[0].artboardRect, rects = [], c = canvasCenter(d), half = 8191 - pt(100);
        if (W > 5500 || H > 5500) throw new Error('лист ' + mmText(W) + ' × ' + mmText(H) + ' мм больше холста Illustrator (около 5,5 м) — задайте лист короче');
        var r1 = [R0[0], R0[1], R0[0] + pt(W), R0[1] - pt(H)];
        // за краем холста область не создать (и пробовать нельзя) — тогда первый лист по середине холста
        if (fresh || r1[0] < c[0] - half || r1[2] > c[0] + half || r1[3] < c[1] - half || r1[1] > c[1] + half)
            r1 = [c[0] - pt(W) / 2, c[1] + pt(H) / 2, c[0] + pt(W) / 2, c[1] - pt(H) / 2];
        d.artboards[0].artboardRect = r1; rects.push(r1);
        for (var k = 1; k < n; k++) {
            var R = freeBoard(d, W, H, 30);
            if (!R) throw new Error('листов ' + n + ' не помещаются на холст Illustrator — уменьшите количество или задайте лист побольше');
            d.artboards.add(R); rects.push(R);
        }
        for (k = 0; k < n; k++) d.artboards[k].name = NEST_RESULT + (n > 1 ? ' — лист ' + (k + 1) + ' из ' + n : '');
        return rects;
    }

    function place(d, tpl, labels, res, p, qtys, fresh) {
        var usedH = cutNum(rv(res, 'usedH')), usedLen = cutNum(rv(res, 'usedLen')), fill = cutNum(rv(res, 'fill')), sheets = Math.max(1, Math.round(+rv(res, 'sheets') || 1));
        if (usedH <= 0) return 'Расчёт вернул пустую раскладку.';
        if (P.shift > 0 && P.alongY) { usedH += P.shift; if (usedLen > 0) usedLen += P.shift; }
        var pageH = p.SheetH > 0 ? p.SheetH : usedH, rects = sheetsFor(d, sheets, p.SheetW, pageH, fresh), i, k, n = 0, cut = 0, lost = [];
        var tl = tplLayer(d); tl.visible = true;
        for (i = 0; i < tpl.length; i++) tpl[i].name = 'Образец ' + (i + 1) + (stripNo(labels[i]) ? ' · ' + stripNo(labels[i]) : '');
        var pl = partsLayer(d);
        for (i = 0; i < res.length; i++) {
            if (res[i].substring(0, 7) == 'placed=') {
                var a = res[i].substring(7).split('|'), ix = +a[0], sh = a.length > 4 ? +a[4] : 1;
                if (sh < 1 || sh > sheets) sh = 1;
                if (ix < 1 || ix > tpl.length) continue;
                var dup = tpl[ix - 1].duplicate(pl, ElementPlacement.PLACEATBEGINNING);
                dropId(dup);
                if (a.length > 5 && a[5] == '1') dup.resize(-100, 100);
                if (cutNum(a[3])) dup.rotate(cutNum(a[3]));
                var b = dup.geometricBounds, at = cutPt(rects[sh - 1], cutNum(a[1]) + (P.alongY ? 0 : P.shift), cutNum(a[2]) + (P.alongY ? P.shift : 0));
                dup.translate(at[0] - b[0], at[1] - b[3]);
                dup.name = labels[ix - 1];
                cut += shapeLen(dup); n++;
            } else if (res[i].substring(0, 9) == 'unplaced=') {
                var u = res[i].substring(9).split('|');
                if (+u[0] >= 1 && +u[0] <= labels.length) lost.push('«' + baseName(labels[+u[0] - 1], +u[0]) + '» — ' + u[1] + ' шт.');
            }
        }
        var st = { cut: cut, n: n }, stripTxt = placeStrips(d, rects[0], tpl, labels, p, st);
        cut = st.cut; n = st.n;
        if (p.Mill && p.Method != 'box' && p.Method != 'grid') for (k = 0; k < sheets; k++) snapRects(d, k, rects[k], p);
        for (k = 0; k < sheets; k++) moveToStart(d, k, rects[k], p.Start);
        if (p.Marks) for (k = 0; k < sheets; k++) marksAround(d, k, rects[k]);
        tl.visible = false; tl.printable = false;
        try { if (d.activeLayer == tl) d.activeLayer = pl; } catch (e) { }
        setDocProp(d, 'nestQty', qtys); setDocProp(d, 'kind', 'nest');
        d.artboards.setActiveArtboardIndex(0);
        var sheetTxt = sheets > 1 ? ' Листов: ' + sheets + ', каждый ' + mmText(p.SheetW) + ' × ' + mmText(pageH) + ' мм'
                                  : ' Материала ' + mmText(p.SheetW) + ' × ' + mmText(usedH) + ' мм (' + (Math.round(p.SheetW * usedH / 10000) / 100).toFixed(2).replace('.', ',') + ' кв. м)';
        var rest = p.SheetH > 0 && usedLen > 0 && p.SheetH - usedLen > 20 ? ' На ' + (sheets > 1 ? 'последнем листе' : 'листе') + ' детали заняли ' + mmText(usedLen) + ' мм по длине, сверху свободно ' + mmText(p.SheetH - usedLen) + ' мм — этот остаток можно пустить в дело.' : '';
        var cutTxt = cut > 0 ? ' Длина реза ' + (Math.round(cut / 100) / 10).toFixed(1).replace('.', ',') + ' м' + (p.Speed > 0 ? ', при ' + p.Speed + ' м/мин это около ' + Math.round(cut / 1000 / p.Speed) + ' мин' : '') + '.' : '';
        var msg = 'Готово: уложено ' + n + ' шт.' + sheetTxt + (fill > 0 ? ', деталями занято ' + mmText(fill) + ' %' : '') + '.' + stripTxt + rest + cutTxt +
                  (lost.length ? ' Не поместилось: ' + lost.join(', ') + (p.Sheets == 1 ? ' — разрешите следующие листы или уменьшите количество.' : '.') : '') + '\u0001DXF' +
                  ' Поменять количество или добавить детали можно прямо в этом файле — потом «Переразложить».';
        logLine('укладка по форме: ' + msg.replace('\u0001DXF', ''));
        return msg;
    }

    function stripLine(L, R, at, p, length, st) {
        st.lines++;
        var l = L.pathItems.add();
        l.setEntirePath(P.alongY ? [cutPt(R, p.Margin, at), cutPt(R, p.Margin + length, at)] : [cutPt(R, at, p.Margin), cutPt(R, at, p.Margin + length)]);
        l.filled = false; l.stroked = true; l.strokeWidth = pt(0.25); l.strokeColor = rgbColor(0, 0, 0);
        l.name = NEST_STRIP_LINE + ' ' + st.lines; st.cut += length;
    }
    function placeStrips(d, R, tpl, labels, p, st) {
        if (!P.str || !P.str.length) return '';
        var L = partsLayer(d), across = P.alongY ? p.SheetW : p.SheetH, usable = across - 2 * p.Margin, full = p.StripLines, cnt = 0, rr = p.Gap / 2, pos = p.Margin, i, k;
        st.lines = 0;
        for (i = 0; i < P.str.length; i++) if (P.str[i][2] < usable - 0.01) full = false;
        for (i = 0; i < P.str.length; i++) {
            var v = P.str[i];
            for (k = 0; k < v[1]; k++) {
                if (full) { if (!cnt) stripLine(L, R, pos - rr, p, v[2], st); }
                else {
                    var dup = tpl[v[0]].duplicate(L, ElementPlacement.PLACEATBEGINNING), s = sz(dup);
                    dropId(dup);
                    if (P.alongY ? s[0] < s[1] : s[0] > s[1]) { dup.rotate(90); s = sz(dup); }
                    var tw = P.alongY ? v[2] : v[3], th = P.alongY ? v[3] : v[2];
                    dup.resize(tw / s[0] * 100, th / s[1] * 100);
                    var b = dup.geometricBounds, at = P.alongY ? cutPt(R, p.Margin, pos) : cutPt(R, pos, p.Margin);
                    dup.translate(at[0] - b[0], at[1] - b[3]);
                    dup.name = labels[v[0]]; st.cut += shapeLen(dup);
                }
                pos += v[3];
                if (full) stripLine(L, R, pos + rr, p, v[2], st);
                pos += p.Gap; cnt++; st.n++;
            }
        }
        return ' Полосы (' + cnt + ' шт.) — первыми, поперёк листа, в его начале' +
               (full ? ': линиями реза (' + st.lines + ', путь центра фрезы ' + mmText(p.Gap) + ' мм — «по линии»), концы — в поле листа, полосы держатся за лист' : '') + '.' +
               (P.cutN ? ' Укорочено до полей: ' + P.cutN + ' шт., теперь ' + mmText(usable) + ' мм.' : '');
    }
    function sheetItems(d, k) { var L = cutFindLayer(d, NEST_PARTS_LAYER); return L ? topItemsOn(d, L, k) : []; }
    // фрезер: прямоугольники — вниз и влево до зазора ровно в фрезу (не дальше 1,5 мм), чтобы у соседей рез был одной линией
    function snapRects(d, k, R, p) {
        var it = sheetItems(d, k), n = it.length, x0 = [], y0 = [], x1 = [], y1 = [], isR = [], rr = p.Gap / 2, i, j;
        if (!n) return;
        for (i = 0; i < n; i++) {
            var b = it[i].geometricBounds; x0[i] = mm(b[0] - R[0]); x1[i] = mm(b[2] - R[0]); y0[i] = mm(b[3] - R[3]); y1[i] = mm(b[1] - R[3]);
            if (it[i].name.substring(0, NEST_STRIP_LINE.length) == NEST_STRIP_LINE) { if (P.alongY) { y0[i] -= rr; y1[i] = y0[i]; } else { x0[i] -= rr; x1[i] = x0[i]; } }
            else isR[i] = isRect(it[i]);
        }
        for (var pass = 0; pass < 3; pass++) for (var dir = 0; dir <= 1; dir++) {
            var ord = []; for (i = 0; i < n; i++) ord.push(i);
            ord.sort(function (a, b) { return dir == 0 ? y0[a] - y0[b] : x0[a] - x0[b]; });
            for (var q = 0; q < n; q++) {
                i = ord[q]; if (!isR[i]) continue;
                var nb = p.Margin;
                for (j = 0; j < n; j++) {
                    if (j == i) continue;
                    if (dir == 0) { if (Math.min(x1[i], x1[j]) - Math.max(x0[i], x0[j]) > 0.01 && y1[j] <= y0[i] + 0.01) nb = Math.max(nb, y1[j] + p.Gap); }
                    else if (Math.min(y1[i], y1[j]) - Math.max(y0[i], y0[j]) > 0.01 && x1[j] <= x0[i] + 0.01) nb = Math.max(nb, x1[j] + p.Gap);
                }
                var cur = dir == 0 ? y0[i] : x0[i];
                if (nb < cur - 0.0005 && cur - nb <= 1.5) {
                    if (dir == 0) { it[i].translate(0, pt(nb - cur)); y1[i] += nb - cur; y0[i] = nb; }
                    else { it[i].translate(pt(nb - cur), 0); x1[i] += nb - cur; x0[i] = nb; }
                }
            }
        }
    }
    // точка старта: расчёт кладёт от левого нижнего угла — остальные получаются отражением мест и сдвигом блока
    function moveToStart(d, k, R, st) {
        if (!st || st == 'bl') return;
        var it = sheetItems(d, k), i, c;
        if (!it.length) return;
        for (i = 0; i < it.length; i++) {
            var b = it[i].geometricBounds, dx = 0, dy = 0;
            if (st.indexOf('r') >= 0) dx = (R[0] + R[2]) - (b[0] + b[2]);
            if (st.indexOf('t') >= 0) dy = (R[1] + R[3]) - (b[1] + b[3]);
            if (dx || dy) it[i].translate(dx, dy);
        }
        var hx = st.indexOf('l') < 0 && st.indexOf('r') < 0, hy = st.indexOf('b') < 0 && st.indexOf('t') < 0;
        if (hx || hy) {
            c = boundsOf(it);
            var mx = hx ? (R[0] + R[2]) / 2 - (c[0] + c[2]) / 2 : 0, my = hy ? (R[1] + R[3]) / 2 - (c[1] + c[3]) / 2 : 0;
            for (i = 0; i < it.length; i++) it[i].translate(mx, my);
        }
    }
    function marksAround(d, k, R) {
        var it = sheetItems(d, k); if (!it.length) return;
        var b = boundsOf(it), g = layerNamed(d, MARK_LAYER, true).groupItems.add(); g.name = 'Метки SignMaster';
        Roll.signMaster(g, R, mm(b[0] - R[0]), mm(b[2] - R[0]), mm(R[1] - b[1]), mm(R[1] - b[3]), 4, 3);
    }
    // DXF каждого листа рядом с файлом укладки; нуль — левый нижний угол листа
    function exportDxf(d) {
        var base = d.fullName.fsName.replace(/\.[^.\\\/]*$/, ''), made = 0, n = d.artboards.length, k;
        for (k = 0; k < n; k++) {
            var it = sheetItems(d, k); if (!it.length) continue;
            CutFile.saveDxf(base + (n > 1 ? ' — лист ' + (k + 1) : '') + '.dxf', it, d.artboards[k].artboardRect);
            made++;
        }
        // DXF прошлой укладки, где листов было больше или один, — прочь: на станок не должен уйти старый
        if (n > 1) { var o = new File(base + '.dxf'); if (o.exists) o.remove(); }
        for (k = n > 1 ? n + 1 : 1; k < 100; k++) { var o2 = new File(base + ' — лист ' + k + '.dxf'); if (o2.exists) o2.remove(); }
        return made ? ' DXF для станка: ' + made + ' ' + plural(made, 'файл', 'файла', 'файлов') + ' рядом с укладкой, нуль — в левом нижнем углу листа.' : '';
    }

    // ---------- список деталей для панели ----------
    function signature(sr) {
        var s = '', h = 0, i;
        for (i = 0; i < sr.length; i++) { var z = sz(sr[i]); s += '|' + sr[i].name + ':' + Math.round(z[0]) + 'x' + Math.round(z[1]); }
        for (i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) & 0xFFFFFF;
        return sr.length + '-' + h.toString(16).toUpperCase();
    }
    function partsJson() {
        if (!hasDoc()) return '{"res":false,"sig":"","parts":[]}';
        var d = app.activeDocument, sr = currentParts(d), res = isResult(d), q = res ? storedQty(d).replace(/ /g, '').split(',') : [], out = [];
        if (sr.length) tmpOpen();
        try {
        for (var i = 0; i < sr.length; i++) {
            var it = sr[i], z = sz(it), now = 0;
            if (res) now = copiesOf(d, templNo(it.name) || partNo(it.name));
            out.push({ name: baseName(it.name, i + 1), w: Math.round(z[0]), h: Math.round(z[1]), rgb: colorHex(it), now: now,
                       qty: q.length == 1 && i > 0 ? q[0] : (q[i] || ''), id: idOf(it, true), thumb: thumb(it, null) });
        }
        } finally { tmpClose(); }
        return toJson({ res: res, sig: signature(sr), parts: out });
    }
    function selBrief() {
        if (!hasDoc()) return '';
        var s = selectionItems(app.activeDocument); if (!s.length) return '';
        var b = boundsOf(s); return s.length + '|' + Math.round(mm(b[2] - b[0])) + '|' + Math.round(mm(b[1] - b[3]));
    }
    function inside(outer, inner) {
        try {
            var po = outer.typename == 'PathItem' ? outer : (outer.typename == 'CompoundPathItem' ? outer.pathItems[0] : null);
            if (!po || !po.closed) return false;
            var R = [0, 0, 0, 0], poly = cutFlatten(po, R, 0.2), pi = inner.typename == 'PathItem' ? inner : (inner.typename == 'CompoundPathItem' ? inner.pathItems[0] : null);
            var p0 = pi ? cutMm(R, pi.pathPoints[0].anchor) : (function () { var b = inner.geometricBounds; return cutMm(R, [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2]); })();
            var c = false;
            for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) if ((poly[i][1] > p0[1]) != (poly[j][1] > p0[1]) && p0[0] < (poly[j][0] - poly[i][0]) * (p0[1] - poly[i][1]) / (poly[j][1] - poly[i][1]) + poly[i][0]) c = !c;
            return c;
        } catch (e) { return false; }
    }
    function partSig(it, holes) {
        var z = sz(it), nodes = 0;
        try { nodes = it.typename == 'PathItem' ? it.pathPoints.length : (it.typename == 'CompoundPathItem' ? it.pathItems.length : 0); } catch (e) { }
        var t = it.typename + '|' + (Math.round(z[0] * 5) / 5) + 'x' + (Math.round(z[1] * 5) / 5) + '|n' + nodes + '|h' + holes.length;
        for (var i = 0; i < holes.length; i++) { var hz = sz(holes[i]); t += ',' + (Math.round(hz[0] * 5) / 5) + 'x' + (Math.round(hz[1] * 5) / 5); }
        return t;
    }
    // разбор выделенного: строка на каждую разную деталь «номер|имя|ширина|высота|картинка|сколько|номера одинаковых|номера окон»
    function selParts() {
        if (!hasDoc()) return '';
        var d = app.activeDocument, sh = selectionItems(d), n = sh.length, i, j;
        if (!n) return '';
        var bx = [], depth = [], parent = [];
        for (i = 0; i < n; i++) { var b = sh[i].geometricBounds; bx.push([b[0], b[3], b[2] - b[0], b[1] - b[3]]); depth.push(0); parent.push(-1); }
        for (i = 0; i < n; i++) {
            var best = -1;
            for (j = 0; j < n; j++) {
                if (i == j) continue;
                var A = bx[i], Bb = bx[j], e = pt(0.01);
                if (A[0] >= Bb[0] - e && A[1] >= Bb[1] - e && A[0] + A[2] <= Bb[0] + Bb[2] + e && A[1] + A[3] <= Bb[1] + Bb[3] + e && A[2] * A[3] < Bb[2] * Bb[3] && inside(sh[j], sh[i])) {
                    depth[i]++;
                    if (best < 0 || Bb[2] * Bb[3] < best) { best = Bb[2] * Bb[3]; parent[i] = j; }
                }
            }
        }
        var holes = []; for (i = 0; i < n; i++) holes.push([]);
        for (i = 0; i < n; i++) if (depth[i] % 2 == 1 && parent[i] >= 0) holes[parent[i]].push(sh[i]);
        var groups = {}, order = [];
        for (i = 0; i < n; i++) if (depth[i] % 2 == 0) { var sg = partSig(sh[i], holes[i]); if (!groups[sg]) { groups[sg] = []; order.push(sg); } groups[sg].push(i); }
        var t = [];
        tmpOpen();
        try {
        for (var o = 0; o < order.length; o++) {
            var g = groups[order[o]], first = g[0], ids = [], hs = [];
            for (j = 0; j < g.length; j++) ids.push(idOf(sh[g[j]], true));
            for (j = 0; j < holes[first].length; j++) hs.push(idOf(holes[first][j], true));
            var z = sz(sh[first]);
            t.push(idOf(sh[first], true) + '|' + humanName(sh[first]).replace(/\|/g, '/') + '|' + Math.round(z[0]) + '|' + Math.round(z[1]) + '|' + thumb(sh[first], holes[first]) + '|' + g.length + '|' + ids.join(',') + '|' + hs.join(','));
        }
        } finally { tmpClose(); }
        try { d.selection = null; for (i = 0; i < n; i++) sh[i].selected = true; } catch (e) { }
        return t.join('\n');
    }
    function partsState(ids) {
        if (!hasDoc()) return '';
        var d = app.activeDocument, want = {}, a = String(ids).split(','), out = [], i, any = false;
        for (i = 0; i < a.length; i++) if (+a[i] > 0) { want[+a[i]] = ''; any = true; }
        if (!any) return '';
        var t = topItems(d);
        for (i = 0; i < t.length; i++) { var id = idOf(t[i], false); if (want.hasOwnProperty(id)) { var z = sz(t[i]); want[id] = '1|' + humanName(t[i]) + '|' + Math.round(z[0]) + '|' + Math.round(z[1]) + '|' + colorHex(t[i]); } }
        for (var k in want) if (want.hasOwnProperty(k)) out.push(k + '|' + (want[k] || '0'));
        return out.join('\n');
    }
    function select(d, list) { d.selection = null; for (var i = 0; i < list.length; i++) try { list[i].selected = true; } catch (e) { } }
    function showPart(n) {
        if (!hasDoc()) return '';
        var d = app.activeDocument;
        if (!isResult(d)) return 'Показать можно в готовой укладке.';
        var t = topItems(d), sr = [];
        for (var i = 0; i < t.length; i++) if (partNo(t[i].name) == n) sr.push(t[i]);
        if (!sr.length) return 'Таких деталей на листе нет.';
        select(d, sr);
        return 'Выделено на листе: ' + sr.length + ' шт. — «' + baseName(sr[0].name, n) + '».';
    }
    function showById(id) {
        if (!hasDoc()) return '';
        var d = app.activeDocument, it = byId(d, id);
        if (!it) return 'Этой детали в документе уже нет — уберите её из списка крестиком.';
        select(d, [it]);
        return 'Выделено на листе: «' + humanName(it) + '».';
    }
    function showIds(ids) {
        if (!hasDoc()) return '';
        var d = app.activeDocument, a = String(ids).split(','), sr = [], t = topItems(d);
        for (var i = 0; i < a.length; i++) {
            var it = byId(d, +a[i]); if (!it) continue;
            var n = templNo(it.name);
            if (n > 0) { for (var k = 0; k < t.length; k++) if (t[k].layer.name != NEST_TPL_LAYER && partNo(t[k].name) == n) sr.push(t[k]); }
            else sr.push(it);
        }
        if (!sr.length) return 'Этих деталей на листах нет — уберите строку или переразложите.';
        select(d, sr);
        return 'Выделено на листе: ' + sr.length + ' шт. — «' + humanName(sr[0]) + '».';
    }

    return { from: from, describe: describe, runList: runList, rerunList: rerunList, progress: progress, stopNow: stopNow, busy: busy, finish: finish,
             isResult: isResult, storedQty: storedQty, partsJson: partsJson, selBrief: selBrief, selParts: selParts, partsState: partsState,
             showPart: showPart, showById: showById, showIds: showIds, runPages: runPages };
})();

Bridge.NestParts = function () { try { return Nest.partsJson(); } catch (e) { return '{"res":false,"sig":"","parts":[]}'; } };
Bridge.NestShow = function (n) { return Nest.showPart(+n || 0); };
Bridge.NestSelBrief = function () { try { return Nest.selBrief(); } catch (e) { return ''; } };
Bridge.NestAddSel = function () { return Nest.selParts(); };
Bridge.NestCheck = function (ids) { try { return Nest.partsState(ids); } catch (e) { return ''; } };
Bridge.NestProgress = function () { return Nest.progress(); };
Bridge.NestStop = function () { return Nest.stopNow(); };
Bridge.NestFinish = function () { return Nest.finish(); };
Bridge.NestShowIds = function (ids) { return Nest.showIds(ids); };
Bridge.NestShowId = function (id) { return Nest.showById(+id || 0); };
Bridge.NestInfo = function (params, qtys) { return Nest.describe(Nest.from(params), qtys); };
Bridge.NestRunList = function (params, list) {
    if (!PSA.has('UWPML')) return 'Укладка по форме входит в части «УФ-планшет», «Рулонная печать», «Плоттер», «Фрезер» и «Лазер» — их нет в вашем ключе.';
    if (!hasDoc()) return 'Нет открытого документа.';
    if (!String(list).replace(/\s/g, '')) return 'Список пуст: выделите детали на листе и нажмите «Добавить в укладку».';
    var n = Nest.from(params), c = parseKV(params);
    Settings.set('Nest', 'W', n.SheetW); Settings.set('Nest', 'H', n.SheetH); Settings.set('Nest', 'Margin', n.Margin); Settings.set('Nest', 'Gap', n.Gap);
    Settings.set('Nest', 'Rot', n.Rot); Settings.set('Nest', 'Qual', c.nsQual || 'good'); Settings.set('Nest', 'More', n.Sheets == 0 ? '1' : '0');
    Settings.set('Nest', 'Mirror', n.Mirror ? '1' : '0'); Settings.set('Nest', 'Dxf', n.Dxf ? '1' : '0'); Settings.set('Nest', 'Speed', n.Speed); Settings.set('Nest', 'InHoles', n.InHoles ? '1' : '0');
    var d = app.activeDocument;
    if (Nest.isResult(d)) return Nest.rerunList(n, list);
    var o = docFolderBase(d);
    var f = outPath('nest', 'Сохранить укладку по форме', (o.base || 'Детали') + ' — укладка.ai', o.folder);
    if (!f) return '';
    return Nest.runList(n, list, f);
};
