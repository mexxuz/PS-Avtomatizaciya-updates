// DataMatrix ECC200 (квадратные 10x10 … 144x144) — как src/DM.bas.
// Режим GS1 (для «Честного знака»): в начале FNC1, символ GS (код 29) — разделитель.
// DM.encode(текст, gs1) -> { m: [строка][столбец], n } или { error }

var DM = (function () {
    // размер символа, данные, коррекция, сторона области данных, областей по стороне, блоков
    var SIZES = ('10,3,5,8,1,1;12,5,7,10,1,1;14,8,10,12,1,1;16,12,12,14,1,1;18,18,14,16,1,1;' +
        '20,22,18,18,1,1;22,30,20,20,1,1;24,36,24,22,1,1;26,44,28,24,1,1;32,62,36,14,2,1;' +
        '36,86,42,16,2,1;40,114,48,18,2,1;44,144,56,20,2,1;48,174,68,22,2,1;52,204,84,24,2,2;' +
        '64,280,112,14,4,2;72,368,144,16,4,4;80,456,192,18,4,4;88,576,224,20,4,4;96,696,272,22,4,4;' +
        '104,816,336,24,4,6;120,1050,408,18,6,6;132,1304,496,20,6,8;144,1558,620,22,6,10').split(';');
    var gfExp = [], gfLog = [], place, nrow, ncol;
    (function () {
        var x = 1, i;
        for (i = 0; i < 256; i++) gfLog.push(0);
        for (i = 0; i <= 254; i++) { gfExp[i] = x; gfLog[x] = i; x *= 2; if (x >= 256) x ^= 0x12D; }
        for (i = 255; i <= 510; i++) gfExp[i] = gfExp[i - 255];
    })();
    function gmul(a, b) { return (a == 0 || b == 0) ? 0 : gfExp[gfLog[a] + gfLog[b]]; }

    // символы -> кодовые слова (режим ASCII)
    function codewords(s, gs1) {
        var c = [], b = QR.utf8(s), i = 0, n = b.length;
        if (gs1) c.push(232);
        while (i < n) {
            if (i + 1 < n && b[i] >= 48 && b[i] <= 57 && b[i + 1] >= 48 && b[i + 1] <= 57) { c.push(130 + (b[i] - 48) * 10 + (b[i + 1] - 48)); i += 2; }
            else { if (b[i] < 128) c.push(b[i] + 1); else c.push(235, b[i] - 127); i++; }
        }
        return c;
    }

    function putModule(r, c, chr, bit) {
        if (r < 0) { r += nrow; c += 4 - ((nrow + 4) % 8); }
        if (c < 0) { c += ncol; r += 4 - ((ncol + 4) % 8); }
        place[r * ncol + c] = chr * 10 + bit;
    }
    function utah(r, c, k) {
        putModule(r - 2, c - 2, k, 1); putModule(r - 2, c - 1, k, 2); putModule(r - 1, c - 2, k, 3); putModule(r - 1, c - 1, k, 4);
        putModule(r - 1, c, k, 5); putModule(r, c - 2, k, 6); putModule(r, c - 1, k, 7); putModule(r, c, k, 8);
    }
    function corner1(k) {
        putModule(nrow - 1, 0, k, 1); putModule(nrow - 1, 1, k, 2); putModule(nrow - 1, 2, k, 3); putModule(0, ncol - 2, k, 4);
        putModule(0, ncol - 1, k, 5); putModule(1, ncol - 1, k, 6); putModule(2, ncol - 1, k, 7); putModule(3, ncol - 1, k, 8);
    }
    function corner2(k) {
        putModule(nrow - 3, 0, k, 1); putModule(nrow - 2, 0, k, 2); putModule(nrow - 1, 0, k, 3); putModule(0, ncol - 4, k, 4);
        putModule(0, ncol - 3, k, 5); putModule(0, ncol - 2, k, 6); putModule(0, ncol - 1, k, 7); putModule(1, ncol - 1, k, 8);
    }
    function corner3(k) {
        putModule(nrow - 3, 0, k, 1); putModule(nrow - 2, 0, k, 2); putModule(nrow - 1, 0, k, 3); putModule(0, ncol - 2, k, 4);
        putModule(0, ncol - 1, k, 5); putModule(1, ncol - 1, k, 6); putModule(2, ncol - 1, k, 7); putModule(3, ncol - 1, k, 8);
    }
    function corner4(k) {
        putModule(nrow - 1, 0, k, 1); putModule(nrow - 1, ncol - 1, k, 2); putModule(0, ncol - 3, k, 3); putModule(0, ncol - 2, k, 4);
        putModule(0, ncol - 1, k, 5); putModule(1, ncol - 3, k, 6); putModule(1, ncol - 2, k, 7); putModule(1, ncol - 1, k, 8);
    }
    function placement() {
        var k = 1, r = 4, c = 0, i;
        place = [];
        for (i = 0; i < nrow * ncol; i++) place.push(0);
        do {
            if (r == nrow && c == 0) corner1(k++);
            if (r == nrow - 2 && c == 0 && ncol % 4 != 0) corner2(k++);
            if (r == nrow - 2 && c == 0 && ncol % 8 == 4) corner3(k++);
            if (r == nrow + 4 && c == 2 && ncol % 8 == 0) corner4(k++);
            do {
                if (r < nrow && c >= 0 && place[r * ncol + c] == 0) utah(r, c, k++);
                r -= 2; c += 2;
            } while (r >= 0 && c < ncol);
            r += 1; c += 3;
            do {
                if (r >= 0 && c < ncol && place[r * ncol + c] == 0) utah(r, c, k++);
                r += 2; c -= 2;
            } while (r < nrow && c >= 0);
            r += 3; c += 1;
        } while (r < nrow || c < ncol);
        // незаполненный правый нижний угол — постоянный узор
        if (place[nrow * ncol - 1] == 0) { place[nrow * ncol - 1] = 1; place[(nrow - 2) * ncol + ncol - 2] = 1; }
    }

    function encode(s, gs1) {
        if (!s.length) return { error: 'DataMatrix: пустые данные' };
        var cw = codewords(s, gs1), cnt = cw.length, f = null, i, j, k, b;
        for (i = 0; i < SIZES.length; i++) { var t = SIZES[i].split(','); if (parseInt(t[1], 10) >= cnt) { f = t; break; } }
        if (!f) return { error: 'DataMatrix: слишком много данных' };
        var symSize = +f[0], dataCap = +f[1], eccTotal = +f[2], reg = +f[3], nReg = +f[4], nBlk = +f[5], total = [];
        for (i = 0; i < dataCap + eccTotal; i++) total.push(0);
        for (i = 0; i < cnt; i++) total[i] = cw[i];
        // дополнение
        for (i = cnt; i < dataCap; i++) {
            if (i == cnt) total[i] = 129;
            else { var pad = 129 + ((149 * (i + 1)) % 253) + 1; if (pad > 254) pad -= 254; total[i] = pad; }
        }
        // коррекция ошибок по блокам с чередованием
        var eccPer = Math.floor(eccTotal / nBlk), gen = [];
        for (i = 0; i <= eccPer; i++) gen.push(0);
        gen[0] = 1;
        for (i = 1; i <= eccPer; i++) {
            for (j = i; j >= 1; j--) gen[j] = gen[j - 1] ^ gmul(gen[j], gfExp[i]);
            gen[0] = gmul(gen[0], gfExp[i]);
        }
        for (b = 0; b < nBlk; b++) {
            var rem = [];
            for (j = 0; j < eccPer; j++) rem.push(0);
            for (k = b; k < dataCap; k += nBlk) {
                var fb = total[k] ^ rem[eccPer - 1];
                for (j = eccPer - 1; j >= 1; j--) rem[j] = rem[j - 1] ^ gmul(fb, gen[j]);
                rem[0] = gmul(fb, gen[0]);
            }
            for (j = 0; j < eccPer; j++) total[dataCap + b + j * nBlk] = rem[eccPer - 1 - j];
        }
        nrow = ncol = reg * nReg;
        placement();
        var m = [];
        for (i = 0; i < symSize; i++) { var row = []; for (j = 0; j < symSize; j++) row.push(0); m.push(row); }
        // рамки областей
        for (var sr = 0; sr < nReg; sr++) for (var sc = 0; sc < nReg; sc++) {
            for (i = 0; i <= reg + 1; i++) {
                var r0 = sr * (reg + 2) + i, c0 = sc * (reg + 2);
                m[r0][c0] = 1;                                          // левая сплошная
                m[r0][c0 + reg + 1] = i % 2 == 1 ? 1 : 0;               // правая пунктирная
                m[sr * (reg + 2) + reg + 1][sc * (reg + 2) + i] = 1;    // нижняя сплошная
                m[sr * (reg + 2)][sc * (reg + 2) + i] = i % 2 == 0 ? 1 : 0; // верхняя пунктирная
            }
            m[sr * (reg + 2) + reg + 1][sc * (reg + 2) + reg + 1] = 1;
        }
        for (i = 0; i < nrow; i++) for (j = 0; j < ncol; j++) {
            var v = place[i * ncol + j], bit;
            if (v == 1) bit = 1;
            else if (v >= 10) { k = Math.floor(v / 10); fb = v % 10; bit = (total[k - 1] & Math.pow(2, 8 - fb)) ? 1 : 0; }
            else bit = 0;
            m[Math.floor(i / reg) * (reg + 2) + 1 + (i % reg)][Math.floor(j / reg) * (reg + 2) + 1 + (j % reg)] = bit;
        }
        return { m: m, n: symSize };
    }

    // «Честный знак»: строка с разделителями GS. Понимает готовый GS, а также <GS>, {GS}, \x1d, \u001d, ~1.
    // Без разделителей пробует расставить их перед полями 91/92/93.
    function normalizeGS1(s) {
        var GS = '\u001d', t = String(s);
        t = t.replace(/<GS>/gi, GS).replace(/\{GS\}/gi, GS).replace(/\\x1d/gi, GS).replace(/\\u001d/gi, GS).replace(/~1/g, GS).replace(/↔/g, GS);
        if (t.charAt(0) == GS || t.charCodeAt(0) == 232) t = t.substring(1);
        if (t.indexOf(GS) < 0 && t.substring(0, 2) == '01' && t.substr(16, 2) == '21') {
            var lens = [13, 6, 7, 8, 11, 12, 20];
            for (var i = 0; i < lens.length; i++) {
                var p = 19 + lens[i];          // позиция с 1, как в CorelDRAW
                var at = t.substr(p - 1, 2);
                if (at == '91' || at == '93') {
                    t = t.substring(0, p - 1) + GS + t.substring(p - 1);
                    if (t.substr(p, 2) == '91' && t.substr(p + 6, 2) == '92') t = t.substring(0, p + 6) + GS + t.substring(p + 6);
                    break;
                }
            }
        }
        return t;
    }

    return { encode: encode, normalizeGS1: normalizeGS1 };
})();
