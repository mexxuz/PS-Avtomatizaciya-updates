// Пре-пресс, вывод: PDF для типографии (src/PrintPDF.bas), формы по краскам, превью на согласование
// (src/Proof.bas), сбор заказа (src/Package.bas), проверка папки (src/Batch.bas).
// Открытый документ не меняется: PDF и картинки делаются из рабочей копии файла.

// Рабочая копия сохранённого файла Illustrator (открыта, без окон). Ответ — документ или строка-ошибка.
// Не сохранён — спросить (silent — сохранить молча); без файла .ai — попросить сохранить.
function workCopyOf(d, silent) {
    var path = '';
    try { path = d.fullName.fsName; } catch (e) { }
    if (!path || !/\.ai$/i.test(path) || !new File(path).exists) return 'Сначала сохраните документ как файл Illustrator (.ai) — Файл → Сохранить как.';
    if (!d.saved) {
        if (!silent && !confirm('Документ не сохранён — в вывод идёт сохранённый файл.\r\n\r\nСохранить и продолжить?', false, 'PS • Автоматизация')) return 'Отменено: документ не сохранён.';
        d.save();
    }
    var f = new File(Folder.temp.fsName + '/psa_work_' + new Date().getTime() + '.ai');
    if (!new File(path).copy(f)) return 'Не удалось сделать рабочую копию файла.';
    var old = app.userInteractionLevel, w = null;
    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    try { w = app.open(f); } catch (e) { w = null; }
    app.userInteractionLevel = old;
    if (!w) { try { f.remove(); } catch (e) { } return 'Не удалось открыть рабочую копию файла.'; }
    return w;
}
function closeWorkCopy(w, back) {
    var f = null;
    try { f = w.fullName; } catch (e) { }
    try { w.close(SaveOptions.DONOTSAVECHANGES); } catch (e) { }
    try { if (f && /psa_work_/.test(f.name)) f.remove(); } catch (e) { }
    try { if (back) back.activate(); } catch (e) { }
}

var PrintPDF = (function () {
    function suffixOf(key) { return { offset: 'офсет PDF-X1a', digital: 'цифра PDF-X4', uv: 'УФ PDF-X4' }[key] || 'широкоформат'; }
    function versionText(key) {
        if (key == 'offset') return 'PDF/X-1a (стандарт типографий для офсета)';
        if (key == 'digital' || key == 'uv') return 'PDF/X-4';
        return 'PDF 1.5, картинки до 150 точек на дюйм';
    }
    function countErrors(chk) {
        var a = chk.split('\n'), n = 0, t = [];
        for (var i = 1; i < a.length; i++) { var f = a[i].split('|'); if (f.length >= 3 && f[1] == '2') { n++; t.push(f[2].toLowerCase()); } }
        return { n: n, titles: t.join(', ') };
    }

    function options(key, bleedMm, crop, isLayout, withStd) {
        var o = new PDFSaveOptions(), dpi = key == 'wide' ? 150 : 300;
        o.compatibility = key == 'offset' ? PDFCompatibility.ACROBAT4 : (key == 'wide' ? PDFCompatibility.ACROBAT6 : PDFCompatibility.ACROBAT7);
        if (withStd) try { if (key == 'offset') o.pDFXStandard = PDFXStandard.PDFX1A2001; else if (key != 'wide') o.pDFXStandard = PDFXStandard.PDFX42007; } catch (e) { }
        o.preserveEditability = false; o.generateThumbnails = false; o.viewAfterSaving = false; o.acrobatLayers = false;
        o.fontSubsetThreshold = 100;
        try { o.colorConversionID = ColorConversion.COLORCONVERSIONREPURPOSE; o.colorDestinationID = ColorDestination.COLORDESTINATIONWORKINGCMYK; } catch (e) { }
        try {
            o.colorDownsamplingMethod = DownsampleMethod.BICUBICDOWNSAMPLE; o.colorDownsampling = dpi; o.colorDownsamplingImageThreshold = dpi * 1.5;
            o.grayscaleDownsamplingMethod = DownsampleMethod.BICUBICDOWNSAMPLE; o.grayscaleDownsampling = dpi; o.grayscaleDownsamplingImageThreshold = dpi * 1.5;
            o.monochromeDownsamplingMethod = DownsampleMethod.BICUBICDOWNSAMPLE; o.monochromeDownsampling = 1200; o.monochromeDownsamplingImageThreshold = 1800;
        } catch (e) { }
        try { o.overprint = PDFOverprint.PRESERVEPDFOVERPRINT; } catch (e) { }
        if (isLayout) { o.trimMarks = false; o.bleedOffsetRect = [0, 0, 0, 0]; }
        else {
            var b = pt(Math.max(0, bleedMm));
            o.bleedOffsetRect = [b, b, b, b];
            o.trimMarks = !!crop;
            if (crop) try { o.trimMarkWeight = PDFTrimMarkWeight.TRIMMARKWEIGHT0125; o.pageMarksType = PageMarksTypes.Roman; } catch (e) { }
        }
        o.registrationMarks = false; o.colorBars = false; o.pageInformation = false;
        return o;
    }

    // Итог — текст для панели. path пустой — спросит, куда сохранить
    function exportPdf(profileKey, bleed, crop, path, silent) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, p = Preflight.profileOf(profileKey), rng = [], isLayout = false, i;
        if (bleed >= 0) p.Bleed = bleed;
        for (i = 0; i < d.artboards.length; i++) {
            var nm = d.artboards[i].name;
            if (nm == TEMPLATE_PAGE) continue;
            rng.push(i + 1);
            if (nm.substring(0, 7) == 'Лист — ' || nm == 'Лист' || nm == 'Рулон' || /^Пластина /.test(nm)) isLayout = true;
        }
        if (!rng.length) return 'В документе нет монтажных областей для печати.';
        var chk = Preflight.check(profileKey, p.Bleed, -1), ce = countErrors(chk);
        if (ce.n > 0 && !silent)
            if (!confirm('Проверка нашла ошибок: ' + ce.n + ' (' + ce.titles + ').\r\n\r\nИх видно на вкладке «Проверка». Всё равно сохранить PDF?', true, 'PDF для типографии'))
                return 'PDF не сохранён: сначала исправьте ошибки на вкладке «Проверка» — нажмите «Проверить».';
        if (!path) {
            var base = d.name.replace(/\.[^.]*$/, '') || 'макет', folder = Folder.myDocuments.fsName;
            try { folder = d.fullName.parent.fsName; } catch (e) { }
            var sel = new File(folder + '/' + base + ' — ' + suffixOf(p.Key) + '.pdf').saveDlg('PDF для типографии', 'PDF:*.pdf');
            if (!sel) return '';
            path = sel.fsName;
            if (!/\.pdf$/i.test(path)) path += '.pdf';
        }
        var w = workCopyOf(d, silent);
        if (typeof w == 'string') return w;
        var ranges = rangeText(rng), err = '';
        try {
            var o = options(p.Key, p.Bleed, crop, isLayout, true);
            o.artboardRange = ranges;
            var f = new File(path);
            if (f.exists) f.remove();
            try { w.saveAs(f, o); }
            catch (e1) {
                // стандарт PDF/X не принял документ — тот же вывод без отметки стандарта
                o = options(p.Key, p.Bleed, crop, isLayout, false);
                o.artboardRange = ranges;
                w.saveAs(f, o);
                err = ' (без отметки PDF/X: ' + e1.message + ')';
            }
        } catch (e) {
            closeWorkCopy(w, d);
            logLine('сбой PDF для типографии: ' + e.message);
            return 'Не удалось сохранить PDF: ' + e.message;
        }
        closeWorkCopy(w, d);
        logLine('PDF для типографии: ' + path + ' (' + p.Title + ', страниц ' + rng.length + ')');
        return 'PDF сохранён: ' + path + '\r\nДля ' + p.Title + ': ' + versionText(p.Key) + err + ', CMYK, страниц ' + rng.length +
            (isLayout ? ', лист раскладки как есть.' : ', вылет ' + mmText(p.Bleed) + ' мм' + (crop ? ', метки реза.' : '.'));
    }

    // [1,2,3,5] → «1-3,5» для artboardRange
    function rangeText(a) {
        var t = [], lo = a[0], hi = lo;
        for (var i = 1; i < a.length; i++) { if (a[i] == hi + 1) hi = a[i]; else { t.push(lo == hi ? lo : lo + '-' + hi); lo = hi = a[i]; } }
        t.push(lo == hi ? lo : lo + '-' + hi);
        return t.join(',');
    }

    // Цветоделение Illustrator включает только из набора настроек печати: заданное командой (режим «Separations»,
    // свой размер бумаги) он молча пропускает или считает минутами и падает (03.10.2026). Образец набора —
    // host/psa_separations.prst (принтер «Adobe PostScript File», описание устройства Adobe PDF, цветоделение,
    // без меток); для листа своего размера — копия образца со своим именем, подключается один раз
    function hexBlock(s) {
        var h = '', i;
        for (i = 0; i < s.length; i++) { var c = s.charCodeAt(i) & 255; h += (c < 16 ? '0' : '') + c.toString(16); }
        var lines = [];
        for (i = 0; i < h.length; i += 64) lines.push('\t\t\t' + h.substring(i, i + 64));
        return '[ ' + s.length + '\n' + lines.join('\n') + '\n\t\t]';
    }
    function sepPreset(d, W, H) {
        var name = 'PSA Sep ' + Math.round(mm(W)) + 'x' + Math.round(mm(H)), i;
        for (i = 0; i < app.printPresetsList.length; i++) if (app.printPresetsList[i] == name) return name;
        var ppd = '', l = app.PPDFileList;
        for (i = 0; i < l.length; i++) if (l[i].name == 'Adobe PDF') try { ppd = l[i].PPDInfo.PPDFilePath.fsName; } catch (e) { }
        if (!ppd) return '';
        var t = readText(PSA_DIR + '/psa_separations.prst').replace(/\r/g, ''), w = W.toFixed(4), h = H.toFixed(4);
        t = t.replace(/\/collectionName \[[^\]]*\]/, '/collectionName ' + hexBlock(name))
             .replace(/\/stl\.customppd \[[^\]]*\]/, '/stl.customppd ' + hexBlock(ppd))
             .replace(/\/(c?ppr\.width|ppr\.image\.right) [\d.]+/g, '/$1 ' + w)
             .replace(/\/(c?ppr\.height|ppr\.image\.bottom) [\d.]+/g, '/$1 ' + h)
             .replace(/\/crd\.orientation \d+/, '/crd.orientation 0');      // без автоповорота: страница — как область
        var f = new File(Folder.temp.fsName + '/psa_sep_' + new Date().getTime() + '.prst');
        f.encoding = 'ASCII'; f.open('w'); f.write(t); f.close();
        d.importPrintPreset(name, f);
        try { f.remove(); } catch (e) { }
        return name;
    }

    function printFileHelper(psPath) {
        var s = new File(PSA_DIR + '/printfile.ps1');
        if (!s.exists) return;
        var vbs = new File(Folder.temp.fsName + '/psa_printfile_' + new Date().getTime() + '.vbs');
        vbs.encoding = 'UTF-16'; vbs.open('w');
        vbs.write('CreateObject("WScript.Shell").Run "powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""' + s.fsName + '"" -Path ""' + psPath + '"" -Wait 120", 0, False\r\n');
        vbs.close();
        vbs.execute();
        $.sleep(1500);     // помощнику — время запуститься до окна печати
    }

    // Формы по краскам: Illustrator печатает цветоделение активной области в файл PostScript,
    // панель переводит его в PDF программой Acrobat Distiller — каждая краска отдельной страницей
    function inkPlates(path) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, ab = d.artboards.getActiveArtboardIndex(), i;
        if (!path) {
            var base = d.name.replace(/\.[^.]*$/, '') || 'Документ', folder = Folder.myDocuments.fsName;
            try { folder = d.fullName.parent.fsName; } catch (e) { }
            var sel = new File(folder + '/' + base + ' — формы.pdf').saveDlg('Формы по краскам', 'PDF:*.pdf');
            if (!sel) return '';
            path = sel.fsName;
            if (!/\.pdf$/i.test(path)) path += '.pdf';
        }
        var ps = new File(Folder.temp.fsName + '/psa_plates_' + new Date().getTime() + '.ps'), r = d.artboards[ab].artboardRect;
        try {
            var preset = sepPreset(d, r[2] - r[0], r[1] - r[3]);
            if (!preset) return 'Для форм по краскам нужен Adobe Acrobat: без его описания устройства (Adobe PDF) Illustrator не делит на краски.';
            var o = new PrintOptions(), j = new PrintJobOptions();
            o.printPreset = preset;
            j.file = ps; j.artboardRange = String(ab + 1); j.designation = PrintArtworkDesignation.VISIBLEPRINTABLELAYERS; j.copies = 1;
            o.jobOptions = j;
            // принтер «PostScript File» открывает окно «Print to File» — имя файла в него впишет помощник
            // (host/printfile.ps1), запущенный заранее: пока окно открыто, Illustrator занят и сам ничего не сделает
            printFileHelper(ps.fsName);
            d.print(o);
        } catch (e) {
            logLine('сбой форм по краскам: ' + e.message + ' (строка ' + e.line + ')');
            return 'Формы не вывелись: ' + e.message;
        }
        if (!ps.exists) return 'Формы не вывелись: Illustrator не записал файл печати.';
        return '\u0001distill|' + toJson({ ps: ps.fsName, pdf: path, msg: 'Формы по краскам — в PDF, каждая краска отдельной страницей: ' + path });
    }

    return { exportPdf: exportPdf, inkPlates: inkPlates, countErrors: countErrors };
})();

// ---------- превью на согласование ----------

var Proof = (function () {
    function capSize(widthMm) { return Math.max(7, Math.min(60, widthMm / 30)); }

    // Каждая область (кроме шаблона стола) — JPG: красная линия — край после резки, серая — вылет, подпись внизу.
    // Итог — папка с картинками или текст ошибки
    function run(bleed, folder, dpi) {
        if (!hasDoc()) return 'Нет открытого документа.';
        dpi = dpi || 150;
        var d = app.activeDocument, base = d.name.replace(/\.[^.]*$/, '') || 'макет', i;
        if (!folder) {
            try { folder = d.fullName.parent.fsName + '/' + base + ' — на согласование'; } catch (e) { return 'Сначала сохраните документ.'; }
        }
        new Folder(folder).create();
        var abs = [];
        for (i = 0; i < d.artboards.length; i++) if (d.artboards[i].name != TEMPLATE_PAGE) abs.push(i);
        var w = workCopyOf(d, false);
        if (typeof w == 'string') return w;
        try {
            for (var n = 0; n < abs.length; n++) {
                var f = folder + '/' + base + (abs.length > 1 ? ' — стр. ' + (n < 9 ? '0' : '') + (n + 1) : '') + '.jpg';
                onePage(w, abs[n], n + 1, abs.length, bleed, f, dpi, d.name);
            }
        } catch (e) {
            closeWorkCopy(w, d);
            logLine('сбой превью: ' + e.message + ' (строка ' + e.line + ')');
            return 'Не удалось сделать превью: ' + e.message;
        }
        closeWorkCopy(w, d);
        logLine('превью на согласование: ' + abs.length + ' стр. → ' + folder);
        return new Folder(folder).fsName;
    }

    function onePage(d, ab, n, total, bleed, path, dpi, fileName) {
        var R = d.artboards[ab].artboardRect, W = mm(R[2] - R[0]), H = mm(R[1] - R[3]), i, k;
        // соседние области не должны попасть в картинку
        var hid = [];
        for (i = 0; i < d.layers.length; i++) {
            var tl = topItemsOn(d, d.layers[i], -1);
            for (k = 0; k < tl.length; k++) if (abIndexOf(d, tl[k]) != ab && !tl[k].hidden) { tl[k].hidden = true; hid.push(tl[k]); }
        }
        var cs = capSize(W + 2 * bleed + 16), lh = cs * 0.353, m = bleed + 8, below = bleed + lh * 2.8 + 6;
        var area = [R[0] - pt(m), R[1] + pt(m), R[2] + pt(m), R[3] - pt(below)];
        // снизу — белый лист, сверху — линия реза и подпись
        var lb = d.layers.add(); lb.name = '~превью фон'; lb.zOrder(ZOrderMethod.SENDTOBACK);
        var bg = lb.pathItems.rectangle(area[1], area[0], area[2] - area[0], area[1] - area[3]); bg.stroked = false; bg.fillColor = rgbColor(255, 255, 255);
        var lt = d.layers.add(); lt.name = '~превью рамка';
        var r1 = lt.pathItems.rectangle(R[1] + pt(bleed), R[0] - pt(bleed), R[2] - R[0] + pt(2 * bleed), R[1] - R[3] + pt(2 * bleed));
        r1.filled = false; r1.stroked = true; r1.strokeWidth = pt(0.2); r1.strokeColor = rgbColor(150, 150, 150);
        var r2 = lt.pathItems.rectangle(R[1], R[0], R[2] - R[0], R[1] - R[3]);
        r2.filled = false; r2.stroked = true; r2.strokeWidth = pt(W > 300 ? 0.8 : 0.3); r2.strokeColor = rgbColor(230, 0, 0);
        var cap = fileName + (total > 1 ? ' · стр. ' + n + ' из ' + total : '') + ' · формат ' + mmText(W) + ' × ' + mmText(H) + ' мм' + (bleed > 0 ? ' · вылет ' + mmText(bleed) + ' мм' : '') + ' · ' + today();
        var maxW = area[2] - area[0] - pt(6);
        caption(lt, cap, cs, rgbColor(40, 40, 40), area[0] + pt(3), area[3] + pt(lh * 1.3 + 3), maxW);
        caption(lt, 'Красная линия — край изделия после резки. Всё, что за ней, срежется. Цвета на экране — приблизительно.', cs * 0.8, rgbColor(200, 0, 0), area[0] + pt(3), area[3] + pt(2), maxW);
        // картинка — по временной области с полями
        var tmp = d.artboards.add(area);
        d.artboards.setActiveArtboardIndex(d.artboards.length - 1);
        var o = new ExportOptionsJPEG(), sc = Math.min(776, dpi / 72 * 100);
        o.artBoardClipping = true; o.horizontalScale = sc; o.verticalScale = sc; o.qualitySetting = 85; o.antiAliasing = true;
        // Illustrator меняет пробелы в имени картинки на дефисы — сохранить под временным именем и переименовать
        var f = new File(path), tf = new File(f.parent.fsName + '/psa_proof_tmp.jpg');
        if (f.exists) f.remove();
        if (tf.exists) tf.remove();
        d.exportFile(tf, ExportType.JPEG, o);
        tf.rename(path.replace(/^.*[\\\/]/, ''));
        d.artboards.setActiveArtboardIndex(0);
        d.artboards.remove(d.artboards.length - 1);
        lb.remove(); lt.remove();
        for (i = 0; i < hid.length; i++) hid[i].hidden = false;
    }

    function caption(L, s, size, color, x, y, maxW) {
        var t = L.textFrames.pointText([x, y]);
        t.contents = s;
        t.textRange.characterAttributes.size = size;
        t.textRange.characterAttributes.fillColor = color;
        var b = t.geometricBounds;
        if (b[2] - b[0] > maxW) t.textRange.characterAttributes.size = size * maxW / (b[2] - b[0]);
        return t;
    }

    return { run: run };
})();

// ---------- сбор заказа ----------

var Package = (function () {
    function collect(d) {
        var fonts = {}, fl = [], links = {}, ll = [], i, k;
        for (i = 0; i < d.textFrames.length; i++) {
            var rs = d.textFrames[i].textRanges;
            for (k = 0; k < rs.length && k < 500; k++) {
                try { var fam = rs[k].characterAttributes.textFont.family; if (fam && !fonts[fam.toLowerCase()]) { fonts[fam.toLowerCase()] = 1; fl.push(fam); } } catch (e) { }
            }
        }
        for (i = 0; i < d.placedItems.length; i++) {
            var p = '';
            try { p = d.placedItems[i].file.fsName; } catch (e) { p = ''; }
            if (p && !links[p.toLowerCase()]) { links[p.toLowerCase()] = 1; ll.push(p); }
        }
        return { fonts: fl, links: ll };
    }

    function chkText(chk) {
        var a = chk.split('\n'), t = '  ' + a[0] + '\r\n';
        for (var i = 1; i < a.length; i++) {
            var f = a[i].split('|');
            if (f.length >= 6) t += '  ' + (['сведения', 'предупреждение', 'ОШИБКА'][+f[1]] || '') + ': ' + f[2] + ' — ' + f[5] + ' шт.\r\n';
        }
        return t;
    }

    function run(profileKey, bleed) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, path = '';
        try { path = d.fullName.fsName; } catch (e) { }
        if (!path || !d.saved || !/\.ai$/i.test(path)) return 'Сначала сохраните документ как файл Illustrator (.ai) — в заказ идёт сохранённый файл.';
        var base = d.name.replace(/\.[^.]*$/, ''), dir = d.fullName.parent.fsName + '/' + base + ' — в печать', miss = [], i;
        new Folder(dir).create();
        try {
            // 1. Макет
            var cp = new File(dir + '/' + d.name);
            if (cp.exists) cp.remove();
            d.fullName.copy(cp);
            // 2. Картинки по ссылкам; шрифты — копирует панель (ей видны файлы шрифтов Windows)
            var c = collect(d);
            if (c.links.length) {
                new Folder(dir + '/Картинки').create();
                for (i = 0; i < c.links.length; i++) {
                    var lf = new File(c.links[i]);
                    if (lf.exists) lf.copy(new File(dir + '/Картинки/' + lf.name)); else miss.push('  нет файла картинки: ' + c.links[i]);
                }
            }
            // 3. Проверка и PDF
            var chk = Preflight.check(profileKey, bleed, -1);
            var r = PrintPDF.exportPdf(profileKey, bleed, false, dir + '/' + base + '.pdf', true);
            // 4. Превью
            Proof.run(bleed, dir + '/Превью');
            // 5. Паспорт
            var R0 = d.artboards[0].artboardRect, t = 'ПАСПОРТ ЗАКАЗА\r\nМакет: ' + d.name + '\r\nСобран: ' + today() + ' ' + timeNow() + '\r\n';
            t += 'Страниц: ' + d.artboards.length + ', формат первой: ' + mmText(mm(R0[2] - R0[0])) + ' × ' + mmText(mm(R0[1] - R0[3])) + ' мм\r\n';
            t += 'Печать: ' + Preflight.profileOf(profileKey).Title + ', вылет ' + mmText(bleed) + ' мм\r\n\r\n';
            t += 'PDF: ' + r.replace(/\r\n/g, ' ') + '\r\n\r\n';
            t += 'Проверка макета:\r\n' + chkText(chk) + '\r\n';
            t += 'Шрифты (' + c.fonts.length + '):\r\n';
            for (i = 0; i < c.fonts.length; i++) t += '  ' + c.fonts[i] + '\r\n';
            if (c.links.length) t += 'Картинки по ссылкам: ' + c.links.length + '\r\n';
            if (miss.length) t += '\r\nНЕ ХВАТАЕТ:\r\n' + miss.join('\r\n') + '\r\n';
            writeText(dir + '/Паспорт заказа.txt', t);
            logLine('сбор заказа: ' + dir);
            var msg = 'Заказ собран: ' + new Folder(dir).fsName + '\r\nМакет, PDF, превью' + (c.links.length ? ', картинки: ' + c.links.length : '');
            return '\u0001fonts|' + toJson({ dir: new Folder(dir).fsName, fonts: c.fonts, passport: new File(dir + '/Паспорт заказа.txt').fsName, msg: msg, miss: miss.length > 0 });
        } catch (e) {
            logLine('сбой сбора заказа: ' + e.message + ' (строка ' + e.line + ')');
            return 'Сбой сбора заказа: ' + e.message;
        }
    }
    return { run: run };
})();

function timeNow() { var d = new Date(), z = function (n) { return (n < 10 ? '0' : '') + n; }; return z(d.getHours()) + ':' + z(d.getMinutes()); }

// ---------- проверка папки ----------

var Batch = {};
Batch.Files = function (folder) {
    var out = [], fs = new Folder(folder).getFiles('*.ai');
    for (var i = 0; i < fs.length; i++) if (fs[i] instanceof File && fs[i].name.charAt(0) != '~') out.push(fs[i]);
    return out;
};
Batch.Run = function (folder, profileKey, bleed, doPdf) {
    var list = this.Files(folder), n = 0, bad = 0, i, k;
    if (!list.length) return 'В папке нет файлов Illustrator (.ai).';
    var pdfDir = folder + '/PDF';
    if (doPdf) new Folder(pdfDir).create();
    var t = 'ПРОВЕРКА ПАПКИ ' + new Folder(folder).fsName + '\r\n' + today() + ' ' + timeNow() + ', ' + Preflight.profileOf(profileKey).Title + ', вылет ' + mmText(bleed) + ' мм\r\n\r\n';
    for (i = 0; i < list.length; i++) {
        n++;
        var p = list[i], d = null, was = false;
        for (k = 0; k < app.documents.length; k++) { try { if (app.documents[k].fullName.fsName.toLowerCase() == p.fsName.toLowerCase()) { d = app.documents[k]; was = true; } } catch (e) { } }
        if (!d) {
            var old = app.userInteractionLevel;
            app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
            try { d = app.open(p); } catch (e) { t += p.fsName.replace(/^.*[\\\/]/, '') + ': НЕ ОТКРЫЛСЯ — ' + e.message + '\r\n\r\n'; bad++; }
            app.userInteractionLevel = old;
            if (!d) continue;
        }
        d.activate();
        var chk = Preflight.check(profileKey, bleed, -1), a = chk.split('\n'), errs = 0, line = '';
        for (k = 1; k < a.length; k++) {
            var f = a[k].split('|');
            if (f.length >= 6) {
                if (f[1] == '2') errs++;
                if (f[1] != '0') line += '    ' + (f[1] == '2' ? 'ОШИБКА: ' : '') + f[2] + ' — ' + f[5] + ' шт.\r\n';
            }
        }
        if (errs) bad++;
        t += d.name + ': ' + (errs ? 'ошибок ' + errs : 'в порядке') + '\r\n' + line;
        if (doPdf) {
            // проверка могла убрать дубли на свой слой — PDF из файла как он есть на диске
            var r = was ? PrintPDF.exportPdf(profileKey, bleed, false, pdfDir + '/' + d.name.replace(/\.[^.]*$/, '') + '.pdf', true) : batchPdf(p, profileKey, bleed, pdfDir);
            t += '    ' + r.split('\r\n')[0] + '\r\n';
        }
        t += '\r\n';
        if (!was) d.close(SaveOptions.DONOTSAVECHANGES);
    }
    writeText(folder + '/Проверка папки.txt', t);
    logLine('проверка папки: ' + folder + ', файлов ' + n + ', с ошибками ' + bad);
    return 'Проверено файлов: ' + n + ', с ошибками: ' + bad + (doPdf ? ', PDF — в подпапке «PDF»' : '') + '.\r\nОтчёт: ' + new File(folder + '/Проверка папки.txt').fsName;
};
// PDF файла папки: открыть заново (проверка меняла документ), вывести, закрыть
function batchPdf(p, profileKey, bleed, pdfDir) {
    var old = app.userInteractionLevel, d;
    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    try { d = app.open(p); } finally { app.userInteractionLevel = old; }
    try { return PrintPDF.exportPdf(profileKey, bleed, false, pdfDir + '/' + d.name.replace(/\.[^.]*$/, '') + '.pdf', true); }
    finally { d.close(SaveOptions.DONOTSAVECHANGES); }
}

// ---------- команды панели ----------

Bridge.PFExport = function (profile, bleed, crop) { return PrintPDF.exportPdf(profile, toNum(bleed, -1), crop == '1', '', false); };
Bridge.InkPlates = function () { return PrintPDF.inkPlates(''); };
Bridge.ProofRun = function (bleed) {
    var r = Proof.run(toNum(bleed, 0), '');
    if (/^[A-Za-z]:\\/.test(r)) { try { new Folder(r).execute(); } catch (e) { } return 'Превью для согласования сохранены в папку: ' + r; }
    return r;
};
Bridge.PackageRun = function (profile, bleed) { return Package.run(profile, toNum(bleed, 0)); };
Bridge.BatchRun = function (profile, bleed, pdf) {
    var start = Settings.get('Batch', 'Folder', ''), f = (start && new Folder(start).exists ? new Folder(start) : Folder.myDocuments).selectDlg('Папка с макетами Illustrator');
    if (!f) return '';
    Settings.set('Batch', 'Folder', f.fsName);
    var n = Batch.Files(f.fsName).length;
    if (!n) return 'В папке нет файлов Illustrator (.ai).';
    if (!confirm('В папке файлов Illustrator: ' + n + '.\r\n\r\nКаждый откроется, проверится' + (pdf == '1' ? ', сохранится в PDF' : '') + ' и закроется без сохранения. Сами файлы не меняются.\r\nНачать?', false, 'Проверка папки')) return '';
    return Batch.Run(f.fsName, profile, toNum(bleed, 0), pdf == '1');
};
