// Резка — как src/CutFile.bas и src/CutCheck.bas: файл для станка (плоттер, лазер, фрезер), метки SignMaster
// вокруг линии реза, проверка контуров (дубли, соринки, разрывы, куски, наложения) с исправлением.
// Координаты для расчёта и файлов — мм от левого нижнего угла активной монтажной области, y вверх.
// Геометрию проверки считает bin/VarPrint_nest.exe --check (тот же, что у CorelDRAW).

var CUT_MARK_LAYER = 'Резка: пометки', CUT_JUNK_LAYER = 'Резка: лишнее', CUT_OLD_LAYER = 'Резка: до правки';
var LASER_CUT_LAYER = 'Лазер: рез', LASER_MOVE_LAYER = 'Лазер: холостые ходы', LASER_SRC_LAYER = 'Лазер: исходные';

// ---------- общее ----------

function cutAb(d) { var i = d.artboards.getActiveArtboardIndex(); return { i: i, R: d.artboards[i].artboardRect }; }
function cutN(v) { return String(Math.round(v * 100000) / 100000); }
function cutNum(s) { return parseFloat(String(s).replace(',', '.')) || 0; }
// точка документа (пт) → мм от левого нижнего угла области, и обратно
function cutMm(R, p) { return [mm(p[0] - R[0]), mm(p[1] - R[3])]; }
function cutPt(R, x, y) { return [R[0] + pt(x), R[3] + pt(y)]; }
function cutIsOurs(L) { var n = L.name; return n == CUT_MARK_LAYER || n == CUT_JUNK_LAYER || n == CUT_OLD_LAYER || n == LASER_MOVE_LAYER || n == LASER_SRC_LAYER || n == LASER_CUT_LAYER; }
function cutTopLayer(it) { var L = it.layer; while (L.parent && L.parent.typename == 'Layer') L = L.parent; return L; }
function cutLayer(d, name, visible) {
    var L = layerNamed(d, name, false);
    L.printable = false; L.visible = visible !== false; L.locked = false;
    return L;
}
function cutFindLayer(d, name) { for (var i = 0; i < d.layers.length; i++) if (d.layers[i].name == name) return d.layers[i]; return null; }

// Запуск VarPrint_nest.exe: задание в файл, программа — через невидимый сценарий Windows, ждём файл ответа
function cutRunExe(mode, job) {
    var exe = new File(PSA_DIR + '/../bin/VarPrint_nest.exe');
    if (!exe.exists) return 'ok=0\nerror=нет программы расчёта VarPrint_nest.exe рядом с панелью';
    var dir = new Folder(Folder.temp.fsName + '/PS-Avtomatizaciya'); if (!dir.exists) dir.create();
    var stamp = new Date().getTime(), fj = new File(dir.fsName + '/cut_job_' + stamp + '.txt'), fo = new File(dir.fsName + '/cut_out_' + stamp + '.txt');
    var done = new File(dir.fsName + '/cut_done_' + stamp + '.flag'), vbs = new File(dir.fsName + '/cut_run_' + stamp + '.vbs');
    writeText(fj.fsName, job);
    var q = function (s) { return '""' + s + '""'; };
    vbs.encoding = 'UTF-16'; vbs.open('w');
    vbs.write('Set sh = CreateObject("WScript.Shell")\r\nsh.Run "' + q(exe.fsName) + ' ' + mode + ' ' + q(fj.fsName) + ' ' + q(fo.fsName) + '", 0, True\r\n' +
              'CreateObject("Scripting.FileSystemObject").CreateTextFile("' + done.fsName + '").Close\r\n');
    vbs.close();
    vbs.execute();
    var t0 = new Date().getTime();
    while (!done.exists && new Date().getTime() - t0 < 180000) $.sleep(100);
    var res = done.exists ? readText(fo.fsName) : 'ok=0\nerror=программа расчёта не ответила за 3 минуты';
    try { fj.remove(); fo.remove(); done.remove(); vbs.remove(); } catch (e) { }
    return res.replace(/^﻿/, '');
}
function cutVal(res, key) {
    var a = String(res).replace(/\r/g, '').split('\n');
    for (var i = 0; i < a.length; i++) if (a[i].substring(0, key.length + 1) == key + '=') return a[i].substring(key.length + 1);
    return '';
}
function cutLines(res, key) {
    var a = String(res).replace(/\r/g, '').split('\n'), out = [];
    for (var i = 0; i < a.length; i++) if (a[i].substring(0, key.length + 1) == key + '=') out.push(a[i].substring(key.length + 1));
    return out;
}

// Контуры объекта: PathItem — он сам; составной — его части; текст — части временной копии в кривых.
// tmp — сюда кладутся временные копии (удалить после)
function cutSubs(it, tmp) {
    var t = it.typename;
    if (t == 'PathItem') return [it];
    if (t == 'CompoundPathItem') { var a = []; for (var i = 0; i < it.pathItems.length; i++) a.push(it.pathItems[i]); return a; }
    if (t == 'TextFrame') {
        try {
            var g = it.duplicate().createOutline(), out = [];
            tmp.push(g);
            (function walk(x) {
                if (x.typename == 'PathItem') out.push(x);
                else if (x.typename == 'CompoundPathItem') for (var k = 0; k < x.pathItems.length; k++) out.push(x.pathItems[k]);
                else if (x.typename == 'GroupItem') for (var k2 = 0; k2 < x.pageItems.length; k2++) walk(x.pageItems[k2]);
            })(g);
            return out;
        } catch (e) { return []; }
    }
    return [];
}
// Контур в виде «x y;C x1 y1 x2 y2 x y;L x y» (мм); замкнутый — с замыкающим отрезком
function cutPathData(pi, R) {
    var pp = pi.pathPoints, n = pp.length;
    if (n < 1) return '';
    var a0 = cutMm(R, pp[0].anchor), t = cutN(a0[0]) + ' ' + cutN(a0[1]);
    var last = pi.closed ? n : n - 1;
    for (var i = 0; i < last; i++) {
        var p = pp[i], q = pp[(i + 1) % n], r = p.rightDirection, l = q.leftDirection;
        var line = Math.abs(r[0] - p.anchor[0]) < 1e-6 && Math.abs(r[1] - p.anchor[1]) < 1e-6 && Math.abs(l[0] - q.anchor[0]) < 1e-6 && Math.abs(l[1] - q.anchor[1]) < 1e-6;
        var e = cutMm(R, q.anchor);
        if (line) t += ';L ' + cutN(e[0]) + ' ' + cutN(e[1]);
        else { var c1 = cutMm(R, r), c2 = cutMm(R, l); t += ';C ' + cutN(c1[0]) + ' ' + cutN(c1[1]) + ' ' + cutN(c2[0]) + ' ' + cutN(c2[1]) + ' ' + cutN(e[0]) + ' ' + cutN(e[1]); }
    }
    return t;
}
// Путь Illustrator из данных расчёта (мм) на слое/в группе cont
function cutMakePath(cont, R, data, closed) {
    var a = data.split(';'), q = a[0].replace(/^\s+|\s+$/g, '').split(' '), pts = [{ a: cutPt(R, cutNum(q[0]), cutNum(q[1])) }];
    for (var j = 1; j < a.length; j++) {
        q = a[j].replace(/^\s+|\s+$/g, '').split(' ');
        if (q[0] == 'C') {
            pts[pts.length - 1].r = cutPt(R, cutNum(q[1]), cutNum(q[2]));
            pts.push({ a: cutPt(R, cutNum(q[5]), cutNum(q[6])), l: cutPt(R, cutNum(q[3]), cutNum(q[4])) });
        } else pts.push({ a: cutPt(R, cutNum(q[1]), cutNum(q[2])) });
    }
    // у замкнутого последняя точка совпадает с первой — сливаем
    if (closed && pts.length > 2) {
        var f = pts[0], l2 = pts[pts.length - 1];
        if (Math.abs(f.a[0] - l2.a[0]) < 0.01 && Math.abs(f.a[1] - l2.a[1]) < 0.01) { if (l2.l) f.l = l2.l; pts.pop(); }
    }
    var p = cont.pathItems.add(), anchors = [];
    for (var i = 0; i < pts.length; i++) anchors.push(pts[i].a);
    p.setEntirePath(anchors);
    for (i = 0; i < pts.length; i++) {
        var pp = p.pathPoints[i];
        if (pts[i].l) pp.leftDirection = pts[i].l;
        if (pts[i].r) pp.rightDirection = pts[i].r;
    }
    p.closed = !!closed;
    return p;
}
// Ломаная контура (мм), кривые — мелкими отрезками с точностью tol
function cutFlatten(pi, R, tol) {
    var pp = pi.pathPoints, n = pp.length, out = [];
    if (!n) return out;
    out.push(cutMm(R, pp[0].anchor));
    var last = pi.closed ? n : n - 1;
    for (var i = 0; i < last; i++) {
        var p = pp[i], q = pp[(i + 1) % n];
        var x0 = cutMm(R, p.anchor), x1 = cutMm(R, p.rightDirection), x2 = cutMm(R, q.leftDirection), x3 = cutMm(R, q.anchor);
        var dv = Math.max(Math.sqrt(Math.pow(x0[0] - 2 * x1[0] + x2[0], 2) + Math.pow(x0[1] - 2 * x1[1] + x2[1], 2)),
                          Math.sqrt(Math.pow(x1[0] - 2 * x2[0] + x3[0], 2) + Math.pow(x1[1] - 2 * x2[1] + x3[1], 2)));
        var straight = Math.abs(x1[0] - x0[0]) + Math.abs(x1[1] - x0[1]) + Math.abs(x2[0] - x3[0]) + Math.abs(x2[1] - x3[1]) < 1e-6;
        var m = straight ? 1 : Math.max(1, Math.min(400, Math.ceil(Math.sqrt(0.75 * dv / tol))));
        for (var k = 1; k < m; k++) {
            var t = k / m, u = 1 - t;
            out.push([u * u * u * x0[0] + 3 * u * u * t * x1[0] + 3 * u * t * t * x2[0] + t * t * t * x3[0],
                      u * u * u * x0[1] + 3 * u * u * t * x1[1] + 3 * u * t * t * x2[1] + t * t * t * x3[1]]);
        }
        if (!(pi.closed && i == last - 1)) out.push(x3);
    }
    return out;
}

// Объекты для резки: из групп — по одному; в обтравочной группе — только её рамка; картинки не режутся
function cutCollect(it, out) {
    var t = it.typename;
    try { if (it.hidden || it.guides) return; } catch (e) { }
    if (t == 'GroupItem') {
        if (it.clipped) { for (var c = 0; c < it.pageItems.length; c++) if (it.pageItems[c].typename == 'PathItem' && it.pageItems[c].clipping) { out.push({ it: it.pageItems[c], clip: true }); return; } return; }
        for (var i = it.pageItems.length - 1; i >= 0; i--) cutCollect(it.pageItems[i], out);
        return;
    }
    if (t == 'PathItem' || t == 'CompoundPathItem' || t == 'TextFrame') out.push({ it: it, clip: false });
}
// Выделенное — или всё видимое и печатное на области; снизу вверх (нижний — первый: режется первым)
function cutSource(d, ab, selOnly) {
    var out = [], i, k;
    if (selOnly) {
        var s = selectionItems(d);
        for (i = s.length - 1; i >= 0; i--) if (!cutIsOurs(cutTopLayer(s[i]))) cutCollect(s[i], out);
        return out;
    }
    for (i = d.layers.length - 1; i >= 0; i--) {
        var L = d.layers[i];
        if (cutIsOurs(L) || !L.visible || !L.printable) continue;
        var tl = topItemsOn(d, L, ab);
        for (k = tl.length - 1; k >= 0; k--) cutCollect(tl[k], out);
    }
    return out;
}

function cutRing(L, R, x, y, r, g, b) {
    var c = cutPt(R, x - 3, y + 3), e = L.pathItems.ellipse(c[1], c[0], pt(6), pt(6));
    e.filled = false; e.stroked = true; e.strokeWidth = pt(0.6); e.strokeColor = rgbColor(r, g, b);
    return e;
}
function cutTrail(L, R, pts, w, r, g, b) {
    var a = pts.split(';'), xy = [];
    for (var i = 0; i < a.length; i++) { var q = a[i].replace(/^\s+|\s+$/g, '').split(' '); if (q.length >= 2) xy.push(cutPt(R, cutNum(q[0]), cutNum(q[1]))); }
    if (xy.length < 2) return null;
    var p = L.pathItems.add(); p.setEntirePath(xy);
    p.filled = false; p.stroked = true; p.strokeWidth = pt(w); p.strokeColor = rgbColor(r, g, b);
    return p;
}
function cutPink(it) {
    var pink = rgbColor(255, 0, 170), lv = [];
    (function walk(x) {
        if (x.typename == 'GroupItem') { for (var k = 0; k < x.pageItems.length; k++) walk(x.pageItems[k]); return; }
        if (x.typename == 'CompoundPathItem') { for (var k2 = 0; k2 < x.pathItems.length; k2++) lv.push(x.pathItems[k2]); return; }
        lv.push(x);
    })(it);
    for (var i = 0; i < lv.length; i++) {
        try {
            if (lv[i].typename == 'TextFrame') { lv[i].textRange.characterAttributes.fillColor = pink; continue; }
            if (lv[i].filled) lv[i].fillColor = pink;
            lv[i].stroked = true; lv[i].strokeColor = pink; if (!lv[i].strokeWidth) lv[i].strokeWidth = pt(0.3);
        } catch (e) { }
    }
}

// ---------- метки SignMaster и файл для станка ----------

var CutFile = (function () {
    function isCutSpot(c) { try { return c.typename == 'SpotColor' && /^(cutcontour|contourcut)$/i.test(c.spot.name); } catch (e) { return false; } }
    function strokeColorOf(x) { var s = x.typename == 'CompoundPathItem' && x.pathItems.length ? x.pathItems[0] : x; try { return s.stroked ? s.strokeColor : null; } catch (e) { return null; } }

    // Линия реза на области: слой CutContour и всё с обводкой плашкой CutContour (ContourCut — так её зовёт SignMaster)
    function cutItems(d, ab) {
        var out = [], i, k;
        for (i = 0; i < d.layers.length; i++) {
            var L = d.layers[i];
            if (!L.visible) continue;
            var tl = topItemsOn(d, L, ab);
            if (L.name.toLowerCase() == CUT_LAYER_ROLL.toLowerCase()) { out = out.concat(tl); continue; }
            var lv = leavesOf(tl);
            for (k = 0; k < lv.length; k++) if (isCutSpot(strokeColorOf(lv[k]))) out.push(lv[k]);
        }
        return out;
    }
    function layerItems(d, ab, name) { var L = cutFindLayer(d, name); return L ? topItemsOn(d, L, ab) : []; }

    // Метки SignMaster вокруг линии реза (а без неё — вокруг всего печатаемого); прежние метки области — долой
    function signMasterMarks(gap) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, A = cutAb(d), R = A.R, i, src, out = '';
        if (!(gap > 0)) gap = 3;
        var ml = cutFindLayer(d, MARK_LAYER);
        if (ml) { var old = topItemsOn(d, ml, A.i); for (i = old.length - 1; i >= 0; i--) old[i].remove(); }
        var items = cutItems(d, A.i);
        if (items.length) src = 'линии реза (CutContour)';
        else {
            for (i = 0; i < d.layers.length; i++) { var L = d.layers[i]; if (L.visible && L.printable && L.name != MARK_LAYER) items = items.concat(topItemsOn(d, L, A.i)); }
            src = 'всего макета на области';
            out = '\r\nВнимание: линии реза в файле нет (цвет или слой CutContour), поэтому метки — вокруг рисунка. SignMaster ставит их вокруг линии реза: ' +
                  'если контур реза больше рисунка, метки не совпадут и рез сдвинется. Добавьте в файл линию реза цветом CutContour и нажмите ещё раз.';
        }
        if (!items.length) return 'На области ничего нет — ставить метки не вокруг чего.';
        var b = boundsOf(items);       // пт: л, в, п, н
        var bl = mm(b[0] - R[0]), br = mm(b[2] - R[0]), bt = mm(R[1] - b[1]), bb = mm(R[1] - b[3]);
        if (src.indexOf('линии реза') == 0) out += bleedNote(d, A, items, b);
        var g = layerNamed(d, MARK_LAYER, true).groupItems.add();
        g.name = 'Метки SignMaster';
        Roll.signMaster(g, R, bl, br, bt, bb, 4, gap);
        // метки должны напечататься: за краем области — сказать на сколько
        var W = mm(R[2] - R[0]), H = mm(R[1] - R[3]);
        var oL = gap + 4 - bl, oR = br + gap + 4 - W, oT = 2 + 3.5 + 4 - bt, oB = bb + 2 - H;
        if (oL > 0 || oR > 0 || oT > 0 || oB > 0)
            out += '\r\nВнимание: метки выходят за край области — ' + (oL > 0 ? 'слева на ' + mmText(oL) + ' мм ' : '') + (oR > 0 ? 'справа на ' + mmText(oR) + ' мм ' : '') +
                   (oT > 0 ? 'сверху на ' + mmText(oT) + ' мм ' : '') + (oB > 0 ? 'снизу на ' + mmText(oB) + ' мм ' : '') + '— и не напечатаются. Увеличьте область или отодвиньте макет от края.';
        var msg = 'Метки SignMaster поставлены вокруг ' + src + ': ' + mmText(bb - bt > 0 ? br - bl : 0) + ' × ' + mmText(bb - bt) + ' мм, отступ ' + mmText(gap) + ' мм, ' +
                  'участков по длине ' + Math.max(1, Math.round((bb - bt) / 300)) + '. Слой «' + MARK_LAYER + '».' + out;
        logLine('метки SignMaster: ' + msg.replace(/\r\n/g, ' / '));
        return msg;
    }

    // Печать должна заходить за линию реза примерно на 2 мм: при промахе ножа не останется белого края
    function bleedNote(d, A, cut, cb) {
        var art = [], i, k, inCut = {};
        for (i = 0; i < d.layers.length; i++) {
            var L = d.layers[i];
            if (!L.visible || !L.printable || L.name == MARK_LAYER || L.name.toLowerCase() == CUT_LAYER_ROLL.toLowerCase()) continue;
            var tl = topItemsOn(d, L, A.i);
            for (k = 0; k < tl.length; k++) {
                var only = true, lv = leavesOf([tl[k]]);
                for (var j = 0; j < lv.length; j++) if (!isCutSpot(strokeColorOf(lv[j]))) { only = false; break; }
                if (!only) art.push(tl[k]);
            }
        }
        if (!art.length) return '\r\nВнимание: на области одна линия реза — печатать нечего.';
        var ab = boundsOf(art), least = Math.min(cb[0] - ab[0], ab[2] - cb[2], ab[1] - cb[1], cb[3] - ab[3]) / (72 / 25.4);
        if (least < 1.5)
            return '\r\nВнимание: ' + (least < -0.05 ? 'печать местами не доходит до линии реза' : (least <= 0.05 ? 'печать кончается ровно по линии реза — вылета нет' : 'печать заходит за линию реза только на ' + mmText(least) + ' мм')) +
                   '. Нужен вылет около 2 мм, иначе при небольшом промахе ножа останется белый край. Постройте его на шаге «Вылет».';
        return '';
    }

    // ---- DXF R12 и PLT (HPGL) пишем сами ----
    var DXF_TOL = 0.01, PLT_TOL = 0.025;
    var ACI_RGB = [[255, 0, 0], [255, 255, 0], [0, 255, 0], [0, 255, 255], [0, 0, 255], [255, 0, 255], [0, 0, 0]], ACI_NAME = ['RED', 'YELLOW', 'GREEN', 'CYAN', 'BLUE', 'MAGENTA', 'BLACK'];
    function rgbOf(c) {
        try {
            switch (c.typename) {
                case 'RGBColor': return [c.red, c.green, c.blue];
                case 'CMYKColor': return [255 * (1 - c.cyan / 100) * (1 - c.black / 100), 255 * (1 - c.magenta / 100) * (1 - c.black / 100), 255 * (1 - c.yellow / 100) * (1 - c.black / 100)];
                case 'GrayColor': var v = 255 * (1 - c.gray / 100); return [v, v, v];
                case 'SpotColor': return rgbOf(c.spot.color);
            }
        } catch (e) { }
        return null;
    }
    function aciOf(x, mill) {
        var s = x, col = null;
        try { col = s.stroked ? s.strokeColor : (s.filled ? s.fillColor : null); } catch (e) { }
        var c = col ? rgbOf(col) : null, best = 6, bd = 1e30;
        if (c) for (var i = 0; i < 7; i++) { var dd = Math.pow(c[0] - ACI_RGB[i][0], 2) + Math.pow(c[1] - ACI_RGB[i][1], 2) + Math.pow(c[2] - ACI_RGB[i][2], 2); if (dd < bd) { bd = dd; best = i; } }
        var lay = ACI_NAME[best];
        // фрезер после «Оптимизировать резку»: зелёные — по линии, синие — снаружи, красные — внутри
        if (mill) lay = { GREEN: 'PO_LINII', BLUE: 'SNARUZHI', RED: 'VNUTRI' }[lay] || lay;
        return { aci: best + 1, lay: lay };
    }
    function layAci(nm) { return { RED: 1, VNUTRI: 1, YELLOW: 2, GREEN: 3, PO_LINII: 3, CYAN: 4, BLUE: 5, SNARUZHI: 5, MAGENTA: 6 }[nm] || 7; }

    // Контуры набора объектов снизу вверх: [{pts:[[x,y]...], closed, color}]
    function contours(items, R, tol, mill, st) {
        var out = [], tmp = [];
        for (var i = 0; i < items.length; i++) {
            var lv = [];
            (function walk(x) {
                if (x.typename == 'GroupItem') { for (var k = x.pageItems.length - 1; k >= 0; k--) walk(x.pageItems[k]); return; }   // нижний — первым
                lv.push(x);
            })(items[i]);
            for (var j = 0; j < lv.length; j++) {
                var subs = cutSubs(lv[j], tmp), col = aciOf(lv[j].typename == 'CompoundPathItem' && lv[j].pathItems.length ? lv[j].pathItems[0] : lv[j], mill);
                for (var k = 0; k < subs.length; k++) {
                    var p = cutFlatten(subs[k], R, tol);
                    if (p.length < 2) continue;
                    out.push({ pts: p, closed: subs[k].closed, aci: col.aci, lay: col.lay });
                    st.paths++; if (!subs[k].closed) st.open++;
                }
            }
        }
        for (i = 0; i < tmp.length; i++) try { tmp[i].remove(); } catch (e) { }
        return out;
    }
    function writeDxf(path, cs, W, H) {
        var body = ['0', 'SECTION', '2', 'ENTITIES'], lays = {}, mn = [1e30, 1e30], mx = [-1e30, -1e30], i, k;
        for (i = 0; i < cs.length; i++) {
            var c = cs[i]; lays[c.lay] = 1;
            body.push('0', 'POLYLINE', '8', c.lay, '62', String(c.aci), '66', '1', '10', '0.0', '20', '0.0', '30', '0.0', '70', c.closed ? '1' : '0');
            for (k = 0; k < c.pts.length; k++) {
                var x = c.pts[k][0], y = c.pts[k][1];
                mn[0] = Math.min(mn[0], x); mn[1] = Math.min(mn[1], y); mx[0] = Math.max(mx[0], x); mx[1] = Math.max(mx[1], y);
                body.push('0', 'VERTEX', '8', c.lay, '10', cutN(x), '20', cutN(y), '30', '0.0');
            }
            body.push('0', 'SEQEND', '8', c.lay);
        }
        body.push('0', 'ENDSEC', '0', 'EOF');
        if (mn[0] > mx[0]) { mn = [0, 0]; mx = [0, 0]; }
        var head = ['0', 'SECTION', '2', 'HEADER', '9', '$ACADVER', '1', 'AC1009', '9', '$INSUNITS', '70', '4', '9', '$MEASUREMENT', '70', '1',
                    '9', '$EXTMIN', '10', cutN(mn[0]), '20', cutN(mn[1]), '30', '0.0', '9', '$EXTMAX', '10', cutN(mx[0]), '20', cutN(mx[1]), '30', '0.0',
                    '9', '$LIMMIN', '10', '0.0', '20', '0.0', '9', '$LIMMAX', '10', cutN(W), '20', cutN(H), '0', 'ENDSEC',
                    '0', 'SECTION', '2', 'TABLES', '0', 'TABLE', '2', 'LTYPE', '70', '1',
                    '0', 'LTYPE', '2', 'CONTINUOUS', '70', '0', '3', 'Solid line', '72', '65', '73', '0', '40', '0.0', '0', 'ENDTAB'];
        var ln = []; for (var nm in lays) if (lays.hasOwnProperty(nm)) ln.push(nm);
        head.push('0', 'TABLE', '2', 'LAYER', '70', String(ln.length + 1), '0', 'LAYER', '2', '0', '70', '0', '62', '7', '6', 'CONTINUOUS');
        for (i = 0; i < ln.length; i++) head.push('0', 'LAYER', '2', ln[i], '70', '0', '62', String(layAci(ln[i])), '6', 'CONTINUOUS');
        head.push('0', 'ENDTAB', '0', 'ENDSEC');
        var f = new File(path); f.encoding = 'ASCII'; f.lineFeed = 'Windows'; f.open('w'); f.write(head.concat(body).join('\r\n') + '\r\n'); f.close();
    }
    // HPGL: 40 шагов на миллиметр, начало — левый нижний угол области
    function writePlt(path, cs) {
        var t = 'IN;PA;SP1;', s = function (v) { return String(Math.round(v * 40)); };
        for (var i = 0; i < cs.length; i++) {
            var p = cs[i].pts, a = [];
            for (var k = 1; k < p.length; k++) a.push(s(p[k][0]) + ',' + s(p[k][1]));
            if (cs[i].closed) a.push(s(p[0][0]) + ',' + s(p[0][1]));
            t += '\nPU' + s(p[0][0]) + ',' + s(p[0][1]) + ';PD' + a.join(',') + ';';
        }
        t += '\nPU0,0;SP0;';
        var f = new File(path); f.encoding = 'ASCII'; f.open('w'); f.write(t); f.close();
    }
    // AI: только эти объекты — копией в новый документ размером с область
    function writeAi(path, items, R) {
        var d0 = app.activeDocument, nd = app.documents.add(d0.documentColorSpace, R[2] - R[0], R[1] - R[3]), L = nd.layers[0];
        try {
            var b0 = items[0].geometricBounds, dups = [];
            for (var i = items.length - 1; i >= 0; i--) dups.push(items[i].duplicate(L, ElementPlacement.PLACEATBEGINNING));
            // между документами Illustrator пересчитывает координаты — область ставим по сдвигу первого объекта
            var b1 = dups[dups.length - 1].geometricBounds, dx = b1[0] - b0[0], dy = b1[1] - b0[1];
            nd.artboards[0].artboardRect = [R[0] + dx, R[1] + dy, R[2] + dx, R[3] + dy];
            var f = new File(path); if (f.exists) f.remove();
            nd.saveAs(f, new IllustratorSaveOptions());
        } finally { nd.close(SaveOptions.DONOTSAVECHANGES); d0.activate(); }
    }

    // what: plot | laser | mill; fmt: plt | dxf | ai; marks — добавить метки плоттера (только плоттер)
    function save(what, fmt, marks) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, A = cutAb(d), R = A.R, items = [], src = '', tip = '', i;
        if (what == 'plot') {
            var onLayer = layerItems(d, A.i, CUT_LAYER_ROLL), all = cutItems(d, A.i);
            items = all;
            if (onLayer.length) src = 'слой «' + CUT_LAYER_ROLL + '»';
            if (all.length > onLayer.length) src = (src ? src + ' и ' : '') + 'линии цвета CutContour';
        } else {
            items = layerItems(d, A.i, LASER_CUT_LAYER);
            if (items.length) src = 'слой «' + LASER_CUT_LAYER + '» — в порядке реза';
        }
        var mill = what == 'mill' && items.length > 0, sel = selectionItems(d);
        if (!items.length && sel.length) { items = sel; src = 'выделенное'; }
        if (!items.length && what == 'mill') {
            for (i = d.layers.length - 1; i >= 0; i--) { var L = d.layers[i]; if (L.visible && L.printable && !cutIsOurs(L)) items = items.concat(topItemsOn(d, L, A.i)); }
            if (items.length) src = 'всё на области';
        }
        if (!items.length) {
            if (what == 'plot') return 'Контура реза нет: на области нет слоя «CutContour» и линий цвета CutContour. Сделайте раскладку на рулон с контуром реза — или выделите линии реза и нажмите ещё раз.';
            if (what == 'laser') return 'Линий реза нет: сначала «Оптимизировать резку» — или выделите линии реза и нажмите ещё раз.';
            return 'На области нечего сохранять.';
        }
        // снизу вверх по наложению — порядок реза
        items.sort(function (a, b) { return cutZ(b) - cutZ(a); });
        var cnt = items.length;
        if (what == 'plot' && marks) {
            var mk = layerItems(d, A.i, MARK_LAYER);
            if (mk.length) { items = items.concat(mk); tip = ', с метками плоттера'; } else tip = ', меток плоттера на области нет';
        }
        if (fmt != 'plt' && fmt != 'ai') fmt = 'dxf';
        var nm = what == 'plot' ? 'плоттер' : (what == 'laser' ? 'лазер' : 'фрезер'), f = '';
        try { f = d.fullName.fsName.replace(/\.[^.\\\/]*$/, '') + ' — ' + nm + (d.artboards.length > 1 ? ' — стр ' + (A.i + 1) : '') + '.' + fmt; } catch (e) { f = ''; }
        if (!f) {
            var sd = new File(Folder.myDocuments.fsName + '/' + d.name + ' — ' + nm + '.' + fmt).saveDlg('Куда сохранить файл для станка', fmt.toUpperCase() + ':*.' + fmt);
            if (!sd) return '';
            f = sd.fsName;
        }
        var W = mm(R[2] - R[0]), H = mm(R[1] - R[3]), st = { paths: 0, open: 0 };
        try {
            if (fmt == 'ai') writeAi(f, items, R);
            else {
                var cs = contours(items, R, fmt == 'dxf' ? DXF_TOL : PLT_TOL, mill, st);
                if (fmt == 'dxf') writeDxf(f, cs, W, H); else writePlt(f, cs);
                if (fmt == 'dxf') tip += ', контуров ' + st.paths + (st.open > 0 && src.indexOf(LASER_CUT_LAYER) < 0 ? ', из них незамкнутых ' + st.open + ' — посмотрите «Контуры»' : '');
            }
        } catch (e) {
            logLine('сбой файла для станка: ' + e.message + ' (строка ' + e.line + ')');
            return 'Файл для станка не сохранился: ' + e.message;
        }
        var msg = 'Сохранено: ' + f.replace(/^.*[\\\/]/, '') + ' — рядом с макетом.\r\nВзято: ' + src + ', объектов ' + cnt + tip + '. Начало координат — левый нижний угол области.';
        if (what == 'laser' && fmt == 'dxf') msg += '\r\nВ RDWorks: меню «Файл», пункт «Импорт». Каждый цвет линий — свой слой со своей скоростью и мощностью. Автоматическую оптимизацию пути выключите — порядок реза уже задан.';
        if (what == 'mill' && fmt == 'dxf') msg += mill ? '\r\nВ ArtCAM: импорт векторов. Слои: PO_LINII — путь центра фрезы, обработка «по линии» без смещения; SNARUZHI — «снаружи»; VNUTRI — окна, «внутри». Сначала VNUTRI, потом PO_LINII, потом SNARUZHI.'
                                                         : '\r\nВ ArtCAM: импорт векторов. Кривые уже разбиты на мелкие отрезки (точность 0,01 мм). Общий рез и порядок — «Порядок реза → Оптимизировать резку».';
        if (what == 'plot') msg += '\r\nОткройте его в программе плоттера. Печать с контуром для RIP — это сама раскладка, отдельный файл не нужен.';
        logLine('файл для станка: ' + f);
        return msg;
    }
    // порядок наложения: больше — выше (слой выше и выше внутри слоя)
    function cutZ(it) {
        var L = cutTopLayer(it), d = app.activeDocument, li = 0, i;
        for (i = 0; i < d.layers.length; i++) if (d.layers[i] == L) { li = i; break; }
        var z = 0; try { z = it.absoluteZOrderPosition; } catch (e) { z = 0; }
        return (d.layers.length - li) * 1e6 + z;
    }

    // DXF набора объектов (для раскроя по форме): R12, мм, нуль — левый нижний угол области R
    function saveDxf(path, items, R) {
        var st = { paths: 0, open: 0 }, cs = contours(items, R, DXF_TOL, false, st);
        writeDxf(path, cs, mm(R[2] - R[0]), mm(R[1] - R[3]));
        return st;
    }

    return { signMasterMarks: signMasterMarks, save: save, cutItems: cutItems, saveDxf: saveDxf };
})();

// ---------- проверка контуров ----------

var CutCheck = (function () {
    var S = null;      // последняя проверка: { doc, ab, items:[{it,clip}], subs:[кол-во], res, params, found:{ключ:[объекты]} }

    function alive(x) { try { return !!x.parent && !cutIsOurs(cutTopLayer(x)); } catch (e) { return false; } }
    function shp(idx) { if (!S) return null; var o = S.items[idx]; return o && alive(o.it) ? o : null; }
    function found(key, o) { if (!o) return; var a = S.found[key] = S.found[key] || []; for (var i = 0; i < a.length; i++) if (a[i] === o.it) return; a.push(o.it); }
    function junkOf(d, kind) {
        var L = cutFindLayer(d, CUT_JUNK_LAYER), out = [];
        if (!L) return out;
        for (var i = 0; i < L.pageItems.length; i++) { var it = L.pageItems[i]; if (it.parent == L && it.note == 'psa:' + kind) out.push(it); }
        return out;
    }
    function toJunk(d, it, kind) {
        var L = cutLayer(d, CUT_JUNK_LAYER, true);
        it.note = 'psa:' + kind;
        it.move(L, ElementPlacement.PLACEATBEGINNING);
        cutPink(it);
    }
    // слой исходных: пока правим — видимый (в скрытый Illustrator класть не даёт), после правки прячется
    function oldLayer(d) { return cutLayer(d, CUT_OLD_LAYER, true); }
    // Пока текущий слой скрыт, Illustrator не даёт рисовать ни на каком слое — текущим делаем обычный видимый
    function hideOld(d) {
        var L = cutFindLayer(d, CUT_OLD_LAYER);
        if (!L) return;
        if (d.activeLayer == L) for (var i = 0; i < d.layers.length; i++) if (d.layers[i].visible && !d.layers[i].locked && !cutIsOurs(d.layers[i])) { d.activeLayer = d.layers[i]; break; }
        if (L.pageItems.length) L.visible = false; else L.remove();
    }
    function sizeMm(it) { var b = it.geometricBounds; return mm(b[2] - b[0]) + mm(b[1] - b[3]); }

    // Отпечаток деталей области: сколько объектов и их общий размер (после «Оптимизировать резку» — исходные)
    function partsSig(d, ab) {
        var list = [], i, sum = 0, cl = cutFindLayer(d, LASER_CUT_LAYER);
        if (cl && topItemsOn(d, cl, ab).length) { var sl = cutFindLayer(d, LASER_SRC_LAYER); if (sl) { var t = topItemsOn(d, sl, ab); for (i = 0; i < t.length; i++) cutCollect(t[i], list); } }
        else list = cutSource(d, ab, false);
        for (i = 0; i < list.length; i++) try { sum += sizeMm(list[i].it); } catch (e) { }
        return list.length + ':' + Math.round(sum);
    }

    function ending(n) { if (n % 100 >= 11 && n % 100 <= 14) return 'ов'; var m = n % 10; return m == 1 ? '' : (m >= 2 && m <= 4 ? 'а' : 'ов'); }

    // Итог: первая строка — сводка; дальше «ключ|уровень|заголовок|исправимо|пояснение|сколько»
    function check(params) {
        if (!hasDoc()) return 'Нет открытого документа.';
        var d = app.activeDocument, A = cutAb(d), R = A.R, c = parseKV(params), G = function (k, dv) { return c.hasOwnProperty(k) ? c[k] : dv; };
        var gap = cutNum(G('ccGap', '0.5')), tiny = cutNum(G('ccTiny', '0.3')), selOnly = G('ccScope', 'page') == 'sel', i, k;
        var keep = selectionItems(d);
        if (selOnly && !keep.length) return 'Ничего не выделено: выделите детали — или выберите «вся страница».';
        var items = cutSource(d, A.i, selOnly);
        if (!items.length) {
            var lc = cutFindLayer(d, LASER_CUT_LAYER);
            if (lc && topItemsOn(d, lc, A.i).length) return 'Резка на этой области уже подготовлена. Проверяют детали, а не линии реза: «Порядок реза → Вернуть как было», проверьте и оптимизируйте заново.';
            return 'Нечего проверять: ' + (selOnly ? 'в выделенном' : 'на области') + ' нет контуров.';
        }
        S = { doc: d, ab: A.i, items: items, subs: [], res: '', params: params, found: {} };
        var job = 'tol=' + cutN(cutNum(G('ccTol', '0.05'))) + '\ngap=' + cutN(gap) + '\ntiny=' + cutN(tiny) + '\n', tmp = [], nPaths = 0;
        for (i = 0; i < items.length; i++) {
            var subs = cutSubs(items[i].it, tmp), n = 0;
            for (k = 0; k < subs.length; k++) { var dt = cutPathData(subs[k], R); if (!dt) continue; n++; job += 'p=' + i + '.' + (k + 1) + '|' + (subs[k].closed ? '1' : '0') + '|' + dt + '\n'; }
            S.subs.push(subs.length); nPaths += n;
        }
        for (i = 0; i < tmp.length; i++) try { tmp[i].remove(); } catch (e) { }
        var res = cutRunExe('--check', job);
        if (cutVal(res, 'ok') != '1') { S = null; return 'Проверка не получилась: ' + cutVal(res, 'error'); }
        S.res = res;
        // прошлые пометки — долой
        var lm = cutFindLayer(d, CUT_MARK_LAYER);
        if (lm) { var om = topItemsOn(d, lm, -1); for (i = om.length - 1; i >= 0; i--) om[i].remove(); }
        lm = null;
        function marks() { if (!lm) { lm = cutLayer(d, CUT_MARK_LAYER, true); lm.zOrder(ZOrderMethod.BRINGTOFRONT); } return lm; }
        var nDup = 0, nTinyW = 0, nTinyP = 0, nOver = 0, nGap = 0, nJoin = 0, nOpen = 0, nCross = 0, nSelf = 0, nOut = 0, overLen = 0, skipClip = 0, tinyCnt = {};
        var a = res.replace(/\r/g, '').split('\n');
        for (i = 0; i < a.length; i++) {
            var key = a[i].split('=')[0];
            if (!key || key == 'ok') continue;
            var f = a[i].substring(key.length + 1).split('|'), q, o, o2;
            if (key == 'dup') {
                var hi = shp(+f[0]), lo = shp(+f[1]);
                if (hi && lo) {
                    // рамку обтравки не трогаем: уносим другую копию или обе оставляем
                    if (hi.clip) { var t = lo; lo = hi; hi = t; }
                    if (hi.clip) skipClip++;
                    else { toJunk(d, hi.it, 'dup'); nDup++; }
                }
            } else if (key == 'tiny') {
                q = f[0].split('.'); tinyCnt[q[0]] = (tinyCnt[q[0]] || 0) + 1;
            } else if (key == 'over') {
                found('over', shp(+f[0].split('.')[0])); found('over', shp(+f[1].split('.')[0]));
                cutTrail(marks(), R, f[3], 1.2, 255, 140, 0); nOver++; overLen += cutNum(f[2]);
            } else if (key == 'gap') {
                q = f[0].split('.'); o = shp(+q[0]);
                if (o) {
                    var sub = cutSubs(o.it, []);
                    var pi = o.it.typename == 'TextFrame' ? null : sub[+q[1] - 1];
                    if (pi) { var p0 = cutMm(R, pi.pathPoints[0].anchor); cutRing(marks(), R, p0[0], p0[1], 230, 0, 0); }
                    found('gap', o); nGap++;
                }
            } else if (key == 'join') {
                q = f[1].split(',');
                for (k = 0; k < q.length; k++) found('join', shp(+q[k].split('.')[0]));
                var jp = cutMakePath(marks(), R, f[3], f[0] == '1');
                jp.filled = false; jp.stroked = true; jp.strokeWidth = pt(0.6); jp.strokeColor = rgbColor(0, 170, 60); jp.strokeDashes = [pt(1.5), pt(1)];
                nJoin++;
            } else if (key == 'open') {
                q = f[0].split(',');
                for (k = 0; k < q.length; k++) found('open', shp(+q[k].split('.')[0]));
                var e1 = f[1].split(' '), e2 = f[2].split(' ');
                cutRing(marks(), R, cutNum(e1[0]), cutNum(e1[1]), 230, 0, 0); cutRing(marks(), R, cutNum(e2[0]), cutNum(e2[1]), 230, 0, 0);
                nOpen++;
            } else if (key == 'cross') {
                found('cross', shp(+f[0])); found('cross', shp(+f[1]));
                q = f[2].split(' '); cutRing(marks(), R, cutNum(q[0]), cutNum(q[1]), 230, 0, 0); nCross++;
            } else if (key == 'self') {
                found('self', shp(+f[0]));
                q = f[1].split(' '); cutRing(marks(), R, cutNum(q[0]), cutNum(q[1]), 230, 0, 0); nSelf++;
            }
        }
        // соринки: весь объект мелкий — на «лишнее», мелочь внутри объекта — кружком
        for (var ki in tinyCnt) if (tinyCnt.hasOwnProperty(ki)) {
            o = shp(+ki);
            if (!o) continue;
            var b = o.it.geometricBounds, cc = cutMm(R, [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2]);
            cutRing(marks(), R, cc[0], cc[1], 255, 0, 170);
            if (tinyCnt[ki] >= S.subs[+ki] && !o.clip) { toJunk(d, o.it, 'tiny'); nTinyW++; }
            else { found('tinyp', o); nTinyP += tinyCnt[ki]; }
        }
        // за краем области
        for (i = 0; i < items.length; i++) {
            o = shp(i); if (!o) continue;
            var bb = o.it.geometricBounds, e = pt(0.01);
            if (bb[0] < R[0] - e || bb[2] > R[2] + e || bb[3] < R[3] - e || bb[1] > R[1] + e) { found('outside', o); nOut++; }
        }
        if (lm && !lm.pageItems.length) lm.remove();
        try { d.selection = null; for (i = 0; i < keep.length; i++) if (alive(keep[i])) keep[i].selected = true; } catch (x) { }
        nDup = junkOf(d, 'dup').length; nTinyW = junkOf(d, 'tiny').length;
        var lines = '';
        if (nDup) lines += '\ndup|2|Дубли|1|Объект лежал точно на таком же — станок прошёл бы по нему дважды: у лазера пережог, у фрезера лишний проход. Копии уже перенесены на слой «' + CUT_JUNK_LAYER + '» и закрашены розовым, в резку этот слой не идёт.' + (skipClip ? ' Рамки обтравки не тронуты: ' + skipClip + '.' : '') + ' Исправить — удалить копии.|' + nDup;
        if (nTinyW + nTinyP) lines += '\ntiny|1|Соринки|1|Контуры мельче ' + mmText(tiny) + ' мм: на каждом станок сделает лишнюю врезку.' + (nTinyW ? ' Целые объекты (' + nTinyW + ') — на слое «' + CUT_JUNK_LAYER + '», розовые.' : '') + (nTinyP ? ' Мелочь внутри объектов (' + nTinyP + ') обведена розовым кружком.' : '') + ' Исправить — удалить.|' + (nTinyW + nTinyP);
        if (nGap) lines += '\ngap|2|Разрывы|1|Концы контура почти сходятся (до ' + mmText(gap) + ' мм), но он не замкнут: фрезер не поймёт, где внутри, где снаружи, лазер оставит перемычку. Места — красными кружками. Исправить — замкнуть.|' + nGap;
        if (nJoin) lines += '\njoin|2|Линия из кусков|1|Контур собран из отдельных кусков, которые сходятся концами — так бывает после PDF и DXF: станок сделает врезку на каждом куске, на стыках останутся следы. Будущие линии — зелёным пунктиром. Исправить — склеить в одну линию; куски уйдут на скрытый слой «' + CUT_OLD_LAYER + '».|' + nJoin;
        if (nSelf) lines += '\nself|2|Буквы внахлёст|1|Внутри одного объекта контуры заходят друг на друга — так бывает у рукописных шрифтов: станок разрежет буквы по месту наложения. Места — красными кружками. Исправить — объединить наложенные буквы в один контур, окна букв сохранятся; исходный — на скрытом слое «' + CUT_OLD_LAYER + '».|' + nSelf;
        if (nCross) lines += '\ncross|2|Детали заходят друг на друга|1|Замкнутые контуры разных объектов пересекаются: станок прорежет одну деталь другой. Места — красными кружками. Исправить — объединить их в один контур, как «Обработка контуров → Добавить» в Illustrator; исходные — на скрытом слое «' + CUT_OLD_LAYER + '».|' + nCross;
        if (nOver) lines += '\nover|1|Двойные линии|0|Кусок одной линии лежит на другой (' + Math.round(overLen) + ' мм) — обычно общий край двух деталей: станок пройдёт по нему дважды. Обведено оранжевым. У лазера прямые общие края уберёт «Порядок реза → Оптимизировать резку» с галочкой «Общие края резать один раз»; кривые — поправьте вручную или раздвиньте детали.|' + nOver;
        if (nOpen) lines += '\nopen|1|Незамкнутые линии|0|Концы линии далеко друг от друга. Для гравировки или надреза линией это нормально, а деталь по такой линии не вырезать. Концы — красными кружками.|' + nOpen;
        if (nOut) lines += '\noutside|1|За краем листа|0|Объекты выходят за край монтажной области — проверьте, что лист материала задан верно и детали на нём помещаются.|' + nOut;
        var bad = nDup + nTinyW + nTinyP + nGap + nJoin + nSelf + nCross + nOver + nOpen + nOut;
        try { setDocProp(d, 'cutcheck_' + A.i, partsSig(d, A.i) + '|' + (nDup + nTinyW + nTinyP + nGap + nJoin + nSelf + nCross) + '|' + (nOver + nOpen + nOut) + '|' + (selOnly ? '1' : '0')); } catch (x) { }
        var sum = 'Проверено: ' + items.length + ' объект' + ending(items.length) + ', контуров ' + nPaths + (selOnly ? ' (выделенное)' : ' (вся область)') + '. ';
        sum += bad ? 'Пометки — на непечатаемом слое «' + CUT_MARK_LAYER + '».' : 'Всё чисто — можно резать.';
        logLine('проверка контуров: ' + sum + ' ' + lines.replace(/\n/g, ' / ').substring(0, 300));
        return sum + lines;
    }

    function show(key) {
        if (!S) return 'Сначала нажмите «Проверить».';
        if (!hasDoc() || app.activeDocument != S.doc) return 'Открыт другой документ — проверьте заново.';
        var d = S.doc, list = [], i;
        if (key == 'dup' || key == 'tiny') list = junkOf(d, key);
        var a = S.found[key == 'tiny' ? 'tinyp' : key] || [];
        for (i = 0; i < a.length; i++) { try { if (a[i].parent) list.push(a[i]); } catch (e) { } }
        if (!list.length) return 'Этого уже нет — проверьте заново.';
        d.selection = null;
        for (i = 0; i < list.length; i++) try { list[i].selected = true; } catch (e) { }
        // показать: середина выделенного — в середину окна, чтобы целиком помещалось
        try {
            var b = boundsOf(list), v = d.views[0], vb = v.bounds, z = v.zoom;
            var fit = Math.min((vb[2] - vb[0]) * z / Math.max(1, b[2] - b[0]), (vb[1] - vb[3]) * z / Math.max(1, b[1] - b[3])) * 0.8;
            v.zoom = Math.max(0.05, Math.min(64, fit));
            v.centerPoint = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2];
        } catch (e) { }
        return 'Выделено: ' + list.length + '.';
    }

    // ---- исправить ----
    function dropJunk(d, kind) {
        var a = junkOf(d, kind), n = a.length;
        for (var i = n - 1; i >= 0; i--) a[i].remove();
        var L = cutFindLayer(d, CUT_JUNK_LAYER); if (L && !L.pageItems.length) L.remove();
        return n;
    }
    // индексы частей составного контура, с конца — чтобы номера оставшихся не сдвигались
    function byShape(key, pick) {
        var m = {}, ls = cutLines(S.res, key);
        for (var i = 0; i < ls.length; i++) { var q = ls[i].split('|')[0].split('.'); (m[q[0]] = m[q[0]] || []).push(+q[1]); }
        return m;
    }
    function dropTinyParts() {
        var m = byShape('tiny'), n = 0;
        for (var k in m) if (m.hasOwnProperty(k)) {
            var o = shp(+k);
            if (!o || o.clip || o.it.typename != 'CompoundPathItem') continue;
            var ks = m[k].sort(function (a, b) { return b - a; });
            if (ks.length >= o.it.pathItems.length) continue;
            for (var i = 0; i < ks.length; i++) { o.it.pathItems[ks[i] - 1].remove(); n++; }
        }
        return n;
    }
    function closeGaps() {
        var m = byShape('gap'), n = 0;
        for (var k in m) if (m.hasOwnProperty(k)) {
            var o = shp(+k);
            if (!o || o.clip || o.it.typename == 'TextFrame') continue;
            var subs = cutSubs(o.it, []);
            for (var i = 0; i < m[k].length; i++) { var p = subs[m[k][i] - 1]; if (p && !p.closed) { p.closed = true; n++; } }
        }
        return n;
    }
    function copyLook(to, from) {
        var s = from.typename == 'CompoundPathItem' && from.pathItems.length ? from.pathItems[0] : from;
        try { to.stroked = s.stroked; if (s.stroked) { to.strokeColor = s.strokeColor; to.strokeWidth = s.strokeWidth; } } catch (e) { }
        try { to.filled = to.closed && s.filled; if (to.filled) to.fillColor = s.fillColor; } catch (e) { }
    }
    function joinPieces(d) {
        var ls = cutLines(S.res, 'join'), used = {}, n = 0, i, k;
        for (i = 0; i < ls.length; i++) {
            var f = ls[i].split('|'), q = f[1].split(','), ok = true, first = null;
            for (k = 0; k < q.length; k++) { var o = shp(+q[k].split('.')[0]); if (!o || o.clip || o.it.typename == 'TextFrame') ok = false; else if (!first) first = o.it; }
            if (!ok || !first) continue;
            var cont = first.parent.typename == 'CompoundPathItem' ? first.parent.parent : first.parent;
            var np = cutMakePath(cont, S.R || cutAb(d).R, f[3], f[0] == '1');
            copyLook(np, first);
            np.move(first, ElementPlacement.PLACEBEFORE);
            try { np.name = first.name; } catch (e) { }
            for (k = 0; k < q.length; k++) { var ix = q[k].split('.'); (used[ix[0]] = used[ix[0]] || []).push(+ix[1]); }
            n++;
        }
        for (var s in used) if (used.hasOwnProperty(s)) {
            var o2 = shp(+s); if (!o2) continue;
            var cntSub = cutSubs(o2.it, []).length;
            if (used[s].length >= cntSub) o2.it.move(oldLayer(d), ElementPlacement.PLACEATBEGINNING);
            else if (o2.it.typename == 'CompoundPathItem') {
                o2.it.duplicate(oldLayer(d), ElementPlacement.PLACEATBEGINNING);
                var ks = used[s].sort(function (a, b) { return b - a; });
                for (k = 0; k < ks.length; k++) try { o2.it.pathItems[ks[k] - 1].remove(); } catch (e) { }
            }
        }
        return n;
    }
    // Объединить объекты в один контур (как «Обработка контуров → Добавить»), результат — на месте нижнего.
    // Эффект обработки контуров Illustrator применяет к группе (по голому выделению показывает окно) —
    // поэтому объекты сначала собираются во временную группу; окна на это время заглушены
    function unite(d, list, look) {
        var old = app.userInteractionLevel, r = null, i;
        app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
        try {
            var g = list[0].layer.groupItems.add();
            g.move(list[0], ElementPlacement.PLACEBEFORE);
            for (i = 0; i < list.length; i++) list[i].move(g, ElementPlacement.PLACEATEND);
            d.selection = null; g.selected = true;
            app.executeMenuCommand('Live Pathfinder Add');
            app.executeMenuCommand('expandStyle');
            r = d.selection.length ? d.selection[0] : null;
            // после разбора — группа с одним контуром внутри: достать его
            while (r && r.typename == 'GroupItem' && r.pageItems.length == 1) { var only = r.pageItems[0]; only.move(r, ElementPlacement.PLACEBEFORE); r.remove(); r = only; }
            if (r && look) { var lv = leavesOf([r]); for (i = 0; i < lv.length; i++) copyLook(lv[i], look); }
        } finally { app.userInteractionLevel = old; d.selection = null; }
        return r;
    }
    function weldCross(d) {
        var ls = cutLines(S.res, 'cross'), par = {}, n = 0;
        function root(x) { if (!par.hasOwnProperty(x)) par[x] = x; while (par[x] != x) x = par[x]; return x; }
        for (var i = 0; i < ls.length; i++) { var f = ls[i].split('|'), a = root(+f[0]), b = root(+f[1]); if (a != b) par[a] = b; }
        var comp = {};
        for (var k in par) if (par.hasOwnProperty(k)) { var r = root(+k); (comp[r] = comp[r] || []).push(+k); }
        for (var c in comp) if (comp.hasOwnProperty(c)) {
            var ks = comp[c], ok = ks.length > 1, objs = [], low = null;
            for (i = 0; i < ks.length; i++) { var o = shp(ks[i]); if (!o || o.clip) ok = false; else { objs.push(o.it); if (!low || ks[i] < low.k) low = { k: ks[i], it: o.it }; } }
            if (!ok) continue;
            // копии — на скрытый слой, объединяются сами объекты
            for (i = 0; i < objs.length; i++) objs[i].duplicate(oldLayer(d), ElementPlacement.PLACEATBEGINNING);
            var look = low.it.typename == 'CompoundPathItem' ? low.it.pathItems[0] : low.it;
            var res = unite(d, objs, look);
            if (res) n++;
        }
        return n;
    }
    function weldSelf(d) {
        var ls = cutLines(S.res, 'self'), n = 0;
        for (var i = 0; i < ls.length; i++) {
            var f = ls[i].split('|'), o = shp(+f[0]);
            if (!o || o.clip || !f[3]) continue;
            var it = o.it, keep = it.duplicate(oldLayer(d), ElementPlacement.PLACEATBEGINNING), tmp = [];
            // текст — в кривые; затем каждая буква (наружный контур с окнами) — своим составным контуром
            if (it.typename == 'TextFrame') { var g = it.createOutline(); it = g; }
            var subs = cutSubs(it, tmp), cont = it.parent, letters = f[2].split(','), parts = [];
            var look = subs.length ? subs[0] : null;
            for (var L = 0; L < letters.length; L++) {
                var cp = cont.compoundPathItems.add(), ks = letters[L].split(' ');
                for (var k = 0; k < ks.length; k++) { var sp = subs[+ks[k] - 1]; if (sp) sp.duplicate(cp, ElementPlacement.PLACEATEND); }
                parts.push(cp);
            }
            var groups = f[3].split(','), res = [];
            for (var gi = 0; gi < groups.length; gi++) {
                var gk = groups[gi].split(' '), set = [];
                for (k = 0; k < gk.length; k++) if (parts[+gk[k]]) { set.push(parts[+gk[k]]); parts[+gk[k]] = null; }
                if (set.length > 1) { var u = unite(d, set, look); if (u) res.push(u); } else if (set.length) res.push(set[0]);
            }
            for (k = 0; k < parts.length; k++) if (parts[k]) res.push(parts[k]);
            // всё снова одним составным контуром
            d.selection = null;
            for (k = 0; k < res.length; k++) res[k].selected = true;
            app.executeMenuCommand('compoundPath');
            var done = d.selection.length ? d.selection[0] : null;
            if (done && look) { var lv = leavesOf([done]); for (k = 0; k < lv.length; k++) copyLook(lv[k], look); }
            d.selection = null;
            try { it.remove(); } catch (e) { }
            for (k = 0; k < tmp.length; k++) try { tmp[k].remove(); } catch (e) { }
            void keep;
            n++;
        }
        return n;
    }

    function fix(key) {
        if (!S || !S.res) return 'Сначала нажмите «Проверить».';
        if (!hasDoc() || app.activeDocument != S.doc || cutAb(S.doc).i != S.ab) return 'Открыт другой документ или область — проверьте заново.';
        var d = S.doc, n = 0, t = '';
        S.R = cutAb(d).R;
        try {
            if (key == 'dup') { n = dropJunk(d, 'dup'); t = 'Удалено дублей: ' + n + '.'; }
            else if (key == 'tiny') { n = dropJunk(d, 'tiny') + dropTinyParts(); t = 'Удалено соринок: ' + n + '.'; }
            else if (key == 'gap') { n = closeGaps(); t = 'Замкнуто контуров: ' + n + '.'; }
            else if (key == 'join') { n = joinPieces(d); t = 'Склеено линий: ' + n + '.'; }
            else if (key == 'self') { n = weldSelf(d); t = 'Объединено объектов с буквами внахлёст: ' + n + '.'; }
            else if (key == 'cross') { n = weldCross(d); t = 'Объединено групп деталей: ' + n + '.'; }
            else t = 'Этого исправить нельзя.';
            hideOld(d);
        } catch (e) {
            try { hideOld(d); } catch (x) { }
            logLine('сбой исправления контуров (' + key + '): ' + e.message + ' (строка ' + e.line + ')');
            return 'Исправить не получилось: ' + e.message + '. Сделанное до ошибки отменяется Ctrl+Z.';
        }
        var params = S.params;
        S.res = '';
        var r = parseKV(params).ccScope == 'sel' ? 'Исправлено. Проверить ещё раз — выделите детали и нажмите «Проверить контуры».' : check(params);
        return t + ' Отменить — Ctrl+Z.\n' + r;
    }
    function fixAll() {
        if (!S || !S.res) return 'Сначала нажмите «Проверить».';
        var keys = ['dup', 'tiny', 'gap', 'join', 'self', 'cross'], t = '', last = '';
        for (var i = 0; i < keys.length; i++) {
            if (!S || !S.res) break;
            var k = keys[i], has = (k == 'dup' || k == 'tiny') ? (junkOf(S.doc, k).length > 0 || (k == 'tiny' && cutLines(S.res, 'tiny').length > 0)) : cutLines(S.res, k).length > 0;
            if (!has) continue;
            var r = fix(k), p = r.indexOf('\n');
            if (p > 0) { last = r.substring(p + 1); r = r.substring(0, p); }
            t += r.replace(' Отменить — Ctrl+Z.', '') + ' ';
        }
        if (!t) t = 'Исправлять нечего. ';
        return t + 'Отменить — Ctrl+Z.\n' + last;
    }

    function status() {
        if (!hasDoc()) return 'parts=0|check=none|lines=0';
        var d = app.activeDocument, A = cutAb(d), sig = partsSig(d, A.i), v = docProp(d, 'cutcheck_' + A.i), st = 'none', a = v ? v.split('|') : [];
        if (a.length >= 4) st = a[0] != sig ? 'stale' : (a[3] == '1' ? 'sel' : (+a[1] > 0 ? 'issues' : (+a[2] > 0 ? 'warns' : 'ok')));
        var cl = cutFindLayer(d, LASER_CUT_LAYER), lines = cl ? topItemsOn(d, cl, A.i).length : 0, start = docProp(d, 'cutstart_' + A.i);
        return 'parts=' + sig.split(':')[0] + '|check=' + st + '|fix=' + (a[1] || '0') + '|warn=' + (a[2] || '0') + '|lines=' + lines +
               '|page=' + String(d.artboards[A.i].name).replace(/\|/g, ' ') + (start ? '|start=' + start : '');
    }

    return { check: check, show: show, fix: fix, fixAll: fixAll, status: status, partsSig: partsSig };
})();

// ---------- команды панели ----------

Bridge.SmMarks = function (gap) {
    if (!PSA.has('P')) return 'Метки плоттера входят в часть «Плоттер» — её нет в вашем ключе.';
    return CutFile.signMasterMarks(toNum(gap, 3));
};
Bridge.CutSave = function (what, fmt, marks) {
    var need = what == 'plot' ? 'P' : (what == 'laser' ? 'L' : 'M');
    if (!PSA.has(need)) return 'Файл для станка входит в часть «' + (need == 'P' ? 'Плоттер' : (need == 'L' ? 'Лазер' : 'Фрезер')) + '» — её нет в вашем ключе.';
    return CutFile.save(what, fmt, marks == '1');
};
Bridge.CutStatus = function () { try { return CutCheck.status(); } catch (e) { return 'parts=0|check=none|lines=0'; } };
Bridge.CutCheckRun = function (params) {
    if (!PSA.has('M')) return 'Проверка контуров входит в часть «Фрезер» — её нет в вашем ключе.';
    Settings.set('CutCheck', 'Params', params);
    return CutCheck.check(params);
};
Bridge.CutCheckShow = function (key) { return CutCheck.show(key); };
Bridge.CutCheckFix = function (key) {
    if (!PSA.has('M')) return 'Исправление контуров входит в часть «Фрезер» — её нет в вашем ключе.';
    return key == 'all' ? CutCheck.fixAll() : CutCheck.fix(key);
};
