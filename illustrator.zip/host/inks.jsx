// Спецкраски для УФ и DTF — как src/Inks.bas: 1 — белила, 2 — лак.
// В макете краска отмечается слоем (всё на слое — эта краска) или плашечным цветом (объекты этого цвета).
// Вывод: PDF — плашки с именами для печати и наложением; TIFF — CMYK и каналы красок.
// Настройки хранятся в документе (вместе с полями); последние выбранные — по умолчанию для новых.

var INK_COUNT = 2;
var INK_TMP_LAYER = 'PS • Автоматизация: краска ';

var Inks = {
    On: true, Mirror: false, Use: [null, true, true], ByColor: [null, false, false],
    LayerName: [null, 'Белила', 'Лак'], SpotName: [null, 'White', 'Varnish'], OutName: [null, 'W', 'V']
};

Inks.Title = function (i) { return i == 1 ? 'Белила' : 'Лак'; };

Inks.Defaults = function () {
    this.On = Settings.get('Inks', 'On', '1') == '1';
    this.Mirror = false;
    for (var i = 1; i <= INK_COUNT; i++) {
        this.Use[i] = Settings.get('Inks', 'Use' + i, '1') == '1';
        this.ByColor[i] = Settings.get('Inks', 'ByColor' + i, '0') == '1';
        this.LayerName[i] = Settings.get('Inks', 'Layer' + i, this.Title(i));
        this.SpotName[i] = Settings.get('Inks', 'Spot' + i, i == 1 ? 'White' : 'Varnish');
        this.OutName[i] = Settings.get('Inks', 'Out' + i, i == 1 ? 'W' : 'V');
    }
};
Inks.SaveDefaults = function () {
    Settings.set('Inks', 'On', this.On ? '1' : '0');
    for (var i = 1; i <= INK_COUNT; i++) {
        Settings.set('Inks', 'Use' + i, this.Use[i] ? '1' : '0'); Settings.set('Inks', 'ByColor' + i, this.ByColor[i] ? '1' : '0');
        Settings.set('Inks', 'Layer' + i, this.LayerName[i]); Settings.set('Inks', 'Spot' + i, this.SpotName[i]); Settings.set('Inks', 'Out' + i, this.OutName[i]);
    }
};
// в настройки документа и обратно
Inks.Save = function () {
    return { On: this.On, Mirror: this.Mirror, Use: this.Use.slice(0), ByColor: this.ByColor.slice(0), LayerName: this.LayerName.slice(0),
             SpotName: this.SpotName.slice(0), OutName: this.OutName.slice(0) };
};
Inks.Load = function (o) {
    this.Defaults();
    if (!o) { this.GuessFromDoc(); return; }
    var k = ['On', 'Mirror', 'Use', 'ByColor', 'LayerName', 'SpotName', 'OutName'];
    for (var i = 0; i < k.length; i++) if (o.hasOwnProperty(k[i]) && o[k[i]] !== null) this[k[i]] = o[k[i]];
};
// Документ без настроек красок: есть слой «Белила» или «Лак» — краска отмечена слоем
Inks.GuessFromDoc = function () {
    if (!hasDoc()) return;
    for (var i = 1; i <= INK_COUNT; i++) {
        var nm = this.Title(i), d = app.activeDocument;
        for (var k = 0; k < d.layers.length; k++) if (d.layers[k].name == nm) { this.ByColor[i] = false; this.LayerName[i] = nm; }
    }
};
Inks.Active = function (i) { return this.On && this.Use[i]; };

// Слой спецкраски: временный слой вывода, а также слой краски, отмеченной слоем
Inks.IsInkLayer = function (name) {
    for (var i = 1; i <= INK_COUNT; i++) {
        if (name == INK_TMP_LAYER + i) return true;
        if (!this.ByColor[i] && name == (this.LayerName[i] || this.Title(i))) return true;
    }
    return false;
};

// Имена, по которым узнаётся краска i: привычные, «цвет в макете» и имя для печати
Inks.Names = function (i) {
    var t = i == 1 ? '|w|white|wh|белила|белый|' : '|lak|lack|varnish|v|gloss|лак|';
    if (trimS(this.SpotName[i])) t += trimS(this.SpotName[i]).toLowerCase() + '|';
    if (trimS(this.OutName[i])) t += trimS(this.OutName[i]).toLowerCase() + '|';
    return t;
};

// Плашки объекта (заливка и обводка, для текста — первый символ): имена в нижнем регистре
function spotKeys(it) {
    var k = [], c;
    try {
        if (it.typename == 'TextFrame') {
            var a = it.textRange.characterAttributes;
            c = a.fillColor; if (c && c.typename == 'SpotColor') k.push(c.spot.name.toLowerCase());
            c = a.strokeColor; if (c && c.typename == 'SpotColor') k.push(c.spot.name.toLowerCase());
            return k;
        }
        var p = it.typename == 'CompoundPathItem' ? (it.pathItems.length ? it.pathItems[0] : null) : it;
        if (!p || p.typename != 'PathItem') return k;
        if (p.filled && p.fillColor.typename == 'SpotColor') k.push(p.fillColor.spot.name.toLowerCase());
        if (p.stroked && p.strokeWidth > 0 && p.strokeColor.typename == 'SpotColor') k.push(p.strokeColor.spot.name.toLowerCase());
    } catch (e) { }
    return k;
}

Inks.IsInkSpot = function (it, i) {
    var k = spotKeys(it), names = this.Names(i);
    for (var j = 0; j < k.length; j++) if (names.indexOf('|' + trimS(k[j]) + '|') >= 0) return true;
    return false;
};
function isVarnishCopy(it) { return Inks.IsInkSpot(it, 2); }

// Плашечный цвет name: из документа, а нет — новый. На экране белила — красно-оранжевые, лак — зелёный.
Inks.MakeSpot = function (d, name, i) {
    var sp = null;
    try { sp = d.spots.getByName(name); } catch (e) { sp = null; }
    if (!sp) {
        sp = d.spots.add();
        sp.name = name;
        sp.colorType = ColorModel.SPOT;
        sp.color = i == 1 ? cmykColor(0, 98, 100, 0) : cmykColor(82, 7, 64, 0);
    }
    var c = new SpotColor();
    c.spot = sp; c.tint = 100;
    return c;
};

// Отдельные объекты (без групп); revert — символы с краской разворачиваются (только в копии для вывода)
function inkLeaves(items, out, revert) {
    for (var i = 0; i < items.length; i++) {
        var it = items[i], t = it.typename;
        if (t == 'GroupItem') {
            var ch = [];
            for (var k = 0; k < it.pageItems.length; k++) ch.push(it.pageItems[k]);
            inkLeaves(ch, out, revert);
        } else if (t == 'SymbolItem') {
            // экземпляры символов с краской разворачиваются заранее (BreakInkSymbols); прочие — рисунок
        } else out.push(it);
    }
}
// верхние объекты слоя на стороне ab (для слоя краски — все на стороне)
function topItemsOn(d, L, ab) {
    var out = [];
    for (var i = 0; i < L.pageItems.length; i++) { var it = L.pageItems[i]; if (it.parent == L && (ab < 0 || abIndexOf(d, it) == ab)) out.push(it); }
    for (i = 0; i < L.layers.length; i++) out = out.concat(topItemsOn(d, L.layers[i], ab));
    return out;
}

// Символы, внутри которых есть краска, — в обычные группы (в копии документа для вывода)
Inks.BreakInkSymbols = function (d) {
    var has = {}, i, k, TL = d.layers.add();
    // пробный экземпляр — на своём слое: после разрыва связи символ рассыпается на несколько объектов,
    // и все они должны уйти (раньше оставались в углу первой области и попадали в печать)
    TL.name = 'PS • Автоматизация: проба символов';
    try {
        for (i = 0; i < d.symbols.length; i++) {
            var s = d.symbols[i], tmp = TL.symbolItems.add(s), leaves = [], parts = [];
            try { tmp.breakLink(); } catch (e) { }
            for (k = 0; k < TL.pageItems.length; k++) parts.push(TL.pageItems[k]);
            inkLeaves(parts, leaves, false);
            var ink = false;
            for (k = 0; k < leaves.length && !ink; k++) for (var n = 1; n <= INK_COUNT; n++) if (this.ByColor[n] && this.IsInkSpot(leaves[k], n)) { ink = true; break; }
            has[s.name] = ink;
            for (k = TL.pageItems.length - 1; k >= 0; k--) TL.pageItems[k].remove();
        }
    } finally { TL.remove(); }
    for (i = d.symbolItems.length - 1; i >= 0; i--) { var si = d.symbolItems[i]; if (has[si.symbol.name]) si.breakLink(); }
};

// Объекты краски i на стороне ab (-1 — все стороны): весь её слой или объекты её плашки
Inks.Shapes = function (d, ab, i) {
    var out = [], L, k;
    if (this.ByColor[i]) {
        var all = [];
        for (k = 0; k < d.layers.length; k++) {
            L = d.layers[k];
            if (!L.printable || !L.visible || this.IsInkLayer(L.name)) continue;
            all = all.concat(topItemsOn(d, L, ab));
        }
        var leaves = [];
        inkLeaves(all, leaves, false);
        for (k = 0; k < leaves.length; k++) if (this.IsInkSpot(leaves[k], i)) out.push(leaves[k]);
        return out;
    }
    for (k = 0; k < d.layers.length; k++) if (d.layers[k].name == this.LayerName[i]) return topItemsOn(d, d.layers[k], ab);
    return out;
};
Inks.CountOnPage = function (d, ab, i) { try { return this.Shapes(d, ab, i).length; } catch (e) { return 0; } };

// Перекрасить объект в плашку c с наложением
function toSpot(it, c) {
    try {
        if (it.typename == 'TextFrame') {
            var a = it.textRange.characterAttributes;
            a.fillColor = c; a.overprintFill = true;
            if (a.strokeWeight > 0) { a.strokeColor = c; a.overprintStroke = true; }
            return;
        }
        if (it.typename == 'CompoundPathItem') { for (var i = 0; i < it.pathItems.length; i++) toSpot(it.pathItems[i], c); return; }
        if (it.typename != 'PathItem') return;      // картинки не перекрашиваются
        if (it.filled) { it.fillColor = c; it.fillOverprint = true; }
        if (it.stroked) { it.strokeColor = c; it.strokeOverprint = true; }
    } catch (e) { }
}

// Копия документа перед PDF: краски — плашкой с именем для печати и наложением, выключенные — убрать; зеркало
Inks.PreparePdf = function (d, sides) {
    var n = 0, i, k, s, items;
    this.BreakInkSymbols(d);
    for (i = 1; i <= INK_COUNT; i++) {
        items = [];
        for (s = 0; s < sides.length; s++) {
            var part = this.Shapes(d, sides[s], i);
            if (!this.ByColor[i]) { var lv = []; inkLeaves(part, lv, true); part = lv; }
            items = items.concat(part);
        }
        if (!items.length) continue;
        if (this.Active(i)) {
            var c = this.MakeSpot(d, this.OutName[i], i);
            for (k = 0; k < items.length; k++) toSpot(items[k], c);
            n += items.length;
        } else for (k = items.length - 1; k >= 0; k--) try { items[k].remove(); } catch (e) { }
    }
    if (this.Mirror) for (s = 0; s < sides.length; s++) mirrorSide(d, sides[s]);
    return n;
};

// Зеркально по горизонтали всё на стороне (плёнка DTF печатается с обратной стороны)
function mirrorSide(d, ab) {
    var r = d.artboards[ab].artboardRect, cx = (r[0] + r[2]) / 2, k, list = [];
    for (k = 0; k < d.layers.length; k++) list = list.concat(topItemsOn(d, d.layers[k], ab));
    for (k = 0; k < list.length; k++) {
        var it = list[k], b = it.geometricBounds, ic = (b[0] + b[2]) / 2;
        it.resize(-100, 100, true, true, true, true, 100, Transformation.CENTER);
        it.translate(2 * cx - 2 * ic, 0);
    }
}

// Копия документа перед TIFF: краски цветом — на свой временный слой, выключенные — убрать; маски — чёрным
Inks.PrepareTiff = function (d, sides) {
    var i, k, s;
    this.BreakInkSymbols(d);
    for (i = 1; i <= INK_COUNT; i++) {
        var items = [];
        for (s = 0; s < sides.length; s++) items = items.concat(this.Shapes(d, sides[s], i));
        if (this.ByColor[i]) {
            if (!items.length) continue;
            if (!this.Active(i)) { for (k = items.length - 1; k >= 0; k--) try { items[k].remove(); } catch (e) { } continue; }
            var L = layerNamed(d, INK_TMP_LAYER + i, true);
            for (k = 0; k < items.length; k++) items[k].move(L, ElementPlacement.PLACEATBEGINNING);
        }
    }
    // маски — чёрным по белому (серой шкалой), чтобы канал был полной плотности
    for (i = 1; i <= INK_COUNT; i++) {
        var lay = null, nm = this.ByColor[i] ? INK_TMP_LAYER + i : this.LayerName[i];
        for (k = 0; k < d.layers.length; k++) if (d.layers[k].name == nm) lay = d.layers[k];
        if (!lay) continue;
        var lv = [];
        inkLeaves(topItemsOn(d, lay, -1), lv, true);
        for (k = 0; k < lv.length; k++) blacken(lv[k]);
    }
    if (this.Mirror) for (s = 0; s < sides.length; s++) mirrorSide(d, sides[s]);
};
function grayK(v) { var g = new GrayColor(); g.gray = v; return g; }
function blacken(it) {
    try {
        if (it.typename == 'TextFrame') { it.textRange.characterAttributes.fillColor = grayK(100); return; }
        if (it.typename == 'CompoundPathItem') { for (var i = 0; i < it.pathItems.length; i++) blacken(it.pathItems[i]); return; }
        if (it.typename == 'PathItem') { if (it.filled) it.fillColor = grayK(100); if (it.stroked) it.strokeColor = grayK(100); }
    } catch (e) { }
}

// Что уйдёт в файл: «W» (белила), «V» (лак)
Inks.OutText = function () {
    if (!this.On) return '';
    var t = [];
    for (var i = 1; i <= INK_COUNT; i++) if (this.Use[i]) t.push('«' + this.OutName[i] + '» (' + this.Title(i).toLowerCase() + ')');
    return t.join(', ');
};

// ---------- инструменты для макета ----------

function ensureInkLayer(d, name) {
    var L = layerNamed(d, name, true);
    L.printable = true; L.visible = true;
    return L;
}

// Выделенное — в краску i: на её слой или перекрасить её плашкой
Inks.Assign = function (i, items) {
    var d = app.activeDocument, sel = items || selectionItems(d), n = 0, k;
    if (!sel.length) return 'Выделите объекты для краски «' + this.Title(i) + '».';
    if (this.ByColor[i]) {
        var c = this.MakeSpot(d, this.SpotName[i], i), lv = [];
        inkLeaves(sel, lv, false);
        for (k = 0; k < lv.length; k++) { toSpot(lv[k], c); n++; }
        return this.Title(i) + ': объектов перекрашено в плашку «' + this.SpotName[i] + '» — ' + n + '.';
    }
    var L = ensureInkLayer(d, this.LayerName[i]);
    for (k = 0; k < sel.length; k++) if (sel[k].layer != L) { sel[k].move(L, ElementPlacement.PLACEATBEGINNING); n++; }
    return this.Title(i) + ': на слой «' + this.LayerName[i] + '» перенесено объектов — ' + n + '.';
};

// Слой краски или плашка в палитре документа
Inks.Create = function (i) {
    var d = app.activeDocument;
    if (this.ByColor[i]) {
        this.MakeSpot(d, this.SpotName[i], i);
        return 'Плашечный цвет «' + this.SpotName[i] + '» есть в палитре документа — закрашивайте им то, что печатается краской «' + this.Title(i) + '».';
    }
    var had = false;
    for (var k = 0; k < d.layers.length; k++) if (d.layers[k].name == this.LayerName[i]) had = true;
    ensureInkLayer(d, this.LayerName[i]);
    return (had ? 'Слой «' + this.LayerName[i] + '» уже есть.' : 'Создан слой «' + this.LayerName[i] + '».') + ' Всё, что на нём, печатается краской «' + this.Title(i) + '».';
};

// Сдвиг контура внутрь на dd мм (эффект «Создать параллельный контур», затем разобрать). null — не вышло.
function offsetInside(it, dd) {
    var d = app.activeDocument;
    try {
        it.applyEffect('<LiveEffect name="Adobe Offset Path"><Dict data="R mlim 4 R ofst ' + (-pt(dd)) + ' I jntp 0 "/></LiveEffect>');
        d.selection = null; it.selected = true;
        app.executeMenuCommand('expandStyle');
        var r = d.selection.length ? d.selection[0] : null;
        d.selection = null;
        return r;
    } catch (e) { return null; }
}

// Белая заливка: такой объект на УФ печатается белилами
function isWhiteFill(it) {
    try {
        var p = it.typename == 'CompoundPathItem' ? it.pathItems[0] : it;
        if (p.typename != 'PathItem' || !p.filled) return false;
        var c = p.fillColor;
        if (c.typename == 'CMYKColor') return c.cyan == 0 && c.magenta == 0 && c.yellow == 0 && c.black == 0;
        if (c.typename == 'RGBColor') return c.red == 255 && c.green == 255 && c.blue == 255;
        if (c.typename == 'GrayColor') return c.gray == 0;
    } catch (e) { }
    return false;
}

// Белила или лак копиями поверх выделенного: копия в плашке краски с наложением. Белила под цветным
// ужимаются внутрь на trap мм (pct > 0 — доля толщины объекта, не больше trap). Текст — в кривые,
// картинка — её прямоугольник; номер из данных остаётся живым текстом-спутником («VP#n~»).
Inks.CopyOver = function (i, trap, pct) {
    var d = app.activeDocument, sel = selectionItems(d), k;
    if (!sel.length) return 'Выделите объекты, под которые нужна краска «' + this.Title(i) + '».';
    var c = this.MakeSpot(d, this.SpotName[i], i), L = sel[0].layer;
    if (!this.ByColor[i]) L = ensureInkLayer(d, this.LayerName[i]);
    var g = L.groupItems.add(), flat = [], n = 0, lost = 0, mates = 0, whites = 0, choked = 0, dMin = 0, dMax = 0;
    g.name = this.Title(i) + ' «' + this.SpotName[i] + '»';
    for (k = sel.length - 1; k >= 0; k--) {
        var dup = sel[k].duplicate(g, ElementPlacement.PLACEATBEGINNING);
        if (dup.typename == 'GroupItem') { var lv = []; inkLeaves([dup], lv, false); for (var j = 0; j < lv.length; j++) { lv[j].move(g, ElementPlacement.PLACEATEND); flat.push(lv[j]); } dup.remove(); }
        else flat.push(dup);
    }
    for (k = 0; k < flat.length; k++) {
        var s = flat[k], white = isWhiteFill(s), mate = false, r = s;
        if (s.name.substring(0, TAG_FIELD.length) == TAG_FIELD) {
            if (s.typename == 'TextFrame') { if (!/~$/.test(s.name)) s.name += '~'; mate = true; mates++; }
            else s.name = '';
        }
        if (!mate) {
            if (s.typename == 'PlacedItem' || s.typename == 'RasterItem') {
                var b = s.geometricBounds; r = g.pathItems.rectangle(b[1], b[0], b[2] - b[0], b[1] - b[3]); s.remove();
            } else if (s.typename == 'TextFrame') {
                try { r = s.createOutline(); } catch (e) { r = null; }
            } else if (s.typename == 'PathItem' && !s.filled) {
                if (!s.stroked) { s.remove(); r = null; }
                else { d.selection = null; s.selected = true; app.executeMenuCommand('OffsetPath v23'); r = d.selection.length ? d.selection[0] : null; d.selection = null; }
            }
        }
        if (!r) { lost++; continue; }
        if (i == 1 && trap > 0 && !white && !mate) {
            var bb = r.geometricBounds, thick = Math.min(mm(bb[2] - bb[0]), mm(bb[1] - bb[3])) / 2, dd = trap;
            if (pct > 0) dd = Math.min(trap, thick * pct / 100);
            dd = Math.round(dd * 100) / 100;
            if (dd >= 0.01 && mm(bb[2] - bb[0]) > 2 * dd && mm(bb[1] - bb[3]) > 2 * dd) {
                var o = offsetInside(r, dd);
                if (o) { r = o; choked++; if (!dMin || dd < dMin) dMin = dd; if (dd > dMax) dMax = dd; }
            }
        }
        if (white && i == 1) whites++;
        var lv2 = [];
        inkLeaves([r], lv2, false);
        for (j = 0; j < lv2.length; j++) { toSpot(lv2[j], c); try { if (lv2[j].typename == 'PathItem') lv2[j].stroked = false; } catch (e) { } }
        n++;
    }
    g.zOrder(ZOrderMethod.BRINGTOFRONT);
    if (i == 1) for (k = 0; k < g.layer.groupItems.length; k++) {
        var lg = g.layer.groupItems[k];
        if (lg.parent == g.layer && lg != g && lg.name.indexOf(this.Title(2) + ' «') == 0) { g.move(lg, ElementPlacement.PLACEAFTER); break; }
    }
    d.selection = null; g.selected = true;
    if (!n) { g.remove(); return 'Копия не получилась: у выделенного нет замкнутой формы.'; }
    return this.Title(i) + ': копий поверх рисунка — ' + n + ', цвет «' + this.SpotName[i] + '» с наложением заливки' +
        (i == 1 && choked ? ', под цветным — меньше рисунка на ' + (dMin == dMax ? dMax : 'от ' + dMin + ' до ' + dMax) + ' мм' + (pct > 0 ? ' (по толщине объектов)' : '') : '') + '.' +
        (lost ? ' Без копии (не замкнутая форма): ' + lost + '.' : '') +
        (whites ? ' Белые объекты — точно по форме: они сами печатаются белилами (' + whites + ').' : '') +
        (mates ? ' Номер или текст из данных — живым текстом: при выводе в ' + this.Title(i).toLowerCase() + ' подставится то же значение (' + mates + ').' : '') +
        ' Отменить — Ctrl+Z.';
};

// Белые объекты стороны (кроме подложки во всю карту) — в белила
Inks.MoveWhite = function () {
    var d = app.activeDocument, ab = d.artboards.getActiveArtboardIndex(), r = d.artboards[ab].artboardRect, area = (r[2] - r[0]) * (r[1] - r[3]) * 0.5, all = [], lv = [], found = [], k;
    for (k = 0; k < d.layers.length; k++) if (d.layers[k].printable && !this.IsInkLayer(d.layers[k].name)) all = all.concat(topItemsOn(d, d.layers[k], ab));
    inkLeaves(all, lv, false);
    for (k = 0; k < lv.length; k++) if (isWhiteFill(lv[k]) && lv[k].width * lv[k].height < area) found.push(lv[k]);
    if (!found.length) return 'На стороне «' + d.artboards[ab].name + '» белых объектов не найдено.';
    return this.Assign(1, found);
};

// Подслой белил: общий контур выделенного (или всего рисунка стороны), ужатый на choke мм
Inks.Underlay = function (choke) {
    var d = app.activeDocument, sel = selectionItems(d), ab = d.artboards.getActiveArtboardIndex(), k;
    if (!sel.length) for (k = 0; k < d.layers.length; k++) if (d.layers[k].printable && !this.IsInkLayer(d.layers[k].name)) sel = sel.concat(topItemsOn(d, d.layers[k], ab));
    if (!sel.length) return 'Нечего обводить: выделите рисунок, под который нужны белила.';
    var g = sel[0].layer.groupItems.add();
    for (k = 0; k < sel.length; k++) sel[k].duplicate(g, ElementPlacement.PLACEATEND);
    d.selection = null; g.selected = true;
    try {
        app.executeMenuCommand('outline');               // текст — в кривые
        app.executeMenuCommand('Live Pathfinder Add');   // объединить
        app.executeMenuCommand('expandStyle');
    } catch (e) { }
    var u = d.selection.length ? d.selection[0] : g;
    d.selection = null;
    if (choke > 0) { var o = offsetInside(u, choke); if (o) u = o; }
    var lv = [];
    inkLeaves([u], lv, false);
    for (k = 0; k < lv.length; k++) { try { lv[k].filled = true; lv[k].fillColor = cmykColor(0, 0, 0, 0); lv[k].stroked = false; } catch (e) { } }
    u.name = 'Подслой белил';
    var msg = this.Assign(1, [u]);
    if (this.ByColor[1]) u.zOrder(ZOrderMethod.SENDTOBACK);
    return 'Подслой белил готов' + (choke > 0 ? ', ужат внутрь на ' + choke + ' мм' : '') + ', ' +
           (this.ByColor[1] ? 'плашкой «' + this.SpotName[1] + '»' : 'на слое «' + this.LayerName[1] + '»') + '.';
};

// ---------- состояние и команды панели ----------

function inksState(d) {
    var list = [], ab = d.artboards.getActiveArtboardIndex();
    for (var i = 1; i <= INK_COUNT; i++)
        list.push({ i: i, title: Inks.Title(i), use: Inks.Use[i], byColor: Inks.ByColor[i], layer: Inks.LayerName[i], spot: Inks.SpotName[i],
                    out: Inks.OutName[i], count: Inks.CountOnPage(d, ab, i) });
    return { on: Inks.On, mirror: Inks.Mirror, list: list, layers: layerNames(d), spots: spotNames(d) };
}

function needUW() { return PSA.has('UW') ? '' : 'Белила и лак входят в части «УФ-планшет» и «Рулонная печать» — их нет в вашем ключе.'; }

Bridge.SetInk = function (key, value) {
    if (needUW()) return needUW();
    prepare();
    if (!hasDoc()) return '';
    var i = parseInt(key.charAt(key.length - 1), 10), v = trimS(value);
    if (key == 'on') Inks.On = v == '1';
    else if (key == 'mirror') Inks.Mirror = v == '1';
    else if (i >= 1 && i <= INK_COUNT) {
        var k = key.substring(0, key.length - 1);
        if (k == 'use') Inks.Use[i] = v == '1';
        else if (k == 'byColor') Inks.ByColor[i] = v == '1';
        else if (k == 'layer' && v) Inks.LayerName[i] = v;
        else if (k == 'spot' && v) Inks.SpotName[i] = v;
        else if (k == 'out' && v) Inks.OutName[i] = v.replace(/"/g, '');
    }
    Engine.SaveConfig();
    Inks.SaveDefaults();
    return 'ok';
};
Bridge.InkAssign = function (i) { if (needUW()) return needUW(); prepare(); return hasDoc() ? Inks.Assign(+i) : ''; };
Bridge.InkCreate = function (i) { if (needUW()) return needUW(); prepare(); return hasDoc() ? Inks.Create(+i) : ''; };
Bridge.InkCopy = function (i, trap, pct) {
    if (needUW()) return needUW();
    prepare();
    if (!hasDoc()) return '';
    if (+i == 1) { Settings.set('White', 'Choke', toNum(trap, 0.2)); Settings.set('White', 'ChokePct', toNum(pct, 10)); }
    return Inks.CopyOver(+i, toNum(trap, 0.2), toNum(pct, 10));
};
Bridge.InkCopyBoth = function (trap, pct) {
    if (needUW()) return needUW();
    prepare();
    if (!hasDoc()) return '';
    var d = app.activeDocument, sel = selectionItems(d);
    if (!sel.length) return 'Выделите объекты, под которые нужны белила и лак.';
    Settings.set('White', 'Choke', toNum(trap, 0.2)); Settings.set('White', 'ChokePct', toNum(pct, 10));
    var a = Inks.CopyOver(1, toNum(trap, 0.2), toNum(pct, 10));
    d.selection = null;
    for (var k = 0; k < sel.length; k++) sel[k].selected = true;
    var b = Inks.CopyOver(2, toNum(trap, 0.2), toNum(pct, 10));
    return a + '\r\n' + b;
};
Bridge.WhiteMove = function () { if (needUW()) return needUW(); prepare(); return hasDoc() ? Inks.MoveWhite() : ''; };
Bridge.WhiteUnderlay = function (choke) {
    if (needUW()) return needUW();
    prepare();
    if (!hasDoc()) return '';
    Settings.set('White', 'Choke', toNum(choke, 0.1));
    return Inks.Underlay(toNum(choke, 0.1));
};
Bridge.VarnishMove = function () { if (needUW()) return needUW(); prepare(); return hasDoc() ? Inks.Assign(2) : ''; };
