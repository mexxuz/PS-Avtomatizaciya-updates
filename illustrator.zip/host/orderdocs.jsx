// Документы заказа — как src/OrderDocs.bas.
// Лист согласования (по образцу карты): одна страница клиенту — лицо и оборот с линией реза, где лягут белила
// и лак, размер, тираж, номера «с — по» и поле «Согласовано». Картинка JPG и PDF.
// Превью листов (по раскладке): одна картинка для бланка заказа — листы в порядке печати и сведения.
// Задание в печать (по раскладке): страница для оператора — что печатать, порядок и таблица листов с номерами
// и квадратиками для отметок. PDF.
// Документ человека не меняется: временные области, слои и копии убираются сразу после снимка.

var OrderDocs = (function () {
    var MARK = [0, 110, 200];

    // ---------- сведения ----------
    function sideTitle(name, i, n) {
        var nm = trimS(name);
        if (nm.toLowerCase().indexOf('лист — ') == 0) nm = trimS(nm.substring(7));
        if (!nm || /^(страница|page|artboard|монтажная)/i.test(nm)) nm = n == 1 || i == 1 ? 'Лицо' : 'Оборот';
        return nm;
    }
    function sideNames(names) { var a = []; for (var i = 0; i < names.length; i++) a.push(sideTitle(names[i], i + 1, names.length).toLowerCase()); return a.join(', '); }
    function clientPart() { var c = trimS(Engine.Client || ''); return c ? ' · заказчик: ' + c : ''; }
    // «Тираж: 2300 шт. · номера с 100 000 000 по 100 002 299» — по первому полю с номерами
    function numbersLine() {
        for (var i = 0; i < Engine.Fields.length; i++) {
            var f = Engine.Fields[i];
            if (f.Kind != 'text') continue;
            var n = f.Count();
            if (n > 0) return 'Тираж: ' + n + ' шт. · номера с ' + f.ValueAt(0) + ' по ' + f.ValueAt(n - 1);
            if (n < 0) return 'Номера с ' + f.ValueAt(0) + ' по порядку';
            return '';
        }
        return '';
    }
    function inksLine() { var s = 'CMYK'; for (var k = 1; k <= 2; k++) if (Inks.Active(k)) s += ' + ' + Inks.Title(k).toLowerCase(); return s; }
    // Профиль принтера из панели: «УФ-принтер, 300 dpi, поворот 90°»
    function printerLine() {
        var nm = Settings.get('Printers', 'Active', ''), fmt = Settings.get('Output', 'Format', 'tiff'), rot = Math.round(toNum(Settings.get('Output', 'Rotate', '0'), 0)), dpi = Engine.TiffDpi;
        var js = Settings.get('Printers', 'List', ''), p = nm ? js.indexOf('"n":"' + nm + '"') : -1;
        if (p >= 0) {
            var q = js.indexOf('}', p), o = js.substring(p, q < 0 ? js.length : q);
            var m = /"dpi":(-?\d+)/.exec(o); if (m && +m[1] > 0) dpi = +m[1];
            m = /"rot":(-?\d+)/.exec(o); rot = m ? +m[1] : 0;
            if (o.indexOf('"fmt":"pdf"') >= 0) fmt = 'pdf';
            if (o.indexOf('"fmt":"tiff"') >= 0) fmt = 'tiff';
        }
        if (!nm) nm = fmt == 'pdf' ? 'PDF' : 'TIFF';
        return nm + (fmt == 'tiff' ? ', ' + dpi + ' dpi' : '') + (rot ? ', поворот ' + rot + '°' : '');
    }
    // Белила и лак на каждой стороне — считать, пока раскладка текущая: у фоновой Illustrator перебирает
    // объекты в сотни раз медленнее (на раскладке Central Park — десятки минут)
    function inkSides(d, sides) {
        var out = [];
        for (var i = 0; i < sides.length; i++) {
            var a = [];
            for (var k = 1; k <= 2; k++) if (Inks.Active(k) && Inks.CountOnPage(d, sides[i], k) > 0) a.push(Inks.Title(k).toLowerCase() + ' «' + Inks.OutName[k] + '»');
            out.push(a);
        }
        return out;
    }
    function outFolder() { return Settings.get('Output', 'Format', 'tiff') == 'pdf' ? Engine.PdfPath : Engine.TiffFolder; }
    function today() { var d = new Date(); return ('0' + d.getDate()).slice(-2) + '.' + ('0' + (d.getMonth() + 1)).slice(-2) + '.' + d.getFullYear(); }
    function savedFile(d) { try { var f = d.fullName; return f && f.exists ? f : null; } catch (e) { return null; } }
    function sideBoards(d) { var a = []; for (var i = 0; i < d.artboards.length; i++) if (d.artboards[i].name != TEMPLATE_PAGE) a.push(i); return a; }
    function tplBoard(d) { for (var i = 0; i < d.artboards.length; i++) if (d.artboards[i].name == TEMPLATE_PAGE) return i; return -1; }

    // Строки ведомости: лист, карт на нём, первый и последний номер — по ключевому полю
    function sheetRows(total, scan) {
        var out = [], kf = Records.KeyField(), s, p;
        if (!kf) { for (s = 1; s <= total; s++) out.push([s, 0, '', '']); return out; }
        var per = Engine.FieldPlaces(kf.Id, scan);
        for (s = 0; s < total; s++) {
            var a = '', b = '', cnt = 0;
            for (p = 0; p < per; p++) {
                var rec = Engine.RecordIndex(s, p, per, total);
                if (Records.HasRecord(kf, rec)) { cnt++; if (!a) a = kf.ValueAt(rec); b = kf.ValueAt(rec); }
            }
            out.push([s + 1, cnt, a, b]);
        }
        return out;
    }
    // карт на листе: группы «Карта …» и «Макет …» на области (по самому полному слою)
    function cardsOn(d, ab) {
        var best = 0;
        for (var i = 0; i < d.layers.length; i++) {
            var a = topItemsOn(d, d.layers[i], ab), n = 0;
            for (var k = 0; k < a.length; k++) if (/^(Карта|Макет) /.test(a[k].name)) n++;
            best = Math.max(best, n);
        }
        return best;
    }
    function gridOf(d, ab) {
        var xs = {}, ys = {}, nx = 0, ny = 0;
        for (var i = 0; i < d.layers.length; i++) {
            var a = topItemsOn(d, d.layers[i], ab);
            for (var k = 0; k < a.length; k++) if (/^(Карта|Макет) /.test(a[k].name)) {
                var b = a[k].geometricBounds, x = Math.round(mm((b[0] + b[2]) / 2)), y = Math.round(mm((b[1] + b[3]) / 2));
                if (!xs[x]) { xs[x] = 1; nx++; }
                if (!ys[y]) { ys[y] = 1; ny++; }
            }
        }
        return [nx, ny];
    }

    // ---------- снимки ----------
    // Снимок прямоугольника rect (пт) документа d в PNG на белом. Только видимые печатные слои
    // (или только слой only); снимается через временную монтажную область
    function snap(d, rect, path, dpi, only) {
        var keep = d.artboards.getActiveArtboardIndex(), vis = [], i, ab;
        d.artboards.add(rect); ab = d.artboards.length - 1;
        try {
            for (i = 0; i < d.layers.length; i++) { var L = d.layers[i]; vis.push(L.visible); if (only ? L != only : !L.printable) L.visible = false; }
            d.artboards.setActiveArtboardIndex(ab);
            var o = new ExportOptionsPNG24(); o.artBoardClipping = true; o.transparency = false; o.antiAliasing = true;
            o.horizontalScale = o.verticalScale = Math.min(776, dpi / 72 * 100);
            var f = new File(path); if (f.exists) f.remove();
            d.exportFile(f, ExportType.PNG24, o);
        } finally {
            for (i = 0; i < vis.length; i++) try { d.layers[i].visible = vis[i]; } catch (e) { }
            d.artboards.setActiveArtboardIndex(keep);
            d.artboards.remove(ab);
        }
    }
    function tmpLayer(d) { var L = d.layers.add(); L.name = '~согласование'; L.printable = true; return L; }
    function frameRect(L, r, fill, red) {
        var x = L.pathItems.rectangle(r[1], r[0], r[2] - r[0], r[1] - r[3]);
        if (fill) { x.filled = true; x.fillColor = rgbColor(fill[0], fill[1], fill[2]); } else x.filled = false;
        x.stroked = !!red; if (red) { x.strokeColor = rgbColor(230, 0, 0); x.strokeWidth = pt(0.25); }
        return x;
    }
    // Карта с вылетом на белом, красная линия — край после резки. Технические копии белил и лака — на время спрятаны:
    // их условные цвета собьют клиента
    function renderCard(d, ab, bleed, path, dpi) {
        var R = d.artboards[ab].artboardRect, ins = pt(insetOfSize(mm(R[2] - R[0]), mm(R[1] - R[3]))), c = [R[0] + ins, R[1] - ins, R[2] - ins, R[3] + ins];
        var e = pt(bleed + 2), area = [c[0] - e, c[1] + e, c[2] + e, c[3] - e], hid = [], k, i, L = null;
        try {
            for (k = 1; k <= 2; k++) if (Inks.Active(k)) { var a = Inks.Shapes(d, ab, k); for (i = 0; i < a.length; i++) if (!a[i].hidden) { a[i].hidden = true; hid.push(a[i]); } }
            L = tmpLayer(d);
            frameRect(L, c, null, true);
            snap(d, area, path, dpi);
        } finally {
            for (i = 0; i < hid.length; i++) try { hid[i].hidden = false; } catch (x) { }
            try { if (L) L.remove(); } catch (x) { }
        }
        return c;
    }
    function recolor(it, col) {
        var lv = leavesOf([it]);
        for (var i = 0; i < lv.length; i++) {
            var x = lv[i];
            try {
                if (x.typename == 'TextFrame') { x.textRange.characterAttributes.fillColor = col; continue; }
                var ps = x.typename == 'CompoundPathItem' ? [] : [x];
                if (x.typename == 'CompoundPathItem') for (var k = 0; k < x.pathItems.length; k++) ps.push(x.pathItems[k]);
                for (k = 0; k < ps.length; k++) { if (ps[k].filled) ps[k].fillColor = col; if (ps[k].stroked) ps[k].strokeColor = col; }
            } catch (e) { }
        }
    }
    // Схема краски k на стороне: карта — светло-серая, краска — синим. false — краски на стороне нет
    function renderInk(d, ab, k, bleed, path, dpi) {
        var sh = Inks.Shapes(d, ab, k);
        if (!sh.length) return false;
        var R = d.artboards[ab].artboardRect, ins = pt(insetOfSize(mm(R[2] - R[0]), mm(R[1] - R[3]))), c = [R[0] + ins, R[1] - ins, R[2] - ins, R[3] + ins];
        var e = pt(bleed + 2), area = [c[0] - e, c[1] + e, c[2] + e, c[3] - e], L = tmpLayer(d), blue = rgbColor(MARK[0], MARK[1], MARK[2]);
        try {
            for (var i = 0; i < sh.length; i++) { var dup = sh[i].duplicate(L, ElementPlacement.PLACEATEND); try { dup.hidden = false; } catch (x) { } recolor(dup, blue); }
            frameRect(L, c, [232, 234, 237], true).zOrder(ZOrderMethod.SENDTOBACK);
            snap(d, area, path, dpi, L);
        } finally { try { L.remove(); } catch (x) { } }
        return true;
    }

    // ---------- новый лист для документа ----------
    function fontOf(bold) { try { return app.textFonts.getByName(bold ? 'Arial-BoldMT' : 'ArialMT'); } catch (e) { return null; } }
    function sheet(w, h) {
        var nd = app.documents.add(DocumentColorSpace.RGB, pt(w), pt(h)), L = nd.layers[0], R = nd.artboards[0].artboardRect;
        var S = { d: nd, L: L, R: R, w: w, h: h, fR: fontOf(false), fB: fontOf(true) };
        bg(S, R);
        return S;
    }
    function bg(S, R) { var r = S.L.pathItems.rectangle(R[1], R[0], R[2] - R[0], R[1] - R[3]); r.filled = true; r.fillColor = rgbColor(255, 255, 255); r.stroked = false; r.zOrder(ZOrderMethod.SENDTOBACK); }
    function X(S, x) { return S.R[0] + pt(x); }
    function Y(S, y) { return S.R[1] - pt(y); }
    // надпись: x, top — мм от левого верхнего угла листа (top — верх букв); align r — x правый край
    function txt(S, x, top, s, size, bold, r, g, b, align) {
        var t = S.L.textFrames.pointText([X(S, x), Y(S, top) - size * 0.75]);
        t.contents = String(s);
        var ca = t.textRange.characterAttributes;
        var f = bold ? S.fB : S.fR; if (f) ca.textFont = f;
        ca.size = size; ca.fillColor = rgbColor(r, g, b);
        if (align == 'r' || align == 'c') t.textRange.paragraphAttributes.justification = align == 'r' ? Justification.RIGHT : Justification.CENTER;
        var bb = t.geometricBounds;
        t.translate(0, Y(S, top) - bb[1]);
        return t;
    }
    // несколько строк одним блоком, межстрочный — 1,25 кегля
    function para(S, x, top, lines, size, r, g, b) {
        var t = txt(S, x, top, lines.join('\r'), size, false, r, g, b);
        try { t.textRange.characterAttributes.autoLeading = false; t.textRange.characterAttributes.leading = size * 1.25; } catch (e) { }
        var bb = t.geometricBounds; t.translate(0, Y(S, top) - bb[1]);
        return t;
    }
    // картинка из файла — вписать в рамку (x, top, w, h мм), по центру по ширине
    function place(S, path, x, top, w, h) {
        var f = new File(path);
        if (!f.exists) return null;
        var p = S.L.placedItems.add(); p.file = f;
        var k = Math.min(pt(w) / p.width, pt(h) / p.height) * 100;
        p.resize(k, k);
        var b = p.geometricBounds;
        p.translate(X(S, x) + (pt(w) - (b[2] - b[0])) / 2 - b[0], Y(S, top) - b[1]);
        try { p.embed(); } catch (e) { }
        return p;
    }
    function rect(S, x, top, w, h, sw, r, g, b) {
        var q = S.L.pathItems.rectangle(Y(S, top), X(S, x), pt(w), pt(h));
        q.filled = false; q.stroked = true; q.strokeWidth = pt(sw); q.strokeColor = rgbColor(r, g, b);
        return q;
    }
    function hline(S, x0, x1, y, grey) {
        var l = S.L.pathItems.add(); l.setEntirePath([[X(S, x0), Y(S, y)], [X(S, x1), Y(S, y)]]);
        l.filled = false; l.stroked = true; l.strokeWidth = pt(0.2); l.strokeColor = rgbColor(grey, grey, grey);
    }
    function saveJpg(S, path, dpi) {
        var o = new ExportOptionsJPEG(); o.artBoardClipping = true; o.antiAliasing = true; o.qualitySetting = 90;
        o.horizontalScale = o.verticalScale = Math.min(776, dpi / 72 * 100);
        S.d.artboards.setActiveArtboardIndex(0);
        exportAs(S.d, path, ExportType.JPEG, o, '.jpg');
    }
    function savePng(S, path, dpi) {
        var o = new ExportOptionsPNG24(); o.artBoardClipping = true; o.transparency = false; o.antiAliasing = true;
        o.horizontalScale = o.verticalScale = Math.min(776, dpi / 72 * 100);
        S.d.artboards.setActiveArtboardIndex(0);
        exportAs(S.d, path, ExportType.PNG24, o, '.png');
    }
    // Illustrator при сохранении картинки меняет пробелы в имени на дефисы — сохраняем под временным именем и переносим
    function exportAs(d, path, type, o, ext) {
        var t = new File(Folder.temp.fsName + '/psa_export_' + new Date().getTime() + ext), f = new File(path);
        d.exportFile(t, type, o);
        if (f.exists) f.remove();
        if (!t.copy(f.fsName)) throw new Error('не записался файл «' + f.displayName + '» — он открыт в другой программе?');
        t.remove();
    }
    function savePdfDoc(S, path) {
        var o = new PDFSaveOptions(); o.preserveEditability = false; o.viewAfterSaving = false;
        var f = new File(path); if (f.exists) f.remove();
        S.d.saveAs(f, o);
    }
    function closeSheet(S) { try { S.d.close(SaveOptions.DONOTSAVECHANGES); } catch (e) { } }
    function tmpDir(tag) { var f = new Folder(Folder.temp.fsName + '/PS-order-' + tag + '-' + new Date().getTime()); f.create(); return f; }
    function dropDir(f) { try { var a = f.getFiles(); for (var i = 0; i < a.length; i++) a[i].remove(); f.remove(); } catch (e) { } }
    // готовое — сразу открыть (в проверках без окон — нет)
    function openFile(path) { if (PSA.quiet) return; try { new File(path).execute(); } catch (e) { } }

    // ---------- лист согласования ----------
    function approval(bleed) {
        var d = app.activeDocument, file = savedFile(d);
        if (!file) return 'Сначала сохраните образец — лист согласования ляжет рядом с ним.';
        var base = d.name.replace(/\.[^.]*$/, '') || 'макет', folder = new Folder(file.parent.fsName + '/' + base + ' — на согласование');
        if (!folder.exists) folder.create();
        var sides = sideBoards(d).slice(0, 2), n = sides.length, tmp = tmpDir('appr'), sp = [], maps = [], wasSaved = d.saved, i, k, S = null;
        if (!n) return 'В документе нет монтажных областей с картой.';
        var R0 = d.artboards[sides[0]].artboardRect, ins = insetOfSize(mm(R0[2] - R0[0]), mm(R0[1] - R0[3]));
        if (ins > 0) bleed = ins;
        var cw = mm(R0[2] - R0[0]) - 2 * ins, ch = mm(R0[1] - R0[3]) - 2 * ins, out = folder.fsName + '/' + base + ' — лист согласования';
        try {
            for (i = 0; i < n; i++) {
                var nm = sideTitle(d.artboards[sides[i]].name, i + 1, n), f = tmp.fsName + '/side' + (i + 1) + '.png';
                renderCard(d, sides[i], bleed, f, 200);
                sp.push([f, nm]);
                for (k = 1; k <= 2; k++) if (Inks.Active(k)) {
                    var fi = tmp.fsName + '/ink' + (i + 1) + '_' + k + '.png';
                    if (renderInk(d, sides[i], k, bleed, fi, 150)) maps.push([fi, Inks.Title(k) + ' — ' + nm.toLowerCase()]);
                }
            }
            d.selection = null;
            try { d.saved = wasSaved; } catch (e) { }
            // страница согласования: A4 альбомом
            S = sheet(297, 210);
            var x0 = 12, x1 = 285, top = 12, gap = 8, bw, bh, y;
            txt(S, x0, top, 'Макет на согласование', 18, true, 30, 30, 30);
            txt(S, x1, top, today() + clientPart(), 10, false, 110, 110, 110, 'r');
            txt(S, x0, top + 9, base, 10, false, 110, 110, 110);
            bh = maps.length ? 78 : 112; bw = (x1 - x0 - gap * (n - 1)) / n; y = top + 18;
            for (i = 0; i < n; i++) {
                txt(S, x0 + (bw + gap) * i, y, sp[i][1], 11, true, 50, 50, 50);
                place(S, sp[i][0], x0 + (bw + gap) * i, y + 6, bw, bh);
            }
            y += 6 + bh + 8;
            if (maps.length) {
                txt(S, x0, y, 'Где лягут белила и лак — отмечено синим:', 10, true, 50, 50, 50);
                var m = maps.length, mw = Math.min(95, (x1 - x0 - gap * (m - 1)) / m);
                for (i = 0; i < m; i++) {
                    txt(S, x0 + (mw + gap) * i, y + 6, maps[i][1], 9, false, 70, 70, 70);
                    place(S, maps[i][0], x0 + (mw + gap) * i, y + 11, mw, 42);
                }
            }
            var info = ['Размер изделия: ' + mmText(cw) + ' × ' + mmText(ch) + ' мм' + (bleed > 0 ? ', вылет ' + mmText(bleed) + ' мм' : '')], s = numbersLine();
            if (s) info.push(s);
            info.push('Краски: ' + inksLine());
            para(S, x0, 210 - 34, info, 10, 40, 40, 40);
            para(S, x1 - 90, 210 - 34, ['Согласовано: _____________________', '', 'Дата: ____________'], 10, 40, 40, 40);
            txt(S, x0, 210 - 9, 'Красная линия — край изделия после резки: всё, что за ней, срежется. Цвета на экране — приблизительно.', 8, false, 200, 0, 0);
            S.d.selection = null;
            saveJpg(S, out + '.jpg', 150);
            savePdfDoc(S, out + '.pdf');
        } catch (e) {
            logLine('сбой листа согласования: ' + e.message + ' (строка ' + e.line + ')');
            return 'Не удалось сделать лист согласования: ' + e.message;
        } finally {
            if (S) closeSheet(S);
            dropDir(tmp);
            try { d.activate(); } catch (x) { }
        }
        logLine('лист согласования: ' + out + '.jpg');
        openFile(out + '.jpg');
        return 'Лист согласования готов: картинка и PDF в папке «' + base + ' — на согласование». Картинку можно сразу отправить клиенту.';
    }

    // ---------- задание в печать ----------
    function jobSheet() {
        var d = app.activeDocument, file = savedFile(d);
        if (!file) return 'Сначала сохраните раскладку — задание ляжет рядом с ней.';
        var base = d.name.replace(/\.[^.]*$/, ''), sides = sideBoards(d), hasTpl = tplBoard(d) >= 0, scan = scanFields(d), why = {}, S = null;
        var total = Math.max(1, Engine.TotalSheets(why, scan)), rows = sheetRows(total, scan), R1 = d.artboards[sides[0]].artboardRect;
        var sheetW = mm(R1[2] - R1[0]), sheetH = mm(R1[1] - R1[3]), tmp = tmpDir('job'), thumb = tmp.fsName + '/thumb.png', wasSaved = d.saved;
        var out = file.parent.fsName + '/' + base + ' — задание в печать.pdf', names = [], i, k;
        for (i = 0; i < sides.length; i++) names.push(d.artboards[sides[i]].name);
        try {
            snap(d, R1, thumb, 40);
            try { d.saved = wasSaved; } catch (e) { }
            var inks = inkSides(d, sides), of = outFolder();
            S = sheet(210, 297);
            var x0 = 14, x1 = 196, y = 14, cards = 0, per = 0, nS = sides.length;
            txt(S, x0, y, 'Задание в печать', 18, true, 30, 30, 30);
            txt(S, x1, y, today(), 10, false, 110, 110, 110, 'r');
            txt(S, x0, y + 9, base + clientPart(), 10, false, 90, 90, 90);
            place(S, thumb, x1 - 48, y + 16, 48, 62);
            for (i = 0; i < rows.length; i++) { cards += rows[i][1]; per = Math.max(per, rows[i][1]); }
            var info = ['Лист: ' + mmText(sheetW) + ' × ' + mmText(sheetH) + ' мм' + (per > 0 ? ', карт на листе: ' + per : ''),
                        'Листов: ' + total + (nS > 1 ? ', сторон: ' + nS + ' (' + sideNames(names) + ')' : '')];
            if (cards > 0) info.push('Всего карт: ' + cards);
            info.push('Принтер: ' + printerLine());
            for (i = 0; i < nS; i++) {
                info.push(sideTitle(names[i], i + 1, nS) + ': CMYK' + (inks[i].length ? ', ' + inks[i].join(', ') : ''));
            }
            if (of) info.push('Файлы: ' + of);
            para(S, x0, y + 16, info, 10, 40, 40, 40);
            var steps = [], st = 0;
            if (hasTpl) steps.push(++st + '. Шаблон стола — первым, прямо на стол: по нему раскладываются заготовки.');
            for (i = 0; i < nS; i++) steps.push(++st + '. ' + sideTitle(names[i], i + 1, nS) + ' — листы 1–' + total + (i > 0 ? ': те же заготовки, после того как высохнет ' + sideTitle(names[0], 1, nS).toLowerCase() + '.' : '.'));
            txt(S, x0, y + 84, 'Порядок печати', 11, true, 40, 40, 40);
            para(S, x0, y + 90, steps, 10, 40, 40, 40);
            table(S, x0, x1, y + 124, rows, names);
            S.d.selection = null;
            savePdfDoc(S, out);
        } catch (e) {
            logLine('сбой задания в печать: ' + e.message + ' (строка ' + e.line + ')');
            return 'Не удалось сделать задание: ' + e.message + '. Проверьте, что открыта раскладка, а не образец, и что прошлое задание не открыто в другой программе, — затем нажмите ещё раз.';
        } finally {
            if (S) closeSheet(S);
            dropDir(tmp);
            try { d.activate(); } catch (x) { }
        }
        logLine('задание в печать: ' + out);
        openFile(out);
        return 'Задание в печать готово: «' + base + ' — задание в печать.pdf» рядом с раскладкой. Распечатайте и отдайте оператору.';
    }
    // Таблица: лист, карт, номера, квадратики «напечатано» по сторонам. Не влезает — следующая страница справа
    function table(S, x0, x1, y, rows, names) {
        var RH = 6.2, nS = names.length, c1 = x0 + 14, c2 = x0 + 30, cs = 26, c3 = x1 - cs * nS, bottom = S.h - 22, first = true, k;
        var R0 = S.R, page = 0;
        function head() {
            txt(S, x0 + 1.5, y + 1.6, 'Лист', 9, true, 90, 90, 90);
            txt(S, c1 + 1.5, y + 1.6, 'Карт', 9, true, 90, 90, 90);
            txt(S, c2 + 1.5, y + 1.6, 'Номера', 9, true, 90, 90, 90);
            for (k = 0; k < nS; k++) txt(S, c3 + cs * k + cs / 2, y + 1.6, sideTitle(names[k], k + 1, nS), 9, true, 90, 90, 90, 'c');
            hline(S, x0, x1, y + RH, 120);
        }
        for (var i = 0; i < rows.length; i++) {
            if (first || y + RH > bottom) {
                if (!first) {
                    page++;
                    var Rn = [R0[0] + page * (R0[2] - R0[0] + pt(20)), R0[1], R0[2] + page * (R0[2] - R0[0] + pt(20)), R0[3]];
                    S.d.artboards.add(Rn); S.R = Rn; bg(S, Rn);
                    y = 14;
                }
                head(); y += RH; first = false;
            }
            var r = rows[i];
            txt(S, x0 + 1.5, y + 1.6, r[0], 10, true, 30, 30, 30);
            txt(S, c1 + 1.5, y + 1.6, r[1], 10, false, 30, 30, 30);
            if (r[2] !== '') txt(S, c2 + 1.5, y + 1.6, r[2] + (r[3] != r[2] ? ' — ' + r[3] : ''), 10, false, 30, 30, 30);
            for (k = 0; k < nS; k++) rect(S, c3 + cs * k + cs / 2 - 2, y + 1.2, 4, 4, 0.3, 60, 60, 60);
            hline(S, x0, x1, y + RH, 200);
            y += RH;
        }
        txt(S, x0, S.h - 16, 'Напечатал: _____________________      Дата: ____________', 10, false, 60, 60, 60);
        S.R = R0;
    }

    // ---------- превью листов для бланка заказа ----------
    // Уголки шаблона на уменьшенном листе тоньше точки — на время снимка обводим их своим цветом
    function tplThick(d, ab, sheetW, sheetH) {
        var k = Math.min(110 / sheetW, 170 / sheetH), list = [];
        for (var i = 0; i < d.layers.length; i++) {
            if (!d.layers[i].printable || !d.layers[i].visible) continue;
            var lv = leavesOf(topItemsOn(d, d.layers[i], ab));
            for (var j = 0; j < lv.length; j++) {
                var x = lv[j];
                try { if (x.typename == 'PathItem' && x.filled && !x.stroked) { x.stroked = true; x.strokeWidth = pt(0.15 / k); x.strokeColor = x.fillColor; list.push(x); } } catch (e) { }
            }
        }
        return list;
    }
    function sheetsPreview() {
        var d = app.activeDocument, file = savedFile(d);
        if (!file) return 'Сначала сохраните раскладку — картинка ляжет рядом с ней.';
        var base = d.name.replace(/\.[^.]*$/, ''), sides = sideBoards(d), tpl = tplBoard(d), nS = sides.length, scan, why = {}, S = null, i, j, k;
        var R1 = d.artboards[sides[0]].artboardRect, sheetW = mm(R1[2] - R1[0]), sheetH = mm(R1[1] - R1[3]), wasSaved = d.saved;
        var tmp = tmpDir('sheets'), files = [], out = file.parent.fsName + '/' + base + ' — превью листов.png';
        try {
            // номера первого листа — как «Показать на экране»
            if (Engine.Fields.length) Engine.RunJob('preview', 1);
            scan = scanFields(d);
            var total = Engine.TotalSheets(why, scan), per = cardsOn(d, sides[0]), gr = gridOf(d, sides[0]);
            var dpi = Math.max(15, Math.min(150, Math.round(900 / (sheetH / 25.4)))), pages = sides.slice(0);
            if (tpl >= 0) pages.push(tpl);
            for (i = 0; i < pages.length; i++) {
                var th = pages[i] == tpl ? tplThick(d, tpl, sheetW, sheetH) : [];
                try { snap(d, d.artboards[pages[i]].artboardRect, tmp.fsName + '/p' + i + '.png', dpi); }
                finally { for (k = 0; k < th.length; k++) try { th[k].stroked = false; } catch (e) { } }
                files.push(tmp.fsName + '/p' + i + '.png');
            }
            try { d.saved = wasSaved; } catch (e) { }
            var inks = inkSides(d, sides);
            var lp = Impose.ParamsFrom((docProp(d, 'layout') || '').replace(/^src=[^|]*\|?/, ''));
            var A = [['Карта', lp.CutW > 0 ? mmText(lp.CutW) + ' × ' + mmText(lp.CutH) + ' мм' : '—'], ['Вылет', mmText(lp.Bleed) + ' мм' + (lp.Radius > 0 ? ' · углы R' + mmText(lp.Radius) : '')],
                     ['Заказчик', trimS(Engine.Client || '') || '—'], ['Файл', d.name]];
            var B = [['Лист', mmText(sheetW) + ' × ' + mmText(sheetH) + ' мм'], ['На листе', per + ' шт.' + (gr[0] > 0 ? '  (' + gr[0] + ' × ' + gr[1] + ')' : '')],
                     ['Листов', total + (per > 0 ? ' · мест ' + per * total : '')]];
            var s = numbersLine(); if (s) B.push(['Тираж', s.replace('Тираж: ', '')]);
            var names = []; for (i = 0; i < nS; i++) names.push(d.artboards[sides[i]].name);
            var C = [['Принтер', printerLine()], ['Краски', inksLine()], ['Порядок', (tpl >= 0 ? 'шаблон → ' : '') + sideNames(names).replace(/, /g, ' → ')]];
            for (i = 0; i < Engine.Fields.length; i++) { var f = Engine.Fields[i]; if (f.Source == 1 && f.FilePath) { C.push(['Данные', String(f.FilePath).replace(/^.*[\\\/]/, '')]); break; } }
            var rowsN = Math.max(A.length, B.length, C.length), n = pages.length, m = 8, gap = 6;
            var slotW = (297 - 2 * m - (n - 1) * gap) / n, imgH = slotW * sheetH / sheetW;
            if (imgH > 118) { imgH = 118; slotW = imgH * sheetW / sheetH; }
            var rowsW = n * slotW + (n - 1) * gap, H = m + 11 + 5 + imgH + 6 + 5.5 + 4.6 * rowsN + 3 + 4 + 4 + m;
            S = sheet(297, H);
            var y = m;
            txt(S, m, y, base, 13, true, 25, 25, 25);
            txt(S, 297 - m, y - 0.5, 'Бланк заказа · ' + today(), 9, false, 110, 110, 110, 'r');
            y += 8; hline(S, m, 297 - m, y, 200); y += 3;
            var x0 = (297 - rowsW) / 2;
            for (j = 0; j < n; j++) {
                var x = x0 + j * (slotW + gap), ii = tpl >= 0 ? (j == 0 ? n - 1 : j - 1) : j, cap, note;
                if (ii < nS) {
                    var side = sideTitle(names[ii], ii + 1, nS);
                    cap = (ii + 1 + (tpl >= 0 ? 1 : 0)) + '  ' + side;
                    note = 'CMYK' + (inks[ii].length ? ' + ' + inks[ii].join(' + ') : '') + (ii > 0 ? ' · после высыхания: ' + sideTitle(names[0], 1, nS).toLowerCase() : '');
                } else { cap = '1  Шаблон стола'; note = 'первым, прямо на стол · один раз'; }
                txt(S, x, y, cap, 10, true, 25, 25, 25);
                txt(S, x + slotW, y + 0.6, note, 7, false, 100, 100, 100, 'r');
                place(S, files[ii], x, y + 5, slotW, imgH);
                rect(S, x, y + 5, slotW, imgH, 0.2, 150, 150, 150);
            }
            y += 5 + imgH + 6;
            var colW = (297 - 2 * m - 2 * gap) / 3, yInfo = Math.max(infoCol(S, m, y, colW, 'Заказ', A), infoCol(S, m + colW + gap, y, colW, 'Раскладка', B), infoCol(S, m + 2 * (colW + gap), y, colW, 'Печать', C));
            y = yInfo + 1;
            hline(S, m, 297 - m, y, 200);
            y += 4;
            txt(S, m, y, 'Оператор ____________________    Начало ________    Конец ________    Напечатано листов ______    Брак ______    Подпись ____________', 8.5, false, 60, 60, 60);
            S.d.selection = null;
            savePng(S, out, 200);
        } catch (e) {
            logLine('сбой превью листов: ' + e.message + ' (строка ' + e.line + ')');
            return 'Не удалось сделать превью: ' + e.message + '. Проверьте, что открыта раскладка, а не образец, и что прошлая картинка превью не открыта в другой программе, — затем нажмите ещё раз.';
        } finally {
            if (S) closeSheet(S);
            dropDir(tmp);
            try { d.activate(); } catch (x) { }
        }
        logLine('превью листов: ' + out);
        openFile(out);
        return 'Превью листов готово: «' + base + ' — превью листов.png» рядом с раскладкой — для бланка заказа.';
    }
    // Колонка сведений: заголовок и строки «подпись — значение»; ответ — низ колонки (мм от верха)
    function infoCol(S, x, top, w, title, rows) {
        var y = top;
        txt(S, x, y, title, 9, true, 40, 90, 160);
        y += 5.5;
        for (var i = 0; i < rows.length; i++) {
            txt(S, x, y, rows[i][0], 7.5, false, 120, 120, 120);
            var t = txt(S, x + 19, y, rows[i][1], 8.5, false, 25, 25, 25), b = t.geometricBounds, right = X(S, x + w);
            // длинное значение — уменьшить, чтобы не залезло в соседнюю колонку
            if (b[2] > right) { var k = (right - b[0]) / (b[2] - b[0]) * 100; t.resize(k, k, true, true, true, true, k, Transformation.TOPLEFT); }
            y += 4.6;
        }
        return y;
    }

    return { approval: approval, jobSheet: jobSheet, sheetsPreview: sheetsPreview };
})();

function orderPrep() {
    prepare();
    Engine.PrepareData();
}
Bridge.OrderApproval = function (bleed) {
    if (!hasDoc()) return 'Нет открытого документа.';
    if (!isSampleDoc(app.activeDocument)) return 'Лист согласования делается по образцу карты: откройте образец — файл с одной картой, где монтажные области — стороны.';
    try { orderPrep(); return OrderDocs.approval(toNum(bleed, 0)); }
    catch (e) { logLine('сбой OrderApproval: ' + e.message + ' (строка ' + e.line + ')'); return 'Не удалось сделать лист согласования: ' + e.message; }
};
Bridge.OrderJob = function () {
    if (!hasDoc()) return 'Нет открытого документа.';
    if (isSampleDoc(app.activeDocument)) return 'Задание в печать делается по раскладке: сначала разложите карты на лист и откройте раскладку.';
    try { orderPrep(); return OrderDocs.jobSheet(); }
    catch (e) { logLine('сбой OrderJob: ' + e.message + ' (строка ' + e.line + ')'); return 'Не удалось сделать задание: ' + e.message; }
};
Bridge.OrderSheets = function () {
    if (!hasDoc()) return 'Нет открытого документа.';
    if (isSampleDoc(app.activeDocument)) return 'Превью листов делается по раскладке: сначала разложите карты на лист и откройте раскладку.';
    try { orderPrep(); return OrderDocs.sheetsPreview(); }
    catch (e) { logLine('сбой OrderSheets: ' + e.message + ' (строка ' + e.line + ')'); return 'Не удалось сделать превью: ' + e.message; }
};
