// QR-код (версии 1–40, коррекция L/M/Q/H) — как src/QR.bas. Текст кодируется в UTF-8.
// QR.encode(текст, уровень) -> { m: матрица [строка][столбец] (1 — тёмный), n: размер } или { error }

var QR = (function () {
    var ECC = {
        L: [7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
        M: [10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
        Q: [13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
        H: [17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]
    };
    var BLK = {
        L: [1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
        M: [1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
        Q: [1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
        H: [1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81]
    };
    var ALNUM = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';
    var sz, mods, isFn, bits;

    function putBits(v, n) { for (var i = n - 1; i >= 0; i--) bits.push(Math.floor(v / Math.pow(2, i)) & 1); }
    function rawModules(ver) {
        var r = (16 * ver + 128) * ver + 64;
        if (ver >= 2) { var na = Math.floor(ver / 7) + 2; r -= (25 * na - 10) * na - 55; if (ver >= 7) r -= 36; }
        return r;
    }
    function dataCodewords(ver, lvl) { return Math.floor(rawModules(ver) / 8) - ECC[lvl][ver - 1] * BLK[lvl][ver - 1]; }

    // ---------- поле Галуа и Рид–Соломон ----------
    function gfMul(x, y) {
        var z = 0;
        for (var i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); if ((y >>> i) & 1) z ^= x; }
        return z;
    }
    function rsDivisor(deg) {
        var r = [], i, j, root = 1;
        for (i = 0; i < deg; i++) r.push(0);
        r[deg - 1] = 1;
        for (i = 0; i < deg; i++) {
            for (j = 0; j < deg; j++) { r[j] = gfMul(r[j], root); if (j + 1 < deg) r[j] ^= r[j + 1]; }
            root = gfMul(root, 2);
        }
        return r;
    }
    function rsRemainder(dat, from, cnt, dv) {
        var n = dv.length, r = [], i, k, f;
        for (i = 0; i < n; i++) r.push(0);
        for (k = from; k < from + cnt; k++) {
            f = dat[k] ^ r[0];
            r.shift(); r.push(0);
            for (i = 0; i < n; i++) r[i] ^= gfMul(dv[i], f);
        }
        return r;
    }

    // ---------- служебные элементы ----------
    function setFn(x, y, dark) { mods[y][x] = dark ? 1 : 0; isFn[y][x] = true; }
    function alignPositions(ver) {
        if (ver == 1) return [];
        var n = Math.floor(ver / 7) + 2, stp = ver == 32 ? 26 : Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2, r = [], pos = sz - 7, i;
        for (i = 0; i < n; i++) r.push(0);
        r[0] = 6;
        for (i = n - 1; i >= 1; i--) { r[i] = pos; pos -= stp; }
        return r;
    }
    function drawFinder(x, y) {
        for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
            var d = Math.max(Math.abs(dx), Math.abs(dy)), xx = x + dx, yy = y + dy;
            if (xx >= 0 && xx < sz && yy >= 0 && yy < sz) setFn(xx, yy, d != 2 && d != 4);
        }
    }
    function drawAlign(x, y) {
        for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) setFn(x + dx, y + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1);
    }
    function bit(v, i) { return ((v >>> i) & 1) != 0; }
    function drawFormat(lvl, mask) {
        var fb = { L: 1, M: 0, Q: 3, H: 2 }[lvl], dat = fb * 8 + mask, r = dat, i;
        for (i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537);
        var b = ((dat << 10) | r) ^ 0x5412;
        for (i = 0; i <= 5; i++) setFn(8, i, bit(b, i));
        setFn(8, 7, bit(b, 6));
        setFn(8, 8, bit(b, 7));
        setFn(7, 8, bit(b, 8));
        for (i = 9; i <= 14; i++) setFn(14 - i, 8, bit(b, i));
        for (i = 0; i <= 7; i++) setFn(sz - 1 - i, 8, bit(b, i));
        for (i = 8; i <= 14; i++) setFn(8, sz - 15 + i, bit(b, i));
        setFn(8, sz - 8, true);
    }
    function drawVersion(ver) {
        if (ver < 7) return;
        var r = ver, i;
        for (i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1F25);
        var b = (ver << 12) | r;
        for (i = 0; i < 18; i++) {
            var a = sz - 11 + i % 3, c = Math.floor(i / 3);
            setFn(a, c, bit(b, i));
            setFn(c, a, bit(b, i));
        }
    }
    function drawFunctionPatterns(ver, lvl) {
        var i, j;
        for (i = 0; i < sz; i++) { setFn(6, i, i % 2 == 0); setFn(i, 6, i % 2 == 0); }
        drawFinder(3, 3); drawFinder(sz - 4, 3); drawFinder(3, sz - 4);
        var ap = alignPositions(ver), n = ap.length;
        for (i = 0; i < n; i++) for (j = 0; j < n; j++)
            if (!((i == 0 && j == 0) || (i == 0 && j == n - 1) || (i == n - 1 && j == 0))) drawAlign(ap[i], ap[j]);
        drawFormat(lvl, 0);
        drawVersion(ver);
    }
    function drawCodewords(cw) {
        var i = 0, total = cw.length * 8, rgt = sz - 1;
        while (rgt >= 1) {
            if (rgt == 6) rgt = 5;
            for (var vert = 0; vert < sz; vert++) for (var j = 0; j < 2; j++) {
                var x = rgt - j, up = ((rgt + 1) & 2) == 0, y = up ? sz - 1 - vert : vert;
                if (!isFn[y][x] && i < total) { mods[y][x] = bit(cw[i >>> 3], 7 - (i & 7)) ? 1 : 0; i++; }
            }
            rgt -= 2;
        }
    }
    function maskHit(m, x, y) {
        switch (m) {
            case 0: return (x + y) % 2 == 0;
            case 1: return y % 2 == 0;
            case 2: return x % 3 == 0;
            case 3: return (x + y) % 3 == 0;
            case 4: return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 == 0;
            case 5: return (x * y) % 2 + (x * y) % 3 == 0;
            case 6: return ((x * y) % 2 + (x * y) % 3) % 2 == 0;
            default: return ((x + y) % 2 + (x * y) % 3) % 2 == 0;
        }
    }
    function applyMask(m) {
        for (var y = 0; y < sz; y++) for (var x = 0; x < sz; x++) if (!isFn[y][x] && maskHit(m, x, y)) mods[y][x] = 1 - mods[y][x];
    }
    function countSub(s, f) { var n = 0, p = s.indexOf(f); while (p >= 0) { n++; p = s.indexOf(f, p + 1); } return n; }
    function penalty() {
        var p = 0, x, y, run, c, prev, dark = 0, ln;
        for (y = 0; y < sz; y++) {
            run = 0; prev = -1;
            for (x = 0; x < sz; x++) { c = mods[y][x]; if (c == prev) run++; else { run = 1; prev = c; } if (run == 5) p += 3; else if (run > 5) p += 1; }
        }
        for (x = 0; x < sz; x++) {
            run = 0; prev = -1;
            for (y = 0; y < sz; y++) { c = mods[y][x]; if (c == prev) run++; else { run = 1; prev = c; } if (run == 5) p += 3; else if (run > 5) p += 1; }
        }
        for (y = 0; y < sz - 1; y++) for (x = 0; x < sz - 1; x++) {
            c = mods[y][x];
            if (c == mods[y][x + 1] && c == mods[y + 1][x] && c == mods[y + 1][x + 1]) p += 3;
        }
        for (y = 0; y < sz; y++) {
            ln = '0000' + mods[y].join('') + '0000';
            p += 40 * countSub(ln, '10111010000') + 40 * countSub(ln, '00001011101');
        }
        for (x = 0; x < sz; x++) {
            ln = '0000';
            for (y = 0; y < sz; y++) ln += mods[y][x];
            ln += '0000';
            p += 40 * countSub(ln, '10111010000') + 40 * countSub(ln, '00001011101');
        }
        for (y = 0; y < sz; y++) for (x = 0; x < sz; x++) dark += mods[y][x];
        var k = Math.floor((Math.abs(dark * 20 - sz * sz * 10) + sz * sz - 1) / (sz * sz)) - 1;
        if (k < 0) k = 0;
        return p + k * 10;
    }

    // ---------- UTF-8 ----------
    function utf8(s) {
        var r = [], i = 0, c, c2;
        while (i < s.length) {
            c = s.charCodeAt(i);
            if (c >= 0xD800 && c <= 0xDBFF && i < s.length - 1) { c2 = s.charCodeAt(i + 1); c = 0x10000 + (c - 0xD800) * 1024 + (c2 - 0xDC00); i++; }
            if (c < 0x80) r.push(c);
            else if (c < 0x800) r.push(0xC0 | (c >> 6), 0x80 | (c & 63));
            else if (c < 0x10000) r.push(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
            else r.push(0xF0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
            i++;
        }
        return r;
    }

    // ---------- основное ----------
    function encode(s, lvl) {
        lvl = String(lvl || 'M').toUpperCase();
        if (!/^[LMQH]$/.test(lvl)) lvl = 'M';
        if (!s.length) return { error: 'QR: пустые данные' };
        var isNum = /^\d+$/.test(s), isAl = true, i, j, k, mode, b = null, nb = 0, ver, cntBits, need, cap;
        for (i = 0; i < s.length; i++) if (ALNUM.indexOf(s.charAt(i)) < 0) isAl = false;
        if (isNum) mode = 1; else if (isAl) mode = 2; else { mode = 4; b = utf8(s); nb = b.length; }
        for (ver = 1; ver <= 40; ver++) {
            if (mode == 1) { cntBits = ver <= 9 ? 10 : (ver <= 26 ? 12 : 14); need = 4 + cntBits + Math.floor(s.length / 3) * 10 + [0, 4, 7][s.length % 3]; }
            else if (mode == 2) { cntBits = ver <= 9 ? 9 : (ver <= 26 ? 11 : 13); need = 4 + cntBits + Math.floor(s.length / 2) * 11 + (s.length % 2) * 6; }
            else { cntBits = ver <= 9 ? 8 : 16; need = 4 + cntBits + nb * 8; }
            cap = dataCodewords(ver, lvl) * 8;
            if (need <= cap) break;
        }
        if (ver > 40) return { error: 'QR: слишком много данных для выбранной коррекции' };

        bits = [];
        putBits(mode, 4);
        if (mode == 1) {
            putBits(s.length, cntBits);
            for (i = 0; i < s.length; i += k) { k = Math.min(3, s.length - i); putBits(parseInt(s.substr(i, k), 10), k * 3 + 1); }
        } else if (mode == 2) {
            putBits(s.length, cntBits);
            for (i = 0; i < s.length; ) {
                if (i < s.length - 1) { putBits(ALNUM.indexOf(s.charAt(i)) * 45 + ALNUM.indexOf(s.charAt(i + 1)), 11); i += 2; }
                else { putBits(ALNUM.indexOf(s.charAt(i)), 6); i++; }
            }
        } else {
            putBits(nb, cntBits);
            for (i = 0; i < nb; i++) putBits(b[i], 8);
        }
        k = Math.min(4, cap - bits.length);
        if (k > 0) putBits(0, k);
        if (bits.length % 8) putBits(0, 8 - bits.length % 8);
        j = 0xEC;
        while (bits.length < cap) { putBits(j, 8); j ^= 0xEC ^ 0x11; }
        var cwCount = bits.length / 8, dataCw = [];
        for (i = 0; i < cwCount; i++) { var v = 0; for (j = 0; j < 8; j++) v = v * 2 + bits[i * 8 + j]; dataCw.push(v); }

        var ecc = ECC[lvl][ver - 1], blocks = BLK[lvl][ver - 1], raw = Math.floor(rawModules(ver) / 8);
        var shortCnt = blocks - raw % blocks, shortLen = Math.floor(raw / blocks), dv = rsDivisor(ecc), blk = [];
        k = 0;
        for (i = 0; i < blocks; i++) {
            var blen = shortLen - ecc + (i < shortCnt ? 0 : 1), rem = rsRemainder(dataCw, k, blen, dv), row = [];
            for (j = 0; j <= shortLen; j++) row.push(0);
            for (j = 0; j < blen; j++) row[j] = dataCw[k + j];
            // у коротких блоков на месте недостающего байта — пропуск
            for (j = 0; j < ecc; j++) row[shortLen + 1 - ecc + j] = rem[j];
            blk.push(row);
            k += blen;
        }
        var result = [];
        for (j = 0; j <= shortLen; j++) for (i = 0; i < blocks; i++) if (j != shortLen - ecc || i >= shortCnt) result.push(blk[i][j]);

        sz = ver * 4 + 17;
        mods = []; isFn = [];
        for (i = 0; i < sz; i++) { var a1 = [], a2 = []; for (j = 0; j < sz; j++) { a1.push(0); a2.push(false); } mods.push(a1); isFn.push(a2); }
        drawFunctionPatterns(ver, lvl);
        drawCodewords(result);
        var best = 0, bestP = -1, p;
        for (i = 0; i < 8; i++) {
            applyMask(i); drawFormat(lvl, i);
            p = penalty();
            if (bestP < 0 || p < bestP) { bestP = p; best = i; }
            applyMask(i);
        }
        applyMask(best);
        drawFormat(lvl, best);
        return { m: mods, n: sz };
    }

    return { encode: encode, utf8: utf8 };
})();
