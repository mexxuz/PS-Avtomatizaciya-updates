// Лицензия для Illustrator — та же, что в CorelDRAW (src/License.bas): тот же код компьютера,
// тот же ключ и пробный период в тех же записях реестра. Ключ, введённый в одной программе,
// действует и в другой. Работает в панели (Node.js), Illustrator о ключе узнаёт от панели.
var AiLic = (function () {
  var crypto = require('crypto'), cp = require('child_process');

  var PUB_X = '33C7CA44A114FBA5DB5E6817059D9F30E5A0CEC2AABD466475079AB0B6D5C4CF';
  var PUB_Y = '378AD851ED986D1F3D9671864C475B75D7B9CBF19AEAE71A4A16E22A36104683';
  var B32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
  var WARN_DAYS = 5, TRIAL_DAYS = 7;
  var CONTACT = '+998 90 328-47-04 · Telegram @iMexx · mexx.gm@gmail.com';
  var MOD_ALL = 'UWPCOMLDK', MOD_OLD = 'DUOR';
  // настройки макроса CorelDRAW (GetSetting/SaveSetting) — общие с ним
  var REG = 'HKCU\\Software\\VB and VBA Program Settings\\VarPrint';

  var pub = crypto.createPublicKey({ key: { kty: 'EC', crv: 'P-256',
    x: Buffer.from(PUB_X, 'hex').toString('base64url'), y: Buffer.from(PUB_Y, 'hex').toString('base64url') }, format: 'jwk' });

  // программа напрямую, без оболочки: та может съесть обратные косые черты в путях реестра
  function sh(exe, args) { try { return cp.execFileSync(exe, args, { encoding: 'utf8', windowsHide: true }); } catch (e) { return ''; } }
  var SYS = (process.env.SystemRoot || 'C:\\Windows') + '\\System32\\';

  // ---- реестр ----
  function regGet(sec, k) {
    var o = sh(SYS + 'reg.exe', ['query', REG + '\\' + sec, '/v', k]);
    var m = o.match(new RegExp('^\\s*' + k + '\\s+REG_SZ\\s+(.*)$', 'm'));
    return m ? m[1].replace(/\s+$/, '') : '';
  }
  function regSet(sec, k, v) {
    sh(SYS + 'reg.exe', ['add', REG + '\\' + sec, '/v', k, '/t', 'REG_SZ', '/d', String(v), '/f']);
  }

  // ---- даты: целые дни по местному времени, как Date в VBA ----
  function today() { var d = new Date(); return Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5; }
  function dayOf(s) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return m ? Date.UTC(+m[1], m[2] - 1, +m[3]) / 864e5 : 0; }
  function isoOf(d) { return new Date(d * 864e5).toISOString().substring(0, 10); }
  function ruOf(d) { var s = isoOf(d); return s.substring(8, 10) + '.' + s.substring(5, 7) + '.' + s.substring(0, 4); }

  // ---- код компьютера: 10 знаков из идентификатора Windows и номера диска C: ----
  var mCode = null;
  function machineCode() {
    if (mCode) return mCode;
    var g = (sh(SYS + 'reg.exe', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid', '/reg:64']).match(/MachineGuid\s+REG_SZ\s+(\S+)/) || [])[1] || '';
    var v = (sh(SYS + 'cmd.exe', ['/c', 'vol', 'C:']).match(/([0-9A-F]{4})-([0-9A-F]{4})\s*$/m) || []);
    // номер тома так, как его отдаёт Scripting.FileSystemObject (число со знаком)
    var ser = v.length ? String(parseInt(v[1] + v[2], 16) | 0) : '';
    var h = crypto.createHash('sha256').update('VarPrint|' + g.toLowerCase() + '|' + ser, 'latin1').digest();
    var bits = 0, nb = 0, s = '';
    for (var i = 0; i <= 6; i++) {
      bits = bits * 256 + h[i]; nb += 8;
      while (nb >= 5 && s.length < 10) { s += B32.charAt(Math.floor(bits / Math.pow(2, nb - 5)) & 31); nb -= 5; bits = bits % Math.pow(2, nb); }
    }
    return (mCode = s.substring(0, 5) + '-' + s.substring(5, 10));
  }
  function normCode(c) { return String(c).toUpperCase().replace(/[^0-9A-Z]/g, ''); }

  function verify(text, sig) {
    try { return crypto.verify('sha256', Buffer.from(text, 'latin1'), { key: pub, dsaEncoding: 'ieee-p1363' }, sig); } catch (e) { return false; }
  }
  function sigOk(body, sig) {
    return verify(body.replace('@', normCode(machineCode())), sig) || verify(body.replace('@', 'ANY'), sig);
  }
  function oldMask(m) {
    var o = '';
    if (m.indexOf('U') >= 0) o += 'U';
    if (m.indexOf('O') >= 0) o += 'OC';
    if (m.indexOf('R') >= 0) o += 'WPML';
    if (m.indexOf('D') >= 0) o += 'D';
    return o;
  }
  function cutBoth(m) {
    if (m.indexOf('M') >= 0 || m.indexOf('L') >= 0) { if (m.indexOf('M') < 0) m += 'M'; if (m.indexOf('L') < 0) m += 'L'; }
    return m;
  }

  // ключ -> { exp: день окончания (0 — не подходит), mask, why }
  function checkKey(key) {
    var NOT = 'это не ключ PS • Автоматизация', r = { exp: 0, mask: '', why: '' };
    key = String(key).replace(/[\s]/g, '');
    var p = key.indexOf('-');
    if (p < 8) { r.why = NOT; return r; }
    var d = key.substring(0, 8);
    if (!/^\d{8}$/.test(d)) { r.why = NOT; return r; }
    var mask = key.substring(8, p).toUpperCase();
    for (var i = 0; i < mask.length; i++) if ((MOD_ALL + MOD_OLD).indexOf(mask.charAt(i)) < 0) { r.why = NOT; return r; }
    var b64 = key.substring(p + 1);
    if (!/^[A-Za-z0-9_-]+$/.test(b64)) { r.why = 'ключ повреждён — скопируйте его целиком'; return r; }
    var sig = Buffer.from(b64, 'base64url');
    if (sig.length != 64) { r.why = 'ключ повреждён — скопируйте его целиком'; return r; }
    if (mask === '') {
      if (!sigOk('VP1|@|' + d, sig)) { r.why = 'ключ выдан для другого компьютера или повреждён'; return r; }
      mask = MOD_ALL;
    } else if (sigOk('VP3|@|' + d + '|' + mask, sig)) {
    } else if (sigOk('VP2|@|' + d + '|' + mask, sig)) {
      mask = oldMask(mask);
    } else { r.why = 'ключ выдан для другого компьютера или повреждён'; return r; }
    r.exp = dayOf(d.substring(0, 4) + '-' + d.substring(4, 6) + '-' + d.substring(6, 8));
    r.mask = mask;
    return r;
  }

  function clockOk() {
    var t = today(), last = dayOf(regGet('License', 'Seen'));
    if (last && t < last - 1) return false;
    if (!last || t > last) regSet('License', 'Seen', isoOf(t));
    return true;
  }

  function trialLeft() {
    var t = today(), a = dayOf(regGet('License', 'Trial')), b = dayOf(regGet('Engine', 'T0').split('').reverse().join(''));
    var t0 = a || b || t;
    if (a && b && b < a) t0 = b;
    regSet('License', 'Trial', isoOf(t0));
    regSet('Engine', 'T0', isoOf(t0).split('').reverse().join(''));
    if (!clockOk()) return 0;
    var n = TRIAL_DAYS - (t - t0);
    return (n < 0 || n > TRIAL_DAYS) ? 0 : n;
  }

  var mKey = null, mRes = null;
  // { ok, exp, days, mask, msg }
  function status() {
    var key = regGet('License', 'Key');
    if (!key) return { ok: false, exp: 0, days: 0, mask: '', msg: 'Ключ не введён.' };
    if (key !== mKey) { mRes = checkKey(key); mKey = key; }
    var r = { ok: false, exp: mRes.exp, days: 0, mask: cutBoth(mRes.mask), msg: '' };
    if (!r.exp) { r.msg = 'Ключ не подходит: ' + mRes.why + '.'; return r; }
    if (!clockOk()) { r.msg = 'Дата на компьютере раньше, чем при прошлом запуске. Проверьте часы.'; return r; }
    r.days = r.exp - today();
    if (r.days < 0) { r.msg = 'Срок ключа закончился ' + ruOf(r.exp) + '.'; return r; }
    r.ok = true;
    return r;
  }

  function modName(m) {
    return { U: 'УФ-планшет', W: 'Рулонная печать', P: 'Плоттерная резка', C: 'Цифровая печать', O: 'Офсет',
             M: 'Резка на станке', L: 'Резка на станке', D: 'Нумерация и данные', K: 'Календарь' }[m] || 'Основное';
  }

  // Сведения о ключе для панели — как Bridge.LicJson в CorelDRAW
  function json() {
    var st = status(), tl = trialLeft(), mods = [];
    for (var i = 0; i < MOD_ALL.length; i++) {
      var m = MOD_ALL.charAt(i);
      if (m == 'L') continue;      // лазер и фрезер — одна часть
      var bought = st.ok && st.mask.indexOf(m) >= 0;
      mods.push({ id: m, name: modName(m), on: bought || tl > 0, bought: bought });
    }
    return { ok: true, key: st.ok, hasKey: !!regGet('License', 'Key'), trial: tl, trialDays: TRIAL_DAYS,
             until: st.exp ? ruOf(st.exp) : '', days: st.days, warn: WARN_DAYS, code: machineCode(), msg: st.msg,
             mods: mods, contact: CONTACT };
  }

  // Какие части можно включать: буквы (в пробный период — все)
  function mask() { var st = status(); return st.ok ? st.mask : (trialLeft() > 0 ? MOD_ALL : ''); }

  function activate(key) {
    var r = checkKey(key);
    if (!r.exp) return 'Ключ не подходит: ' + r.why + '.';
    if (r.exp < today()) return 'Срок этого ключа уже закончился (' + ruOf(r.exp) + ').';
    regSet('License', 'Key', String(key).trim());
    mKey = null;
    return 'ok|Ключ принят. Программа работает до ' + ruOf(r.exp) + ' включительно.';
  }

  // подпись списка обновления (тот же ключ; текст — в UTF-8, подпись — base64url, 64 байта)
  function verifyText(text, sigB64) {
    try {
      var sig = Buffer.from(String(sigB64).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
      if (sig.length != 64) return false;
      return crypto.verify('sha256', Buffer.from(text, 'utf8'), { key: pub, dsaEncoding: 'ieee-p1363' }, sig);
    } catch (e) { return false; }
  }

  return { json: json, mask: mask, activate: activate, machineCode: machineCode, checkKey: checkKey, regGet: regGet, regSet: regSet, verifyText: verifyText };
})();
if (typeof module !== 'undefined' && typeof window === 'undefined') module.exports = AiLic;
