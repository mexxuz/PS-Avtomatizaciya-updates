// Склейка PDF листов в один файл — для вывода «одним PDF» из Illustrator (там каждый лист сохраняется
// отдельно: все листы заказа на холст не помещаются). Без сторонних программ: читает таблицы объектов
// (обычные и сжатые), переносит страницы со всем, на что они ссылаются, и пишет новый файл.
var PdfJoin = (function () {
  var fs = require('fs'), zlib = require('zlib');

  function Pdf(path) {
    this.s = fs.readFileSync(path).toString('latin1');
    this.xref = {};          // номер -> { off } или { stm, idx }
    this.trailer = '';
    this.cache = {};
    this.readXref();
  }

  // ---- значения в словаре: кусок текста после ключа ----
  function skipWs(s, i) { while (i < s.length && /[\s\0]/.test(s.charAt(i))) i++; return i; }
  function valueEnd(s, i) {
    i = skipWs(s, i);
    var c = s.charAt(i), d;
    if (s.substr(i, 2) == '<<') {
      d = 0;
      while (i < s.length) {
        if (s.substr(i, 2) == '<<') { d++; i += 2; } else if (s.substr(i, 2) == '>>') { d--; i += 2; if (!d) return i; }
        else if (s.charAt(i) == '(') i = strEnd(s, i); else i++;
      }
      return i;
    }
    if (c == '[') {
      d = 0;
      while (i < s.length) {
        var ch = s.charAt(i);
        if (ch == '[') d++; else if (ch == ']') { d--; if (!d) return i + 1; } else if (ch == '(') { i = strEnd(s, i); continue; }
        i++;
      }
      return i;
    }
    if (c == '(') return strEnd(s, i);
    if (c == '<') return s.indexOf('>', i) + 1;
    var m = /^(\d+\s+\d+\s+R)|^(\/[^\s\/\[\]<>()]*)|^([^\s\/\[\]<>()]+)/.exec(s.substr(i, 64));
    return i + (m ? m[0].length : 1);
  }
  function strEnd(s, i) {
    var d = 0;
    for (; i < s.length; i++) {
      var c = s.charAt(i);
      if (c == '\\') { i++; continue; }
      if (c == '(') d++; else if (c == ')') { d--; if (!d) return i + 1; }
    }
    return i;
  }
  // значение ключа key на верхнем уровне словаря dict (текст) или null
  function dictGet(dict, key) {
    var i = dict.indexOf('<<');
    if (i < 0) return null;
    i += 2;
    while (i < dict.length) {
      i = skipWs(dict, i);
      if (dict.substr(i, 2) == '>>') return null;
      if (dict.charAt(i) != '/') { i++; continue; }
      var m = /^\/[^\s\/\[\]<>()]*/.exec(dict.substr(i, 128)), k = m[0];
      i += k.length;
      var st = skipWs(dict, i), en = valueEnd(dict, st);
      if (k == key) return dict.substring(st, en);
      i = en;
    }
    return null;
  }
  function refNum(v) { var m = /^(\d+)\s+\d+\s+R/.exec(v || ''); return m ? +m[1] : 0; }
  function num(v) { return v == null ? 0 : parseFloat(v); }

  // ---- поток: данные и распаковка ----
  Pdf.prototype.streamOf = function (body) {
    var k = body.indexOf('stream', body.lastIndexOf('>>') - 1);
    var d = body.substring(0, k), st = k + 6;
    if (body.charAt(st) == '\r') st++;
    if (body.charAt(st) == '\n') st++;
    var lenV = dictGet(d, '/Length'), len = refNum(lenV) ? num(this.obj(refNum(lenV))) : num(lenV);
    var raw = body.substr(st, len);
    var filt = dictGet(d, '/Filter') || '';
    var data = Buffer.from(raw, 'latin1');
    if (/FlateDecode/.test(filt)) data = zlib.inflateSync(data);
    var parms = dictGet(d, '/DecodeParms');
    if (parms && /\/Predictor\s+1[0-5]/.test(parms)) data = unpredict(data, num(dictGet(parms, '/Columns')) || 1);
    return data;
  };
  function unpredict(b, cols) {
    var rows = Math.floor(b.length / (cols + 1)), out = Buffer.alloc(rows * cols), prev = Buffer.alloc(cols);
    for (var r = 0; r < rows; r++) {
      var t = b[r * (cols + 1)], row = b.subarray(r * (cols + 1) + 1, (r + 1) * (cols + 1)), cur = Buffer.alloc(cols);
      for (var i = 0; i < cols; i++) {
        var a = i ? cur[i - 1] : 0, up = prev[i], c = i ? prev[i - 1] : 0, x = row[i];
        if (t == 1) x += a; else if (t == 2) x += up; else if (t == 3) x += (a + up) >> 1;
        else if (t == 4) { var p = a + up - c, pa = Math.abs(p - a), pb = Math.abs(p - up), pc = Math.abs(p - c); x += (pa <= pb && pa <= pc) ? a : (pb <= pc ? up : c); }
        cur[i] = x & 255;
      }
      cur.copy(out, r * cols); prev = cur;
    }
    return out;
  }

  // ---- таблица объектов ----
  Pdf.prototype.readXref = function () {
    var s = this.s, k = s.lastIndexOf('startxref'), off = parseInt(s.substr(k + 9, 30).trim(), 10), seen = {};
    while (off && !seen[off]) {
      seen[off] = 1;
      var at = skipWs(s, off), prev = null;
      if (s.substr(at, 4) == 'xref') {
        var i = at + 4;
        for (;;) {
          i = skipWs(s, i);
          if (s.substr(i, 7) == 'trailer') break;
          var m = /^(\d+)\s+(\d+)/.exec(s.substr(i, 40));
          if (!m) break;
          i += m[0].length;
          var first = +m[1], cnt = +m[2];
          i = skipWs(s, i);
          for (var j = 0; j < cnt; j++) {
            var e = s.substr(i, 20), mm = /^(\d{10}) (\d{5}) ([nf])/.exec(e);
            if (mm && mm[3] == 'n' && !this.xref[first + j]) this.xref[first + j] = { off: +mm[1] };
            i += 20;
          }
        }
        var ti = s.indexOf('<<', i), tr = s.substring(ti, valueEnd(s, ti));
        if (!this.trailer) this.trailer = tr;
        prev = dictGet(tr, '/Prev');
        var xs = dictGet(tr, '/XRefStm');
        if (xs) this.readXrefStream(+xs);
      } else {
        prev = this.readXrefStream(at);
      }
      off = prev ? +prev : 0;
    }
  };
  Pdf.prototype.readXrefStream = function (at) {
    var body = this.rawAt(at), d = body.substring(0, body.indexOf('stream'));
    if (!this.trailer) this.trailer = d.substring(d.indexOf('<<'));
    var w = dictGet(d, '/W').replace(/[\[\]]/g, '').trim().split(/\s+/).map(Number);
    var idx = dictGet(d, '/Index'), size = num(dictGet(d, '/Size'));
    var ranges = idx ? idx.replace(/[\[\]]/g, '').trim().split(/\s+/).map(Number) : [0, size];
    var data = this.streamOf(body), p = 0;
    function rd(n, dflt) { if (!n) return dflt; var v = 0; for (var q = 0; q < n; q++) v = v * 256 + data[p++]; return v; }
    for (var r = 0; r < ranges.length; r += 2)
      for (var j = 0; j < ranges[r + 1]; j++) {
        var t = rd(w[0], 1), f2 = rd(w[1], 0), f3 = rd(w[2], 0), n = ranges[r] + j;
        if (this.xref[n]) continue;
        if (t == 1) this.xref[n] = { off: f2 }; else if (t == 2) this.xref[n] = { stm: f2, idx: f3 };
      }
    return dictGet(d, '/Prev');
  };

  // текст объекта от «N G obj» до «endobj» (без них)
  Pdf.prototype.rawAt = function (off) {
    var s = this.s, m = /^\s*\d+\s+\d+\s+obj/.exec(s.substr(off, 40)), st = off + m[0].length;
    var dEnd = valueEnd(s, st), after = skipWs(s, dEnd);
    if (s.substr(after, 6) == 'stream') {
      var d = s.substring(st, dEnd), lenV = dictGet(d, '/Length');
      var len = refNum(lenV) ? num(this.obj(refNum(lenV))) : num(lenV);
      var ds = after + 6;
      if (s.charAt(ds) == '\r') ds++;
      if (s.charAt(ds) == '\n') ds++;
      var es = s.indexOf('endstream', ds + len);
      if (es < 0 || es - (ds + len) > 4) es = s.indexOf('endstream', ds);
      return s.substring(st, es + 9);
    }
    return s.substring(st, dEnd);
  };

  // объект по номеру: текст (для сжатых в потоке объектов — без потока)
  Pdf.prototype.obj = function (n) {
    if (this.cache[n] != null) return this.cache[n];
    var e = this.xref[n], v = 'null';
    if (e && e.off != null) v = this.rawAt(e.off);
    else if (e && e.stm != null) {
      var sb = this.rawAt(this.xref[e.stm].off), sd = sb.substring(0, sb.indexOf('stream'));
      var data = this.streamOf(sb).toString('latin1'), N = num(dictGet(sd, '/N')), first = num(dictGet(sd, '/First'));
      var head = data.substring(0, first).trim().split(/\s+/).map(Number);
      for (var i = 0; i < N; i++) {
        var on = head[i * 2], oo = head[i * 2 + 1], end = i + 1 < N ? head[i * 2 + 3] : data.length - first;
        if (this.cache[on] == null) this.cache[on] = data.substring(first + oo, first + end).trim();
      }
      v = this.cache[n] != null ? this.cache[n] : 'null';
    }
    this.cache[n] = v;
    return v;
  };

  // страницы по порядку: [{ n, inherit: {ключ: значение} }]
  Pdf.prototype.pages = function () {
    var root = refNum(dictGet(this.trailer, '/Root')), cat = this.obj(root), out = [], self = this;
    var INH = ['/Resources', '/MediaBox', '/CropBox', '/Rotate'];
    function walk(n, inh, depth) {
      if (depth > 50) return;
      var o = self.obj(n), type = (dictGet(o, '/Type') || '').trim(), my = {};
      for (var k in inh) my[k] = inh[k];
      for (var i = 0; i < INH.length; i++) { var v = dictGet(o, INH[i]); if (v != null) my[INH[i]] = v; }
      if (type == '/Pages') {
        var kids = (dictGet(o, '/Kids') || '').match(/\d+\s+\d+\s+R/g) || [];
        for (i = 0; i < kids.length; i++) walk(refNum(kids[i]), my, depth + 1);
      } else out.push({ n: n, inherit: my });
    }
    walk(refNum(dictGet(cat, '/Pages')), {}, 0);
    return out;
  };

  // ---- склейка ----
  // Листы тиража почти одинаковы: фото, рисунок, шрифты в каждом файле те же, меняются только номера.
  // Одинаковые объекты (после перенумерации — тот же текст) пишутся один раз: файл в разы меньше.
  function join(files, outPath) {
    var crypto = require('crypto'), objs = [], kids = [], next = 3, seen = {};     // 1 — каталог, 2 — дерево страниц
    for (var f = 0; f < files.length; f++) {
      var pdf = new Pdf(files[f]), map = {}, state = {}, pages = pdf.pages(), pageSet = {}, i;
      for (i = 0; i < pages.length; i++) pageSet[pages[i].n] = pages[i];
      // номер нужен раньше, чем объект собран (ссылка по кругу: страница ↔ её родитель) — такой объект не объединяется
      var pin = function (n) { if (!map[n]) map[n] = next++; return map[n]; };
      var build = function (n) {
        if (state[n] == 2) return map[n];
        if (state[n] == 1) return pin(n);
        state[n] = 1;
        var body = pdf.obj(n);
        var isStream = /^\s*<</.test(body) && /\bstream\r?\n/.test(body) && /endstream$/.test(body);
        var head = isStream ? body.substring(0, body.search(/stream\r?\n/)) : body, tail = isStream ? body.substring(head.length) : '';
        if (pageSet[n]) {
          // родитель — новое дерево страниц; унаследованное — прямо в страницу
          // метка вместо ссылки: иначе ниже перенумерация ссылок приняла бы «2 0 R» за объект исходного файла
          head = head.replace(/\/Parent\s+\d+\s+\d+\s+R/, '/Parent \u0001PAGES');
          var inh = pageSet[n].inherit, add = '';
          for (var key in inh) if (dictGet(head, key) == null) add += key + ' ' + inh[key] + ' ';
          if (add) head = head.replace(/>>\s*$/, add + '>>');
        }
        // описание файла (XMP) в каждом листе своё — в склеенном не нужно
        head = head.replace(/\/Metadata\s+\d+\s+\d+\s+R/, '');
        head = head.replace(/(\d+)\s+(\d+)\s+R\b/g, function (m0, a) { return pdf.xref[+a] ? build(+a) + ' 0 R' : 'null'; });
        var text = head.replace('\u0001PAGES', '2 0 R') + tail;
        if (!map[n] && !pageSet[n]) {
          var h = crypto.createHash('sha1').update(text, 'latin1').digest('hex');
          if (seen[h]) map[n] = seen[h];
          else { map[n] = next++; seen[h] = map[n]; objs.push({ id: map[n], text: text }); }
        } else {
          if (!map[n]) map[n] = next++;
          objs.push({ id: map[n], text: text });
        }
        state[n] = 2;
        return map[n];
      };
      for (i = 0; i < pages.length; i++) kids.push(build(pages[i].n));
    }
    objs.push({ id: 1, text: '<< /Type /Catalog /Pages 2 0 R >>' });
    objs.push({ id: 2, text: '<< /Type /Pages /Count ' + kids.length + ' /Kids [' + kids.map(function (k) { return k + ' 0 R'; }).join(' ') + '] >>' });
    objs.sort(function (a, b) { return a.id - b.id; });

    var parts = ['%PDF-1.6\n%âãÏÓ\n'], pos = parts[0].length, offs = [];
    for (var j = 0; j < objs.length; j++) {
      var t = objs[j].id + ' 0 obj\n' + objs[j].text + '\nendobj\n';
      offs[objs[j].id] = pos; parts.push(t); pos += t.length;
    }
    var x = 'xref\n0 ' + next + '\n0000000000 65535 f \n';
    for (j = 1; j < next; j++) x += offs[j] != null ? ('000000000' + offs[j]).slice(-10) + ' 00000 n \n' : '0000000000 65535 f \n';
    x += 'trailer\n<< /Size ' + next + ' /Root 1 0 R >>\nstartxref\n' + pos + '\n%%EOF\n';
    parts.push(x);
    fs.writeFileSync(outPath, Buffer.from(parts.join(''), 'latin1'));
    return kids.length;
  }

  return { join: join, Pdf: Pdf };
})();
if (typeof module !== 'undefined' && typeof window === 'undefined') module.exports = PdfJoin;
