// Отчёты о проблемах для Illustrator — как src/Reports.bas: уходят в закрытое хранилище через интернет, чтобы
// разбирать сбои, не дожидаясь, пока человек сам пришлёт файл. Уходит только текст отчёта (что нажимали, что
// ответила программа, версия и код компьютера, имена и пути открытых документов, настройки панели) и, если человек
// разрешил, снимок окна Illustrator. Сами макеты и файлы клиентов не отправляются. Не ушло (нет сети, нет ключа
// доступа) — отчёт остаётся в очереди и уйдёт в другой раз.
// Галочка «Сообщать о сбоях автоматически» (enabled) касается только отчётов о сбоях: то, что человек отправил сам
// (сообщение, отчёт по кнопке), уходит всегда.
// Очередь и настройки — те же, что у CorelDRAW (папка во временной, реестр VarPrint\Reports).
var AiRep = (function () {
  var fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process'), https = require('https');
  var REPO = 'mexxuz/PS-Avtomatizaciya-reports', SEED = 137, MAX_QUEUE = 20;
  // не ушло — фоновые попытки замолкают на 10 минут (как в CorelDRAW); отправка по кнопке пробует сразу
  var RETRY_MS = 600000, lastFail = 0, busy = false;
  // ключ доступа подставляет сборка (illustrator/tools/make_panel.js) перемешанным — строкой он лежать не должен
  var DEF_TOKEN = 'EEE3FFE4F8ECD0E0F0E6CCA5A4D4DFDBCACDD9C5ADD0A7E9C2D5D0E9CEF1CFFECBF5FAC2C6EAE7E1C9D1DEC0E7F8E680DAD0D6C58ED6F8F1A684A295F7AA90B0A5A6A89DFDA2AD9BA6B591BD90818F9A9680E888E8959E8B9BB8A8B197';

  // реестр читается внешней программой — не чаще раза в 10 с (панель спрашивает состояние часто)
  var cache = {};
  function setting(k, dv) {
    var c = cache[k], now = Date.now();
    if (!c || now - c.t > 10000) c = cache[k] = { v: AiLic.regGet('Reports', k), t: now };
    return c.v === '' ? dv : c.v;
  }
  function enabled() { return setting('Auto', '1') == '1'; }
  function unmix(s) {
    var out = '';
    for (var i = 0; i + 1 < s.length; i += 2) out += String.fromCharCode(parseInt(s.substr(i, 2), 16) ^ ((SEED + i / 2) % 256));
    return out;
  }
  function token() { return setting('Token', '') || unmix(DEF_TOKEN); }
  function repo() { return setting('Repo', REPO); }
  function clean(s) { s = String(s).replace(/[^0-9A-Za-z_-]/g, ''); return s || 'no-code'; }
  // метка для имени файла: секунды и тысячные — два сбоя в одну секунду не затирают друг друга (и в очереди,
  // и в хранилище, где файл с тем же именем уже не положить); совпало — номер сверху
  function stamp() {
    var d = new Date(), p = function (n) { return ('0' + n).slice(-2); };
    var s = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds()) + '-' + ('00' + d.getMilliseconds()).slice(-3);
    var t = s, n = 0, fl = [];
    try { fl = fs.readdirSync(queueDir()).concat(fs.readdirSync(tmpDir())); } catch (e) { }
    while (n < 50 && fl.some(function (f) { return f.indexOf(t + '_') == 0; })) t = s + '-' + (++n);
    return t;
  }
  function ruNow() { var d = new Date(), p = function (n) { return ('0' + n).slice(-2); }; return p(d.getDate()) + '.' + p(d.getMonth() + 1) + '.' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()); }
  function queueDir() { var d = path.join(os.tmpdir(), 'PS-Avtomatizaciya-reports'); if (!fs.existsSync(d)) fs.mkdirSync(d); return d; }
  function tmpDir() { var d = path.join(queueDir(), 'tmp'); if (!fs.existsSync(d)) fs.mkdirSync(d); return d; }
  var dataDir = path.join(process.env.APPDATA || '', 'PS Automation');

  // ---------- очередь ----------
  function queue(text, reason) {
    try {
      fs.writeFileSync(path.join(queueDir(), stamp() + '_' + clean(reason) + '.txt'), text, 'utf8');
      var fl = fs.readdirSync(queueDir()).filter(function (n) { return /\.txt$/i.test(n); }).sort();
      while (fl.length > MAX_QUEUE) fs.unlinkSync(path.join(queueDir(), fl.shift()));
    } catch (e) { }
  }
  // patient = false (фоном) — сеть ждём недолго
  function put(name, b64, what, patient) {
    return new Promise(function (ok) {
      var who = clean(AiLic.machineCode()), body = JSON.stringify({ message: what + ' ' + who + ' ' + ruNow(), content: b64 });
      try {
        var rq = https.request({ host: 'api.github.com', method: 'PUT', path: '/repos/' + repo() + '/contents/reports/' + encodeURIComponent(who) + '/' + encodeURIComponent(name),
          headers: { 'Authorization': 'Bearer ' + token(), 'Accept': 'application/vnd.github+json', 'User-Agent': 'PS-Avtomatizaciya', 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
          timeout: patient === false ? 8000 : 30000 }, function (rs) {
            var t = ''; rs.on('data', function (c) { t += c; });
            rs.on('end', function () { if (rs.statusCode != 200 && rs.statusCode != 201) logLine('отчёт не ушёл: ответ ' + rs.statusCode + ' — ' + t.substring(0, 200)); ok(rs.statusCode == 200 || rs.statusCode == 201); });
          });
        rq.on('error', function () { ok(false); });
        rq.on('timeout', function () { rq.destroy(); ok(false); });
        rq.end(body);
      } catch (e) { ok(false); }
    });
  }
  // отправить всё, что скопилось; ответ — сколько ушло.
  // now = true — человек сам нажал «Отправить»: пробуем сразу. Иначе (фоном) — после неудачи молчим 10 минут.
  // Отчёты о сбоях при снятой галочке остаются лежать; сообщения и отчёты по кнопке уходят всегда.
  async function flush(now) {
    if (!token()) return 0;
    if (!now && (busy || (lastFail && Date.now() - lastFail < RETRY_MS))) return 0;
    // по кнопке, а фоновая отправка ещё идёт — дождаться её, иначе один файл уйдёт дважды
    for (var w = 0; busy && w < 160; w++) await new Promise(function (r) { setTimeout(r, 250); });
    var sent = 0, fl = [], auto = enabled();
    busy = true;
    try {
      try { fl = fs.readdirSync(queueDir()).filter(function (n) { return /\.txt$/i.test(n) && (auto || !/_crash\.txt$/i.test(n)); }).sort(); } catch (e) { }
      for (var i = 0; i < fl.length; i++) {
        var p = path.join(queueDir(), fl[i]), t = '';
        try { t = fs.readFileSync(p, 'utf8'); } catch (e) { }
        if (!t) { try { fs.unlinkSync(p); } catch (e) { } continue; }
        // сеть недоступна — в другой раз
        if (!(await put(fl[i], Buffer.from(t, 'utf8').toString('base64'), 'report', !!now))) { lastFail = Date.now(); break; }
        lastFail = 0;
        try { fs.unlinkSync(p); } catch (e) { }
        sent++;
      }
    } finally { busy = false; }
    if (sent) logLine('отчётов отправлено: ' + sent);
    return sent;
  }
  function logLine(t) { try { fs.appendFileSync(path.join(dataDir, 'illustrator.log'), (function () { var d = new Date(), z = function (n) { return (n < 10 ? '0' : '') + n; }; return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + ' ' + z(d.getHours()) + ':' + z(d.getMinutes()) + ':' + z(d.getSeconds()); })() + '  ' + t + '\r\n', 'utf8'); } catch (e) { } }

  // ---------- снимок окна Illustrator ----------
  function shot() {
    var png = path.join(tmpDir(), stamp() + '_snimok.png'), ps = path.join(tmpDir(), 'shot.ps1');
    var s = 'Add-Type -AssemblyName System.Drawing\r\n' +
      'Add-Type @\'\r\nusing System; using System.Runtime.InteropServices;\r\n' +
      'public class ShotW { [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);\r\n' +
      ' [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r); public struct RECT { public int L, T, R, B; } }\r\n\'@\r\n' +
      '$p = Get-Process Illustrator -ErrorAction SilentlyContinue | Select-Object -First 1; if (-not $p) { exit }\r\n' +
      '$h = $p.MainWindowHandle; if ($h -eq [IntPtr]::Zero) { exit }\r\n' +
      '$r = New-Object ShotW+RECT; [void][ShotW]::GetWindowRect($h, [ref]$r)\r\n' +
      '$w = $r.R - $r.L; $hh = $r.B - $r.T; if ($w -lt 50 -or $hh -lt 50) { exit }\r\n' +
      '$bmp = New-Object Drawing.Bitmap $w, $hh; $g = [Drawing.Graphics]::FromImage($bmp); $dc = $g.GetHdc()\r\n' +
      '[void][ShotW]::PrintWindow($h, $dc, 2); $g.ReleaseHdc($dc); $g.Dispose()\r\n' +
      'if ($w -gt 1600) { $k = 1600 / $w; $n = New-Object Drawing.Bitmap ([int]($w * $k)), ([int]($hh * $k)); $g2 = [Drawing.Graphics]::FromImage($n); $g2.DrawImage($bmp, 0, 0, $n.Width, $n.Height); $g2.Dispose(); $bmp.Dispose(); $bmp = $n }\r\n' +
      '$bmp.Save(\'' + png.replace(/'/g, "''") + '\', [Drawing.Imaging.ImageFormat]::Png)\r\n';
    try {
      fs.writeFileSync(ps, '﻿' + s, 'utf8');
      cp.execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ps], { windowsHide: true, timeout: 30000 });
    } catch (e) { }
    return fs.existsSync(png) ? png : '';
  }

  // ---------- текст отчёта ----------
  function desktop() {
    try { return String(cp.execFileSync('powershell.exe', ['-NoProfile', '-Command', '[Environment]::GetFolderPath("Desktop")'], { windowsHide: true, encoding: 'utf8' })).trim(); }
    catch (e) { return path.join(os.homedir(), 'Desktop'); }
  }
  function tail(p, n) { try { var a = fs.readFileSync(p, 'utf8').split(/\r?\n/); return a.slice(Math.max(0, a.length - n)).join('\r\n'); } catch (e) { return ''; } }
  function version() {
    try { var m = /ExtensionBundleVersion="([^"]+)"/.exec(fs.readFileSync(path.join(window.__adobe_cep__.getSystemPath('extension').replace(/^file:\/*/, '').replace(/%20/g, ' '), 'CSXS', 'manifest.xml'), 'utf8')); return m ? m[1] : ''; } catch (e) { return ''; }
  }
  // hostInfo — сведения от Illustrator (документы, области, слои), state — состояние панели
  function report(hostInfo, state) {
    var t = 'PS • Автоматизация для Illustrator — отчёт о проблеме\r\nВремя: ' + ruNow() + '\r\n' +
      'Компьютер: ' + (process.env.COMPUTERNAME || '') + ', пользователь ' + (process.env.USERNAME || '') + '\r\n' +
      'Панель: версия ' + version() + '\r\n' + (hostInfo || '') + '\r\n' +
      'Лицензия: ' + JSON.stringify(AiLic.json()) + '\r\n\r\n' +
      '--- Состояние панели ---\r\n' + String(state || '').substring(0, 6000) + '\r\n\r\n' +
      '--- Журнал (последние 200 строк) ---\r\n' + tail(path.join(dataDir, 'illustrator.log'), 200) + '\r\n';
    var setup = path.join(os.tmpdir(), 'PS-Avtomatizaciya-setup.log');
    if (fs.existsSync(setup)) { try { t += '\r\n--- Установка ---\r\n' + fs.readFileSync(setup, 'utf8').slice(-4000) + '\r\n'; } catch (e) { } }
    return t;
  }
  // на рабочий стол (PS-отчёт.txt) — только по кнопке «Скопировать отчёт»; сбои и сообщения на стол не пишут
  function save(t) {
    try { fs.writeFileSync(path.join(desktop(), 'PS-отчёт.txt'), t, 'utf8'); } catch (e) { }
    return t;
  }

  async function send(text) {
    queue(save(text), 'manual');
    var n = await flush(true);
    return n > 0 ? 'Отчёт отправлен разработчику. Копия сохранена на рабочем столе: PS-отчёт.txt.'
                 : 'Отправить не удалось — отчёт сохранён и уйдёт, когда появится связь. Копия на рабочем столе: PS-отчёт.txt.';
  }
  // фото к сообщению: ужатая копия (до 2000 px, JPEG) во временной папке; src пусто — из буфера обмена
  function photo(src) {
    var dst = path.join(tmpDir(), stamp() + '_' + Math.floor(Math.random() * 10000) + '_foto'), ps = path.join(tmpDir(), 'photo.ps1');
    var q = function (t) { return String(t).replace(/'/g, "''"); };
    var s = 'Add-Type -AssemblyName System.Drawing\r\n' +
      '$src = ' + "'" + q(src) + "'; $dst = '" + q(dst) + "'; $img = $null\r\n" +
      "if ($src -eq '') { Add-Type -AssemblyName System.Windows.Forms\r\n" +
      '  if ([Windows.Forms.Clipboard]::ContainsImage()) { $img = [Windows.Forms.Clipboard]::GetImage() }\r\n' +
      '  elseif ([Windows.Forms.Clipboard]::ContainsFileDropList()) { $src = [Windows.Forms.Clipboard]::GetFileDropList()[0] } }\r\n' +
      'if (-not $img -and $src) { try { $img = [Drawing.Image]::FromFile($src) } catch { } }\r\n' +
      'if (-not $img) { exit }\r\n' +
      "try { switch ([int]$img.GetPropertyItem(274).Value[0]) { 3 { $img.RotateFlip('Rotate180FlipNone') } 6 { $img.RotateFlip('Rotate90FlipNone') } 8 { $img.RotateFlip('Rotate270FlipNone') } } } catch { }\r\n" +
      '$k = [Math]::Min(1.0, 2000.0 / [Math]::Max($img.Width, $img.Height)); $w = [Math]::Max(1, [int]($img.Width * $k)); $h = [Math]::Max(1, [int]($img.Height * $k))\r\n' +
      "$bmp = New-Object Drawing.Bitmap $w, $h; $g = [Drawing.Graphics]::FromImage($bmp); $g.Clear([Drawing.Color]::White); $g.InterpolationMode = 'HighQualityBicubic'; $g.DrawImage($img, 0, 0, $w, $h); $g.Dispose()\r\n" +
      "$enc = [Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' }\r\n" +
      '$ep = New-Object Drawing.Imaging.EncoderParameters 1; $ep.Param[0] = New-Object Drawing.Imaging.EncoderParameter ([Drawing.Imaging.Encoder]::Quality), 88L\r\n' +
      "$bmp.Save($dst + '.jpg', $enc, $ep)\r\n";
    try {
      fs.writeFileSync(ps, '﻿' + s, 'utf8');
      cp.execFileSync('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', ps], { windowsHide: true, timeout: 60000 });
    } catch (e) { }
    return fs.existsSync(dst + '.jpg') ? dst + '.jpg' : '';
  }
  // сообщение о проблеме от человека: его слова, фото, отчёт и снимок окна Illustrator.
  // Фото и снимок уходят раньше текста: по тексту хранилище шлёт уведомление и ищет файлы рядом
  async function problem(words, withShot, rep, photos) {
    if (!String(words).replace(/\s/g, '')) return 'Напишите одной строкой, что не так — иначе непонятно, что смотреть.';
    var png = withShot == '1' ? shot() : '', st = stamp(), sent = [], i, a = String(photos || '').split('|');
    var up = async function (file, nm) {
      if (!token()) return false;
      var ok = false;
      try { ok = await put(nm, fs.readFileSync(file).toString('base64'), 'shot'); } catch (e) { }
      if (ok) try { fs.unlinkSync(file); } catch (e) { }
      return ok;
    };
    for (i = 0; i < a.length; i++) if (a[i] && fs.existsSync(a[i]) && await up(a[i], st + '_foto' + (i + 1) + '.jpg')) sent.push(st + '_foto' + (i + 1) + '.jpg');
    var shotName = png ? path.basename(png) : '';
    if (png) await up(png, shotName);
    var body = 'PS • Автоматизация для Illustrator — сообщение о проблеме\r\nВремя: ' + ruNow() + '\r\n\r\n--- Что пишет человек ---\r\n' + words + '\r\n\r\n' +
               (sent.length ? 'Фото рядом: ' + sent.join(', ') + '\r\n' : '') + (png ? 'Снимок окна рядом: ' + shotName + '\r\n' : '') + '\r\n' + rep;
    queue(body, 'message');
    if (await flush(true) > 0) return 'Отправлено разработчику' + (sent.length ? ' с фото' : '') + (png ? ' и снимком окна' : (withShot == '1' ? ' (снимок окна не получился — окно Illustrator было не видно)' : '')) + '. Спасибо — разберусь и отвечу.';
    return 'Пока не уходит (нет связи или не настроена отправка). Сообщение сохранено и уйдёт само, когда связь появится.';
  }
  function auto(v) { if (v === '0' || v === '1') { AiLic.regSet('Reports', 'Auto', v); delete cache.Auto; } return setting('Auto', '1'); }

  // Сбой в Illustrator: программа отмечает его в файле crash.flag — отчёт о нём уходит сам (если разрешено)
  var crashFlag = path.join(dataDir, 'crash.flag');
  function crashPending() { try { return fs.existsSync(crashFlag); } catch (e) { return false; } }
  function crashTaken() { try { fs.unlinkSync(crashFlag); } catch (e) { } }

  return { report: report, save: save, send: send, problem: problem, photo: photo, auto: auto, flush: flush, queue: queue, enabled: enabled, crashPending: crashPending, crashTaken: crashTaken };
})();
